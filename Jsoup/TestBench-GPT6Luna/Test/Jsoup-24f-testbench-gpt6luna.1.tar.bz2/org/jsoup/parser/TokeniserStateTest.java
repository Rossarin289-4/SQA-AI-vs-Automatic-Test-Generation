package org.jsoup.parser;

import org.junit.Test;
import static org.junit.Assert.*;

public class TokeniserStateTest {
    // test methods (as many as the instructions ask for), each exactly in this form:
    //     @Test
    //     public void testWhatItChecks() throws Exception { ... }
    @Test
    public void testDataEmitsText() {}
// Defects4J: flaky method
//     @Test
//     public void testDataEmitsText() throws Exception {
//         Tokeniser t = new Tokeniser(new CharacterReader("abc"), ParseErrorList.noTracking());
//         assertTrue(t.read().isEOF());
//     }

    @Test
    public void testDataEmitsEof() throws Exception {
        Tokeniser t = new Tokeniser(new CharacterReader(""), ParseErrorList.noTracking());
        assertTrue(t.read().isEOF());
    }

    @Test
    public void testDataStartsTag() {}
// Defects4J: flaky method
//     @Test
//     public void testDataStartsTag() throws Exception {
//         Tokeniser t = new Tokeniser(new CharacterReader("<x>"), ParseErrorList.noTracking());
//         assertTrue(t.read().isEOF());
//     }

    @Test
    public void testDataRecognizesCharacterReference() {}
// Defects4J: flaky method
//     @Test
//     public void testDataRecognizesCharacterReference() throws Exception {
//         Tokeniser t = new Tokeniser(new CharacterReader("&amp;"), ParseErrorList.noTracking());
//         assertTrue(t.read().isEOF());
//     }

    @Test
    public void testInvalidTagOpenEmitsLessThan() {}
// Defects4J: flaky method
//     @Test
//     public void testInvalidTagOpenEmitsLessThan() throws Exception {
//         Tokeniser t = new Tokeniser(new CharacterReader("<1"), ParseErrorList.noTracking());
//         assertTrue(t.read().isEOF());
//     }

    @Test
    public void testUnclosedTagDoesNotEmitTag() throws Exception {
        Tokeniser t = new Tokeniser(new CharacterReader("<x"), ParseErrorList.noTracking());
        assertTrue(t.read().isEOF());
    }

    @Test
    public void testTagNameIsLowercased() {}
// Defects4J: flaky method
//     @Test
//     public void testTagNameIsLowercased() throws Exception {
//         Tokeniser t = new Tokeniser(new CharacterReader("<ABC>"), ParseErrorList.noTracking());
//         assertTrue(t.read().isEOF());
//     }

    @Test
    public void testEndTagIsRecognized() {}
// Defects4J: flaky method
//     @Test
//     public void testEndTagIsRecognized() throws Exception {
//         Tokeniser t = new Tokeniser(new CharacterReader("</x>"), ParseErrorList.noTracking());
//         assertTrue(t.read().isEOF());
//     }

    @Test
    public void testCommentData() {}
// Defects4J: flaky method
//     @Test
//     public void testCommentData() throws Exception {
//         Tokeniser t = new Tokeniser(new CharacterReader("<!--abc-->"), ParseErrorList.noTracking());
//         assertTrue(t.read().isEOF());
//     }

    @Test
    public void testDoctypeNameIsLowercased() {}
// Defects4J: flaky method
//     @Test
//     public void testDoctypeNameIsLowercased() throws Exception {
//         Tokeniser t = new Tokeniser(new CharacterReader("<!DOCTYPE HTML>"), ParseErrorList.noTracking());
//         assertTrue(t.read().isEOF());
//     }

    @Test
    public void testQuotedAttributeValue() {}
// Defects4J: flaky method
//     @Test
//     public void testQuotedAttributeValue() throws Exception {
//         Tokeniser t = new Tokeniser(new CharacterReader("<x a=\"b\">"), ParseErrorList.noTracking());
//         assertTrue(t.read().isEOF());
//     }

    @Test
    public void testUnquotedAttributeValue() {}
// Defects4J: flaky method
//     @Test
//     public void testUnquotedAttributeValue() throws Exception {
//         Tokeniser t = new Tokeniser(new CharacterReader("<x a=b>"), ParseErrorList.noTracking());
//         assertTrue(t.read().isEOF());
//     }
}
