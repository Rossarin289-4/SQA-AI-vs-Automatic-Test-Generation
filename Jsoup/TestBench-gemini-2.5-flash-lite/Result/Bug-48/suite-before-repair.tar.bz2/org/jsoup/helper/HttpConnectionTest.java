package org.jsoup.helper;

import org.junit.Test;
import static org.junit.Assert.*;
import org.jsoup.Connection;
import org.jsoup.HttpStatusException;
import org.jsoup.UnsupportedMimeTypeException;
import org.jsoup.nodes.Document;
import org.jsoup.parser.Parser;
import org.jsoup.parser.TokenQueue;
import javax.net.ssl.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.IllegalCharsetNameException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.*;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;

public class HttpConnectionTest {

    // Helper method to create a dummy URL for testing
    private URL createDummyUrl(String urlString) throws MalformedURLException {
        return new URL("http://example.com/" + urlString);
    }

    // Test for the static connect(String url) method
    @Test
    public void testStaticConnectWithStringUrl() throws Exception {
        Connection con = HttpConnection.connect("http://example.com");
        assertNotNull(con);
        assertEquals("http://example.com", con.request().url().toExternalForm());
    }

    // Test for the static connect(URL url) method
    @Test
    public void testStaticConnectWithUrlObject() throws Exception {
        URL url = new URL("http://example.com");
        Connection con = HttpConnection.connect(url);
        assertNotNull(con);
        assertEquals(url, con.request().url());
    }

    // Test the url(String url) method with a valid URL
    @Test
    public void testUrlStringValid() throws Exception {
        Connection con = HttpConnection.connect("http://example.com").url("http://example.com/page");
        assertEquals("http://example.com/page", con.request().url().toExternalForm());
    }

    // Test the url(String url) method with spaces to encode
    @Test
    public void testUrlStringWithSpaces() throws Exception {
        Connection con = HttpConnection.connect("http://example.com").url("http://example.com/page with spaces");
        assertEquals("http://example.com/page%20with%20spaces", con.request().url().toExternalForm());
    }

    // Test the url(URL url) method
    @Test
    public void testUrlObject() throws Exception {
        URL url = new URL("http://example.com/resource");
        Connection con = HttpConnection.connect("http://example.com").url(url);
        assertEquals(url, con.request().url());
    }

    // Test the userAgent(String userAgent) method
    @Test
    public void testUserAgent() throws Exception {
        Connection con = HttpConnection.connect("http://example.com").userAgent("MyAgent/1.0");
        assertEquals("MyAgent/1.0", con.request().header("User-Agent"));
    }

    // Test the timeout(int millis) method
    @Test
    public void testTimeout() throws Exception {
        Connection con = HttpConnection.connect("http://example.com").timeout(5000);
        assertEquals(5000, con.request().timeout());
    }

    // Test the timeout(int millis) method with 0 (infinite)
    @Test
    public void testTimeoutInfinite() throws Exception {
        Connection con = HttpConnection.connect("http://example.com").timeout(0);
        assertEquals(0, con.request().timeout());
    }

    // Test the maxBodySize(int bytes) method
    @Test
    public void testMaxBodySize() throws Exception {
        Connection con = HttpConnection.connect("http://example.com").maxBodySize(2048);
        assertEquals(2048, con.request().maxBodySize());
    }

    // Test the maxBodySize(int bytes) method with 0 (unlimited)
    @Test
    public void testMaxBodySizeUnlimited() throws Exception {
        Connection con = HttpConnection.connect("http://example.com").maxBodySize(0);
        assertEquals(0, con.request().maxBodySize());
    }

    // Test the followRedirects(boolean followRedirects) method
    @Test
    public void testFollowRedirectsTrue() throws Exception {
        Connection con = HttpConnection.connect("http://example.com").followRedirects(true);
        assertTrue(con.request().followRedirects());
    }

    // Test the followRedirects(boolean followRedirects) method
    @Test
    public void testFollowRedirectsFalse() throws Exception {
        Connection con = HttpConnection.connect("http://example.com").followRedirects(false);
        assertFalse(con.request().followRedirects());
    }

    // Test the referrer(String referrer) method
    @Test
    public void testReferrer() throws Exception {
        Connection con = HttpConnection.connect("http://example.com").referrer("http://referrer.com");
        assertEquals("http://referrer.com", con.request().header("Referer"));
    }

    // Test the method(Method method) method
    @Test
    public void testMethodGet() throws Exception {
        Connection con = HttpConnection.connect("http://example.com").method(Connection.Method.GET);
        assertEquals(Connection.Method.GET, con.request().method());
    }

    // Test the method(Method method) method
    @Test
    public void testMethodPost() throws Exception {
        Connection con = HttpConnection.connect("http://example.com").method(Connection.Method.POST);
        assertEquals(Connection.Method.POST, con.request().method());
    }

    // Test the ignoreHttpErrors(boolean ignoreHttpErrors) method
    @Test
    public void testIgnoreHttpErrorsTrue() throws Exception {
        Connection con = HttpConnection.connect("http://example.com").ignoreHttpErrors(true);
        assertTrue(con.request().ignoreHttpErrors());
    }

    // Test the ignoreHttpErrors(boolean ignoreHttpErrors) method
    @Test
    public void testIgnoreHttpErrorsFalse() throws Exception {
        Connection con = HttpConnection.connect("http://example.com").ignoreHttpErrors(false);
        assertFalse(con.request().ignoreHttpErrors());
    }

    // Test the ignoreContentType(boolean ignoreContentType) method
    @Test
    public void testIgnoreContentTypeTrue() throws Exception {
        Connection con = HttpConnection.connect("http://example.com").ignoreContentType(true);
        assertTrue(con.request().ignoreContentType());
    }

    // Test the ignoreContentType(boolean ignoreContentType) method
    @Test
    public void testIgnoreContentTypeFalse() throws Exception {
        Connection con = HttpConnection.connect("http://example.com").ignoreContentType(false);
        assertFalse(con.request().ignoreContentType());
    }

    // Test the validateTLSCertificates(boolean value) method
    @Test
    public void testValidateTLSCertificatesTrue() throws Exception {
        Connection con = HttpConnection.connect("http://example.com").validateTLSCertificates(true);
        assertTrue(con.request().validateTLSCertificates());
    }

    // Test the validateTLSCertificates(boolean value) method
    @Test
    public void testValidateTLSCertificatesFalse() throws Exception {
        Connection con = HttpConnection.connect("http://example.com").validateTLSCertificates(false);
        assertFalse(con.request().validateTLSCertificates());
    }

    // Test the data(String key, String value) method
    @Test
    public void testDataStringString() throws Exception {
        Connection con = HttpConnection.connect("http://example.com").data("key1", "value1");
        assertEquals("value1", con.request().data().stream().filter(kv -> kv.key().equals("key1")).findFirst().get().value());
    }

    // Test the data(Map<String, String> data) method
    @Test
    public void testDataMap() throws Exception {
        Map<String, String> dataMap = new HashMap<>();
        dataMap.put("key2", "value2");
        dataMap.put("key3", "value3");
        Connection con = HttpConnection.connect("http://example.com").data(dataMap);
        assertEquals("value2", con.request().data().stream().filter(kv -> kv.key().equals("key2")).findFirst().get().value());
        assertEquals("value3", con.request().data().stream().filter(kv -> kv.key().equals("key3")).findFirst().get().value());
    }

    // Test the data(String... keyvals) method
    @Test
    public void testDataVarargs() throws Exception {
        Connection con = HttpConnection.connect("http://example.com").data("key4", "value4", "key5", "value5");
        assertEquals("value4", con.request().data().stream().filter(kv -> kv.key().equals("key4")).findFirst().get().value());
        assertEquals("value5", con.request().data().stream().filter(kv -> kv.key().equals("key5")).findFirst().get().value());
    }

    // Test the header(String name, String value) method
    @Test
    public void testHeader() throws Exception {
        Connection con = HttpConnection.connect("http://example.com").header("X-Custom-Header", "CustomValue");
        assertEquals("CustomValue", con.request().header("X-Custom-Header"));
    }

    // Test the header(String name, String value) method for case-insensitivity of header names
    @Test
    public void testHeaderCaseInsensitive() throws Exception {
        Connection con = HttpConnection.connect("http://example.com").header("X-Custom-Header", "CustomValue");
        assertEquals("CustomValue", con.request().header("x-custom-header"));
    }

    // Test the cookie(String name, String value) method
    @Test
    public void testCookie() throws Exception {
        Connection con = HttpConnection.connect("http://example.com").cookie("sessionid", "12345");
        assertEquals("12345", con.request().cookie("sessionid"));
    }

    // Test the cookies(Map<String, String> cookies) method
    @Test
    public void testCookiesMap() throws Exception {
        Map<String, String> cookieMap = new HashMap<>();
        cookieMap.put("userpref", "dark");
        cookieMap.put("lang", "en");
        Connection con = HttpConnection.connect("http://example.com").cookies(cookieMap);
        assertEquals("dark", con.request().cookie("userpref"));
        assertEquals("en", con.request().cookie("lang"));
    }

    // Test the parser(Parser parser) method
    @Test
    public void testParser() throws Exception {
        Parser xmlParser = Parser.xmlParser();
        Connection con = HttpConnection.connect("http://example.com").parser(xmlParser);
        assertEquals(xmlParser, con.request().parser());
    }

    // Test the postDataCharset(String charset) method
    @Test
    public void testPostDataCharset() throws Exception {
        Connection con = HttpConnection.connect("http://example.com").postDataCharset("UTF-16");
        assertEquals("UTF-16", con.request().postDataCharset());
    }

    // Test the hasHeader(String name) method from Connection.Base

    // Test the hasHeaderWithValue(String name, String value) method from Connection.Base

    // Test the removeHeader(String name) method from Connection.Base

    // Test the headers() method from Connection.Base

    // Test the hasCookie(String name) method from Connection.Base

    // Test the removeCookie(String name) method from Connection.Base

    // Test the KeyVal static create(String key, String value) method
    @Test
    public void testKeyValCreateStringString() {
        Connection.KeyVal kv = HttpConnection.KeyVal.create("testkey", "testvalue");
        assertEquals("testkey", kv.key());
        assertEquals("testvalue", kv.value());
        assertFalse(kv.hasInputStream());
    }

    // Test the KeyVal key(String key) method
    @Test
    public void testKeyValKey() {
        Connection.KeyVal kv = HttpConnection.KeyVal.create("key1", "value1").key("newkey");
        assertEquals("newkey", kv.key());
    }

    // Test the KeyVal value(String value) method
    @Test
    public void testKeyValValue() {
        Connection.KeyVal kv = HttpConnection.KeyVal.create("key1", "value1").value("newvalue");
        assertEquals("newvalue", kv.value());
    }

    // Test the KeyVal inputStream(InputStream inputStream) method
    @Test
    public void testKeyValInputStream() throws IOException {
        InputStream dummyStream = new ByteArrayInputStream("test".getBytes());
        Connection.KeyVal kv = HttpConnection.KeyVal.create("key1", "filename.txt", dummyStream).inputStream(dummyStream);
        assertEquals(dummyStream, kv.inputStream());
        assertTrue(kv.hasInputStream());
    }

    // Test the KeyVal toString() method
    @Test
    public void testKeyValToString() {
        Connection.KeyVal kv = HttpConnection.KeyVal.create("testkey", "testvalue");
        assertEquals("testkey=testvalue", kv.toString());
    }

    // Test the Request object's default values

    // Test the Response object's default values after initialization (before execute)
    @Test
    public void testResponseDefaults() {
        HttpConnection.Response res = new HttpConnection.Response();
        assertEquals(0, res.statusCode());
        assertNull(res.statusMessage());
        assertNull(res.charset());
        assertNull(res.contentType());
        // The 'executed' field is private, so we cannot directly test it here.
        // However, the public methods like body() and parse() check for it.
    }

    // Test that validate() method for null object throws IllegalArgumentException
    @Test(expected = IllegalArgumentException.class)
    public void testValidateNotNullNullObject() {
        Validate.notNull(null);
    }

    // Test that validate() method for null object with message throws IllegalArgumentException
    @Test(expected = IllegalArgumentException.class)
    public void testValidateNotNullNullObjectWithMessage() {
        Validate.notNull(null, "Null object test");
    }

    // Test that validate() method for true value passes
    @Test
    public void testValidateIsTrueTrue() {
        Validate.isTrue(true);
        Validate.isTrue(true, "True test");
    }

    // Test that validate() method for false value throws IllegalArgumentException
    @Test(expected = IllegalArgumentException.class)
    public void testValidateIsTrueFalse() {
        Validate.isTrue(false);
    }

    // Test that validate() method for false value with message throws IllegalArgumentException
    @Test(expected = IllegalArgumentException.class)
    public void testValidateIsTrueFalseWithMessage() {
        Validate.isTrue(false, "False test");
    }

    // Test that validate() method for non-empty string passes
    @Test
    public void testValidateNotEmptyString() {
        Validate.notEmpty("some string");
        Validate.notEmpty("another string", "Not empty test");
    }

    // Test that validate() method for empty string throws IllegalArgumentException
    @Test(expected = IllegalArgumentException.class)
    public void testValidateNotEmptyEmptyString() {
        Validate.notEmpty("");
    }

    // Test that validate() method for empty string with message throws IllegalArgumentException
    @Test(expected = IllegalArgumentException.class)
    public void testValidateNotEmptyEmptyStringWithMessage() {
        Validate.notEmpty("", "Empty string test");
    }

    // Test for execute() method with a simple GET request

    // Test for execute() method with a POST request

    // Test for execute() method with redirects

    // Test for execute() method with ignored HTTP errors

    // Test for execute() method with ignored Content-Type errors

    // Test for parse() method

    // Test for body() method

    // Test for bodyAsBytes() method

    // Test for get() method
    @Test
    public void testGet() throws IOException {
        Document doc = HttpConnection.connect("http://httpbin.org/html").get();
        assertNotNull(doc);
        assertEquals("Moby Dick", doc.title());
    }

    // Test for post() method
    @Test
    public void testPost() throws IOException {
        Document doc = HttpConnection.connect("http://httpbin.org/post").post();
        assertNotNull(doc);
        assertTrue(doc.body().html().contains("\"origin\":")); // basic check for response content
    }

    // Test for Request.parser() setter and getter

    // Test for Request.postDataCharset() setter and getter

    // Test for Response.statusCode()
    @Test
    public void testResponseStatusCode() throws IOException {
        Connection.Response res = HttpConnection.connect("http://httpbin.org/html").execute();
        assertEquals(200, res.statusCode());
    }

    // Test for Response.statusMessage()
    @Test
    public void testResponseStatusMessage() throws IOException {
        Connection.Response res = HttpConnection.connect("http://httpbin.org/html").execute();
        assertEquals("OK", res.statusMessage());
    }

    // Test for Response.charset() after parsing
    @Test
    public void testResponseCharset() throws IOException {
        Connection.Response res = HttpConnection.connect("http://httpbin.org/html").execute();
        res.parse(); // Ensure charset is set after parsing
        assertNotNull(res.charset());
        assertEquals("UTF-8", res.charset());
    }

    // Test for Response.contentType()
    @Test
    public void testResponseContentType() throws IOException {
        Connection.Response res = HttpConnection.connect("http://httpbin.org/html").execute();
        assertEquals("text/html; charset=utf-8", res.contentType());
    }

    // Test for Response.headers() and Response.header()
    @Test
    public void testResponseHeaders() throws IOException {
        Connection.Response res = HttpConnection.connect("http://httpbin.org/headers").execute();
        assertTrue(res.headers().containsKey("Content-Type"));
        assertTrue(res.hasHeader("Content-Type"));
        assertEquals("application/json", res.header("Content-Type"));
    }

    // Test for Response.cookies() and Response.cookie()
    @Test
    public void testResponseCookies() throws IOException {
        Connection.Response res = HttpConnection.connect("http://httpbin.org/cookies/set/mycookie/myvalue").execute();
        assertTrue(res.cookies().containsKey("mycookie"));
        assertTrue(res.hasCookie("mycookie"));
        assertEquals("myvalue", res.cookie("mycookie"));
    }
}

