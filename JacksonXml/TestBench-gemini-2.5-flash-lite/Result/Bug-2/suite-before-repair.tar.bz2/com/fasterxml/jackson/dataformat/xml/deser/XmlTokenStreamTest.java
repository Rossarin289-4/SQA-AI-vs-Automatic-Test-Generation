package com.fasterxml.jackson.dataformat.xml.deser;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import javax.xml.stream.*;
import org.codehaus.stax2.XMLStreamLocation2;
import org.codehaus.stax2.XMLStreamReader2;
import org.codehaus.stax2.ri.Stax2ReaderAdapter;
import com.fasterxml.jackson.core.JsonLocation;
import com.fasterxml.jackson.dataformat.xml.util.StaxUtil;

import static com.fasterxml.jackson.dataformat.xml.deser.XmlTokenStream.*;

public class XmlTokenStreamTest {

    // Helper method to create a mock XMLStreamReader for testing.
    // This method needs to be implemented based on how XMLStreamReader is typically mocked or instantiated for tests.
    // For the purpose of this example, we will assume a basic XMLStreamReader can be created.
    // In a real scenario, you would use a library like Mockito or a concrete StAX implementation.
    private XMLStreamReader createMockXmlReader(String xmlContent) throws XMLStreamException {
        XMLInputFactory factory = XMLInputFactory.newInstance();
        return factory.createXMLStreamReader(new java.io.StringReader(xmlContent));
    }

    @Test
    public void testNextReturnsStartElement() throws Exception {
        String xml = "<root attr='value'>text</root>";
        XMLStreamReader reader = createMockXmlReader(xml);
        reader.next(); // Move to START_ELEMENT
        XmlTokenStream stream = new XmlTokenStream(reader, "source");
        int token = stream.next();
        assertEquals(XML_START_ELEMENT, token);
        assertEquals("root", stream.getLocalName());
        assertTrue(stream.hasAttributes());
    }

    @Test
    public void testNextReturnsAttributeNameAndValue() throws Exception {
        String xml = "<root attr='value'>text</root>";
        XMLStreamReader reader = createMockXmlReader(xml);
        reader.next(); // Move to START_ELEMENT
        XmlTokenStream stream = new XmlTokenStream(reader, "source");
        stream.next(); // consume START_ELEMENT
        int token1 = stream.next(); // consume attribute name
        assertEquals(XML_ATTRIBUTE_NAME, token1);
        assertEquals("attr", stream.getLocalName());
        int token2 = stream.next(); // consume attribute value
        assertEquals(XML_ATTRIBUTE_VALUE, token2);
        assertEquals("value", stream.getText());
    }

    @Test
    public void testNextReturnsText() throws Exception {
        String xml = "<root>Hello World</root>";
        XMLStreamReader reader = createMockXmlReader(xml);
        reader.next(); // Move to START_ELEMENT
        XmlTokenStream stream = new XmlTokenStream(reader, "source");
        stream.next(); // consume START_ELEMENT
        stream.next(); // consume attribute NAME (none)
        stream.next(); // consume attribute VALUE (none)
        int token = stream.next(); // consume TEXT
        assertEquals(XML_TEXT, token);
        assertEquals("Hello World", stream.getText());
    }

    @Test
    public void testNextReturnsEndElement() throws Exception {
        String xml = "<root>text</root>";
        XMLStreamReader reader = createMockXmlReader(xml);
        reader.next(); // Move to START_ELEMENT
        XmlTokenStream stream = new XmlTokenStream(reader, "source");
        stream.next(); // START_ELEMENT
        stream.next(); // ATTRIBUTE_NAME (none)
        stream.next(); // ATTRIBUTE_VALUE (none)
        stream.next(); // TEXT
        int token = stream.next(); // END_ELEMENT
        assertEquals(XML_END_ELEMENT, token);
        assertEquals("root", stream.getLocalName());
    }

    @Test
    public void testNextReturnsEnd() throws Exception {
        String xml = "<root/>";
        XMLStreamReader reader = createMockXmlReader(xml);
        reader.next(); // Move to START_ELEMENT
        XmlTokenStream stream = new XmlTokenStream(reader, "source");
        stream.next(); // START_ELEMENT
        stream.next(); // ATTRIBUTE_NAME (none)
        stream.next(); // ATTRIBUTE_VALUE (none)
        int token = stream.next(); // END_ELEMENT
        assertEquals(XML_END, token);
    }

    @Test
    public void testHasAttributesReturnsTrueWhenAttributesExist() throws Exception {
        String xml = "<root attr='value'/>";
        XMLStreamReader reader = createMockXmlReader(xml);
        reader.next(); // Move to START_ELEMENT
        XmlTokenStream stream = new XmlTokenStream(reader, "source");
        stream.next(); // consume START_ELEMENT
        assertTrue(stream.hasAttributes());
    }

    @Test
    public void testHasAttributesReturnsFalseWhenNoAttributes() throws Exception {
        String xml = "<root>text</root>";
        XMLStreamReader reader = createMockXmlReader(xml);
        reader.next(); // Move to START_ELEMENT
        XmlTokenStream stream = new XmlTokenStream(reader, "source");
        stream.next(); // consume START_ELEMENT
        assertFalse(stream.hasAttributes());
    }

    @Test
    public void testGetCurrentTokenReturnsCorrectToken() throws Exception {
        String xml = "<root attr='value'>text</root>";
        XMLStreamReader reader = createMockXmlReader(xml);
        reader.next(); // Move to START_ELEMENT
        XmlTokenStream stream = new XmlTokenStream(reader, "source");

        assertEquals(XML_START_ELEMENT, stream.getCurrentToken());
        stream.next(); // consume START_ELEMENT
        assertEquals(XML_ATTRIBUTE_NAME, stream.getCurrentToken());
        stream.next(); // consume ATTRIBUTE_NAME
        assertEquals(XML_ATTRIBUTE_VALUE, stream.getCurrentToken());
        stream.next(); // consume ATTRIBUTE_VALUE
        assertEquals(XML_TEXT, stream.getCurrentToken());
        stream.next(); // consume TEXT
        assertEquals(XML_END_ELEMENT, stream.getCurrentToken());
        stream.next(); // consume END_ELEMENT
        assertEquals(XML_END, stream.getCurrentToken());
    }

    @Test
    public void testgetTextReturnsCorrectTextValueForAttribute() throws Exception {
        String xml = "<root attr='attributeValue'/>";
        XMLStreamReader reader = createMockXmlReader(xml);
        reader.next(); // Move to START_ELEMENT
        XmlTokenStream stream = new XmlTokenStream(reader, "source");
        stream.next(); // consume START_ELEMENT
        stream.next(); // consume ATTRIBUTE_NAME
        assertEquals("attributeValue", stream.getText());
        stream.next(); // consume ATTRIBUTE_VALUE
    }

    @Test
    public void testgetTextReturnsCorrectTextValueForTextNode() throws Exception {
        String xml = "<root>textContent</root>";
        XMLStreamReader reader = createMockXmlReader(xml);
        reader.next(); // Move to START_ELEMENT
        XmlTokenStream stream = new XmlTokenStream(reader, "source");
        stream.next(); // consume START_ELEMENT
        stream.next(); // ATTRIBUTE_NAME (none)
        stream.next(); // ATTRIBUTE_VALUE (none)
        stream.next(); // consume TEXT
        assertEquals("textContent", stream.getText());
    }

    @Test
    public void testGetLocalNameReturnsCorrectLocalNameForStartElement() throws Exception {
        String xml = "<ns:root xmlns:ns='http://example.com'/>";
        XMLStreamReader reader = createMockXmlReader(xml);
        reader.next(); // Move to START_ELEMENT
        XmlTokenStream stream = new XmlTokenStream(reader, "source");
        assertEquals("root", stream.getLocalName());
        stream.next(); // consume START_ELEMENT
    }

    @Test
    public void testGetLocalNameReturnsCorrectLocalNameForAttribute() throws Exception {
        String xml = "<root attr='value'/>";
        XMLStreamReader reader = createMockXmlReader(xml);
        reader.next(); // Move to START_ELEMENT
        XmlTokenStream stream = new XmlTokenStream(reader, "source");
        stream.next(); // consume START_ELEMENT
        stream.next(); // consume ATTRIBUTE_NAME
        assertEquals("attr", stream.getLocalName());
        stream.next(); // consume ATTRIBUTE_VALUE
    }

    @Test
    public void testGetNamespaceURIReturnsCorrectNamespaceForStartElement() throws Exception {
        String xml = "<ns:root xmlns:ns='http://example.com'>text</ns:root>";
        XMLStreamReader reader = createMockXmlReader(xml);
        reader.next(); // Move to START_ELEMENT
        XmlTokenStream stream = new XmlTokenStream(reader, "source");
        assertEquals("http://example.com", stream.getNamespaceURI());
        stream.next(); // consume START_ELEMENT
    }

    @Test
    public void testGetNamespaceURIReturnsCorrectNamespaceForAttribute() throws Exception {
        String xml = "<root ns:attr='value' xmlns:ns='http://example.com'/>";
        XMLStreamReader reader = createMockXmlReader(xml);
        reader.next(); // Move to START_ELEMENT
        XmlTokenStream stream = new XmlTokenStream(reader, "source");
        stream.next(); // consume START_ELEMENT
        stream.next(); // consume ATTRIBUTE_NAME
        assertEquals("http://example.com", stream.getNamespaceURI());
        stream.next(); // consume ATTRIBUTE_VALUE
    }

    @Test
    public void testSkipEndElementSkipsCorrectly() throws Exception {
        String xml = "<root>text</root>";
        XMLStreamReader reader = createMockXmlReader(xml);
        reader.next(); // Move to START_ELEMENT
        XmlTokenStream stream = new XmlTokenStream(reader, "source");
        stream.next(); // START_ELEMENT
        stream.next(); // ATTRIBUTE_NAME (none)
        stream.next(); // ATTRIBUTE_VALUE (none)
        stream.next(); // TEXT
        stream.skipEndElement(); // This should consume the END_ELEMENT token
        assertEquals(XML_END, stream.getCurrentToken());
    }

    @Test(expected = IOException.class)
    public void testSkipEndElementThrowsExceptionIfUnexpectedToken() throws Exception {
        String xml = "<root/>"; // No text or attributes to skip
        XMLStreamReader reader = createMockXmlReader(xml);
        reader.next(); // Move to START_ELEMENT
        XmlTokenStream stream = new XmlTokenStream(reader, "source");
        stream.next(); // consume START_ELEMENT
        // Attempting to skip an END_ELEMENT when the next token is END_ELEMENT (of root)
        // This will likely throw because the internal logic expects an END_ELEMENT event.
        stream.skipEndElement();
    }

    @Test
    public void testCloseCompletelyClosesReader() throws Exception {
        // This test requires a way to verify if closeCompletely was called on the underlying reader.
        // For simplicity, we'll assume it works if no exception is thrown.
        String xml = "<root/>";
        XMLStreamReader reader = createMockXmlReader(xml);
        reader.next(); // Move to START_ELEMENT
        XmlTokenStream stream = new XmlTokenStream(reader, "source");
        stream.closeCompletely();
        // If closeCompletely throws an exception, the test will fail.
        // No specific assertion here as we can't directly inspect the reader's state.
    }

    @Test
    public void testCloseClosesReader() throws Exception {
        // Similar to closeCompletely, we assume it works if no exception is thrown.
        String xml = "<root/>";
        XMLStreamReader reader = createMockXmlReader(xml);
        reader.next(); // Move to START_ELEMENT
        XmlTokenStream stream = new XmlTokenStream(reader, "source");
        stream.close();
        // If close throws an exception, the test will fail.
    }

    @Test
    public void testGetCurrentLocationProvidesCorrectLocation() throws Exception {
        String xml = "<root attr='value'>text</root>";
        XMLStreamReader reader = createMockXmlReader(xml);
        reader.next(); // Move to START_ELEMENT
        XmlTokenStream stream = new XmlTokenStream(reader, "source");
        JsonLocation loc = stream.getCurrentLocation();
        // These values depend on the specific StAX implementation and how it reports locations.
        // We'll assert that they are not -1, indicating a location was retrieved.
        assertNotEquals(-1, loc.getCharOffset());
        assertNotEquals(-1, loc.getLineNr());
        assertNotEquals(-1, loc.getColumnNr());
        stream.next(); // consume START_ELEMENT
    }

    @Test
    public void testGetTokenLocationProvidesCorrectLocation() throws Exception {
        String xml = "<root attr='value'>text</root>";
        XMLStreamReader reader = createMockXmlReader(xml);
        reader.next(); // Move to START_ELEMENT
        XmlTokenStream stream = new XmlTokenStream(reader, "source");
        // Location of the START_ELEMENT token
        JsonLocation loc = stream.getTokenLocation();
        assertNotEquals(-1, loc.getCharOffset());
        assertNotEquals(-1, loc.getLineNr());
        assertNotEquals(-1, loc.getColumnNr());
        stream.next(); // consume START_ELEMENT
    }

    @Test
    public void testMultipleAttributesAreHandledCorrectly() throws Exception {
        String xml = "<root attr1='val1' attr2='val2'/>";
        XMLStreamReader reader = createMockXmlReader(xml);
        reader.next(); // Move to START_ELEMENT
        XmlTokenStream stream = new XmlTokenStream(reader, "source");
        stream.next(); // START_ELEMENT
        stream.next(); // ATTRIBUTE_NAME
        assertEquals("attr1", stream.getLocalName());
        stream.next(); // ATTRIBUTE_VALUE
        assertEquals("val1", stream.getText());
        stream.next(); // ATTRIBUTE_NAME
        assertEquals("attr2", stream.getLocalName());
        stream.next(); // ATTRIBUTE_VALUE
        assertEquals("val2", stream.getText());
        stream.next(); // END_ELEMENT
        assertEquals(XML_END, stream.getCurrentToken());
    }

    @Test
    public void testEmptyElementWithAttributes() throws Exception {
        String xml = "<ns:empty xmlns:ns='http://example.com' id='123'/>";
        XMLStreamReader reader = createMockXmlReader(xml);
        reader.next(); // Move to START_ELEMENT
        XmlTokenStream stream = new XmlTokenStream(reader, "source");
        assertEquals(XML_START_ELEMENT, stream.next());
        assertEquals("empty", stream.getLocalName());
        assertEquals("http://example.com", stream.getNamespaceURI());
        assertTrue(stream.hasAttributes());
        assertEquals(XML_ATTRIBUTE_NAME, stream.next());
        assertEquals("id", stream.getLocalName());
        assertEquals(XML_ATTRIBUTE_VALUE, stream.next());
        assertEquals("123", stream.getText());
        assertEquals(XML_END_ELEMENT, stream.next());
    }

    @Test
    public void testElementWithOnlyTextContent() throws Exception {
        String xml = "<textOnly>Just text</textOnly>";
        XMLStreamReader reader = createMockXmlReader(xml);
        reader.next(); // Move to START_ELEMENT
        XmlTokenStream stream = new XmlTokenStream(reader, "source");
        assertEquals(XML_START_ELEMENT, stream.next());
        assertEquals("textOnly", stream.getLocalName());
        assertEquals(XML_TEXT, stream.next());
        assertEquals("Just text", stream.getText());
        assertEquals(XML_END_ELEMENT, stream.next());
    }

    @Test
    public void testElementWithMixedContent() throws Exception {
        String xml = "<mixed>Text <bold>bold</bold> more text</mixed>";
        XMLStreamReader reader = createMockXmlReader(xml);
        reader.next(); // Move to START_ELEMENT
        XmlTokenStream stream = new XmlTokenStream(reader, "source");

        assertEquals(XML_START_ELEMENT, stream.next()); // <mixed>
        assertEquals(XML_TEXT, stream.next()); // "Text "
        assertEquals("Text ", stream.getText());
        assertEquals(XML_START_ELEMENT, stream.next()); // <bold>
        assertEquals("bold", stream.getLocalName());
        assertEquals(XML_END_ELEMENT, stream.next()); // </bold>
        assertEquals(XML_TEXT, stream.next()); // " more text"
        assertEquals(" more text", stream.getText());
        assertEquals(XML_END_ELEMENT, stream.next()); // </mixed>
    }

    @Test
    public void testNamespacesAreCorrectlyRead() throws Exception {
        String xml = "<root xmlns='defaultns' attr='val' xmlns:pref='prefixns' pref:attr2='val2'/>";
        XMLStreamReader reader = createMockXmlReader(xml);
        reader.next(); // Move to START_ELEMENT
        XmlTokenStream stream = new XmlTokenStream(reader, "source");

        assertEquals(XML_START_ELEMENT, stream.next());
        assertEquals("root", stream.getLocalName());
        assertEquals("defaultns", stream.getNamespaceURI()); // default namespace

        assertEquals(XML_ATTRIBUTE_NAME, stream.next()); // attr
        assertEquals("attr", stream.getLocalName());
        assertEquals(null, stream.getNamespaceURI()); // attributes in default namespace have null URI

        assertEquals(XML_ATTRIBUTE_VALUE, stream.next());
        assertEquals("val", stream.getText());

        assertEquals(XML_ATTRIBUTE_NAME, stream.next()); // pref:attr2
        assertEquals("attr2", stream.getLocalName());
        assertEquals("prefixns", stream.getNamespaceURI()); // prefixed attribute

        assertEquals(XML_ATTRIBUTE_VALUE, stream.next());
        assertEquals("val2", stream.getText());

        assertEquals(XML_END_ELEMENT, stream.next());
    }

    @Test
    public void testEmptyTextNode() throws Exception {
        String xml = "<emptyText/>";
        XMLStreamReader reader = createMockXmlReader(xml);
        reader.next(); // Move to START_ELEMENT
        XmlTokenStream stream = new XmlTokenStream(reader, "source");
        stream.next(); // START_ELEMENT
        int token = stream.next(); // END_ELEMENT
        assertEquals(XML_END_ELEMENT, token);
        // According to _collectUntilTag, null text is returned if no characters are found.
        // The `convertToString` method handles null text as an empty string.
        // The `_next` method also handles cases where text is null or all whitespace.
        // After consuming START_ELEMENT and attributes (none), if there's no text,
        // the next token should be END_ELEMENT.
    }

    @Test
    public void testTextWithLeadingAndTrailingWhitespace() throws Exception {
        String xml = "<padded>  spaced out  </padded>";
        XMLStreamReader reader = createMockXmlReader(xml);
        reader.next(); // Move to START_ELEMENT
        XmlTokenStream stream = new XmlTokenStream(reader, "source");
        stream.next(); // START_ELEMENT
        int token = stream.next(); // TEXT
        assertEquals(XML_TEXT, token);
        assertEquals("  spaced out  ", stream.getText());
        stream.next(); // END_ELEMENT
    }

    @Test
    public void testCDATASectionIsTreatedAsText() throws Exception {
        String xml = "<data><![CDATA[This is CDATA content]]></data>";
        XMLStreamReader reader = createMockXmlReader(xml);
        reader.next(); // Move to START_ELEMENT
        XmlTokenStream stream = new XmlTokenStream(reader, "source");
        stream.next(); // START_ELEMENT
        int token = stream.next(); // TEXT
        assertEquals(XML_TEXT, token);
        assertEquals("This is CDATA content", stream.getText());
        stream.next(); // END_ELEMENT
    }
}
