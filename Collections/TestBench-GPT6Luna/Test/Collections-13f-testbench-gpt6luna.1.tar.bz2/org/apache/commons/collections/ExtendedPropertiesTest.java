package org.apache.commons.collections;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Vector;

public class ExtendedPropertiesTest {
    @Test
    public void testLoadAndRepeatedProperties() throws Exception {
        ExtendedProperties p = new ExtendedProperties();
        p.load(new java.io.ByteArrayInputStream("item=one\nitem=two\n".getBytes("8859_1")));
        assertArrayEquals(new String[] {"one", "two"}, p.getStringArray("item"));
        assertTrue(p.isInitialized());
    }

    @Test
    public void testLoadCommaTokensAndEscapedComma() throws Exception {
        ExtendedProperties p = new ExtendedProperties();
        p.load(new java.io.ByteArrayInputStream("x=red,blue\\,green\n".getBytes("8859_1")));
        assertArrayEquals(new String[] {"red", "blue,green"}, p.getStringArray("x"));
    }

    @Test
    public void testSetReplacesAndClearRemoves() throws Exception {
        ExtendedProperties p = new ExtendedProperties();
        p.addProperty("x", "old");
        p.addProperty("x", "extra");
        p.setProperty("x", "new");
        assertArrayEquals(new String[] {"new"}, p.getStringArray("x"));
        p.clearProperty("x");
        assertNull(p.getProperty("x"));
    }

    @Test
    public void testGetKeysAndPrefixSubset() throws Exception {
        ExtendedProperties p = new ExtendedProperties();
        p.addProperty("app.one", "1");
        p.addProperty("app.two", "2");
        p.addProperty("other", "3");
        Iterator keys = p.getKeys("app.");
        assertEquals("app.one", keys.next());
        assertEquals("app.two", keys.next());
        assertFalse(keys.hasNext());
        ExtendedProperties sub = p.subset("app");
        assertEquals("1", sub.getString("one"));
        assertEquals("2", sub.getString("two"));
        assertNull(p.subset("missing"));
    }

    @Test
    public void testSubsetExactPrefixKey() throws Exception {
        ExtendedProperties p = new ExtendedProperties();
        p.addProperty("root", "v");
        assertEquals("v", p.subset("root").getString("root"));
    }

    @Test
    public void testGetStringInterpolation() throws Exception {
        ExtendedProperties p = new ExtendedProperties();
        p.addProperty("name", "Ada");
        p.addProperty("greeting", "Hi ${name}!");
        assertEquals("Hi Ada!", p.getString("greeting"));
        assertEquals("${unknown}", p.getString("missing", "${unknown}"));
    }

    @Test
    public void testStringArrayListAndVector() throws Exception {
        ExtendedProperties p = new ExtendedProperties();
        p.addProperty("vals", "a,b");
        assertArrayEquals(new String[] {"a", "b"}, p.getStringArray("vals"));
        List list = p.getList("vals");
        list.add("c");
        assertEquals(2, p.getList("vals").size());
        Vector vector = p.getVector("vals");
        vector.add("d");
        assertEquals(2, p.getVector("vals").size());
    }

    @Test
    public void testPropertiesTokensAndMalformedToken() throws Exception {
        ExtendedProperties p = new ExtendedProperties();
        p.addProperty("props", "a=1,b=2");
        Properties props = p.getProperties("props");
        assertEquals("1", props.getProperty("a"));
        assertEquals("2", props.getProperty("b"));

        p.setProperty("bad", "malformed");
        try {
            p.getProperties("bad");
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) { }
    }

    @Test
    public void testBooleanFormsAndDefault() throws Exception {
        ExtendedProperties p = new ExtendedProperties();
        assertEquals("true", p.testBoolean("YeS"));
        assertEquals("false", p.testBoolean("OFF"));
        assertNull(p.testBoolean("perhaps"));
        p.addProperty("flag", "ON");
        assertTrue(p.getBoolean("flag"));
        assertFalse(p.getBoolean("absent", false));
    }

    @Test
    public void testBooleanMissingThrows() throws Exception {
        ExtendedProperties p = new ExtendedProperties();
        try {
            p.getBoolean("absent");
            fail("expected NoSuchElementException");
        } catch (NoSuchElementException expected) { }
    }

    @Test
    public void testByteMinimumAndMaximum() throws Exception {
        ExtendedProperties p = new ExtendedProperties();
        p.addProperty("low", "-128");
        p.addProperty("high", "127");
        assertEquals((byte) -128, p.getByte("low"));
        assertEquals((byte) 127, p.getByte("high"));
    }

    @Test
    public void testByteOutOfRangeThrows() throws Exception {
        ExtendedProperties p = new ExtendedProperties();
        p.addProperty("x", "128");
        try {
            p.getByte("x");
            fail("expected NumberFormatException");
        } catch (NumberFormatException expected) { }
    }

    @Test
    public void testShortMinimumAndMaximum() throws Exception {
        ExtendedProperties p = new ExtendedProperties();
        p.addProperty("low", "-32768");
        p.addProperty("high", "32767");
        assertEquals((short) -32768, p.getShort("low"));
        assertEquals((short) 32767, p.getShort("high"));
    }

    @Test
    public void testIntegerBoundaryValues() throws Exception {
        ExtendedProperties p = new ExtendedProperties();
        p.addProperty("low", "-2147483648");
        p.addProperty("high", "2147483647");
        assertEquals(-2147483648, p.getInt("low"));
        assertEquals(2147483647, p.getInteger("high"));
    }

    @Test
    public void testIntegerFirstValueAboveRangeThrows() throws Exception {
        ExtendedProperties p = new ExtendedProperties();
        p.addProperty("x", "2147483648");
        try {
            p.getInteger("x");
            fail("expected NumberFormatException");
        } catch (NumberFormatException expected) { }
    }

    @Test
    public void testLongBoundaryValues() throws Exception {
        ExtendedProperties p = new ExtendedProperties();
        p.addProperty("low", "-9223372036854775808");
        p.addProperty("high", "9223372036854775807");
        assertEquals(-9223372036854775808L, p.getLong("low"));
        assertEquals(9223372036854775807L, p.getLong("high"));
    }

    @Test
    public void testFloatingPointConversions() throws Exception {
        ExtendedProperties p = new ExtendedProperties();
        p.addProperty("f", "1.25");
        p.addProperty("d", "-2.5");
        assertEquals(1.25, p.getFloat("f"), 1e-6);
        assertEquals(-2.5, p.getDouble("d"), 1e-9);
    }

    @Test
    public void testIncludeConfiguration() throws Exception {
        ExtendedProperties p = new ExtendedProperties();
        assertEquals("include", p.getInclude());
        p.setInclude("load");
        assertEquals("load", p.getInclude());
        p.setInclude("");
        assertNull(p.getInclude());
    }

    @Test
    public void testCombineOverwritesExistingValue() throws Exception {
        ExtendedProperties p = new ExtendedProperties();
        ExtendedProperties source = new ExtendedProperties();
        p.addProperty("x", "old");
        source.addProperty("x", "new");
        source.addProperty("y", "added");
        p.combine(source);
        assertEquals("new", p.getString("x"));
        assertEquals("added", p.getString("y"));
    }

    @Test
    public void testPutAndRemoveReturnValues() throws Exception {
        ExtendedProperties p = new ExtendedProperties();
        assertNull(p.put("x", "first"));
        assertEquals("first", p.put("x", "second"));
        assertEquals("first", p.getStringArray("x")[0]);
        assertEquals("second", p.getStringArray("x")[1]);
        assertTrue(p.remove("x") instanceof List);
        assertNull(p.getProperty("x"));
    }

    @Test
    public void testPutAllAndConvertProperties() throws Exception {
        Properties raw = new Properties();
        raw.setProperty("a", "one");
        raw.setProperty("b", "two");
        ExtendedProperties converted = ExtendedProperties.convertProperties(raw);
        assertEquals("one", converted.getString("a"));

        ExtendedProperties p = new ExtendedProperties();
        p.putAll(converted);
        assertEquals("two", p.getString("b"));
    }

    @Test
    public void testSaveWritesHeaderAndEscapedValue() throws Exception {
        ExtendedProperties p = new ExtendedProperties();
        p.addProperty("x", "a,b");
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        p.save(out, "head");
        String saved = new String(out.toByteArray(), "8859_1");
        assertTrue(saved.startsWith("head"));
        assertTrue(saved.contains("x=a"));
    }

    @Test
    public void testDisplayDoesNotChangeStoredValue() throws Exception {
        ExtendedProperties p = new ExtendedProperties();
        p.addProperty("x", "value");
        p.display();
        assertEquals("value", p.getString("x"));
    }
}
