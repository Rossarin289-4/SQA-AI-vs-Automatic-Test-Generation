package org.apache.commons.collections;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Vector;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.io.StringReader;

public class ExtendedPropertiesTest {

    // Helper method to create a temporary properties file
    private File createTempPropertiesFile(String content) throws IOException {
        File tempFile = File.createTempFile("extendedproperties", ".properties");
        tempFile.deleteOnExit();
        java.nio.file.Files.write(tempFile.toPath(), content.getBytes());
        return tempFile;
    }

    @Test
    public void testEmptyConstructor() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        assertNotNull(props);
        assertTrue(props.isEmpty());
        assertFalse(props.isInitialized());
    }

    @Test
    public void testFileConstructor() throws Exception {
        String content = "key1 = value1\nkey2 = value2";
        File tempFile = createTempPropertiesFile(content);
        ExtendedProperties props = new ExtendedProperties(tempFile.getAbsolutePath());
        assertNotNull(props);
        assertFalse(props.isEmpty());
        assertTrue(props.isInitialized());
        assertEquals("value1", props.getString("key1"));
        assertEquals("value2", props.getString("key2"));
    }

    @Test
    public void testFileConstructorWithDefaults() throws Exception {
        String content = "key1 = value1";
        String defaultContent = "defaultKey = defaultValue";
        File tempFile = createTempPropertiesFile(content);
        File defaultFile = createTempPropertiesFile(defaultContent);
        ExtendedProperties props = new ExtendedProperties(tempFile.getAbsolutePath(), defaultFile.getAbsolutePath());
        assertNotNull(props);
        assertEquals("value1", props.getString("key1"));
        assertEquals("defaultValue", props.getString("defaultKey"));
    }

    @Test
    public void testIsInitialized() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        assertFalse(props.isInitialized());
        props.load(new ByteArrayInputStream("a=b".getBytes()));
        assertTrue(props.isInitialized());
    }

    @Test
    public void testGetSetInclude() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.setInclude("myInclude");
        assertEquals("myInclude", props.getInclude());
        props.setInclude(null);
        // The getInclude() method returns the static 'include' if includePropertyName is null.
        // The static 'include' is "include" by default.
        assertEquals("include", props.getInclude());
        props.setInclude("");
        assertNull(props.getInclude()); // Empty string converted to null
    }

    @Test
    public void testLoadInputStream() throws Exception {
        String content = "key1=value1\nkey2=value2";
        InputStream is = new ByteArrayInputStream(content.getBytes());
        ExtendedProperties props = new ExtendedProperties();
        props.load(is);
        assertEquals("value1", props.getString("key1"));
        assertEquals("value2", props.getString("key2"));
    }

    @Test
    public void testLoadInputStreamWithEncoding() throws Exception {
        String content = "key1=value1";
        InputStream is = new ByteArrayInputStream(content.getBytes());
        ExtendedProperties props = new ExtendedProperties();
        props.load(is, "UTF-8");
        assertEquals("value1", props.getString("key1"));
    }

    @Test
    public void testGetProperty() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("key1", "value1");
        assertEquals("value1", props.getProperty("key1"));
        assertNull(props.getProperty("nonexistent"));
    }

    @Test
    public void testAddPropertySimple() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("key1", "value1");
        assertEquals("value1", props.getString("key1"));
    }

    @Test
    public void testAddPropertyMultipleValues() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("key1", "value1");
        props.addProperty("key1", "value2");
        Object value = props.get("key1");
        assertTrue(value instanceof List);
        List list = (List) value;
        assertEquals(2, list.size());
        assertEquals("value1", list.get(0));
        assertEquals("value2", list.get(1));
    }

    @Test
    public void testAddPropertyWithComma() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("key1", "value1,value2");
        Object value = props.get("key1");
        assertTrue(value instanceof List);
        List list = (List) value;
        assertEquals(2, list.size());
        assertEquals("value1", list.get(0));
        assertEquals("value2", list.get(1));
    }

    @Test
    public void testAddPropertyWithEscapedComma() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("key1", "value1\\,value2");
        assertEquals("value1,value2", props.getString("key1"));
    }

    @Test
    public void testAddPropertyWithBackslash() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("key1", "value1\\\\value2");
        assertEquals("value1\\value2", props.getString("key1"));
    }

    @Test
    public void testSetProperty() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.setProperty("key1", "value1");
        assertEquals("value1", props.getString("key1"));
        props.setProperty("key1", "newValue");
        assertEquals("newValue", props.getString("key1"));
    }

    @Test
    public void testSave() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("key1", "value1");
        props.addProperty("key2", "value2,value3");
        OutputStream os = new ByteArrayOutputStream();
        props.save(os, "# My Header");
        String output = os.toString();
        assertTrue(output.contains("# My Header"));
        assertTrue(output.contains("key1=value1"));
        assertTrue(output.contains("key2=value2"));
        assertTrue(output.contains("key2=value3"));
    }

    @Test
    public void testCombine() throws Exception {
        ExtendedProperties props1 = new ExtendedProperties();
        props1.addProperty("key1", "value1");
        ExtendedProperties props2 = new ExtendedProperties();
        props2.addProperty("key1", "value2");
        props2.addProperty("key2", "value3");
        props1.combine(props2);
        // combine uses setProperty, which clears and then adds.
        // The addProperty for "value2" should result in a string if no comma is present.
        assertEquals("value2", props1.getString("key1"));
        assertFalse(props1.get("key1") instanceof List);
        assertEquals("value3", props1.getString("key2"));
    }

    @Test
    public void testClearProperty() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("key1", "value1");
        props.addProperty("key2", "value2");
        assertTrue(props.containsKey("key1"));
        props.clearProperty("key1");
        assertFalse(props.containsKey("key1"));
        assertEquals("value2", props.getString("key2"));
    }

    @Test
    public void testGetKeys() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("key1", "value1");
        props.addProperty("key2", "value2");
        Iterator keys = props.getKeys();
        List keyList = new ArrayList();
        while (keys.hasNext()) {
            keyList.add(keys.next());
        }
        assertTrue(keyList.contains("key1"));
        assertTrue(keyList.contains("key2"));
        assertEquals(2, keyList.size());
    }

    @Test
    public void testGetKeysWithPrefix() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("prefix.key1", "value1");
        props.addProperty("prefix.key2", "value2");
        props.addProperty("other.key", "value3");
        Iterator keys = props.getKeys("prefix.");
        List keyList = new ArrayList();
        while (keys.hasNext()) {
            keyList.add(keys.next());
        }
        assertTrue(keyList.contains("prefix.key1"));
        assertTrue(keyList.contains("prefix.key2"));
        assertEquals(2, keyList.size());
    }

    @Test
    public void testSubset() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("config.key1", "value1");
        props.addProperty("config.key2", "value2,value3");
        props.addProperty("other.key", "value4");
        ExtendedProperties subset = props.subset("config");
        assertNotNull(subset);
        assertEquals("value1", subset.getString("key1"));
        List<String> listValues = subset.getList("key2");
        assertEquals(2, listValues.size());
        assertEquals("value2", listValues.get(0));
        assertEquals("value3", listValues.get(1));
    }

    @Test
    public void testSubsetNotFound() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("key1", "value1");
        ExtendedProperties subset = props.subset("nonexistent");
        assertNull(subset);
    }

    @Test
    public void testGetString() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("key1", "value1");
        props.addProperty("key2", "value2,value3");
        assertEquals("value1", props.getString("key1"));
        // getString returns the first token if the value is a list
        assertEquals("value2", props.getString("key2"));
    }

    @Test
    public void testGetStringWithDefault() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("key1", "value1");
        assertEquals("value1", props.getString("key1", "default"));
        assertEquals("default", props.getString("nonexistent", "default"));
    }

    
    @Test
    public void testGetStringInterpolationDefault() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("key1", "defaultValue");
        props.addProperty("key2", "hello ${key1}");
        // The interpolate method will be called on the value of key2.
        // It should find ${key1} and substitute its value.
        assertEquals("hello defaultValue", props.getString("key2"));
    }

    @Test
    public void testGetStringInterpolationLoop() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("key1", "${key2}");
        props.addProperty("key2", "${key1}");
        try {
            props.getString("key1");
            fail("Expected IllegalStateException for interpolation loop");
        } catch (IllegalStateException e) {
            assertTrue(e.getMessage().contains("infinite loop"));
        }
    }

    @Test
    public void testGetProperties() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        // The addProperty method handles comma-separated values.
        // For getProperties to work correctly, the value should be a single string,
        // even if it contains commas, and then the getProperties method itself
        // will parse it.
        props.addProperty("props.key1", "propValue1");
        props.addProperty("props.key2", "propValue2");
        Properties result = props.getProperties("props");
        assertEquals("propValue1", result.getProperty("key1"));
        assertEquals("propValue2", result.getProperty("key2"));
    }
    
    @Test
    public void testGetPropertiesWithEqualsInValue() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        // When `addProperty` receives "propValue1=abc", it treats the whole string as the value.
        // `getProperties` then splits this string at the first '='.
        // So, "propValue1=abc" should be split into key "propValue1" and value "abc".
        props.addProperty("props.key1", "propValue1=abc");
        Properties result = props.getProperties("props");
        assertEquals("abc", result.getProperty("propValue1")); // Corrected expected value
    }

    @Test
    public void testGetPropertiesMalformedToken() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        // When `addProperty` is called with "valueWithoutEquals", it's treated as a single token.
        // `getProperties` expects tokens like "key=value".
        props.addProperty("props.malformed", "valueWithoutEquals");
        try {
            props.getProperties("props");
            fail("Expected IllegalArgumentException for malformed token");
        } catch (IllegalArgumentException e) {
            assertTrue(e.getMessage().contains("does not contain an equals sign"));
        }
    }

    @Test
    public void testGetStringArray() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("key1", "value1,value2");
        String[] array = props.getStringArray("key1");
        assertEquals(2, array.length);
        assertEquals("value1", array[0]);
        assertEquals("value2", array[1]);
    }

    @Test
    public void testGetStringArraySingleValue() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("key1", "value1");
        String[] array = props.getStringArray("key1");
        assertEquals(1, array.length);
        assertEquals("value1", array[0]);
    }

    @Test
    public void testGetStringArrayEmpty() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        String[] array = props.getStringArray("nonexistent");
        assertEquals(0, array.length);
    }
    
    @Test
    public void testGetVector() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("key1", "value1,value2");
        Vector vector = props.getVector("key1");
        assertEquals(2, vector.size());
        assertEquals("value1", vector.get(0));
        assertEquals("value2", vector.get(1));
    }

    @Test
    public void testGetVectorSingleValue() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("key1", "value1");
        Vector vector = props.getVector("key1");
        assertEquals(1, vector.size());
        assertEquals("value1", vector.get(0));
    }

    @Test
    public void testGetVectorDefault() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        Vector defaultVector = new Vector();
        defaultVector.add("default");
        Vector result = props.getVector("nonexistent", defaultVector);
        assertEquals(1, result.size());
        assertEquals("default", result.get(0));
        // Test with null default
        result = props.getVector("nonexistent", null);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testGetList() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("key1", "value1,value2");
        List list = props.getList("key1");
        assertEquals(2, list.size());
        assertEquals("value1", list.get(0));
        assertEquals("value2", list.get(1));
    }

    @Test
    public void testGetListSingleValue() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("key1", "value1");
        List list = props.getList("key1");
        assertEquals(1, list.size());
        assertEquals("value1", list.get(0));
    }

    @Test
    public void testGetListDefault() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        List defaultList = new ArrayList();
        defaultList.add("default");
        List result = props.getList("nonexistent", defaultList);
        assertEquals(1, result.size());
        assertEquals("default", result.get(0));
        // Test with null default
        result = props.getList("nonexistent", null);
        assertTrue(result.isEmpty());
    }

    @Test
    public void testGetBoolean() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("bool.true", "true");
        props.addProperty("bool.on", "on");
        props.addProperty("bool.yes", "yes");
        props.addProperty("bool.false", "false");
        props.addProperty("bool.off", "off");
        props.addProperty("bool.no", "no");

        assertTrue(props.getBoolean("bool.true"));
        assertTrue(props.getBoolean("bool.on"));
        assertTrue(props.getBoolean("bool.yes"));
        assertFalse(props.getBoolean("bool.false"));
        assertFalse(props.getBoolean("bool.off"));
        assertFalse(props.getBoolean("bool.no"));
    }

    @Test
    public void testGetBooleanCaseInsensitive() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("bool.TRUE", "TRUE");
        assertTrue(props.getBoolean("bool.TRUE"));
    }

    @Test
    public void testGetBooleanInvalidString() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("bool.invalid", "maybe");
        // testBoolean returns null for "maybe".
        // getBoolean(key, Boolean defaultValue) will then return the defaultValue.
        assertNull(props.getBoolean("bool.invalid", null));
    }

    @Test
    public void testGetBooleanDefault() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        assertTrue(props.getBoolean("nonexistent", true));
        assertFalse(props.getBoolean("nonexistent", false));
    }

    @Test
    public void testGetBooleanNumeric() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("bool.inttrue", "1"); // This should not be interpreted as boolean true by testBoolean
        props.addProperty("bool.intfalse", "0"); // This should not be interpreted as boolean false by testBoolean
        
        // testBoolean returns null for "1" and "0".
        // getBoolean(key, Boolean defaultValue) should return the defaultValue.
        assertNull(props.getBoolean("bool.inttrue", null));
        assertNull(props.getBoolean("bool.intfalse", null));
        
        // getBoolean(String key) throws NoSuchElementException if no default is found.
        try {
            props.getBoolean("bool.inttrue");
            fail("Expected NoSuchElementException");
        } catch (NoSuchElementException e) {
            // Expected
        }
    }

    @Test
    public void testTestBoolean() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        assertEquals("true", props.testBoolean("true"));
        assertEquals("true", props.testBoolean("on"));
        assertEquals("true", props.testBoolean("yes"));
        assertEquals("false", props.testBoolean("false"));
        assertEquals("false", props.testBoolean("off"));
        assertEquals("false", props.testBoolean("no"));
        assertNull(props.testBoolean("maybe"));
        assertNull(props.testBoolean(""));
    }

    @Test
    public void testGetByte() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("byte.val", "123");
        assertEquals((byte) 123, props.getByte("byte.val"));
    }

    @Test
    public void testGetByteOutOfRange() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("byte.val", "300"); // This is outside the range of a byte.
        try {
            props.getByte("byte.val");
            fail("Expected NumberFormatException");
        } catch (NumberFormatException e) {
            // Expected
        }
    }

    @Test
    public void testGetByteDefault() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        assertEquals((byte) 5, props.getByte("nonexistent", (byte) 5));
    }

    @Test
    public void testGetShort() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("short.val", "12345");
        assertEquals((short) 12345, props.getShort("short.val"));
    }

    @Test
    public void testGetShortOutOfRange() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("short.val", "40000"); // This is outside the range of a short.
        try {
            props.getShort("short.val");
            fail("Expected NumberFormatException");
        } catch (NumberFormatException e) {
            // Expected
        }
    }

    @Test
    public void testGetShortDefault() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        assertEquals((short) 5, props.getShort("nonexistent", (short) 5));
    }

    @Test
    public void testGetInt() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("int.val", "123456789");
        assertEquals(123456789, props.getInt("int.val"));
    }

    @Test
    public void testGetIntOutOfRange() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("int.val", "2147483648"); // Integer.MAX_VALUE + 1
        try {
            props.getInt("int.val");
            fail("Expected NumberFormatException");
        } catch (NumberFormatException e) {
            // Expected
        }
    }

    @Test
    public void testGetIntDefault() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        assertEquals(5, props.getInt("nonexistent", 5));
    }
    

    @Test
    public void testGetIntegerDefault() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        assertEquals(Integer.valueOf(5), props.getInteger("nonexistent", Integer.valueOf(5)));
    }

    @Test
    public void testGetLong() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("long.val", "1234567890123");
        assertEquals(1234567890123L, props.getLong("long.val"));
    }

    @Test
    public void testGetLongOutOfRange() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("long.val", "9223372036854775808"); // Long.MAX_VALUE + 1
        try {
            props.getLong("long.val");
            fail("Expected NumberFormatException");
        } catch (NumberFormatException e) {
            // Expected
        }
    }

    @Test
    public void testGetLongDefault() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        assertEquals(5L, props.getLong("nonexistent", 5L));
    }

    @Test
    public void testGetFloat() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("float.val", "123.45");
        assertEquals(123.45f, props.getFloat("float.val"), 1e-9f);
    }

    @Test
    public void testGetFloatEdgeCases() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("float.max", Float.toString(Float.MAX_VALUE));
        assertEquals(Float.MAX_VALUE, props.getFloat("float.max"), 1e-9f);
        
        props.addProperty("float.min", Float.toString(Float.MIN_VALUE));
        assertEquals(Float.MIN_VALUE, props.getFloat("float.min"), 1e-9f);
    }

    @Test
    public void testGetFloatDefault() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        assertEquals(5.5f, props.getFloat("nonexistent", 5.5f), 1e-9f);
    }

    @Test
    public void testGetDouble() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("double.val", "123.456789");
        assertEquals(123.456789d, props.getDouble("double.val"), 1e-9d);
    }

    @Test
    public void testGetDoubleEdgeCases() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("double.max", Double.toString(Double.MAX_VALUE));
        assertEquals(Double.MAX_VALUE, props.getDouble("double.max"), 1e-9d);
        
        props.addProperty("double.min", Double.toString(Double.MIN_VALUE));
        assertEquals(Double.MIN_VALUE, props.getDouble("double.min"), 1e-9d);
    }

    @Test
    public void testGetDoubleDefault() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        assertEquals(5.5d, props.getDouble("nonexistent", 5.5d), 1e-9d);
    }

    @Test
    public void testConvertProperties() throws Exception {
        Properties javaProps = new Properties();
        javaProps.put("key1", "value1");
        javaProps.put("key2", "value2");
        ExtendedProperties extendedProps = ExtendedProperties.convertProperties(javaProps);
        assertEquals("value1", extendedProps.getString("key1"));
        assertEquals("value2", extendedProps.getString("key2"));
    }

    @Test
    public void testPut() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("key1", "value1");
        Object oldValue = props.put("key1", "newValue");
        assertEquals("value1", oldValue);
        assertEquals("newValue", props.getString("key1"));
    }

    @Test
    public void testPutNewKey() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        Object oldValue = props.put("key1", "value1");
        assertNull(oldValue);
        assertEquals("value1", props.getString("key1"));
    }

    @Test
    public void testPutAll() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("key1", "value1");
        Map<String, String> map = new HashMap<>();
        map.put("key1", "newValue1");
        map.put("key2", "value2");
        props.putAll(map);
        assertEquals("newValue1", props.getString("key1"));
        assertEquals("value2", props.getString("key2"));
    }

    @Test
    public void testPutAllExtendedProperties() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("key1", "value1");
        ExtendedProperties otherProps = new ExtendedProperties();
        otherProps.addProperty("key1", "newValue1");
        otherProps.addProperty("key2", "value2");
        props.putAll(otherProps);
        assertEquals("newValue1", props.getString("key1"));
        assertEquals("value2", props.getString("key2"));
    }

    @Test
    public void testRemove() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("key1", "value1");
        props.addProperty("key2", "value2");
        Object oldValue = props.remove("key1");
        assertEquals("value1", oldValue);
        assertFalse(props.containsKey("key1"));
        assertEquals("value2", props.getString("key2"));
    }

    @Test
    public void testRemoveNonExistent() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        Object oldValue = props.remove("nonexistent");
        assertNull(oldValue);
    }
    
    @Test
    public void testPropertiesReaderReadProperty() throws Exception {
        String content = "line1\\ \nline2\n#comment\nline3";
        Reader reader = new StringReader(content);
        ExtendedProperties.PropertiesReader propertiesReader = new ExtendedProperties.PropertiesReader(reader);
        assertEquals("line1line2", propertiesReader.readProperty());
        assertEquals("line3", propertiesReader.readProperty());
        assertNull(propertiesReader.readProperty());
    }

    @Test
    public void testPropertiesReaderReadPropertyWithEscapedBackslash() throws Exception {
        String content = "line1\\\\ \nline2";
        Reader reader = new StringReader(content);
        ExtendedProperties.PropertiesReader propertiesReader = new ExtendedProperties.PropertiesReader(reader);
        // The expected output should be "line1\\line2" after unescaping the backslashes.
        assertEquals("line1\\line2", propertiesReader.readProperty());
    }

    @Test
    public void testPropertiesReaderReadPropertyEndsWithSlash() throws Exception {
        String content = "line1\\"; // Line ends with a single backslash, indicating continuation
        Reader reader = new StringReader(content);
        ExtendedProperties.PropertiesReader propertiesReader = new ExtendedProperties.PropertiesReader(reader);
        // Should read until EOF or a line not ending with an odd number of backslashes.
        // Since it's EOF, it should return null as no complete property line is formed.
        assertNull(propertiesReader.readProperty());
    }
    
    @Test
    public void testPropertiesTokenizer() throws Exception {
        ExtendedProperties.PropertiesTokenizer tokenizer = new ExtendedProperties.PropertiesTokenizer("token1,token2\\,token3");
        assertTrue(tokenizer.hasMoreTokens());
        assertEquals("token1", tokenizer.nextToken());
        assertTrue(tokenizer.hasMoreTokens());
        assertEquals("token2,token3", tokenizer.nextToken());
        assertFalse(tokenizer.hasMoreTokens());
    }

    @Test
    public void testPropertiesTokenizerWithEscapedBackslash() throws Exception {
        ExtendedProperties.PropertiesTokenizer tokenizer = new ExtendedProperties.PropertiesTokenizer("token1\\\\,token2");
        assertTrue(tokenizer.hasMoreTokens());
        assertEquals("token1\\", tokenizer.nextToken()); // Unescapes the double backslash
        assertTrue(tokenizer.hasMoreTokens());
        assertEquals("token2", tokenizer.nextToken());
        assertFalse(tokenizer.hasMoreTokens());
    }

    @Test
    public void testPropertiesTokenizerEmptyToken() throws Exception {
        ExtendedProperties.PropertiesTokenizer tokenizer = new ExtendedProperties.PropertiesTokenizer("token1,,token2");
        assertTrue(tokenizer.hasMoreTokens());
        assertEquals("token1", tokenizer.nextToken());
        assertTrue(tokenizer.hasMoreTokens());
        assertEquals("", tokenizer.nextToken()); // Empty token between commas
        assertTrue(tokenizer.hasMoreTokens());
        assertEquals("token2", tokenizer.nextToken());
        assertFalse(tokenizer.hasMoreTokens());
    }
    
    @Test
    public void testDisplay() throws Exception {
        ExtendedProperties props = new ExtendedProperties();
        props.addProperty("key1", "value1");
        props.addProperty("key2", "value2");
        // The display method prints to System.out, so we can't assert directly without output redirection.
        // We'll just call it to ensure it doesn't throw an exception.
        props.display(); 
    }
    
    // Inner class to simulate ByteArrayInputStream for load methods
    private static class ByteArrayInputStream extends InputStream {
        private byte[] buf;
        private int pos;

        public ByteArrayInputStream(byte[] buf) {
            this.buf = buf;
        }

        @Override
        public int read() {
            if (pos < buf.length) {
                return buf[pos++];
            }
            return -1;
        }
    }
    
    // Inner class to simulate HashMap for putAll
    private static class HashMap<K, V> extends java.util.HashMap<K, V> {
        // no additional methods needed, just for type clarity
    }
}
