package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import com.google.common.base.Preconditions;
import com.google.common.base.Supplier;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.javascript.jscomp.ReferenceCollectingCallback.Behavior;
import com.google.javascript.jscomp.ReferenceCollectingCallback.Reference;
import com.google.javascript.jscomp.ReferenceCollectingCallback.ReferenceCollection;
import com.google.javascript.jscomp.ReferenceCollectingCallback.ReferenceMap;
import com.google.javascript.jscomp.Scope.Var;
import com.google.javascript.rhino.IR;
import com.google.javascript.rhino.Node;
import com.google.javascript.rhino.Token;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class InlineObjectLiteralsTest {
    @Test
    public void testEmptyScriptIsUnchanged() throws Exception {
        Compiler compiler = new Compiler();
        Node root = IR.script();
        new InlineObjectLiterals(compiler, new Supplier<String>() {
            public String get() { return "a"; }
        }).process(null, root);
        assertEquals(Token.SCRIPT, root.getType());
        assertFalse(root.hasChildren());
    }

    @Test
    public void testGlobalObjectDeclarationRemainsUnsplit() throws Exception {
        Compiler compiler = new Compiler();
        Node declaration = IR.var(IR.name("obj"),
                IR.objectlit(IR.propdef(IR.stringKey("x"), IR.number(1))));
        Node root = IR.script(declaration);
        new InlineObjectLiterals(compiler, new Supplier<String>() {
            public String get() { return "a"; }
        }).process(null, root);
        assertEquals(1, root.getChildAtIndex(0).getType() == Token.VAR ? 1 : 0);
        assertEquals("obj", root.getFirstChild().getFirstChild().getString());
    }

    @Test
    public void testGlobalObjectPropertyUseRemainsUnchanged() throws Exception {
        Compiler compiler = new Compiler();
        Node declaration = IR.var(IR.name("obj"),
                IR.objectlit(IR.propdef(IR.stringKey("x"), IR.number(2))));
        Node use = IR.exprResult(IR.getprop(IR.name("obj"), IR.string("x")));
        Node root = IR.script(declaration, use);
        new InlineObjectLiterals(compiler, new Supplier<String>() {
            public String get() { return "b"; }
        }).process(null, root);
        assertEquals(2, root.getChildAtIndex(0).getType() == Token.VAR ? 2 : 0);
        assertEquals(Token.GETPROP, root.getChildAtIndex(1).getFirstChild().getType());
    }

    @Test
    public void testGlobalObjectAssignedLaterRemainsUnchanged() throws Exception {
        Compiler compiler = new Compiler();
        Node declaration = IR.var(IR.name("obj"));
        Node assignment = IR.exprResult(IR.assign(IR.name("obj"),
                IR.objectlit(IR.propdef(IR.stringKey("x"), IR.number(3)))));
        Node root = IR.script(declaration, assignment);
        new InlineObjectLiterals(compiler, new Supplier<String>() {
            public String get() { return "c"; }
        }).process(null, root);
        assertEquals(Token.VAR, root.getFirstChild().getType());
        assertEquals(Token.EXPR_RESULT, root.getChildAtIndex(1).getType());
        assertEquals(Token.ASSIGN, root.getChildAtIndex(1).getFirstChild().getType());
    }

    @Test
    public void testGlobalObjectPassedToMethodRemainsUnchanged() throws Exception {
        Compiler compiler = new Compiler();
        Node declaration = IR.var(IR.name("obj"),
                IR.objectlit(IR.propdef(IR.stringKey("x"), IR.number(4))));
        Node call = IR.exprResult(IR.call(IR.getprop(IR.name("obj"), IR.string("x"))));
        Node root = IR.script(declaration, call);
        new InlineObjectLiterals(compiler, new Supplier<String>() {
            public String get() { return "d"; }
        }).process(null, root);
        assertEquals(Token.VAR, root.getFirstChild().getType());
        assertEquals(Token.CALL, root.getChildAtIndex(1).getFirstChild().getType());
    }

    @Test
    public void testGlobalDeletedPropertyRemainsUnchanged() throws Exception {
        Compiler compiler = new Compiler();
        Node declaration = IR.var(IR.name("obj"),
                IR.objectlit(IR.propdef(IR.stringKey("x"), IR.number(5))));
        Node deletion = IR.exprResult(new Node(Token.DELPROP,
                IR.getprop(IR.name("obj"), IR.string("x"))));
        Node root = IR.script(declaration, deletion);
        new InlineObjectLiterals(compiler, new Supplier<String>() {
            public String get() { return "e"; }
        }).process(null, root);
        assertEquals(Token.VAR, root.getFirstChild().getType());
        assertEquals(Token.DELPROP, root.getChildAtIndex(1).getFirstChild().getType());
    }

    @Test
    public void testGlobalUndefinedPropertyReadRemainsUnchanged() throws Exception {
        Compiler compiler = new Compiler();
        Node declaration = IR.var(IR.name("obj"),
                IR.objectlit(IR.propdef(IR.stringKey("x"), IR.number(6))));
        Node use = IR.exprResult(IR.getprop(IR.name("obj"), IR.string("missing")));
        Node root = IR.script(declaration, use);
        new InlineObjectLiterals(compiler, new Supplier<String>() {
            public String get() { return "f"; }
        }).process(null, root);
        assertEquals(Token.VAR, root.getFirstChild().getType());
        assertEquals("missing", root.getChildAtIndex(1).getFirstChild()
                .getLastChild().getString());
    }

    @Test
    public void testGlobalNonObjectAssignmentRemainsUnchanged() throws Exception {
        Compiler compiler = new Compiler();
        Node declaration = IR.var(IR.name("obj"), IR.number(7));
        Node root = IR.script(declaration);
        new InlineObjectLiterals(compiler, new Supplier<String>() {
            public String get() { return "g"; }
        }).process(null, root);
        assertEquals(Token.VAR, root.getFirstChild().getType());
        assertEquals(7.0, root.getFirstChild().getFirstChild()
                .getFirstChild().getDouble(), 0.0);
    }

    @Test
    public void testGlobalUninitializedDeclarationRemainsPresent() throws Exception {
        Compiler compiler = new Compiler();
        Node root = IR.script(IR.var(IR.name("obj")));
        new InlineObjectLiterals(compiler, new Supplier<String>() {
            public String get() { return "h"; }
        }).process(null, root);
        assertEquals(Token.VAR, root.getFirstChild().getType());
        assertEquals("obj", root.getFirstChild().getFirstChild().getString());
    }

    @Test
    public void testMultipleGlobalVariablesRemainInOrder() throws Exception {
        Compiler compiler = new Compiler();
        Node root = IR.script(
                IR.var(IR.name("first"), IR.objectlit()),
                IR.var(IR.name("second"), IR.objectlit()));
        new InlineObjectLiterals(compiler, new Supplier<String>() {
            public String get() { return "i"; }
        }).process(null, root);
        assertEquals(2, root.getChildAtIndex(0).getFirstChild().getString()
                .equals("first") ? 2 : 0);
        assertEquals("second", root.getChildAtIndex(1).getFirstChild().getString());
    }

    @Test
    public void testEmptyObjectDeclarationRemainsGlobal() throws Exception {
        Compiler compiler = new Compiler();
        Node root = IR.script(IR.var(IR.name("obj"), IR.objectlit()));
        new InlineObjectLiterals(compiler, new Supplier<String>() {
            public String get() { return "j"; }
        }).process(null, root);
        assertEquals(Token.VAR, root.getFirstChild().getType());
        assertEquals("obj", root.getFirstChild().getFirstChild().getString());
    }

    @Test
    public void testObjectWithTwoPropertiesRemainsGlobal() throws Exception {
        Compiler compiler = new Compiler();
        Node object = IR.objectlit(
                IR.propdef(IR.stringKey("left"), IR.number(1)),
                IR.propdef(IR.stringKey("right"), IR.number(2)));
        Node root = IR.script(IR.var(IR.name("obj"), object));
        new InlineObjectLiterals(compiler, new Supplier<String>() {
            public String get() { return "k"; }
        }).process(null, root);
        assertEquals(2, root.getFirstChild().getFirstChild().getFirstChild()
                .getNext().getString().equals("right") ? 2 : 0);
    }
}
