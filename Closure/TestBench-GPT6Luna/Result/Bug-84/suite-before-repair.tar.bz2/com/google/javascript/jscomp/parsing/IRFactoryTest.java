package com.google.javascript.jscomp.parsing;

import org.junit.Test;
import static org.junit.Assert.*;
import com.google.common.collect.Sets;
import com.google.javascript.jscomp.mozilla.rhino.ErrorReporter;
import com.google.javascript.jscomp.mozilla.rhino.ast.ArrayLiteral;
import com.google.javascript.jscomp.mozilla.rhino.ast.Assignment;
import com.google.javascript.jscomp.mozilla.rhino.ast.AstNode;
import com.google.javascript.jscomp.mozilla.rhino.ast.AstRoot;
import com.google.javascript.jscomp.mozilla.rhino.ast.Block;
import com.google.javascript.jscomp.mozilla.rhino.ast.BreakStatement;
import com.google.javascript.jscomp.mozilla.rhino.ast.CatchClause;
import com.google.javascript.jscomp.mozilla.rhino.ast.Comment;
import com.google.javascript.jscomp.mozilla.rhino.ast.ConditionalExpression;
import com.google.javascript.jscomp.mozilla.rhino.ast.ContinueStatement;
import com.google.javascript.jscomp.mozilla.rhino.ast.DoLoop;
import com.google.javascript.jscomp.mozilla.rhino.ast.ElementGet;
import com.google.javascript.jscomp.mozilla.rhino.ast.EmptyExpression;
import com.google.javascript.jscomp.mozilla.rhino.ast.ExpressionStatement;
import com.google.javascript.jscomp.mozilla.rhino.ast.ForInLoop;
import com.google.javascript.jscomp.mozilla.rhino.ast.ForLoop;
import com.google.javascript.jscomp.mozilla.rhino.ast.FunctionCall;
import com.google.javascript.jscomp.mozilla.rhino.ast.FunctionNode;
import com.google.javascript.jscomp.mozilla.rhino.ast.IfStatement;
import com.google.javascript.jscomp.mozilla.rhino.ast.InfixExpression;
import com.google.javascript.jscomp.mozilla.rhino.ast.KeywordLiteral;
import com.google.javascript.jscomp.mozilla.rhino.ast.Label;
import com.google.javascript.jscomp.mozilla.rhino.ast.LabeledStatement;
import com.google.javascript.jscomp.mozilla.rhino.ast.Name;
import com.google.javascript.jscomp.mozilla.rhino.ast.NewExpression;
import com.google.javascript.jscomp.mozilla.rhino.ast.NumberLiteral;
import com.google.javascript.jscomp.mozilla.rhino.ast.ObjectLiteral;
import com.google.javascript.jscomp.mozilla.rhino.ast.ObjectProperty;
import com.google.javascript.jscomp.mozilla.rhino.ast.ParenthesizedExpression;
import com.google.javascript.jscomp.mozilla.rhino.ast.PropertyGet;
import com.google.javascript.jscomp.mozilla.rhino.ast.RegExpLiteral;
import com.google.javascript.jscomp.mozilla.rhino.ast.ReturnStatement;
import com.google.javascript.jscomp.mozilla.rhino.ast.Scope;
import com.google.javascript.jscomp.mozilla.rhino.ast.StringLiteral;
import com.google.javascript.jscomp.mozilla.rhino.ast.SwitchCase;
import com.google.javascript.jscomp.mozilla.rhino.ast.SwitchStatement;
import com.google.javascript.jscomp.mozilla.rhino.ast.ThrowStatement;
import com.google.javascript.jscomp.mozilla.rhino.ast.TryStatement;
import com.google.javascript.jscomp.mozilla.rhino.ast.UnaryExpression;
import com.google.javascript.jscomp.mozilla.rhino.ast.VariableDeclaration;
import com.google.javascript.jscomp.mozilla.rhino.ast.VariableInitializer;
import com.google.javascript.jscomp.mozilla.rhino.ast.WhileLoop;
import com.google.javascript.jscomp.mozilla.rhino.ast.WithStatement;
import com.google.javascript.rhino.JSDocInfo;
import com.google.javascript.rhino.Node;
import com.google.javascript.rhino.Token;
import java.util.Set;

public class IRFactoryTest {
    private static final int EMPTY = com.google.javascript.jscomp.mozilla.rhino.Token.EMPTY;
    private static final int STRING = com.google.javascript.jscomp.mozilla.rhino.Token.STRING;
    private static final int NAME = com.google.javascript.jscomp.mozilla.rhino.Token.NAME;
    private static final int NUMBER = com.google.javascript.jscomp.mozilla.rhino.Token.NUMBER;

    private static Config config() {
        return new Config(Sets.<String>newHashSet(), Sets.<String>newHashSet(),
                false, true);
    }

    private static AstRoot root() {
        AstRoot root = new AstRoot();
        root.setSourceName("test.js");
        return root;
    }

    private static Node transform(AstRoot root, ErrorReporter reporter) {
        return IRFactory.transformTree(root, "", config(), reporter);
    }

    @Test
    public void testEmptyRootBecomesScript() throws Exception {
        Node result = transform(root(), null);
        assertEquals(Token.SCRIPT, result.getType());
        assertFalse(result.hasChildren());
    }

    @Test
    public void testNameExpressionTransformsToScriptExpression() throws Exception {
        AstRoot root = root();
        ExpressionStatement statement = new ExpressionStatement();
        Name name = new Name();
        name.setIdentifier("x");
        statement.setExpression(name);
        root.addChildToBack(statement);

        Node result = transform(root, null);
        assertEquals(Token.SCRIPT, result.getType());
        assertEquals(Token.EXPR_RESULT, result.getFirstChild().getType());
        assertEquals(NAME, result.getFirstChild().getFirstChild().getType());
        assertEquals("x", result.getFirstChild().getFirstChild().getString());
    }

    @Test
    public void testStringExpressionRemainsInExpressionStatement() throws Exception {
        AstRoot root = root();
        ExpressionStatement statement = new ExpressionStatement();
        StringLiteral literal = new StringLiteral();
        literal.setValue("hello");
        statement.setExpression(literal);
        root.addChildToBack(statement);

        Node result = transform(root, null);
        assertEquals(Token.EXPR_RESULT, result.getFirstChild().getType());
        assertEquals(STRING, result.getFirstChild().getFirstChild().getType());
        assertEquals("hello", result.getFirstChild().getFirstChild().getString());
    }

    @Test
    public void testNegativeNumberLiteralIsFolded() throws Exception {
        AstRoot root = root();
        UnaryExpression negative = new UnaryExpression();
        negative.setType(com.google.javascript.jscomp.mozilla.rhino.Token.NEG);
        NumberLiteral number = new NumberLiteral();
        number.setNumber(7.0);
        negative.setOperand(number);
        ExpressionStatement statement = new ExpressionStatement();
        statement.setExpression(negative);
        root.addChildToBack(statement);

        Node value = transform(root, null).getFirstChild().getFirstChild();
        assertEquals(NUMBER, value.getType());
        assertEquals(-7.0, value.getDouble(), 0.0);
    }

    @Test
    public void testPositiveZeroNegativeNumberIsFolded() throws Exception {
        AstRoot root = root();
        UnaryExpression negative = new UnaryExpression();
        negative.setType(com.google.javascript.jscomp.mozilla.rhino.Token.NEG);
        NumberLiteral number = new NumberLiteral();
        number.setNumber(0.0);
        negative.setOperand(number);
        ExpressionStatement statement = new ExpressionStatement();
        statement.setExpression(negative);
        root.addChildToBack(statement);

        Node value = transform(root, null).getFirstChild().getFirstChild();
        assertEquals(NUMBER, value.getType());
        assertEquals(0.0, value.getDouble(), 0.0);
    }

    @Test
    public void testEmptyArrayHasNoChildren() throws Exception {
        AstRoot root = root();
        ExpressionStatement statement = new ExpressionStatement();
        statement.setExpression(new ArrayLiteral());
        root.addChildToBack(statement);

        Node array = transform(root, null).getFirstChild().getFirstChild();
        assertEquals(Token.ARRAYLIT, array.getType());
        assertFalse(array.hasChildren());
    }

    @Test
    public void testArrayHoleIsRecordedAsSkippedIndex() throws Exception {
        AstRoot root = root();
        ArrayLiteral array = new ArrayLiteral();
        EmptyExpression hole = new EmptyExpression();
        array.addElement(hole);
        ExpressionStatement statement = new ExpressionStatement();
        statement.setExpression(array);
        root.addChildToBack(statement);

        Node result = transform(root, null).getFirstChild().getFirstChild();
        assertEquals(Token.ARRAYLIT, result.getType());
        assertFalse(result.hasChildren());
        assertArrayEquals(new int[] {0}, (int[]) result.getProp(Node.SKIP_INDEXES_PROP));
    }

    @Test
    public void testArrayHoleBeforeValuePreservesSkipIndex() throws Exception {
        AstRoot root = root();
        ArrayLiteral array = new ArrayLiteral();
        array.addElement(new EmptyExpression());
        NumberLiteral number = new NumberLiteral();
        number.setNumber(3.0);
        array.addElement(number);
        ExpressionStatement statement = new ExpressionStatement();
        statement.setExpression(array);
        root.addChildToBack(statement);

        Node result = transform(root, null).getFirstChild().getFirstChild();
        assertArrayEquals(new int[] {0}, (int[]) result.getProp(Node.SKIP_INDEXES_PROP));
        assertEquals(NUMBER, result.getFirstChild().getType());
        assertEquals(3.0, result.getFirstChild().getDouble(), 0.0);
    }

    @Test
    public void testUnquotedObjectKeyBecomesStringKey() throws Exception {
        AstRoot root = root();
        ObjectLiteral object = new ObjectLiteral();
        ObjectProperty property = new ObjectProperty();
        Name key = new Name();
        key.setIdentifier("key");
        NumberLiteral number = new NumberLiteral();
        number.setNumber(2.0);
        property.setLeft(key);
        property.setRight(number);
        object.addElement(property);
        ExpressionStatement statement = new ExpressionStatement();
        statement.setExpression(object);
        root.addChildToBack(statement);

        Node entry = transform(root, null).getFirstChild()
                .getFirstChild().getFirstChild();
        assertEquals(STRING, entry.getType());
        assertEquals("key", entry.getString());
        assertEquals(NUMBER, entry.getFirstChild().getType());
    }

    @Test
    public void testQuotedObjectKeyRemainsQuoted() throws Exception {
        AstRoot root = root();
        ObjectLiteral object = new ObjectLiteral();
        ObjectProperty property = new ObjectProperty();
        StringLiteral key = new StringLiteral();
        key.setValue("key");
        NumberLiteral number = new NumberLiteral();
        number.setNumber(2.0);
        property.setLeft(key);
        property.setRight(number);
        object.addElement(property);
        ExpressionStatement statement = new ExpressionStatement();
        statement.setExpression(object);
        root.addChildToBack(statement);

        Node entry = transform(root, null).getFirstChild()
                .getFirstChild().getFirstChild();
        assertEquals(STRING, entry.getType());
        assertTrue(entry.getBooleanProp(Node.QUOTED_PROP));
        assertEquals("key", entry.getString());
    }

    @Test
    public void testPropertyAccessTransformsToGetprop() throws Exception {
        AstRoot root = root();
        PropertyGet get = new PropertyGet();
        Name target = new Name();
        target.setIdentifier("obj");
        Name property = new Name();
        property.setIdentifier("field");
        get.setTarget(target);
        get.setProperty(property);
        ExpressionStatement statement = new ExpressionStatement();
        statement.setExpression(get);
        root.addChildToBack(statement);

        Node result = transform(root, null).getFirstChild().getFirstChild();
        assertEquals(Token.GETPROP, result.getType());
        assertEquals("obj", result.getFirstChild().getString());
        assertEquals(STRING, result.getLastChild().getType());
        assertEquals("field", result.getLastChild().getString());
    }

    @Test
    public void testElementAccessTransformsToGetelem() throws Exception {
        AstRoot root = root();
        ElementGet get = new ElementGet();
        Name target = new Name();
        target.setIdentifier("arr");
        NumberLiteral index = new NumberLiteral();
        index.setNumber(0.0);
        get.setTarget(target);
        get.setElement(index);
        ExpressionStatement statement = new ExpressionStatement();
        statement.setExpression(get);
        root.addChildToBack(statement);

        Node result = transform(root, null).getFirstChild().getFirstChild();
        assertEquals(Token.GETELEM, result.getType());
        assertEquals("arr", result.getFirstChild().getString());
        assertEquals(0.0, result.getLastChild().getDouble(), 0.0);
    }

    @Test
    public void testConditionalExpressionHasThreeOperands() throws Exception {
        AstRoot root = root();
        ConditionalExpression conditional = new ConditionalExpression();
        Name condition = new Name();
        condition.setIdentifier("c");
        NumberLiteral yes = new NumberLiteral();
        yes.setNumber(1.0);
        NumberLiteral no = new NumberLiteral();
        no.setNumber(2.0);
        conditional.setTestExpression(condition);
        conditional.setTrueExpression(yes);
        conditional.setFalseExpression(no);
        ExpressionStatement statement = new ExpressionStatement();
        statement.setExpression(conditional);
        root.addChildToBack(statement);

        Node result = transform(root, null).getFirstChild().getFirstChild();
        assertEquals(Token.HOOK, result.getType());
        assertEquals("c", result.getFirstChild().getString());
        assertEquals(1.0, result.getChildAtIndex(1).getDouble(), 0.0);
        assertEquals(2.0, result.getLastChild().getDouble(), 0.0);
    }

    @Test
    public void testParenthesizedExpressionSetsParenthesizedProperty() throws Exception {
        AstRoot root = root();
        ParenthesizedExpression expression = new ParenthesizedExpression();
        Name name = new Name();
        name.setIdentifier("x");
        expression.setExpression(name);
        ExpressionStatement statement = new ExpressionStatement();
        statement.setExpression(expression);
        root.addChildToBack(statement);

        Node result = transform(root, null).getFirstChild().getFirstChild();
        assertEquals(NAME, result.getType());
        assertTrue(result.getBooleanProp(Node.PARENTHESIZED_PROP));
        assertEquals("x", result.getString());
    }

    @Test
    public void testRegExpWithoutFlagsHasOnlyPatternChild() throws Exception {
        AstRoot root = root();
        RegExpLiteral regexp = new RegExpLiteral();
        regexp.setValue("/a/");
        regexp.setFlags("");
        ExpressionStatement statement = new ExpressionStatement();
        statement.setExpression(regexp);
        root.addChildToBack(statement);

        Node result = transform(root, null).getFirstChild().getFirstChild();
        assertEquals(Token.REGEXP, result.getType());
        assertEquals("/a/", result.getFirstChild().getString());
        assertNull(result.getFirstChild().getNext());
    }

    @Test
    public void testRegExpWithFlagsHasPatternAndFlags() throws Exception {
        AstRoot root = root();
        RegExpLiteral regexp = new RegExpLiteral();
        regexp.setValue("/a/");
        regexp.setFlags("g");
        ExpressionStatement statement = new ExpressionStatement();
        statement.setExpression(regexp);
        root.addChildToBack(statement);

        Node result = transform(root, null).getFirstChild().getFirstChild();
        assertEquals("/a/", result.getFirstChild().getString());
        assertEquals("g", result.getLastChild().getString());
    }

    @Test
    public void testEmptyReturnHasNoValueChild() throws Exception {
        AstRoot root = root();
        ReturnStatement statement = new ReturnStatement();
        root.addChildToBack(statement);

        Node result = transform(root, null).getFirstChild();
        assertEquals(Token.RETURN, result.getType());
        assertFalse(result.hasChildren());
    }

    @Test
    public void testReturnValueIsTransformedAsChild() throws Exception {
        AstRoot root = root();
        ReturnStatement statement = new ReturnStatement();
        NumberLiteral number = new NumberLiteral();
        number.setNumber(4.0);
        statement.setReturnValue(number);
        root.addChildToBack(statement);

        Node result = transform(root, null).getFirstChild();
        assertEquals(Token.RETURN, result.getType());
        assertEquals(4.0, result.getFirstChild().getDouble(), 0.0);
    }

    @Test
    public void testBlockExpressionTransformsToBlock() throws Exception {
        AstRoot root = root();
        Block block = new Block();
        ExpressionStatement statement = new ExpressionStatement();
        Name name = new Name();
        name.setIdentifier("x");
        statement.setExpression(name);
        block.addChildToBack(statement);
        root.addChildToBack(block);

        Node result = transform(root, null).getFirstChild();
        assertEquals(Token.BLOCK, result.getType());
        assertEquals(Token.EXPR_RESULT, result.getFirstChild().getType());
    }

    @Test
    public void testUnaryIncrementPreservesPrefixForm() throws Exception {
        AstRoot root = root();
        UnaryExpression expression = new UnaryExpression();
        expression.setType(com.google.javascript.jscomp.mozilla.rhino.Token.INC);
        Name name = new Name();
        name.setIdentifier("x");
        expression.setOperand(name);
        expression.setIsPostfix(false);
        ExpressionStatement statement = new ExpressionStatement();
        statement.setExpression(expression);
        root.addChildToBack(statement);

        Node result = transform(root, null).getFirstChild().getFirstChild();
        assertEquals(Token.INC, result.getType());
        assertFalse(result.getBooleanProp(Node.INCRDECR_PROP));
        assertEquals("x", result.getFirstChild().getString());
    }

    @Test
    public void testUnaryIncrementMarksPostfixForm() throws Exception {
        AstRoot root = root();
        UnaryExpression expression = new UnaryExpression();
        expression.setType(com.google.javascript.jscomp.mozilla.rhino.Token.INC);
        Name name = new Name();
        name.setIdentifier("x");
        expression.setOperand(name);
        expression.setIsPostfix(true);
        ExpressionStatement statement = new ExpressionStatement();
        statement.setExpression(expression);
        root.addChildToBack(statement);

        Node result = transform(root, null).getFirstChild().getFirstChild();
        assertEquals(Token.INC, result.getType());
        assertTrue(result.getBooleanProp(Node.INCRDECR_PROP));
    }
}
