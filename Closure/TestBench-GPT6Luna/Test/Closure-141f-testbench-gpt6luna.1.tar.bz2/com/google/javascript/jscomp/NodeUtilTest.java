package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import com.google.common.base.Preconditions;
import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import com.google.common.collect.Maps;
import com.google.javascript.rhino.FunctionNode;
import com.google.javascript.rhino.JSDocInfo;
import com.google.javascript.rhino.Node;
import com.google.javascript.rhino.Token;
import com.google.javascript.rhino.TokenStream;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.google.javascript.jscomp.DefinitionsRemover.Definition;
import com.google.javascript.jscomp.NodeTraversal.Callback;
import com.google.javascript.jscomp.Scope.Var;
import com.google.javascript.jscomp.graph.DiGraph;
import com.google.javascript.jscomp.graph.FixedPointGraphTraversal;
import com.google.javascript.jscomp.graph.FixedPointGraphTraversal.EdgeCallback;
import com.google.javascript.jscomp.graph.LinkedDirectedGraph;

public class NodeUtilTest {
    @Test
    public void testNewExprWrapsChild() throws Exception {
        Node child = Node.newNumber(3);
        Node expr = NodeUtil.newExpr(child);
        assertEquals(Token.EXPR_RESULT, expr.getType());
        assertSame(child, expr.getFirstChild());
    }

    @Test
    public void testNewQualifiedNameSingleName() throws Exception {
        Node name = NodeUtil.newQualifiedNameNode("alpha", 2, 3);
        assertEquals(Token.NAME, name.getType());
        assertEquals("alpha", name.getString());
    }

    @Test
    public void testNewQualifiedNameTwoParts() throws Exception {
        Node qualified = NodeUtil.newQualifiedNameNode("alpha.beta", 2, 3);
        assertEquals("alpha.beta", qualified.getQualifiedName());
        assertEquals(Token.GETPROP, qualified.getType());
    }

    @Test
    public void testNewQualifiedNameThreeParts() throws Exception {
        Node qualified = NodeUtil.newQualifiedNameNode("a.b.c", 0, 0);
        assertEquals("a.b.c", qualified.getQualifiedName());
        assertEquals("c", qualified.getLastChild().getString());
    }

    @Test
    public void testNewFunctionNodeCreatesFunctionAndBody() throws Exception {
        Node body = new Node(Token.BLOCK);
        FunctionNode function = NodeUtil.newFunctionNode(
                "f", Collections.<Node>emptyList(), body, 1, 2);
        assertEquals(Token.FUNCTION, function.getType());
        assertEquals("f", function.getFirstChild().getString());
        assertSame(body, function.getLastChild());
    }

    @Test
    public void testGetVarsDeclaredInBranchCollectsDeclarations() throws Exception {
        Node root = new Node(Token.BLOCK);
        Node var = new Node(Token.VAR, Node.newString(Token.NAME, "item"));
        root.addChildToBack(var);
        Collection<Node> vars = NodeUtil.getVarsDeclaredInBranch(root);
        assertEquals(1, vars.size());
        assertSame(var.getFirstChild(), vars.iterator().next());
    }

    @Test
    public void testGetVarsDeclaredInBranchKeepsFirstDuplicate() throws Exception {
        Node root = new Node(Token.BLOCK);
        Node firstVar = new Node(Token.VAR, Node.newString(Token.NAME, "item"));
        Node secondVar = new Node(Token.VAR, Node.newString(Token.NAME, "item"));
        root.addChildToBack(firstVar);
        root.addChildToBack(secondVar);
        Collection<Node> vars = NodeUtil.getVarsDeclaredInBranch(root);
        assertEquals(1, vars.size());
        assertSame(firstVar.getFirstChild(), vars.iterator().next());
    }

    @Test
    public void testGetVarsDeclaredInBranchDoesNotEnterFunction() throws Exception {
        Node root = new Node(Token.BLOCK);
        Node body = new Node(Token.BLOCK);
        body.addChildToBack(
                new Node(Token.VAR, Node.newString(Token.NAME, "inner")));
        Node function = new Node(Token.FUNCTION,
                Node.newString(Token.NAME, "f"),
                new Node(Token.LP),
                body);
        root.addChildToBack(
                new Node(Token.VAR, Node.newString(Token.NAME, "outer")));
        root.addChildToBack(function);
        Collection<Node> vars = NodeUtil.getVarsDeclaredInBranch(root);
        assertEquals(1, vars.size());
        assertEquals("outer", vars.iterator().next().getString());
    }

    @Test
    public void testGetVarsDeclaredInBranchEmptyTree() throws Exception {
        assertEquals(0, NodeUtil.getVarsDeclaredInBranch(
                new Node(Token.BLOCK)).size());
    }

    @Test
    public void testNodeUtilPublicMethodEntryPointAvailable() throws Exception {
        Node empty = new Node(Token.BLOCK);
        assertEquals(0, NodeUtil.getVarsDeclaredInBranch(empty).size());
    }

    @Test
    public void testQualifiedNameSinglePartHasNoChildren() throws Exception {
        Node name = NodeUtil.newQualifiedNameNode("x", 0, 0);
        assertEquals(0, name.getChildCount());
    }

    @Test
    public void testQualifiedNamePartsAreNested() throws Exception {
        Node name = NodeUtil.newQualifiedNameNode("a.b.c", 0, 0);
        assertEquals(Token.GETPROP, name.getFirstChild().getType());
        assertEquals("a", name.getFirstChild().getFirstChild().getString());
    }

    @Test
    public void testProcessRejectsSecondInvocation() throws Exception {
        PureFunctionIdentifier pass =
                new PureFunctionIdentifier(null, null);
        Node externs = new Node(Token.SCRIPT);
        Node source = new Node(Token.SCRIPT);
        pass.process(externs, source);
        try {
            pass.process(new Node(Token.SCRIPT), new Node(Token.SCRIPT));
            fail("expected IllegalStateException");
        } catch (IllegalStateException expected) {
        }
    }
}
