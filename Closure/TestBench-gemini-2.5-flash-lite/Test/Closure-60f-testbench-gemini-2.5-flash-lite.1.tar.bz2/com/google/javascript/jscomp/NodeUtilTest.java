package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import com.google.common.base.Preconditions;
import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Maps;
import com.google.javascript.rhino.JSDocInfo;
import com.google.javascript.rhino.Node;
import com.google.javascript.rhino.Token;
import com.google.javascript.rhino.TokenStream;
import com.google.javascript.rhino.jstype.FunctionType;
import com.google.javascript.rhino.jstype.JSType;
import com.google.javascript.rhino.jstype.TernaryValue;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.Nullable;

public class NodeUtilTest {
    // test methods (as many as the instructions ask for), each exactly in this form:
    //     @Test
    //     public void testWhatItChecks() throws Exception { ... }

    @Test
    public void testGetImpureBooleanValue_stringLiteralTrue() throws Exception {
        Node n = Node.newString("hello");
        assertEquals(TernaryValue.TRUE, NodeUtil.getImpureBooleanValue(n));
    }

    @Test
    public void testGetImpureBooleanValue_stringLiteralFalse() throws Exception {
        Node n = Node.newString("");
        assertEquals(TernaryValue.FALSE, NodeUtil.getImpureBooleanValue(n));
    }

    @Test
    public void testGetImpureBooleanValue_numberLiteralTrue() throws Exception {
        Node n = Node.newNumber(123.45);
        assertEquals(TernaryValue.TRUE, NodeUtil.getImpureBooleanValue(n));
    }

    @Test
    public void testGetImpureBooleanValue_numberLiteralFalse() throws Exception {
        Node n = Node.newNumber(0);
        assertEquals(TernaryValue.FALSE, NodeUtil.getImpureBooleanValue(n));
    }

    @Test
    public void testGetImpureBooleanValue_trueLiteral() throws Exception {
        Node n = new Node(Token.TRUE);
        assertEquals(TernaryValue.TRUE, NodeUtil.getImpureBooleanValue(n));
    }

    @Test
    public void testGetImpureBooleanValue_falseLiteral() throws Exception {
        Node n = new Node(Token.FALSE);
        assertEquals(TernaryValue.FALSE, NodeUtil.getImpureBooleanValue(n));
    }

    @Test
    public void testGetImpureBooleanValue_nullLiteral() throws Exception {
        Node n = new Node(Token.NULL);
        assertEquals(TernaryValue.FALSE, NodeUtil.getImpureBooleanValue(n));
    }

    @Test
    public void testGetImpureBooleanValue_undefinedName() {}
// Defects4J: flaky method
//     @Test
//     public void testGetImpureBooleanValue_undefinedName() throws Exception {
//         Node n = Node.newString("undefined");
//         assertEquals(TernaryValue.FALSE, NodeUtil.getImpureBooleanValue(n));
//     }

    @Test
    public void testGetImpureBooleanValue_nanName() {}
// Defects4J: flaky method
//     @Test
//     public void testGetImpureBooleanValue_nanName() throws Exception {
//         Node n = Node.newString("NaN");
//         assertEquals(TernaryValue.FALSE, NodeUtil.getImpureBooleanValue(n));
//     }

    @Test
    public void testGetImpureBooleanValue_infinityName() throws Exception {
        Node n = Node.newString("Infinity");
        assertEquals(TernaryValue.TRUE, NodeUtil.getImpureBooleanValue(n));
    }

    @Test
    public void testGetImpureBooleanValue_notOperator() throws Exception {
        Node trueNode = Node.newString("a");
        Node notTrueNode = new Node(Token.NOT, trueNode);
        assertEquals(TernaryValue.FALSE, NodeUtil.getImpureBooleanValue(notTrueNode));

        Node falseNode = Node.newString("");
        Node notFalseNode = new Node(Token.NOT, falseNode);
        assertEquals(TernaryValue.TRUE, NodeUtil.getImpureBooleanValue(notFalseNode));
    }

    @Test
    public void testGetImpureBooleanValue_andOperator() throws Exception {
        Node lhsTrue = Node.newString("a");
        Node rhsTrue = Node.newString("b");
        Node andTrue = new Node(Token.AND, lhsTrue, rhsTrue);
        assertEquals(TernaryValue.TRUE, NodeUtil.getImpureBooleanValue(andTrue));

        Node lhsFalse = Node.newString("");
        Node rhsFalse = Node.newString("b");
        Node andFalse = new Node(Token.AND, lhsFalse, rhsFalse);
        assertEquals(TernaryValue.FALSE, NodeUtil.getImpureBooleanValue(andFalse));
    }

    @Test
    public void testGetImpureBooleanValue_orOperator() throws Exception {
        Node lhsTrue = Node.newString("a");
        Node rhsTrue = Node.newString("b");
        Node orTrue = new Node(Token.OR, lhsTrue, rhsTrue);
        assertEquals(TernaryValue.TRUE, NodeUtil.getImpureBooleanValue(orTrue));

        Node lhsFalse = Node.newString("");
        Node rhsFalse = Node.newString("");
        Node orFalse = new Node(Token.OR, lhsFalse, rhsFalse);
        assertEquals(TernaryValue.FALSE, NodeUtil.getImpureBooleanValue(orFalse));
    }

    @Test
    public void testGetImpureBooleanValue_hookOperatorSame() throws Exception {
        Node condition = Node.newString("a");
        Node trueVal = Node.newString("b");
        Node falseVal = Node.newString("b");
        Node hook = new Node(Token.HOOK, condition, trueVal, falseVal);
        assertEquals(TernaryValue.TRUE, NodeUtil.getImpureBooleanValue(hook));
    }

    @Test
    public void testGetImpureBooleanValue_hookOperatorDifferent() {}
// Defects4J: flaky method
//     @Test
//     public void testGetImpureBooleanValue_hookOperatorDifferent() throws Exception {
//         Node condition = Node.newString("a");
//         Node trueVal = Node.newString("b");
//         Node falseVal = Node.newString("c");
//         Node hook = new Node(Token.HOOK, condition, trueVal, falseVal);
//         assertEquals(TernaryValue.UNKNOWN, NodeUtil.getImpureBooleanValue(hook));
//     }

    @Test
    public void testGetImpureBooleanValue_arrayLiteral() throws Exception {
        Node n = new Node(Token.ARRAYLIT);
        assertEquals(TernaryValue.TRUE, NodeUtil.getImpureBooleanValue(n));
    }

    @Test
    public void testGetImpureBooleanValue_objectLiteral() throws Exception {
        Node n = new Node(Token.OBJECTLIT);
        assertEquals(TernaryValue.TRUE, NodeUtil.getImpureBooleanValue(n));
    }

    @Test
    public void testGetImpureBooleanValue_voidOperator() throws Exception {
        Node expr = Node.newNumber(1);
        Node voidNode = new Node(Token.VOID, expr);
        assertEquals(TernaryValue.FALSE, NodeUtil.getImpureBooleanValue(voidNode));
    }

    @Test
    public void testGetPureBooleanValue_stringLiteralTrue() throws Exception {
        Node n = Node.newString("a");
        assertEquals(TernaryValue.TRUE, NodeUtil.getPureBooleanValue(n));
    }

    @Test
    public void testGetPureBooleanValue_stringLiteralFalse() throws Exception {
        Node n = Node.newString("");
        assertEquals(TernaryValue.FALSE, NodeUtil.getPureBooleanValue(n));
    }

    @Test
    public void testGetPureBooleanValue_numberLiteralTrue() throws Exception {
        Node n = Node.newNumber(1);
        assertEquals(TernaryValue.TRUE, NodeUtil.getPureBooleanValue(n));
    }

    @Test
    public void testGetPureBooleanValue_numberLiteralFalse() throws Exception {
        Node n = Node.newNumber(0);
        assertEquals(TernaryValue.FALSE, NodeUtil.getPureBooleanValue(n));
    }

    @Test
    public void testGetPureBooleanValue_notOperator() throws Exception {
        Node trueNode = Node.newString("a");
        Node notTrueNode = new Node(Token.NOT, trueNode);
        assertEquals(TernaryValue.FALSE, NodeUtil.getPureBooleanValue(notTrueNode));

        Node falseNode = Node.newString("");
        Node notFalseNode = new Node(Token.NOT, falseNode);
        assertEquals(TernaryValue.TRUE, NodeUtil.getPureBooleanValue(notFalseNode));
    }

    @Test
    public void testGetPureBooleanValue_trueLiteral() throws Exception {
        Node n = new Node(Token.TRUE);
        assertEquals(TernaryValue.TRUE, NodeUtil.getPureBooleanValue(n));
    }

    @Test
    public void testGetPureBooleanValue_falseLiteral() throws Exception {
        Node n = new Node(Token.FALSE);
        assertEquals(TernaryValue.FALSE, NodeUtil.getPureBooleanValue(n));
    }

    @Test
    public void testGetPureBooleanValue_nullLiteral() throws Exception {
        Node n = new Node(Token.NULL);
        assertEquals(TernaryValue.FALSE, NodeUtil.getPureBooleanValue(n));
    }

    @Test
    public void testGetPureBooleanValue_undefinedName() {}
// Defects4J: flaky method
//     @Test
//     public void testGetPureBooleanValue_undefinedName() throws Exception {
//         Node n = Node.newString("undefined");
//         assertEquals(TernaryValue.FALSE, NodeUtil.getPureBooleanValue(n));
//     }

    @Test
    public void testGetPureBooleanValue_nanName() {}
// Defects4J: flaky method
//     @Test
//     public void testGetPureBooleanValue_nanName() throws Exception {
//         Node n = Node.newString("NaN");
//         assertEquals(TernaryValue.FALSE, NodeUtil.getPureBooleanValue(n));
//     }

    @Test
    public void testGetPureBooleanValue_infinityName() throws Exception {
        Node n = Node.newString("Infinity");
        assertEquals(TernaryValue.TRUE, NodeUtil.getPureBooleanValue(n));
    }

    @Test
    public void testGetPureBooleanValue_arrayLiteral() throws Exception {
        Node n = new Node(Token.ARRAYLIT);
        assertEquals(TernaryValue.TRUE, NodeUtil.getPureBooleanValue(n));
    }

    @Test
    public void testGetPureBooleanValue_objectLiteral() throws Exception {
        Node n = new Node(Token.OBJECTLIT);
        assertEquals(TernaryValue.TRUE, NodeUtil.getPureBooleanValue(n));
    }

    @Test
    public void testGetPureBooleanValue_voidOperatorNoSideEffects() throws Exception {
        Node child = Node.newNumber(0);
        Node voidNode = new Node(Token.VOID, child);
        assertEquals(TernaryValue.FALSE, NodeUtil.getPureBooleanValue(voidNode));
    }

    @Test
    public void testGetStringValue_stringLiteral() throws Exception {
        Node n = Node.newString("test");
        assertEquals("test", NodeUtil.getStringValue(n));
    }

    @Test
    public void testGetStringValue_emptyStringLiteral() throws Exception {
        Node n = Node.newString("");
        assertEquals("", NodeUtil.getStringValue(n));
    }

    @Test
    public void testGetStringValue_numberLiteralInteger() throws Exception {
        Node n = Node.newNumber(123);
        assertEquals("123", NodeUtil.getStringValue(n));
    }

    @Test
    public void testGetStringValue_numberLiteralDouble() throws Exception {
        Node n = Node.newNumber(123.45);
        assertEquals("123.45", NodeUtil.getStringValue(n));
    }

    @Test
    public void testGetStringValue_trueLiteral() throws Exception {
        Node n = new Node(Token.TRUE);
        assertEquals("true", NodeUtil.getStringValue(n));
    }

    @Test
    public void testGetStringValue_falseLiteral() throws Exception {
        Node n = new Node(Token.FALSE);
        assertEquals("false", NodeUtil.getStringValue(n));
    }

    @Test
    public void testGetStringValue_nullLiteral() throws Exception {
        Node n = new Node(Token.NULL);
        assertEquals("null", NodeUtil.getStringValue(n));
    }

    @Test
    public void testGetStringValue_undefinedName() throws Exception {
        Node n = Node.newString("undefined");
        assertEquals("undefined", NodeUtil.getStringValue(n));
    }

    @Test
    public void testGetStringValue_nanName() throws Exception {
        Node n = Node.newString("NaN");
        assertEquals("NaN", NodeUtil.getStringValue(n));
    }

    @Test
    public void testGetStringValue_infinityName() throws Exception {
        Node n = Node.newString("Infinity");
        assertEquals("Infinity", NodeUtil.getStringValue(n));
    }

    @Test
    public void testGetStringValue_voidOperator() throws Exception {
        Node expr = Node.newNumber(1);
        Node voidNode = new Node(Token.VOID, expr);
        assertEquals("undefined", NodeUtil.getStringValue(voidNode));
    }

    @Test
    public void testGetStringValue_notOperatorTrue() throws Exception {
        Node falseNode = new Node(Token.FALSE);
        Node notFalseNode = new Node(Token.NOT, falseNode);
        assertEquals("true", NodeUtil.getStringValue(notFalseNode));
    }

    @Test
    public void testGetStringValue_notOperatorFalse() throws Exception {
        Node trueNode = Node.newString("a");
        Node notTrueNode = new Node(Token.NOT, trueNode);
        assertEquals("false", NodeUtil.getStringValue(notTrueNode));
    }

    @Test
    public void testGetStringValue_arrayLiteralEmpty() throws Exception {
        Node n = new Node(Token.ARRAYLIT);
        assertEquals("", NodeUtil.getStringValue(n));
    }

    @Test
    public void testGetStringValue_arrayLiteralSingleElement() throws Exception {
        Node element = Node.newString("test");
        Node array = new Node(Token.ARRAYLIT, element);
        assertEquals("test", NodeUtil.getStringValue(array));
    }

    @Test
    public void testGetStringValue_arrayLiteralMultipleElements() throws Exception {
        Node element1 = Node.newString("a");
        Node element2 = Node.newString("b");
        Node array = new Node(Token.ARRAYLIT, element1, element2);
        assertEquals("a,b", NodeUtil.getStringValue(array));
    }

    @Test
    public void testGetStringValue_arrayLiteralWithNullAndUndefined() throws Exception {
        Node element1 = Node.newString("a");
        Node element2 = new Node(Token.NULL);
        Node element3 = Node.newString("undefined");
        Node element4 = Node.newString("b");
        Node array = new Node(Token.ARRAYLIT, element1, element2, element3, element4);
        assertEquals("a,,undefined,b", NodeUtil.getStringValue(array));
    }

    @Test
    public void testGetStringValue_objectLiteral() throws Exception {
        Node n = new Node(Token.OBJECTLIT);
        assertEquals("[object Object]", NodeUtil.getStringValue(n));
    }

    @Test
    public void testGetStringValue_nullResult() throws Exception {
        // A node that doesn't map to a string value for getStringValue
        Node n = new Node(Token.ADD, Node.newNumber(1), Node.newNumber(2));
        assertNull(NodeUtil.getStringValue(n));
    }

    @Test
    public void testGetNumberValue_trueLiteral() throws Exception {
        Node n = new Node(Token.TRUE);
        assertEquals(1.0, NodeUtil.getNumberValue(n), 1e-9);
    }

    @Test
    public void testGetNumberValue_falseLiteral() throws Exception {
        Node n = new Node(Token.FALSE);
        assertEquals(0.0, NodeUtil.getNumberValue(n), 1e-9);
    }

    @Test
    public void testGetNumberValue_nullLiteral() throws Exception {
        Node n = new Node(Token.NULL);
        assertEquals(0.0, NodeUtil.getNumberValue(n), 1e-9);
    }

    @Test
    public void testGetNumberValue_numberLiteral() throws Exception {
        Node n = Node.newNumber(123.45);
        assertEquals(123.45, NodeUtil.getNumberValue(n), 1e-9);
    }

    @Test
    public void testGetNumberValue_voidOperatorNoSideEffects() throws Exception {
        Node child = Node.newNumber(0);
        Node voidNode = new Node(Token.VOID, child);
        assertEquals(Double.NaN, NodeUtil.getNumberValue(voidNode), 1e-9);
    }


    @Test
    public void testGetNumberValue_undefinedName() throws Exception {
        Node n = Node.newString("undefined");
        assertEquals(Double.NaN, NodeUtil.getNumberValue(n), 1e-9);
    }

    @Test
    public void testGetNumberValue_nanName() throws Exception {
        Node n = Node.newString("NaN");
        assertEquals(Double.NaN, NodeUtil.getNumberValue(n), 1e-9);
    }

    @Test
    public void testGetNumberValue_infinityName() throws Exception {
        Node n = Node.newString("Infinity");
        assertEquals(Double.POSITIVE_INFINITY, NodeUtil.getNumberValue(n), 1e-9);
    }

    @Test
    public void testGetNumberValue_negativeInfinityName() {}
// Defects4J: flaky method
//     @Test
//     public void testGetNumberValue_negativeInfinityName() throws Exception {
//         Node n = new Node(Token.NEG, Node.newString("Infinity"));
//         assertEquals(Double.NEGATIVE_INFINITY, NodeUtil.getNumberValue(n), 1e-9);
//     }

    @Test
    public void testGetNumberValue_notOperatorTrue() throws Exception {
        Node falseNode = new Node(Token.FALSE);
        Node notFalseNode = new Node(Token.NOT, falseNode);
        assertEquals(1.0, NodeUtil.getNumberValue(notFalseNode), 1e-9);
    }

    @Test
    public void testGetNumberValue_notOperatorFalse() throws Exception {
        Node trueNode = Node.newString("a");
        Node notTrueNode = new Node(Token.NOT, trueNode);
        assertEquals(0.0, NodeUtil.getNumberValue(notTrueNode), 1e-9);
    }

    @Test
    public void testGetNumberValue_stringLiteralInteger() throws Exception {
        Node n = Node.newString("123");
        assertEquals(123.0, NodeUtil.getNumberValue(n), 1e-9);
    }

    @Test
    public void testGetNumberValue_stringLiteralFloat() throws Exception {
        Node n = Node.newString("123.45");
        assertEquals(123.45, NodeUtil.getNumberValue(n), 1e-9);
    }

    @Test
    public void testGetNumberValue_stringLiteralEmpty() throws Exception {
        Node n = Node.newString("");
        assertEquals(0.0, NodeUtil.getNumberValue(n), 1e-9);
    }

    @Test
    public void testGetNumberValue_stringLiteralHex() throws Exception {
        Node n = Node.newString("0xFF");
        assertEquals(255.0, NodeUtil.getNumberValue(n), 1e-9);
    }

    @Test
    public void testGetNumberValue_stringLiteralHexInvalid() throws Exception {
        Node n = Node.newString("0xG");
        assertEquals(Double.NaN, NodeUtil.getNumberValue(n), 1e-9);
    }

    @Test
    public void testGetNumberValue_stringLiteralNaN() throws Exception {
        Node n = Node.newString("abc");
        assertEquals(Double.NaN, NodeUtil.getNumberValue(n), 1e-9);
    }

    @Test
    public void testGetNumberValue_stringLiteralInfinity() throws Exception {
        Node n = Node.newString("Infinity");
        assertEquals(Double.POSITIVE_INFINITY, NodeUtil.getNumberValue(n), 1e-9);
    }

    @Test
    public void testGetNumberValue_stringLiteralNegativeInfinity() throws Exception {
        Node n = Node.newString("-Infinity");
        assertEquals(Double.NEGATIVE_INFINITY, NodeUtil.getNumberValue(n), 1e-9);
    }

    @Test
    public void testGetNumberValue_stringLiteralVerticalTab() throws Exception {
        Node n = Node.newString("1\u000b2");
        assertNull(NodeUtil.getNumberValue(n));
    }

    @Test
    public void testGetNumberValue_arrayLiteralEmpty() throws Exception {
        Node n = new Node(Token.ARRAYLIT);
        assertEquals(0.0, NodeUtil.getNumberValue(n), 1e-9);
    }

    @Test
    public void testGetNumberValue_arrayLiteralSingleNumber() throws Exception {
        Node element = Node.newNumber(42);
        Node array = new Node(Token.ARRAYLIT, element);
        assertEquals(42.0, NodeUtil.getNumberValue(array), 1e-9);
    }

    @Test
    public void testGetNumberValue_arrayLiteralSingleString() throws Exception {
        Node element = Node.newString("100");
        Node array = new Node(Token.ARRAYLIT, element);
        assertEquals(100.0, NodeUtil.getNumberValue(array), 1e-9);
    }

    @Test
    public void testGetNumberValue_arrayLiteralMixed() throws Exception {
        Node element1 = Node.newNumber(10);
        Node element2 = Node.newString("20");
        Node array = new Node(Token.ARRAYLIT, element1, element2);
        // When Array.prototype.toString is called, elements are converted.
        // For Number(element2) it's 20. For Number(element1) it's 10.
        // Then these are joined by ',', so "10,20".
        // Then Number("10,20") is NaN.
        assertEquals(Double.NaN, NodeUtil.getNumberValue(array), 1e-9);
    }

    @Test
    public void testGetNumberValue_objectLiteral() throws Exception {
        Node n = new Node(Token.OBJECTLIT);
        // Object.prototype.toString returns "[object Object]".
        // Number("[object Object]") is NaN.
        assertEquals(Double.NaN, NodeUtil.getNumberValue(n), 1e-9);
    }

    @Test
    public void testGetFunctionName_functionDeclaration() {}
// Defects4J: flaky method
//     @Test
//     public void testGetFunctionName_functionDeclaration() throws Exception {
//         Node functionBody = new Node(Token.BLOCK);
//         Node functionName = Node.newString("myFunc");
//         Node functionNode = new Node(Token.FUNCTION, functionName, new Node(Token.LP), functionBody);
//         assertEquals("myFunc", NodeUtil.getFunctionName(functionNode));
//     }

    @Test
    public void testGetFunctionName_varAssignment() {}
// Defects4J: flaky method
//     @Test
//     public void testGetFunctionName_varAssignment() throws Exception {
//         Node functionBody = new Node(Token.BLOCK);
//         Node functionNameExpr = Node.newString("innerFunc");
//         Node functionNode = new Node(Token.FUNCTION, functionNameExpr, new Node(Token.LP), functionBody);
//         Node varName = Node.newString("outerVar");
//         Node varNode = new Node(Token.VAR, varName);
//         varName.addChildToBack(functionNode); // This attaches the function node as a child of the var name node
//         assertEquals("outerVar", NodeUtil.getFunctionName(functionNode));
//     }

    @Test
    public void testGetFunctionName_qualifiedAssignment() {}
// Defects4J: flaky method
//     @Test
//     public void testGetFunctionName_qualifiedAssignment() throws Exception {
//         Node functionBody = new Node(Token.BLOCK);
//         Node functionNameExpr = Node.newString("innerFunc");
//         Node functionNode = new Node(Token.FUNCTION, functionNameExpr, new Node(Token.LP), functionBody);
//         Node qualifiedName = Node.newString("qualified.name"); // This needs to be a GETPROP node for getQualifiedName to work correctly on parent
//         Node qualifiedNameNode = Node.newString("qualified");
//         qualifiedNameNode.addChildToBack(Node.newString("name"));
//         qualifiedNameNode.setType(Token.GETPROP);
// 
//         Node assignNode = new Node(Token.ASSIGN, qualifiedNameNode, functionNode);
//         assertEquals("qualified.name", NodeUtil.getFunctionName(functionNode));
//     }

    @Test
    public void testGetFunctionName_namedFunctionExpressionInVar() {}
// Defects4J: flaky method
//     @Test
//     public void testGetFunctionName_namedFunctionExpressionInVar() throws Exception {
//         Node functionBody = new Node(Token.BLOCK);
//         Node namedFn = Node.newString("namedFn");
//         Node functionNode = new Node(Token.FUNCTION, namedFn, new Node(Token.LP), functionBody);
//         Node varName = Node.newString("outerVar");
//         Node varNode = new Node(Token.VAR, varName);
//         varName.addChildToBack(functionNode);
//         assertEquals("outerVar", NodeUtil.getFunctionName(functionNode));
//     }

    @Test
    public void testGetFunctionName_namedFunctionExpressionInAssign() {}
// Defects4J: flaky method
//     @Test
//     public void testGetFunctionName_namedFunctionExpressionInAssign() throws Exception {
//         Node functionBody = new Node(Token.BLOCK);
//         Node namedFn = Node.newString("namedFn");
//         Node functionNode = new Node(Token.FUNCTION, namedFn, new Node(Token.LP), functionBody);
//         Node qualifiedNameNode = Node.newString("qualified");
//         qualifiedNameNode.addChildToBack(Node.newString("name"));
//         qualifiedNameNode.setType(Token.GETPROP);
//         Node assignNode = new Node(Token.ASSIGN, qualifiedNameNode, functionNode);
//         assertEquals("qualified.name", NodeUtil.getFunctionName(functionNode));
//     }

    @Test
    public void testGetNearestFunctionName_functionDeclaration() {}
// Defects4J: flaky method
//     @Test
//     public void testGetNearestFunctionName_functionDeclaration() throws Exception {
//         Node functionBody = new Node(Token.BLOCK);
//         Node functionName = Node.newString("myFunc");
//         Node functionNode = new Node(Token.FUNCTION, functionName, new Node(Token.LP), functionBody);
//         assertEquals("myFunc", NodeUtil.getNearestFunctionName(functionNode));
//     }

    @Test
    public void testGetNearestFunctionName_objectLiteralStringKey() {}
// Defects4J: flaky method
//     @Test
//     public void testGetNearestFunctionName_objectLiteralStringKey() throws Exception {
//         Node functionBody = new Node(Token.BLOCK);
//         Node functionNode = new Node(Token.FUNCTION, null, new Node(Token.LP), functionBody);
//         Node key = Node.newString("myKey");
//         Node objLitProp = new Node(Token.SET, key, functionNode);
//         Node objLit = new Node(Token.OBJECTLIT, objLitProp);
//         assertEquals("myKey", NodeUtil.getNearestFunctionName(functionNode));
//     }

    @Test
    public void testGetNearestFunctionName_objectLiteralNumericKey() {}
// Defects4J: flaky method
//     @Test
//     public void testGetNearestFunctionName_objectLiteralNumericKey() throws Exception {
//         Node functionBody = new Node(Token.BLOCK);
//         Node functionNode = new Node(Token.FUNCTION, null, new Node(Token.LP), functionBody);
//         Node key = Node.newNumber(123);
//         Node objLitProp = new Node(Token.SET, key, functionNode);
//         Node objLit = new Node(Token.OBJECTLIT, objLitProp);
//         assertEquals("123", NodeUtil.getNearestFunctionName(functionNode));
//     }

    @Test
    public void testIsImmutableValue_stringLiteral() throws Exception {
        Node n = Node.newString("test");
        assertTrue(NodeUtil.isImmutableValue(n));
    }

    @Test
    public void testIsImmutableValue_numberLiteral() throws Exception {
        Node n = Node.newNumber(123.45);
        assertTrue(NodeUtil.isImmutableValue(n));
    }

    @Test
    public void testIsImmutableValue_trueLiteral() throws Exception {
        Node n = new Node(Token.TRUE);
        assertTrue(NodeUtil.isImmutableValue(n));
    }

    @Test
    public void testIsImmutableValue_falseLiteral() throws Exception {
        Node n = new Node(Token.FALSE);
        assertTrue(NodeUtil.isImmutableValue(n));
    }

    @Test
    public void testIsImmutableValue_nullLiteral() throws Exception {
        Node n = new Node(Token.NULL);
        assertTrue(NodeUtil.isImmutableValue(n));
    }

    @Test
    public void testIsImmutableValue_notOperator() throws Exception {
        Node trueNode = Node.newString("a");
        Node notTrueNode = new Node(Token.NOT, trueNode);
        assertTrue(NodeUtil.isImmutableValue(notTrueNode));
    }

    @Test
    public void testIsImmutableValue_negOperator() throws Exception {
        Node numNode = Node.newNumber(5);
        Node negNode = new Node(Token.NEG, numNode);
        assertTrue(NodeUtil.isImmutableValue(negNode));
    }

    @Test
    public void testIsImmutableValue_voidOperator() throws Exception {
        Node numNode = Node.newNumber(5);
        Node voidNode = new Node(Token.VOID, numNode);
        assertTrue(NodeUtil.isImmutableValue(voidNode));
    }

    @Test
    public void testIsImmutableValue_undefinedName() throws Exception {
        Node n = Node.newString("undefined");
        assertTrue(NodeUtil.isImmutableValue(n));
    }

    @Test
    public void testIsImmutableValue_nanName() throws Exception {
        Node n = Node.newString("NaN");
        assertTrue(NodeUtil.isImmutableValue(n));
    }

    @Test
    public void testIsImmutableValue_infinityName() throws Exception {
        Node n = Node.newString("Infinity");
        assertTrue(NodeUtil.isImmutableValue(n));
    }

    @Test
    public void testIsImmutableValue_variableName() {}
// Defects4J: flaky method
//     @Test
//     public void testIsImmutableValue_variableName() throws Exception {
//         Node n = Node.newString("myVar");
//         assertFalse(NodeUtil.isImmutableValue(n));
//     }


    @Test
    public void testIsImmutableValue_arrayLiteral() throws Exception {
        Node n = new Node(Token.ARRAYLIT);
        assertFalse(NodeUtil.isImmutableValue(n));
    }

    @Test
    public void testIsImmutableValue_objectLiteral() throws Exception {
        Node n = new Node(Token.OBJECTLIT);
        assertFalse(NodeUtil.isImmutableValue(n));
    }

    @Test
    public void testIsLiteralValue_stringLiteral() throws Exception {
        Node n = Node.newString("test");
        assertTrue(NodeUtil.isLiteralValue(n, false));
    }

    @Test
    public void testIsLiteralValue_numberLiteral() throws Exception {
        Node n = Node.newNumber(123.45);
        assertTrue(NodeUtil.isLiteralValue(n, false));
    }

    @Test
    public void testIsLiteralValue_trueLiteral() throws Exception {
        Node n = new Node(Token.TRUE);
        assertTrue(NodeUtil.isLiteralValue(n, false));
    }

    @Test
    public void testIsLiteralValue_falseLiteral() throws Exception {
        Node n = new Node(Token.FALSE);
        assertTrue(NodeUtil.isLiteralValue(n, false));
    }

    @Test
    public void testIsLiteralValue_nullLiteral() throws Exception {
        Node n = new Node(Token.NULL);
        assertTrue(NodeUtil.isLiteralValue(n, false));
    }

    @Test
    public void testIsLiteralValue_undefinedName() throws Exception {
        Node n = Node.newString("undefined");
        assertTrue(NodeUtil.isLiteralValue(n, false));
    }

    @Test
    public void testIsLiteralValue_nanName() throws Exception {
        Node n = Node.newString("NaN");
        assertTrue(NodeUtil.isLiteralValue(n, false));
    }

    @Test
    public void testIsLiteralValue_infinityName() throws Exception {
        Node n = Node.newString("Infinity");
        assertTrue(NodeUtil.isLiteralValue(n, false));
    }

    @Test
    public void testIsLiteralValue_notOperator() throws Exception {
        Node trueNode = Node.newString("a");
        Node notTrueNode = new Node(Token.NOT, trueNode);
        assertTrue(NodeUtil.isLiteralValue(notTrueNode, false));
    }

    @Test
    public void testIsLiteralValue_negOperator() throws Exception {
        Node numNode = Node.newNumber(5);
        Node negNode = new Node(Token.NEG, numNode);
        assertTrue(NodeUtil.isLiteralValue(negNode, false));
    }

    @Test
    public void testIsLiteralValue_voidOperator() throws Exception {
        Node numNode = Node.newNumber(5);
        Node voidNode = new Node(Token.VOID, numNode);
        assertTrue(NodeUtil.isLiteralValue(voidNode, false));
    }

    @Test
    public void testIsLiteralValue_functionDeclaration() throws Exception {
        Node declaration = new Node(Token.FUNCTION);
        declaration.addChildrenToBack(Node.newString("f", -1, -1));
        declaration.addChildrenToBack(new Node(Token.LP));
        declaration.addChildrenToBack(new Node(Token.BLOCK));
        Node block = new Node(Token.BLOCK, declaration);
        assertFalse(NodeUtil.isLiteralValue(declaration, true));
    }

    @Test
    public void testIsValidDefineValue_string() throws Exception {
        Node n = Node.newString("abc");
        Set<String> defines = Collections.emptySet();
        assertTrue(NodeUtil.isValidDefineValue(n, defines));
    }

    @Test
    public void testIsValidDefineValue_number() throws Exception {
        Node n = Node.newNumber(123);
        Set<String> defines = Collections.emptySet();
        assertTrue(NodeUtil.isValidDefineValue(n, defines));
    }

    @Test
    public void testIsValidDefineValue_true() throws Exception {
        Node n = new Node(Token.TRUE);
        Set<String> defines = Collections.emptySet();
        assertTrue(NodeUtil.isValidDefineValue(n, defines));
    }

    @Test
    public void testIsValidDefineValue_false() throws Exception {
        Node n = new Node(Token.FALSE);
        Set<String> defines = Collections.emptySet();
        assertTrue(NodeUtil.isValidDefineValue(n, defines));
    }

    @Test
    public void testIsValidDefineValue_addOperator() throws Exception {
        Node left = Node.newNumber(1);
        Node right = Node.newNumber(2);
        Node add = new Node(Token.ADD, left, right);
        Set<String> defines = Collections.emptySet();
        assertTrue(NodeUtil.isValidDefineValue(add, defines));
    }

    @Test
    public void testIsValidDefineValue_subOperator() throws Exception {
        Node left = Node.newNumber(10);
        Node right = Node.newNumber(5);
        Node sub = new Node(Token.SUB, left, right);
        Set<String> defines = Collections.emptySet();
        assertTrue(NodeUtil.isValidDefineValue(sub, defines));
    }


    @Test
    public void testIsValidDefineValue_negOperator() throws Exception {
        Node child = Node.newNumber(10);
        Node neg = new Node(Token.NEG, child);
        Set<String> defines = Collections.emptySet();
        assertTrue(NodeUtil.isValidDefineValue(neg, defines));
    }

    @Test
    public void testIsValidDefineValue_posOperator() throws Exception {
        Node child = Node.newNumber(-5);
        Node pos = new Node(Token.POS, child);
        Set<String> defines = Collections.emptySet();
        assertTrue(NodeUtil.isValidDefineValue(pos, defines));
    }

    @Test
    public void testIsValidDefineValue_nameThatIsDefine() {}
// Defects4J: flaky method
//     @Test
//     public void testIsValidDefineValue_nameThatIsDefine() throws Exception {
//         Node n = Node.newString("MY_DEFINE");
//         Set<String> defines = new HashSet<>(Arrays.asList("MY_DEFINE"));
//         assertTrue(NodeUtil.isValidDefineValue(n, defines));
//     }

    @Test
    public void testIsValidDefineValue_nameThatIsNotDefine() {}
// Defects4J: flaky method
//     @Test
//     public void testIsValidDefineValue_nameThatIsNotDefine() throws Exception {
//         Node n = Node.newString("MY_DEFINE");
//         Set<String> defines = new HashSet<>(Arrays.asList("OTHER_DEFINE"));
//         assertFalse(NodeUtil.isValidDefineValue(n, defines));
//     }



    @Test
    public void testIsEmptyBlock_emptyBlock() throws Exception {
        Node block = new Node(Token.BLOCK);
        assertTrue(NodeUtil.isEmptyBlock(block));
    }

    @Test
    public void testIsEmptyBlock_blockWithEmptyNode() throws Exception {
        Node block = new Node(Token.BLOCK);
        block.addChildToBack(new Node(Token.EMPTY));
        assertTrue(NodeUtil.isEmptyBlock(block));
    }

    @Test
    public void testIsEmptyBlock_blockWithStatement() throws Exception {
        Node block = new Node(Token.BLOCK);
        block.addChildToBack(Node.newString("test"));
        assertFalse(NodeUtil.isEmptyBlock(block));
    }

    @Test
    public void testIsEmptyBlock_nonBlockNode() throws Exception {
        Node node = new Node(Token.NAME);
        assertFalse(NodeUtil.isEmptyBlock(node));
    }

    @Test
    public void testIsSimpleOperator_add() throws Exception {
        Node n = new Node(Token.ADD);
        assertTrue(NodeUtil.isSimpleOperator(n));
    }

    @Test
    public void testIsSimpleOperator_assignAdd() throws Exception {
        Node n = new Node(Token.ASSIGN_ADD);
        assertFalse(NodeUtil.isSimpleOperator(n));
    }

    @Test
    public void testIsSimpleOperator_comma() throws Exception {
        Node n = new Node(Token.COMMA);
        assertTrue(NodeUtil.isSimpleOperator(n));
    }

    @Test
    public void testIsSimpleOperator_hook() throws Exception {
        Node n = new Node(Token.HOOK);
        assertFalse(NodeUtil.isSimpleOperator(n));
    }

    @Test
    public void testIsSimpleOperator_or() throws Exception {
        Node n = new Node(Token.OR);
        assertFalse(NodeUtil.isSimpleOperator(n));
    }

    @Test
    public void testIsSimpleOperator_getProp() throws Exception {
        Node n = new Node(Token.GETPROP);
        assertTrue(NodeUtil.isSimpleOperator(n));
    }

    @Test
    public void testNewExpr() throws Exception {
        Node child = Node.newString("hello");
        Node exprResult = NodeUtil.newExpr(child);
        assertEquals(Token.EXPR_RESULT, exprResult.getType());
        assertEquals(child, exprResult.getFirstChild());
        assertEquals(child.getLineno(), exprResult.getLineno());
        assertEquals(child.getCharno(), exprResult.getCharno());
    }

    @Test
    public void testMayHaveSideEffects_newCall() throws Exception {
        Node newNode = new Node(Token.NEW, Node.newString("Object"));
        assertTrue(NodeUtil.mayHaveSideEffects(newNode));
    }


    @Test
    public void testMayHaveSideEffects_assignment() {}
// Defects4J: flaky method
//     @Test
//     public void testMayHaveSideEffects_assignment() throws Exception {
//         Node assignTarget = Node.newString("x");
//         Node assignValue = Node.newNumber(1);
//         Node assignNode = new Node(Token.ASSIGN, assignTarget, assignValue);
//         assertTrue(NodeUtil.mayHaveSideEffects(assignNode));
//     }

    @Test
    public void testMayHaveSideEffects_throwStatement() throws Exception {
        Node throwNode = new Node(Token.THROW, Node.newString("error"));
        assertTrue(NodeUtil.mayHaveSideEffects(throwNode));
    }

    @Test
    public void testMayHaveSideEffects_varWithInitializer() throws Exception {
        Node varName = Node.newString("x", -1, -1);
        varName.addChildToBack(Node.newNumber(1));
        Node varNode = new Node(Token.VAR, varName);
        assertTrue(NodeUtil.mayHaveSideEffects(varNode));
    }

    @Test
    public void testMayHaveSideEffects_varWithoutInitializer() {}
// Defects4J: flaky method
//     @Test
//     public void testMayHaveSideEffects_varWithoutInitializer() throws Exception {
//         Node varNode = new Node(Token.VAR, Node.newString("x", -1, -1));
//         assertFalse(NodeUtil.mayHaveSideEffects(varNode));
//     }

    @Test
    public void testMayHaveSideEffects_functionDeclaration() {}
// Defects4J: flaky method
//     @Test
//     public void testMayHaveSideEffects_functionDeclaration() throws Exception {
//         Node declaration = new Node(Token.FUNCTION);
//         declaration.addChildrenToBack(Node.newString("f", -1, -1));
//         declaration.addChildrenToBack(new Node(Token.LP));
//         declaration.addChildrenToBack(new Node(Token.BLOCK));
//         assertTrue(NodeUtil.mayHaveSideEffects(declaration));
//     }

    @Test
    public void testMayHaveSideEffects_functionExpression() {}
// Defects4J: flaky method
//     @Test
//     public void testMayHaveSideEffects_functionExpression() throws Exception {
//         Node expression = new Node(Token.FUNCTION);
//         expression.addChildrenToBack(Node.newString("f", -1, -1));
//         expression.addChildrenToBack(new Node(Token.LP));
//         expression.addChildrenToBack(new Node(Token.BLOCK));
//         assertFalse(NodeUtil.mayHaveSideEffects(expression));
//     }



    @Test
    public void testMayHaveSideEffects_arrayLiteralWithSideEffects() {}
// Defects4J: flaky method
//     @Test
//     public void testMayHaveSideEffects_arrayLiteralWithSideEffects() throws Exception {
//         Node funcExpr = new Node(Token.FUNCTION);
//         funcExpr.addChildrenToBack(Node.newString("f", -1, -1));
//         funcExpr.addChildrenToBack(new Node(Token.LP));
//         funcExpr.addChildrenToBack(new Node(Token.BLOCK));
//         Node arrayLit = new Node(Token.ARRAYLIT, funcExpr);
//         assertTrue(NodeUtil.mayHaveSideEffects(arrayLit));
//     }

    @Test
    public void testMayHaveSideEffects_arrayLiteralWithoutSideEffects() throws Exception {
        Node arrayLit = new Node(Token.ARRAYLIT, Node.newNumber(1));
        assertFalse(NodeUtil.mayHaveSideEffects(arrayLit));
    }

    @Test
    public void testConstructorCallHasSideEffects_standardNew() throws Exception {
        Node newNode = new Node(Token.NEW, Node.newString("Object"));
        assertTrue(NodeUtil.constructorCallHasSideEffects(newNode));
    }

    @Test
    public void testConstructorCallHasSideEffects_knownNoSideEffectsConstructor() {}
// Defects4J: flaky method
//     @Test
//     public void testConstructorCallHasSideEffects_knownNoSideEffectsConstructor() throws Exception {
//         Node newNode = new Node(Token.NEW, Node.newString("Array"));
//         assertFalse(NodeUtil.constructorCallHasSideEffects(newNode));
//     }








    @Test
    public void testNodeTypeMayHaveSideEffects_assignment() throws Exception {
        Node assignTarget = Node.newString("x");
        Node assignValue = Node.newNumber(1);
        Node assignNode = new Node(Token.ASSIGN, assignTarget, assignValue);
        assertTrue(NodeUtil.nodeTypeMayHaveSideEffects(assignNode));
    }

    @Test
    public void testNodeTypeMayHaveSideEffects_inc() throws Exception {
        Node incNode = new Node(Token.INC, Node.newString("x"));
        assertTrue(NodeUtil.nodeTypeMayHaveSideEffects(incNode));
    }

    @Test
    public void testNodeTypeMayHaveSideEffects_dec() throws Exception {
        Node decNode = new Node(Token.DEC, Node.newString("x"));
        assertTrue(NodeUtil.nodeTypeMayHaveSideEffects(decNode));
    }

    @Test
    public void testNodeTypeMayHaveSideEffects_throw() throws Exception {
        Node throwNode = new Node(Token.THROW, Node.newString("error"));
        assertTrue(NodeUtil.nodeTypeMayHaveSideEffects(throwNode));
    }


    @Test
    public void testNodeTypeMayHaveSideEffects_new() throws Exception {
        Node newNode = new Node(Token.NEW, Node.newString("Object"));
        assertTrue(NodeUtil.nodeTypeMayHaveSideEffects(newNode));
    }

    @Test
    public void testNodeTypeMayHaveSideEffects_nameWithChildren() {}
// Defects4J: flaky method
//     @Test
//     public void testNodeTypeMayHaveSideEffects_nameWithChildren() throws Exception {
//         Node nameNode = Node.newString("varName");
//         nameNode.addChildToBack(Node.newNumber(1));
//         assertTrue(NodeUtil.nodeTypeMayHaveSideEffects(nameNode));
//     }

    @Test
    public void testNodeTypeMayHaveSideEffects_nameWithoutChildren() throws Exception {
        Node nameNode = Node.newString("varName");
        assertFalse(NodeUtil.nodeTypeMayHaveSideEffects(nameNode));
    }


    @Test
    public void testCanBeSideEffected_new() throws Exception {
        Node newNode = new Node(Token.NEW, Node.newString("Object"));
        assertTrue(NodeUtil.canBeSideEffected(newNode));
    }

    @Test
    public void testCanBeSideEffected_nameNotConstant() {}
// Defects4J: flaky method
//     @Test
//     public void testCanBeSideEffected_nameNotConstant() throws Exception {
//         Node nameNode = Node.newString("myVar");
//         assertFalse(NodeUtil.canBeSideEffected(nameNode, Collections.emptySet()));
//     }

    @Test
    public void testCanBeSideEffected_nameConstant() {}
// Defects4J: flaky method
//     @Test
//     public void testCanBeSideEffected_nameConstant() throws Exception {
//         Node nameNode = Node.newString("MY_CONST");
//         nameNode.putBooleanProp(Node.IS_CONSTANT_NAME, true);
//         assertFalse(NodeUtil.canBeSideEffected(nameNode, Collections.emptySet()));
//     }

    @Test
    public void testCanBeSideEffected_nameInKnownConstants() {}
// Defects4J: flaky method
//     @Test
//     public void testCanBeSideEffected_nameInKnownConstants() throws Exception {
//         Node nameNode = Node.newString("myVar");
//         Set<String> knownConstants = new HashSet<>(Arrays.asList("myVar"));
//         assertFalse(NodeUtil.canBeSideEffected(nameNode, knownConstants));
//     }

    @Test
    public void testCanBeSideEffected_getProp() throws Exception {
        Node obj = Node.newString("obj");
        Node prop = Node.newString("prop");
        Node getPropNode = new Node(Token.GETPROP, obj, prop);
        assertTrue(NodeUtil.canBeSideEffected(getPropNode));
    }

    @Test
    public void testCanBeSideEffected_getElem() throws Exception {
        Node obj = Node.newString("obj");
        Node elem = Node.newNumber(0);
        Node getElemNode = new Node(Token.GETELEM, obj, elem);
        assertTrue(NodeUtil.canBeSideEffected(getElemNode));
    }


    @Test
    public void testPrecedence_comma() throws Exception {
        assertEquals(0, NodeUtil.precedence(Token.COMMA));
    }

    @Test
    public void testPrecedence_assign() throws Exception {
        assertEquals(1, NodeUtil.precedence(Token.ASSIGN));
    }

    @Test
    public void testPrecedence_hook() throws Exception {
        assertEquals(2, NodeUtil.precedence(Token.HOOK));
    }

    @Test
    public void testPrecedence_or() throws Exception {
        assertEquals(3, NodeUtil.precedence(Token.OR));
    }

    @Test
    public void testPrecedence_and() throws Exception {
        assertEquals(4, NodeUtil.precedence(Token.AND));
    }

    @Test
    public void testPrecedence_bitor() throws Exception {
        assertEquals(5, NodeUtil.precedence(Token.BITOR));
    }

    @Test
    public void testPrecedence_bitxor() throws Exception {
        assertEquals(6, NodeUtil.precedence(Token.BITXOR));
    }

    @Test
    public void testPrecedence_bitand() throws Exception {
        assertEquals(7, NodeUtil.precedence(Token.BITAND));
    }

    @Test
    public void testPrecedence_eq() throws Exception {
        assertEquals(8, NodeUtil.precedence(Token.EQ));
    }

    @Test
    public void testPrecedence_lt() throws Exception {
        assertEquals(9, NodeUtil.precedence(Token.LT));
    }

    @Test
    public void testPrecedence_lsh() throws Exception {
        assertEquals(10, NodeUtil.precedence(Token.LSH));
    }

    @Test
    public void testPrecedence_add() throws Exception {
        assertEquals(11, NodeUtil.precedence(Token.ADD));
    }

    @Test
    public void testPrecedence_mul() throws Exception {
        assertEquals(12, NodeUtil.precedence(Token.MUL));
    }

    @Test
    public void testPrecedence_neg() throws Exception {
        assertEquals(13, NodeUtil.precedence(Token.NEG));
    }

    @Test
    public void testPrecedence_call() throws Exception {
        assertEquals(15, NodeUtil.precedence(Token.CALL));
    }

    @Test
    public void testPrecedence_number() throws Exception {
        assertEquals(15, NodeUtil.precedence(Token.NUMBER));
    }

    @Test
    public void testValueCheck_andOperator() {}
// Defects4J: flaky method
//     @Test
//     public void testValueCheck_andOperator() throws Exception {
//         Node lhsTrue = Node.newString("a");
//         Node rhsTrue = Node.newString("b");
//         Node andTrue = new Node(Token.AND, lhsTrue, rhsTrue);
//         assertTrue(NodeUtil.valueCheck(andTrue, new NodeUtil.NumbericResultPredicate()));
//     }

    @Test
    public void testValueCheck_orOperator() {}
// Defects4J: flaky method
//     @Test
//     public void testValueCheck_orOperator() throws Exception {
//         Node lhsTrue = Node.newString("a");
//         Node rhsTrue = Node.newString("b");
//         Node orTrue = new Node(Token.OR, lhsTrue, rhsTrue);
//         assertTrue(NodeUtil.valueCheck(orTrue, new NodeUtil.NumbericResultPredicate()));
//     }

    @Test
    public void testValueCheck_hookOperator() throws Exception {
        Node condition = Node.newString("a");
        Node trueVal = Node.newString("b");
        Node falseVal = Node.newString("c");
        Node hook = new Node(Token.HOOK, condition, trueVal, falseVal);
        assertFalse(NodeUtil.valueCheck(hook, new NodeUtil.NumbericResultPredicate()));
    }

    @Test
    public void testValueCheck_stringLiteral() {}
// Defects4J: flaky method
//     @Test
//     public void testValueCheck_stringLiteral() throws Exception {
//         Node n = Node.newString("test");
//         assertTrue(NodeUtil.valueCheck(n, new NodeUtil.NumbericResultPredicate()));
//     }

    @Test
    public void testValueCheck_numberLiteral() throws Exception {
        Node n = Node.newNumber(123.45);
        assertTrue(NodeUtil.valueCheck(n, new NodeUtil.NumbericResultPredicate()));
    }

    @Test
    public void testValueCheck_nonNumericResult() throws Exception {
        Node n = Node.newString("not a number");
        assertFalse(NodeUtil.valueCheck(n, new NodeUtil.NumbericResultPredicate()));
    }

    @Test
    public void testIsNumericResult_addOperator() throws Exception {
        Node left = Node.newNumber(1);
        Node right = Node.newNumber(2);
        Node add = new Node(Token.ADD, left, right);
        assertTrue(NodeUtil.isNumericResult(add));
    }

    @Test
    public void testIsNumericResult_addOperatorWithNonNumeric() throws Exception {
        Node left = Node.newNumber(1);
        Node right = Node.newString("abc");
        Node add = new Node(Token.ADD, left, right);
        assertFalse(NodeUtil.isNumericResult(add));
    }

    @Test
    public void testIsNumericResult_mulOperator() throws Exception {
        Node left = Node.newNumber(10);
        Node right = Node.newNumber(5);
        Node mul = new Node(Token.MUL, left, right);
        assertTrue(NodeUtil.isNumericResult(mul));
    }

    @Test
    public void testIsNumericResult_negOperator() throws Exception {
        Node child = Node.newNumber(10);
        Node neg = new Node(Token.NEG, child);
        assertTrue(NodeUtil.isNumericResult(neg));
    }

    @Test
    public void testIsNumericResult_numberLiteral() throws Exception {
        Node n = Node.newNumber(123.45);
        assertTrue(NodeUtil.isNumericResult(n));
    }

    @Test
    public void testIsNumericResult_nanName() {}
// Defects4J: flaky method
//     @Test
//     public void testIsNumericResult_nanName() throws Exception {
//         Node n = Node.newString("NaN");
//         assertTrue(NodeUtil.isNumericResult(n));
//     }

    @Test
    public void testIsNumericResult_infinityName() {}
// Defects4J: flaky method
//     @Test
//     public void testIsNumericResult_infinityName() throws Exception {
//         Node n = Node.newString("Infinity");
//         assertTrue(NodeUtil.isNumericResult(n));
//     }

    @Test
    public void testIsNumericResult_stringLiteral() throws Exception {
        Node n = Node.newString("123");
        assertFalse(NodeUtil.isNumericResult(n));
    }

    @Test
    public void testIsBooleanResult_eqOperator() throws Exception {
        Node left = Node.newNumber(1);
        Node right = Node.newNumber(1);
        Node eq = new Node(Token.EQ, left, right);
        assertTrue(NodeUtil.isBooleanResult(eq));
    }

    @Test
    public void testIsBooleanResult_ltOperator() throws Exception {
        Node left = Node.newNumber(1);
        Node right = Node.newNumber(2);
        Node lt = new Node(Token.LT, left, right);
        assertTrue(NodeUtil.isBooleanResult(lt));
    }


    @Test
    public void testIsBooleanResult_trueLiteral() throws Exception {
        Node n = new Node(Token.TRUE);
        assertTrue(NodeUtil.isBooleanResult(n));
    }

    @Test
    public void testIsBooleanResult_falseLiteral() throws Exception {
        Node n = new Node(Token.FALSE);
        assertTrue(NodeUtil.isBooleanResult(n));
    }

    @Test
    public void testIsBooleanResult_delProp() throws Exception {
        Node n = new Node(Token.DELPROP, Node.newString("obj"), Node.newString("prop"));
        assertTrue(NodeUtil.isBooleanResult(n));
    }

    @Test
    public void testIsBooleanResult_numberLiteral() throws Exception {
        Node n = Node.newNumber(123);
        assertFalse(NodeUtil.isBooleanResult(n));
    }

    @Test
    public void testIsUndefined_voidOperator() throws Exception {
        Node expr = Node.newNumber(0);
        Node voidNode = new Node(Token.VOID, expr);
        assertTrue(NodeUtil.isUndefined(voidNode));
    }

    @Test
    public void testIsUndefined_undefinedName() {}
// Defects4J: flaky method
//     @Test
//     public void testIsUndefined_undefinedName() throws Exception {
//         Node n = Node.newString("undefined");
//         assertTrue(NodeUtil.isUndefined(n));
//     }

    @Test
    public void testIsUndefined_definedName() throws Exception {
        Node n = Node.newString("definedVar");
        assertFalse(NodeUtil.isUndefined(n));
    }

    @Test
    public void testIsUndefined_numberLiteral() throws Exception {
        Node n = Node.newNumber(0);
        assertFalse(NodeUtil.isUndefined(n));
    }

    @Test
    public void testIsNull_nullLiteral() throws Exception {
        Node n = new Node(Token.NULL);
        assertTrue(NodeUtil.isNull(n));
    }

    @Test
    public void testIsNull_definedName() throws Exception {
        Node n = Node.newString("someVar");
        assertFalse(NodeUtil.isNull(n));
    }

    @Test
    public void testIsNullOrUndefined_nullLiteral() throws Exception {
        Node n = new Node(Token.NULL);
        assertTrue(NodeUtil.isNullOrUndefined(n));
    }

    @Test
    public void testIsNullOrUndefined_undefinedName() {}
// Defects4J: flaky method
//     @Test
//     public void testIsNullOrUndefined_undefinedName() throws Exception {
//         Node n = Node.newString("undefined");
//         assertTrue(NodeUtil.isNullOrUndefined(n));
//     }

    @Test
    public void testIsNullOrUndefined_definedName() throws Exception {
        Node n = Node.newString("someVar");
        assertFalse(NodeUtil.isNullOrUndefined(n));
    }

    @Test
    public void testMayBeString_stringLiteral() throws Exception {
        Node n = Node.newString("hello");
        assertTrue(NodeUtil.mayBeString(n));
    }

    @Test
    public void testMayBeString_numberLiteral() throws Exception {
        Node n = Node.newNumber(123);
        assertFalse(NodeUtil.mayBeString(n));
    }

    @Test
    public void testMayBeString_booleanLiteral() throws Exception {
        Node n = new Node(Token.TRUE);
        assertFalse(NodeUtil.mayBeString(n));
    }

    @Test
    public void testMayBeString_addOperatorWithStrings() throws Exception {
        Node left = Node.newString("a");
        Node right = Node.newString("b");
        Node add = new Node(Token.ADD, left, right);
        assertTrue(NodeUtil.mayBeString(add));
    }

    @Test
    public void testMayBeString_addOperatorWithNumberAndString() throws Exception {
        Node left = Node.newNumber(1);
        Node right = Node.newString("b");
        Node add = new Node(Token.ADD, left, right);
        assertTrue(NodeUtil.mayBeString(add));
    }

    @Test
    public void testMayBeString_addOperatorWithNumbers() throws Exception {
        Node left = Node.newNumber(1);
        Node right = Node.newNumber(2);
        Node add = new Node(Token.ADD, left, right);
        assertFalse(NodeUtil.mayBeString(add));
    }

    @Test
    public void testMayBeString_addOperatorWithUnknownBoolean() throws Exception {
        Node left = Node.newNumber(1);
        Node right = Node.newString("true");

        Node add = new Node(Token.ADD, left, right);
        assertTrue(NodeUtil.mayBeString(add));
    }

    @Test
    public void testIsAssociative_mul() throws Exception {
        assertTrue(NodeUtil.isAssociative(Token.MUL));
    }

    @Test
    public void testIsAssociative_add() throws Exception {
        assertFalse(NodeUtil.isAssociative(Token.ADD));
    }

    @Test
    public void testIsAssociative_and() throws Exception {
        assertTrue(NodeUtil.isAssociative(Token.AND));
    }

    @Test
    public void testIsAssociative_bitor() throws Exception {
        assertTrue(NodeUtil.isAssociative(Token.BITOR));
    }

    @Test
    public void testIsAssociative_sub() throws Exception {
        assertFalse(NodeUtil.isAssociative(Token.SUB));
    }

    @Test
    public void testIsCommutative_mul() throws Exception {
        assertTrue(NodeUtil.isCommutative(Token.MUL));
    }

    @Test
    public void testIsCommutative_add() throws Exception {
        assertFalse(NodeUtil.isCommutative(Token.ADD));
    }

    @Test
    public void testIsCommutative_bitor() throws Exception {
        assertTrue(NodeUtil.isCommutative(Token.BITOR));
    }

    @Test
    public void testIsCommutative_bitxor() throws Exception {
        assertTrue(NodeUtil.isCommutative(Token.BITXOR));
    }

    @Test
    public void testIsCommutative_sub() throws Exception {
        assertFalse(NodeUtil.isCommutative(Token.SUB));
    }

    @Test
    public void testIsAssignmentOp_assign() throws Exception {
        Node n = new Node(Token.ASSIGN);
        assertTrue(NodeUtil.isAssignmentOp(n));
    }

    @Test
    public void testIsAssignmentOp_assignAdd() throws Exception {
        Node n = new Node(Token.ASSIGN_ADD);
        assertTrue(NodeUtil.isAssignmentOp(n));
    }

    @Test
    public void testIsAssignmentOp_add() throws Exception {
        Node n = new Node(Token.ADD);
        assertFalse(NodeUtil.isAssignmentOp(n));
    }

    @Test
    public void testGetOpFromAssignmentOp_assignAdd() throws Exception {
        Node n = new Node(Token.ASSIGN_ADD);
        assertEquals(Token.ADD, NodeUtil.getOpFromAssignmentOp(n));
    }

    @Test
    public void testGetOpFromAssignmentOp_assignBitOr() throws Exception {
        Node n = new Node(Token.ASSIGN_BITOR);
        assertEquals(Token.BITOR, NodeUtil.getOpFromAssignmentOp(n));
    }

    @Test
    public void testIsExpressionNode() throws Exception {
        Node n = NodeUtil.newExpr(Node.newString("test"));
        assertTrue(NodeUtil.isExpressionNode(n));
        Node nonExpr = Node.newString("test");
        assertFalse(NodeUtil.isExpressionNode(nonExpr));
    }


    @Test
    public void testContainsFunction_functionDeclaration() throws Exception {
        Node func = new Node(Token.FUNCTION);
        func.addChildrenToBack(Node.newString("f", -1, -1));
        func.addChildrenToBack(new Node(Token.LP));
        func.addChildrenToBack(new Node(Token.BLOCK));
        Node block = new Node(Token.BLOCK, func);
        assertTrue(NodeUtil.containsFunction(block));
    }

    @Test
    public void testContainsFunction_blockWithoutFunction() throws Exception {
        Node block = new Node(Token.BLOCK, Node.newString("test"));
        assertFalse(NodeUtil.containsFunction(block));
    }



    @Test
    public void testReferencesThis_standaloneThis() throws Exception {
        Node thisNode = new Node(Token.THIS);
        assertTrue(NodeUtil.referencesThis(thisNode));
    }

    @Test
    public void testIsGet_getProp() throws Exception {
        Node obj = Node.newString("obj");
        Node prop = Node.newString("prop");
        Node getNode = new Node(Token.GETPROP, obj, prop);
        assertTrue(NodeUtil.isGet(getNode));
    }

    @Test
    public void testIsGet_getElem() throws Exception {
        Node obj = Node.newString("obj");
        Node elem = Node.newNumber(0);
        Node getNode = new Node(Token.GETELEM, obj, elem);
        assertTrue(NodeUtil.isGet(getNode));
    }

    @Test
    public void testIsGet_name() throws Exception {
        Node n = Node.newString("varName");
        assertFalse(NodeUtil.isGet(n));
    }

    @Test
    public void testIsGetProp_getProp() throws Exception {
        Node obj = Node.newString("obj");
        Node prop = Node.newString("prop");
        Node getNode = new Node(Token.GETPROP, obj, prop);
        assertTrue(NodeUtil.isGetProp(getNode));
    }

    @Test
    public void testIsGetProp_getElem() throws Exception {
        Node obj = Node.newString("obj");
        Node elem = Node.newNumber(0);
        Node getNode = new Node(Token.GETELEM, obj, elem);
        assertFalse(NodeUtil.isGetProp(getNode));
    }

    @Test
    public void testIsName_nameNode() {}
// Defects4J: flaky method
//     @Test
//     public void testIsName_nameNode() throws Exception {
//         Node n = Node.newString("varName");
//         assertTrue(NodeUtil.isName(n));
//     }

    @Test
    public void testIsName_stringNode() throws Exception {
        Node n = Node.newString("varName");
        assertFalse(NodeUtil.isName(n));
    }

    @Test
    public void testIsNew_newNode() throws Exception {
        Node n = new Node(Token.NEW, Node.newString("Object"));
        assertTrue(NodeUtil.isNew(n));
    }


    @Test
    public void testIsVar_varNode() throws Exception {
        Node n = new Node(Token.VAR, Node.newString("varName"));
        assertTrue(NodeUtil.isVar(n));
    }

    @Test
    public void testIsVar_letNode() throws Exception {
        Node n = Node.newString("letVar");
        assertFalse(NodeUtil.isVar(n));
    }

    @Test
    public void testIsVarDeclaration_varNameNode() {}
// Defects4J: flaky method
//     @Test
//     public void testIsVarDeclaration_varNameNode() throws Exception {
//         Node varName = Node.newString("varName");
//         Node varNode = new Node(Token.VAR, varName);
//         assertTrue(NodeUtil.isVarDeclaration(varName));
//     }

    @Test
    public void testIsVarDeclaration_nameNodeNotVarParent() throws Exception {
        Node nameNode = Node.newString("someName");
        Node parent = new Node(Token.ADD, nameNode, Node.newNumber(1));
        assertFalse(NodeUtil.isVarDeclaration(nameNode));
    }

    @Test
    public void testGetAssignedValue_varDeclaration() {}
// Defects4J: flaky method
//     @Test
//     public void testGetAssignedValue_varDeclaration() throws Exception {
//         Node value = Node.newNumber(10);
//         Node nameNode = Node.newString("varName");
//         nameNode.addChildToBack(value);
//         Node varNode = new Node(Token.VAR, nameNode);
//         assertEquals(value, NodeUtil.getAssignedValue(nameNode));
//     }

    @Test
    public void testGetAssignedValue_assignment() {}
// Defects4J: flaky method
//     @Test
//     public void testGetAssignedValue_assignment() throws Exception {
//         Node value = Node.newNumber(20);
//         Node nameNode = Node.newString("varName");
//         Node assignNode = new Node(Token.ASSIGN, nameNode, value);
//         assertEquals(value, NodeUtil.getAssignedValue(nameNode));
//     }

    @Test
    public void testGetAssignedValue_nameNotInVarOrAssign() {}
// Defects4J: flaky method
//     @Test
//     public void testGetAssignedValue_nameNotInVarOrAssign() throws Exception {
//         Node nameNode = Node.newString("varName");
//         Node parent = new Node(Token.ADD, nameNode, Node.newNumber(1));
//         assertNull(NodeUtil.getAssignedValue(nameNode));
//     }

    @Test
    public void testIsString_stringNode() throws Exception {
        Node n = Node.newString("hello");
        assertTrue(NodeUtil.isString(n));
    }

    @Test
    public void testIsString_nameNode() {}
// Defects4J: flaky method
//     @Test
//     public void testIsString_nameNode() throws Exception {
//         Node n = Node.newString("hello");
//         assertFalse(NodeUtil.isString(n));
//     }

    @Test
    public void testIsExprAssign_validExprAssign() throws Exception {
        Node name = Node.newString("x");
        Node value = Node.newNumber(10);
        Node assign = new Node(Token.ASSIGN, name, value);
        Node exprAssign = new Node(Token.EXPR_RESULT, assign);
        assertTrue(NodeUtil.isExprAssign(exprAssign));
    }

    @Test
    public void testIsExprAssign_notExprResult() throws Exception {
        Node name = Node.newString("x");
        Node value = Node.newNumber(10);
        Node assign = new Node(Token.ASSIGN, name, value);
        assertFalse(NodeUtil.isExprAssign(assign));
    }

    @Test
    public void testIsExprAssign_exprResultNotAssign() throws Exception {
        Node exprResult = NodeUtil.newExpr(Node.newString("hello"));
        assertFalse(NodeUtil.isExprAssign(exprResult));
    }

    @Test
    public void testIsAssign_assignNode() throws Exception {
        Node n = new Node(Token.ASSIGN);
        assertTrue(NodeUtil.isAssign(n));
    }

    @Test
    public void testIsAssign_addNode() throws Exception {
        Node n = new Node(Token.ADD);
        assertFalse(NodeUtil.isAssign(n));
    }



    @Test
    public void testIsExprCall_exprResultNotCall() throws Exception {
        Node exprResult = NodeUtil.newExpr(Node.newString("hello"));
        assertFalse(NodeUtil.isExprCall(exprResult));
    }

    @Test
    public void testIsForIn_forInNode() throws Exception {
        Node loopVar = Node.newString("i");
        Node iterable = Node.newString("arr");
        Node body = new Node(Token.BLOCK);
        Node forInNode = new Node(Token.FOR, loopVar, iterable, body);
        assertTrue(NodeUtil.isForIn(forInNode));
    }


    @Test
    public void testIsLoopStructure_forLoop() throws Exception {
        Node forNode = new Node(Token.FOR);
        assertTrue(NodeUtil.isLoopStructure(forNode));
    }

    @Test
    public void testIsLoopStructure_whileLoop() throws Exception {
        Node whileNode = new Node(Token.WHILE);
        assertTrue(NodeUtil.isLoopStructure(whileNode));
    }

    @Test
    public void testIsLoopStructure_doLoop() throws Exception {
        Node doNode = new Node(Token.DO);
        assertTrue(NodeUtil.isLoopStructure(doNode));
    }

    @Test
    public void testIsLoopStructure_ifNode() throws Exception {
        Node ifNode = new Node(Token.IF);
        assertFalse(NodeUtil.isLoopStructure(ifNode));
    }


    @Test
    public void testGetLoopCodeBlock_whileLoop() throws Exception {
        Node condition = Node.newNumber(1);
        Node body = new Node(Token.BLOCK);
        Node whileNode = new Node(Token.WHILE, condition, body);
        assertEquals(body, NodeUtil.getLoopCodeBlock(whileNode));
    }

    @Test
    public void testGetLoopCodeBlock_doLoop() throws Exception {
        Node condition = Node.newNumber(1);
        Node body = new Node(Token.BLOCK);
        Node doNode = new Node(Token.DO, body, condition);
        assertEquals(body, NodeUtil.getLoopCodeBlock(doNode));
    }


    @Test
    public void testIsWithinLoop_outsideLoop() throws Exception {
        Node body = new Node(Token.BLOCK);
        Node script = new Node(Token.SCRIPT, body);
        assertFalse(NodeUtil.isWithinLoop(body));
    }


    @Test
    public void testIsControlStructure_forLoop() throws Exception {
        Node forNode = new Node(Token.FOR);
        assertTrue(NodeUtil.isControlStructure(forNode));
    }

    @Test
    public void testIsControlStructure_ifNode() throws Exception {
        Node ifNode = new Node(Token.IF);
        assertTrue(NodeUtil.isControlStructure(ifNode));
    }

    @Test
    public void testIsControlStructure_tryNode() throws Exception {
        Node tryNode = new Node(Token.TRY);
        assertTrue(NodeUtil.isControlStructure(tryNode));
    }

    @Test
    public void testIsControlStructure_blockNode() throws Exception {
        Node blockNode = new Node(Token.BLOCK);
        assertFalse(NodeUtil.isControlStructure(blockNode));
    }

    @Test
    public void testIsControlStructureCodeBlock_ifCondition() throws Exception {
        Node condition = Node.newNumber(1);
        Node thenBlock = new Node(Token.BLOCK);
        Node ifNode = new Node(Token.IF, condition, thenBlock);
        assertFalse(NodeUtil.isControlStructureCodeBlock(ifNode, condition));
    }

    @Test
    public void testIsControlStructureCodeBlock_ifThenBlock() throws Exception {
        Node condition = Node.newNumber(1);
        Node thenBlock = new Node(Token.BLOCK);
        Node ifNode = new Node(Token.IF, condition, thenBlock);
        assertTrue(NodeUtil.isControlStructureCodeBlock(ifNode, thenBlock));
    }



    @Test
    public void testGetConditionExpression_ifNode() throws Exception {
        Node condition = Node.newNumber(1);
        Node thenBlock = new Node(Token.BLOCK);
        Node ifNode = new Node(Token.IF, condition, thenBlock);
        assertEquals(condition, NodeUtil.getConditionExpression(ifNode));
    }

    @Test
    public void testGetConditionExpression_whileNode() throws Exception {
        Node condition = Node.newNumber(1);
        Node body = new Node(Token.BLOCK);
        Node whileNode = new Node(Token.WHILE, condition, body);
        assertEquals(condition, NodeUtil.getConditionExpression(whileNode));
    }

    @Test
    public void testGetConditionExpression_doNode() throws Exception {
        Node condition = Node.newNumber(1);
        Node body = new Node(Token.BLOCK);
        Node doNode = new Node(Token.DO, body, condition);
        assertEquals(condition, NodeUtil.getConditionExpression(doNode));
    }


    @Test
    public void testIsStatementBlock_scriptNode() throws Exception {
        Node scriptNode = new Node(Token.SCRIPT);
        assertTrue(NodeUtil.isStatementBlock(scriptNode));
    }

    @Test
    public void testIsStatementBlock_blockNode() throws Exception {
        Node blockNode = new Node(Token.BLOCK);
        assertTrue(NodeUtil.isStatementBlock(blockNode));
    }

    @Test
    public void testIsStatementBlock_nameNode() throws Exception {
        Node nameNode = Node.newString("test");
        assertFalse(NodeUtil.isStatementBlock(nameNode));
    }

    @Test
    public void testIsStatement_statementInBlock() throws Exception {
        Node statement = Node.newString("statement");
        Node block = new Node(Token.BLOCK, statement);
        assertTrue(NodeUtil.isStatement(statement));
    }

    @Test
    public void testIsStatement_statementInScript() throws Exception {
        Node statement = Node.newString("statement");
        Node script = new Node(Token.SCRIPT, statement);
        assertTrue(NodeUtil.isStatement(statement));
    }

    @Test
    public void testIsStatement_statementInLabel() throws Exception {
        Node statement = Node.newString("statement");
        Node label = new Node(Token.LABEL, Node.newString("myLabel"), statement);
        assertTrue(NodeUtil.isStatement(statement));
    }

    @Test
    public void testIsStatement_expressionInBlock() throws Exception {
        Node expression = NodeUtil.newExpr(Node.newString("expression"));
        Node block = new Node(Token.BLOCK, expression);
        assertTrue(NodeUtil.isStatement(expression));
    }

    @Test
    public void testIsStatement_expressionNotInStatementBlock() throws Exception {
        Node expression = NodeUtil.newExpr(Node.newString("expression"));
        Node parent = new Node(Token.ADD, expression, Node.newNumber(1));
        assertFalse(NodeUtil.isStatement(expression));
    }

    @Test
    public void testIsStatementParent_block() throws Exception {
        Node parent = new Node(Token.BLOCK);
        assertTrue(NodeUtil.isStatementParent(parent));
    }

    @Test
    public void testIsStatementParent_script() throws Exception {
        Node parent = new Node(Token.SCRIPT);
        assertTrue(NodeUtil.isStatementParent(parent));
    }

    @Test
    public void testIsStatementParent_label() throws Exception {
        Node parent = new Node(Token.LABEL);
        assertTrue(NodeUtil.isStatementParent(parent));
    }

    @Test
    public void testIsStatementParent_function() throws Exception {
        Node parent = new Node(Token.FUNCTION);
        assertFalse(NodeUtil.isStatementParent(parent));
    }

    @Test
    public void testIsSwitchCase_caseNode() throws Exception {
        Node n = new Node(Token.CASE);
        assertTrue(NodeUtil.isSwitchCase(n));
    }

    @Test
    public void testIsSwitchCase_defaultNode() throws Exception {
        Node n = new Node(Token.DEFAULT);
        assertTrue(NodeUtil.isSwitchCase(n));
    }

    @Test
    public void testIsSwitchCase_blockNode() throws Exception {
        Node n = new Node(Token.BLOCK);
        assertFalse(NodeUtil.isSwitchCase(n));
    }

    @Test
    public void testIsReferenceName_nameNode() {}
// Defects4J: flaky method
//     @Test
//     public void testIsReferenceName_nameNode() throws Exception {
//         Node n = Node.newString("myVar");
//         assertTrue(NodeUtil.isReferenceName(n));
//     }

    @Test
    public void testIsReferenceName_emptyStringNameNode() throws Exception {
        Node n = Node.newString(Token.NAME, "");
        assertFalse(NodeUtil.isReferenceName(n));
    }

    @Test
    public void testIsReferenceName_stringNode() throws Exception {
        Node n = Node.newString("myVar");
        assertFalse(NodeUtil.isReferenceName(n));
    }

    @Test
    public void testIsLabelName_labelNameNode() throws Exception {
        Node n = new Node(Token.LABEL_NAME);
        assertTrue(NodeUtil.isLabelName(n));
    }

    @Test
    public void testIsLabelName_nameNode() throws Exception {
        Node n = Node.newString("myLabel");
        assertFalse(NodeUtil.isLabelName(n));
    }

    @Test
    public void testIsTryFinallyNode_finallyBlock() {}
// Defects4J: flaky method
//     @Test
//     public void testIsTryFinallyNode_finallyBlock() throws Exception {
//         Node tryNode = new Node(Token.TRY);
//         Node catchBlock = new Node(Token.BLOCK);
//         Node finallyBlock = new Node(Token.BLOCK);
//         tryNode.addChildrenToBack(catchBlock);
//         tryNode.addChildrenToBack(finallyBlock);
//         assertTrue(NodeUtil.isTryFinallyNode(tryNode, finallyBlock));
//     }

    @Test
    public void testIsTryFinallyNode_catchBlock() throws Exception {
        Node tryNode = new Node(Token.TRY);
        Node catchBlock = new Node(Token.BLOCK);
        Node finallyBlock = new Node(Token.BLOCK);
        tryNode.addChildrenToBack(catchBlock);
        tryNode.addChildrenToBack(finallyBlock);
        assertFalse(NodeUtil.isTryFinallyNode(tryNode, catchBlock));
    }

    @Test
    public void testIsTryFinallyNode_noFinally() throws Exception {
        Node tryNode = new Node(Token.TRY);
        Node catchBlock = new Node(Token.BLOCK);
        tryNode.addChildrenToBack(catchBlock);
        assertFalse(NodeUtil.isTryFinallyNode(tryNode, new Node(Token.BLOCK)));
    }

    @Test
    public void testIsTryCatchNodeContainer_catchBlockContainer() {}
// Defects4J: flaky method
//     @Test
//     public void testIsTryCatchNodeContainer_catchBlockContainer() throws Exception {
//         Node tryNode = new Node(Token.TRY);
//         Node catchBlock = new Node(Token.BLOCK);
//         Node catchNode = new Node(Token.CATCH, Node.newString("e"), catchBlock);
//         tryNode.addChildrenToBack(catchNode);
//         assertTrue(NodeUtil.isTryCatchNodeContainer(catchBlock));
//     }

    @Test
    public void testIsTryCatchNodeContainer_finallyBlock() throws Exception {
        Node tryNode = new Node(Token.TRY);
        Node finallyBlock = new Node(Token.BLOCK);
        tryNode.addChildrenToBack(finallyBlock);
        assertFalse(NodeUtil.isTryCatchNodeContainer(finallyBlock));
    }

    @Test
    public void testRemoveChild_emptyBlock() {}
// Defects4J: flaky method
//     @Test
//     public void testRemoveChild_emptyBlock() throws Exception {
//         Node block = new Node(Token.BLOCK);
//         Node parent = new Node(Token.SCRIPT, block);
//         NodeUtil.removeChild(block, new Node(Token.EMPTY));
//         assertFalse(block.hasChildren());
//     }

    @Test
    public void testRemoveChild_statementInBlock() throws Exception {
        Node statement = Node.newString("test");
        Node block = new Node(Token.BLOCK, statement);
        Node parent = new Node(Token.SCRIPT, block);
        NodeUtil.removeChild(block, statement);
        assertFalse(block.hasChildren());
    }

    @Test
    public void testRemoveChild_varWithMultipleDeclarations() throws Exception {
        Node var1 = Node.newString("v1");
        Node var2 = Node.newString("v2");
        Node varNode = new Node(Token.VAR, var1, var2);
        NodeUtil.removeChild(varNode, var1);
        assertEquals(1, varNode.getChildCount());
        assertEquals(var2, varNode.getFirstChild());
    }

    @Test
    public void testRemoveChild_varWithSingleDeclaration() throws Exception {
        Node var1 = Node.newString("v1");
        Node varNode = new Node(Token.VAR, var1);
        Node parent = new Node(Token.BLOCK, varNode);
        NodeUtil.removeChild(varNode, var1);
        assertEquals(0, varNode.getChildCount());
        assertFalse(parent.hasChildren());
    }

    @Test
    public void testRemoveChild_labelWithStatement() {}
// Defects4J: flaky method
//     @Test
//     public void testRemoveChild_labelWithStatement() throws Exception {
//         Node statement = Node.newString("statement");
//         Node label = new Node(Token.LABEL, Node.newString("myLabel"), statement);
//         Node parent = new Node(Token.BLOCK, label);
//         NodeUtil.removeChild(label, statement);
//         assertEquals(1, label.getChildCount());
//         assertEquals(Node.newString("myLabel"), label.getFirstChild());
//     }

    @Test
    public void testRemoveChild_labelWithoutStatement() throws Exception {
        Node label = new Node(Token.LABEL, Node.newString("myLabel"));
        Node parent = new Node(Token.BLOCK, label);
        NodeUtil.removeChild(parent, label);
        assertFalse(parent.hasChildren());
    }


    @Test
    public void testMaybeAddFinally_noFinally() {}
// Defects4J: flaky method
//     @Test
//     public void testMaybeAddFinally_noFinally() throws Exception {
//         Node tryNode = new Node(Token.TRY);
//         Node catchBlock = new Node(Token.BLOCK);
//         tryNode.addChildrenToBack(catchBlock);
//         NodeUtil.maybeAddFinally(tryNode);
//         assertEquals(3, tryNode.getChildCount());
//         assertEquals(Token.BLOCK, tryNode.getLastChild().getType());
//     }

    @Test
    public void testMaybeAddFinally_alreadyHasFinally() {}
// Defects4J: flaky method
//     @Test
//     public void testMaybeAddFinally_alreadyHasFinally() throws Exception {
//         Node tryNode = new Node(Token.TRY);
//         Node catchBlock = new Node(Token.BLOCK);
//         Node finallyBlock = new Node(Token.BLOCK);
//         tryNode.addChildrenToBack(catchBlock);
//         tryNode.addChildrenToBack(finallyBlock);
//         int initialChildCount = tryNode.getChildCount();
//         NodeUtil.maybeAddFinally(tryNode);
//         assertEquals(initialChildCount, tryNode.getChildCount());
//     }

    @Test
    public void testTryMergeBlock_mergeIntoScript() throws Exception {
        Node blockToMerge = new Node(Token.BLOCK, Node.newString("stmt1"));
        Node script = new Node(Token.SCRIPT, blockToMerge);
        NodeUtil.tryMergeBlock(blockToMerge);
        assertEquals(Token.SCRIPT, script.getType());
        assertEquals("stmt1", script.getFirstChild().getString());
    }

    @Test
    public void testTryMergeBlock_mergeIntoBlock() throws Exception {
        Node childStmt = Node.newString("child");
        Node blockToMerge = new Node(Token.BLOCK, childStmt);
        Node parentBlock = new Node(Token.BLOCK, blockToMerge);
        NodeUtil.tryMergeBlock(blockToMerge);
        assertEquals(Token.BLOCK, parentBlock.getType());
        assertEquals("child", parentBlock.getFirstChild().getString());
    }

    @Test
    public void testTryMergeBlock_doNotMergeIntoOther() throws Exception {
        Node blockToMerge = new Node(Token.BLOCK, Node.newString("stmt1"));
        Node otherNode = new Node(Token.IF, Node.newNumber(1), blockToMerge);
        Node parent = new Node(Token.SCRIPT, otherNode);
        assertFalse(NodeUtil.tryMergeBlock(blockToMerge));
    }


    @Test
    public void testIsCall_newNode() throws Exception {
        Node n = new Node(Token.NEW, Node.newString("Object"));
        assertFalse(NodeUtil.isCall(n));
    }


    @Test
    public void testIsCallOrNew_newNode() throws Exception {
        Node n = new Node(Token.NEW, Node.newString("Object"));
        assertTrue(NodeUtil.isCallOrNew(n));
    }

    @Test
    public void testIsCallOrNew_nameNode() throws Exception {
        Node n = Node.newString("foo");
        assertFalse(NodeUtil.isCallOrNew(n));
    }


    @Test
    public void testIsFunction_blockNode() throws Exception {
        Node n = new Node(Token.BLOCK);
        assertFalse(NodeUtil.isFunction(n));
    }


    @Test
    public void testIsThis_thisNode() throws Exception {
        Node n = new Node(Token.THIS);
        assertTrue(NodeUtil.isThis(n));
    }

    @Test
    public void testIsThis_nameNode() throws Exception {
        Node n = Node.newString("this");
        assertFalse(NodeUtil.isThis(n));
    }

    @Test
    public void testIsArrayLiteral_arrayLiteralNode() throws Exception {
        Node n = new Node(Token.ARRAYLIT);
        assertTrue(NodeUtil.isArrayLiteral(n));
    }

    @Test
    public void testIsArrayLiteral_objectLiteralNode() throws Exception {
        Node n = new Node(Token.OBJECTLIT);
        assertFalse(NodeUtil.isArrayLiteral(n));
    }


    @Test
    public void testContainsCall_noCall() throws Exception {
        Node n = Node.newString("test");
        assertFalse(NodeUtil.containsCall(n));
    }

    @Test
    public void testIsFunctionDeclaration_functionStatement() throws Exception {
        Node func = new Node(Token.FUNCTION);
        func.addChildrenToBack(Node.newString("f", -1, -1));
        func.addChildrenToBack(new Node(Token.LP));
        func.addChildrenToBack(new Node(Token.BLOCK));
        Node block = new Node(Token.BLOCK, func);
        assertTrue(NodeUtil.isFunctionDeclaration(func));
    }


    @Test
    public void testIsHoistedFunctionDeclaration_topLevel() throws Exception {
        Node func = new Node(Token.FUNCTION);
        func.addChildrenToBack(Node.newString("f", -1, -1));
        func.addChildrenToBack(new Node(Token.LP));
        func.addChildrenToBack(new Node(Token.BLOCK));
        Node script = new Node(Token.SCRIPT, func);
        assertTrue(NodeUtil.isHoistedFunctionDeclaration(func));
    }




    @Test
    public void testIsFunctionExpression_functionDeclaration() throws Exception {
        Node func = new Node(Token.FUNCTION);
        func.addChildrenToBack(Node.newString("f", -1, -1));
        func.addChildrenToBack(new Node(Token.LP));
        func.addChildrenToBack(new Node(Token.BLOCK));
        Node block = new Node(Token.BLOCK, func);
        assertFalse(NodeUtil.isFunctionExpression(func));
    }



    @Test
    public void testIsEmptyFunctionExpression_notFunctionExpression() {}
// Defects4J: flaky method
//     @Test
//     public void testIsEmptyFunctionExpression_notFunctionExpression() throws Exception {
//         Node func = new Node(Token.FUNCTION);
//         func.addChildrenToBack(Node.newString("f", -1, -1));
//         func.addChildrenToBack(new Node(Token.LP));
//         func.addChildrenToBack(new Node(Token.BLOCK));
//         assertFalse(NodeUtil.isEmptyFunctionExpression(func));
//     }















    @Test
    public void testIsVarOrSimpleAssignLhs_varDeclaration() throws Exception {
        Node nameNode = Node.newString("varName");
        Node varNode = new Node(Token.VAR, nameNode);
        assertTrue(NodeUtil.isVarOrSimpleAssignLhs(nameNode, varNode));
    }

    @Test
    public void testIsVarOrSimpleAssignLhs_assignmentLhs() throws Exception {
        Node nameNode = Node.newString("varName");
        Node value = Node.newNumber(10);
        Node assignNode = new Node(Token.ASSIGN, nameNode, value);
        assertTrue(NodeUtil.isVarOrSimpleAssignLhs(nameNode, assignNode));
    }

    @Test
    public void testIsVarOrSimpleAssignLhs_assignmentRhs() throws Exception {
        Node nameNode = Node.newString("varName");
        Node value = Node.newNumber(10);
        Node assignNode = new Node(Token.ASSIGN, nameNode, value);
        assertFalse(NodeUtil.isVarOrSimpleAssignLhs(value, assignNode));
    }

    @Test
    public void testIsLValue_varDeclaration() {}
// Defects4J: flaky method
//     @Test
//     public void testIsLValue_varDeclaration() throws Exception {
//         Node nameNode = Node.newString("varName");
//         Node varNode = new Node(Token.VAR, nameNode);
//         assertTrue(NodeUtil.isLValue(nameNode));
//     }

    @Test
    public void testIsLValue_assignmentLhs() {}
// Defects4J: flaky method
//     @Test
//     public void testIsLValue_assignmentLhs() throws Exception {
//         Node nameNode = Node.newString("varName");
//         Node value = Node.newNumber(10);
//         Node assignNode = new Node(Token.ASSIGN, nameNode, value);
//         assertTrue(NodeUtil.isLValue(nameNode));
//     }

    @Test
    public void testIsLValue_assignmentRhs() {}
// Defects4J: flaky method
//     @Test
//     public void testIsLValue_assignmentRhs() throws Exception {
//         Node nameNode = Node.newString("varName");
//         Node value = Node.newNumber(10);
//         Node assignNode = new Node(Token.ASSIGN, nameNode, value);
//         assertFalse(NodeUtil.isLValue(value));
//     }

    @Test
    public void testIsLValue_getProp() throws Exception {
        Node obj = Node.newString("obj");
        Node prop = Node.newString("prop");
        Node getPropNode = new Node(Token.GETPROP, obj, prop);
        Node assignNode = new Node(Token.ASSIGN, getPropNode, Node.newNumber(10));
        assertTrue(NodeUtil.isLValue(getPropNode));
    }

    @Test
    public void testIsLValue_getElem() throws Exception {
        Node obj = Node.newString("obj");
        Node elem = Node.newNumber(0);
        Node getElemNode = new Node(Token.GETELEM, obj, elem);
        Node assignNode = new Node(Token.ASSIGN, getElemNode, Node.newNumber(10));
        assertTrue(NodeUtil.isLValue(getElemNode));
    }

    @Test
    public void testIsLValue_inc() {}
// Defects4J: flaky method
//     @Test
//     public void testIsLValue_inc() throws Exception {
//         Node nameNode = Node.newString("varName");
//         Node incNode = new Node(Token.INC, nameNode);
//         assertTrue(NodeUtil.isLValue(nameNode));
//     }

    @Test
    public void testIsLValue_functionNameInDeclaration() {}
// Defects4J: flaky method
//     @Test
//     public void testIsLValue_functionNameInDeclaration() throws Exception {
//         Node func = new Node(Token.FUNCTION);
//         func.addChildrenToBack(Node.newString("f", -1, -1));
//         func.addChildrenToBack(new Node(Token.LP));
//         func.addChildrenToBack(new Node(Token.BLOCK));
//         assertTrue(NodeUtil.isLValue(func.getFirstChild()));
//     }

    @Test
    public void testIsObjectLitKey_stringKey() throws Exception {
        Node key = Node.newString("myKey");
        Node value = Node.newNumber(1);
        Node objLitProp = new Node(Token.SET, key, value);
        Node parent = new Node(Token.OBJECTLIT, objLitProp);
        assertTrue(NodeUtil.isObjectLitKey(key, parent));
    }

    @Test
    public void testIsObjectLitKey_getSetterKey() throws Exception {
        Node key = Node.newString("myKey");
        Node value = Node.newNumber(1);
        Node objLitProp = new Node(Token.GET, key, value);
        Node parent = new Node(Token.OBJECTLIT, objLitProp);
        assertTrue(NodeUtil.isObjectLitKey(key, parent));
    }

    @Test
    public void testIsObjectLitKey_regularNameNode() {}
// Defects4J: flaky method
//     @Test
//     public void testIsObjectLitKey_regularNameNode() throws Exception {
//         Node key = Node.newString("myKey");
//         Node parent = new Node(Token.OBJECTLIT);
//         assertFalse(NodeUtil.isObjectLitKey(key, parent));
//     }

    @Test
    public void testGetObjectLitKeyName_stringKey() throws Exception {
        Node key = Node.newString("myKey");
        assertEquals("myKey", NodeUtil.getObjectLitKeyName(key));
    }

    @Test
    public void testGetObjectLitKeyName_getSetterKey() {}
// Defects4J: flaky method
//     @Test
//     public void testGetObjectLitKeyName_getSetterKey() throws Exception {
//         Node key = Node.newString("myKey");
//         Node getOrSet = new Node(Token.GET, key, Node.newNumber(1));
//         assertEquals("myKey", NodeUtil.getObjectLitKeyName(getOrSet));
//     }

    @Test
    public void testGetObjectLitKeyTypeFromValueType_getter() throws Exception {
        Node key = new Node(Token.GET);
        assertTrue(key.getType() == Token.GET);
    }

    @Test
    public void testGetObjectLitKeyTypeFromValueType_setter() throws Exception {
        Node key = new Node(Token.SET);
        assertTrue(key.getType() == Token.SET);
    }

    @Test
    public void testIsGetOrSetKey_getNode() throws Exception {
        Node key = new Node(Token.GET);
        assertTrue(NodeUtil.isGetOrSetKey(key));
    }

    @Test
    public void testIsGetOrSetKey_setNode() throws Exception {
        Node key = new Node(Token.SET);
        assertTrue(NodeUtil.isGetOrSetKey(key));
    }

    @Test
    public void testIsGetOrSetKey_stringNode() throws Exception {
        Node key = Node.newString("key");
        assertFalse(NodeUtil.isGetOrSetKey(key));
    }

    @Test
    public void testOpToStr_add() throws Exception {
        assertEquals("+", NodeUtil.opToStr(Token.ADD));
    }

    @Test
    public void testOpToStr_assignAdd() throws Exception {
        assertEquals("+=", NodeUtil.opToStr(Token.ASSIGN_ADD));
    }

    @Test
    public void testOpToStr_logicalAnd() throws Exception {
        assertEquals("&&", NodeUtil.opToStr(Token.AND));
    }

    @Test
    public void testOpToStr_bitwiseAnd() throws Exception {
        assertEquals("&", NodeUtil.opToStr(Token.BITAND));
    }

    @Test
    public void testOpToStr_equality() throws Exception {
        assertEquals("==", NodeUtil.opToStr(Token.EQ));
    }

    @Test
    public void testOpToStr_strictEquality() throws Exception {
        assertEquals("===", NodeUtil.opToStr(Token.SHEQ));
    }

    @Test
    public void testOpToStr_lessThan() throws Exception {
        assertEquals("<", NodeUtil.opToStr(Token.LT));
    }

    @Test
    public void testOpToStr_greaterThanOrEqual() throws Exception {
        assertEquals(">=", NodeUtil.opToStr(Token.GE));
    }

    @Test
    public void testOpToStr_shiftLeft() throws Exception {
        assertEquals("<<", NodeUtil.opToStr(Token.LSH));
    }

    @Test
    public void testOpToStr_unsignedRightShift() throws Exception {
        assertEquals(">>>", NodeUtil.opToStr(Token.URSH));
    }

    @Test
    public void testOpToStr_void() throws Exception {
        assertEquals("void", NodeUtil.opToStr(Token.VOID));
    }

    @Test
    public void testOpToStr_unknown() throws Exception {
        assertNull(NodeUtil.opToStr(Token.LAST_TOKEN + 1));
    }

    @Test
    public void testOpToStrNoFail_add() throws Exception {
        assertEquals("+", NodeUtil.opToStrNoFail(Token.ADD));
    }

    @Test
    public void testOpToStrNoFail_unknown() {}
// Defects4J: flaky method
//     @Test
//     public void testOpToStrNoFail_unknown() throws Exception {
//         try {
//             NodeUtil.opToStrNoFail(Token.LAST_TOKEN + 1);
//             fail("Expected error for unknown operator");
//         } catch (Error e) {
//         }
//     }

    @Test
    public void testContainsType_nodeWithMatchingChild() {}
// Defects4J: flaky method
//     @Test
//     public void testContainsType_nodeWithMatchingChild() throws Exception {
//         Node child = Node.newString("name");
//         Node parent = new Node(Token.BLOCK, child);
//         assertTrue(NodeUtil.containsType(parent, Token.NAME));
//     }

    @Test
    public void testContainsType_nodeWithoutMatchingChild() throws Exception {
        Node child = Node.newString("string");
        Node parent = new Node(Token.BLOCK, child);
        assertFalse(NodeUtil.containsType(parent, Token.NAME));
    }

    @Test
    public void testContainsType_nestedMatchingChild() {}
// Defects4J: flaky method
//     @Test
//     public void testContainsType_nestedMatchingChild() throws Exception {
//         Node grandChild = Node.newString("name");
//         Node child = new Node(Token.BLOCK, grandChild);
//         Node parent = new Node(Token.SCRIPT, child);
//         assertTrue(NodeUtil.containsType(parent, Token.NAME));
//     }

    @Test
    public void testRedeclareVarsInsideBranch_noVars() throws Exception {
        Node branch = new Node(Token.BLOCK, Node.newString("test"));
        Node parent = new Node(Token.SCRIPT, branch);
        NodeUtil.redeclareVarsInsideBranch(branch);
        assertEquals(1, branch.getChildCount());
    }

    @Test
    public void testRedeclareVarsInsideBranch_singleVar() {}
// Defects4J: flaky method
//     @Test
//     public void testRedeclareVarsInsideBranch_singleVar() throws Exception {
//         Node varName = Node.newString("myVar");
//         varName.putBooleanProp(Node.IS_CONSTANT_NAME, true);
//         Node varDecl = new Node(Token.VAR, varName);
//         Node branch = new Node(Token.BLOCK, varDecl);
//         Node parent = new Node(Token.SCRIPT, branch);
// 
//         NodeUtil.redeclareVarsInsideBranch(branch);
// 
//         assertEquals(2, branch.getChildCount());
//         Node redeclaredVar = branch.getFirstChild();
//         assertEquals(Token.VAR, redeclaredVar.getType());
//         assertEquals("myVar", redeclaredVar.getFirstChild().getString());
//         assertTrue(redeclaredVar.getFirstChild().getBooleanProp(Node.IS_CONSTANT_NAME));
//     }

    @Test
    public void testRedeclareVarsInsideBranch_multipleVars() {}
// Defects4J: flaky method
//     @Test
//     public void testRedeclareVarsInsideBranch_multipleVars() throws Exception {
//         Node varName1 = Node.newString("var1");
//         Node varDecl1 = new Node(Token.VAR, varName1);
//         Node varName2 = Node.newString("var2");
//         Node varDecl2 = new Node(Token.VAR, varName2);
//         Node branch = new Node(Token.BLOCK, varDecl1, varDecl2);
//         Node parent = new Node(Token.SCRIPT, branch);
// 
//         NodeUtil.redeclareVarsInsideBranch(branch);
// 
//         assertEquals(4, branch.getChildCount());
//         Node redeclaredVar1 = branch.getFirstChild();
//         assertEquals("var1", redeclaredVar1.getFirstChild().getString());
//         Node redeclaredVar2 = branch.getChildAtIndex(2);
//         assertEquals("var2", redeclaredVar2.getFirstChild().getString());
//     }


    @Test
    public void testNewFunctionNode_basicFunction() throws Exception {
        Node body = new Node(Token.BLOCK);
        List<Node> params = Arrays.asList(Node.newString("p1"), Node.newString("p2"));
        Node func = NodeUtil.newFunctionNode("myFunc", params, body, 1, 10);
        assertEquals(Token.FUNCTION, func.getType());
        assertEquals("myFunc", func.getChildAtIndex(0).getString());
        assertEquals(Token.LP, func.getChildAtIndex(1).getType());
        assertEquals(body, func.getLastChild());
    }



    @Test
    public void testGetRootOfQualifiedName_nameNode() {}
// Defects4J: flaky method
//     @Test
//     public void testGetRootOfQualifiedName_nameNode() throws Exception {
//         Node n = Node.newString("myVar");
//         assertEquals(n, NodeUtil.getRootOfQualifiedName(n));
//     }

    @Test
    public void testGetRootOfQualifiedName_getProp() {}
// Defects4J: flaky method
//     @Test
//     public void testGetRootOfQualifiedName_getProp() throws Exception {
//         Node root = Node.newString("root");
//         Node prop1 = Node.newString("prop1");
//         Node prop2 = Node.newString("prop2");
//         Node getProp1 = new Node(Token.GETPROP, root, prop1);
//         Node getProp2 = new Node(Token.GETPROP, getProp1, prop2);
//         assertEquals(root, NodeUtil.getRootOfQualifiedName(getProp2));
//     }

    @Test
    public void testGetRootOfQualifiedName_thisNode() throws Exception {
        Node n = new Node(Token.THIS);
        assertEquals(n, NodeUtil.getRootOfQualifiedName(n));
    }

    @Test
    public void testGetFunctionJSDocInfo_functionNode() throws Exception {
        JSDocInfo jsDoc = new JSDocInfo();
        Node func = new Node(Token.FUNCTION);
        func.setJSDocInfo(jsDoc);
        assertEquals(jsDoc, NodeUtil.getFunctionJSDocInfo(func));
    }





    @Test
    public void testGetSourceName_noSourceFile() throws Exception {
        Node n = Node.newString("test");
        assertNull(NodeUtil.getSourceName(n));
    }

    @Test
    public void testNewCallNode_freeCall() throws Exception {
        Node callTarget = Node.newString("foo");
        Node param1 = Node.newNumber(1);
        Node param2 = Node.newString("bar");
        Node callNode = NodeUtil.newCallNode(callTarget, param1, param2);
        assertTrue(callNode.getBooleanProp(Node.FREE_CALL));
        assertEquals(callTarget, callNode.getFirstChild());
        assertEquals(param1, callNode.getChildAtIndex(1));
        assertEquals(param2, callNode.getLastChild());
    }

    @Test
    public void testNewCallNode_nonFreeCall() throws Exception {
        Node obj = Node.newString("obj");
        Node method = Node.newString("method");
        Node callTarget = new Node(Token.GETPROP, obj, method);
        Node param1 = Node.newNumber(1);
        Node callNode = NodeUtil.newCallNode(callTarget, param1);
        assertFalse(callNode.getBooleanProp(Node.FREE_CALL));
        assertEquals(callTarget, callNode.getFirstChild());
        assertEquals(param1, callNode.getLastChild());
    }

    @Test
    public void testEvaluatesToLocalValue_assignment() throws Exception {
        Node child = Node.newNumber(5);
        Node assignment = new Node(Token.ASSIGN, Node.newString("x"), child);
        assertTrue(NodeUtil.evaluatesToLocalValue(assignment));
    }

    @Test
    public void testEvaluatesToLocalValue_comma() throws Exception {
        Node child = Node.newNumber(5);
        Node comma = new Node(Token.COMMA, Node.newNumber(1), child);
        assertTrue(NodeUtil.evaluatesToLocalValue(comma));
    }

    @Test
    public void testEvaluatesToLocalValue_andOperator() throws Exception {
        Node left = Node.newNumber(1);
        Node right = Node.newNumber(0);
        Node andOp = new Node(Token.AND, left, right);
        assertTrue(NodeUtil.evaluatesToLocalValue(andOp));
    }

    @Test
    public void testEvaluatesToLocalValue_orOperator() throws Exception {
        Node left = Node.newNumber(1);
        Node right = Node.newNumber(0);
        Node orOp = new Node(Token.OR, left, right);
        assertTrue(NodeUtil.evaluatesToLocalValue(orOp));
    }

    @Test
    public void testEvaluatesToLocalValue_hookOperator() throws Exception {
        Node condition = Node.newNumber(1);
        Node trueVal = Node.newNumber(2);
        Node falseVal = Node.newNumber(3);
        Node hookOp = new Node(Token.HOOK, condition, trueVal, falseVal);
        assertTrue(NodeUtil.evaluatesToLocalValue(hookOp));
    }

    @Test
    public void testEvaluatesToLocalValue_increment() throws Exception {
        Node nameNode = Node.newString("x");
        Node incNode = new Node(Token.INC, nameNode);
        incNode.putBooleanProp(Node.INCRDECR_PROP, true);
        assertTrue(NodeUtil.evaluatesToLocalValue(incNode));
    }

    @Test
    public void testEvaluatesToLocalValue_decrement() throws Exception {
        Node nameNode = Node.newString("x");
        Node decNode = new Node(Token.DEC, nameNode);
        decNode.putBooleanProp(Node.INCRDECR_PROP, true);
        assertTrue(NodeUtil.evaluatesToLocalValue(decNode));
    }

    @Test
    public void testEvaluatesToLocalValue_thisNode() throws Exception {
        Node thisNode = new Node(Token.THIS);
        assertFalse(NodeUtil.evaluatesToLocalValue(thisNode));
    }

    @Test
    public void testEvaluatesToLocalValue_nameNodeImmutable() throws Exception {
        Node nameNode = Node.newString("undefined");
        assertTrue(NodeUtil.evaluatesToLocalValue(nameNode));
    }

    @Test
    public void testEvaluatesToLocalValue_nameNodeLocal() {}
// Defects4J: flaky method
//     @Test
//     public void testEvaluatesToLocalValue_nameNodeLocal() throws Exception {
//         Node nameNode = Node.newString("myVar");
//         Predicate<Node> locals = n -> n.getString().equals("myVar");
//         assertTrue(NodeUtil.evaluatesToLocalValue(nameNode, locals));
//     }

    @Test
    public void testEvaluatesToLocalValue_getElem() throws Exception {
        Node obj = Node.newString("obj");
        Node elem = Node.newNumber(0);
        Node getElemNode = new Node(Token.GETELEM, obj, elem);
        assertFalse(NodeUtil.evaluatesToLocalValue(getElemNode));
    }

    @Test
    public void testEvaluatesToLocalValue_getProp() throws Exception {
        Node obj = Node.newString("obj");
        Node prop = Node.newString("prop");
        Node getPropNode = new Node(Token.GETPROP, obj, prop);
        assertFalse(NodeUtil.evaluatesToLocalValue(getPropNode));
    }





    @Test
    public void testEvaluatesToLocalValue_newNodeWithoutLocalResult() throws Exception {
        Node newNode = new Node(Token.NEW, Node.newString("Object"));
        assertFalse(NodeUtil.evaluatesToLocalValue(newNode));
    }

    @Test
    public void testEvaluatesToLocalValue_objectLiteral() throws Exception {
        Node objLit = new Node(Token.OBJECTLIT);
        assertTrue(NodeUtil.evaluatesToLocalValue(objLit));
    }

    @Test
    public void testEvaluatesToLocalValue_arrayLiteral() throws Exception {
        Node arrayLit = new Node(Token.ARRAYLIT);
        assertTrue(NodeUtil.evaluatesToLocalValue(arrayLit));
    }

    @Test
    public void testEvaluatesToLocalValue_regexpLiteral() throws Exception {
        Node regexpLit = new Node(Token.REGEXP);
        assertTrue(NodeUtil.evaluatesToLocalValue(regexpLit));
    }

    @Test
    public void testEvaluatesToLocalValue_delProp() throws Exception {
        Node delPropNode = new Node(Token.DELPROP, Node.newString("obj"), Node.newString("prop"));
        assertTrue(NodeUtil.evaluatesToLocalValue(delPropNode));
    }

    @Test
    public void testEvaluatesToLocalValue_inOperator() throws Exception {
        Node left = Node.newString("prop");
        Node right = Node.newString("obj");
        Node inOp = new Node(Token.IN, left, right);
        assertTrue(NodeUtil.evaluatesToLocalValue(inOp));
    }

    @Test
    public void testEvaluatesToLocalValue_simpleOperator() throws Exception {
        Node n = new Node(Token.ADD, Node.newNumber(1), Node.newNumber(2));
        assertTrue(NodeUtil.evaluatesToLocalValue(n));
    }

    @Test
    public void testEvaluatesToLocalValue_immutableValue() throws Exception {
        Node n = Node.newString("immutable");
        assertTrue(NodeUtil.evaluatesToLocalValue(n));
    }

    @Test
    public void testGetArgumentForFunction_firstArg() throws Exception {
        Node param1 = Node.newString("p1");
        Node param2 = Node.newString("p2");
        Node lp = new Node(Token.LP, param1, param2);
        Node name = Node.newString("f");
        Node body = new Node(Token.BLOCK);
        Node func = new Node(Token.FUNCTION, name, lp, body);
        assertEquals(param1, NodeUtil.getArgumentForFunction(func, 0));
    }

    @Test
    public void testGetArgumentForFunction_secondArg() throws Exception {
        Node param1 = Node.newString("p1");
        Node param2 = Node.newString("p2");
        Node lp = new Node(Token.LP, param1, param2);
        Node name = Node.newString("f");
        Node body = new Node(Token.BLOCK);
        Node func = new Node(Token.FUNCTION, name, lp, body);
        assertEquals(param2, NodeUtil.getArgumentForFunction(func, 1));
    }

    @Test
    public void testGetArgumentForFunction_outOfBounds() throws Exception {
        Node param1 = Node.newString("p1");
        Node lp = new Node(Token.LP, param1);
        Node name = Node.newString("f");
        Node body = new Node(Token.BLOCK);
        Node func = new Node(Token.FUNCTION, name, lp, body);
        assertNull(NodeUtil.getArgumentForFunction(func, 1));
    }

}
