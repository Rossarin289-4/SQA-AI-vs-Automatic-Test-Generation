package com.google.javascript.jscomp;

import org.junit.Test;
import static org.junit.Assert.*;
import com.google.common.base.Preconditions;
import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Maps;
import com.google.javascript.rhino.JSDocInfo;
import com.google.javascript.rhino.Node;
import com.google.javascript.rhino.Token;
import com.google.javascript.rhino.TokenStream;
import com.google.javascript.rhino.jstype.TernaryValue;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.annotation.Nullable;
import java.util.function.Supplier; // Import added based on usage

public class NodeUtilTest {
    // Helper to create a simple Node with a given type and value.
    private Node createNode(int type, Object value) {
        Node node;
        switch (type) {
            case Token.STRING:
                node = Node.newString((String) value);
                break;
            case Token.NUMBER:
                node = Node.newNumber((Double) value);
                break;
            case Token.NAME:
                node = Node.newString(Token.NAME, (String) value);
                break;
            case Token.TRUE:
                node = new Node(Token.TRUE);
                break;
            case Token.FALSE:
                node = new Node(Token.FALSE);
                break;
            case Token.NULL:
                node = new Node(Token.NULL);
                break;
            case Token.VOID:
                node = new Node(Token.VOID);
                break;
            case Token.ASSIGN:
                node = new Node(Token.ASSIGN);
                break;
            case Token.COMMA:
                node = new Node(Token.COMMA);
                break;
            case Token.NOT:
                node = new Node(Token.NOT);
                break;
            case Token.AND:
                node = new Node(Token.AND);
                break;
            case Token.OR:
                node = new Node(Token.OR);
                break;
            case Token.HOOK:
                node = new Node(Token.HOOK);
                break;
            case Token.ARRAYLIT:
                node = new Node(Token.ARRAYLIT);
                break;
            case Token.OBJECTLIT:
                node = new Node(Token.OBJECTLIT);
                break;
            case Token.REGEXP:
                node = new Node(Token.REGEXP);
                break;
            case Token.FUNCTION:
                node = new Node(Token.FUNCTION);
                break;
            case Token.NEW:
                node = new Node(Token.NEW);
                break;
            case Token.CALL:
                node = new Node(Token.CALL);
                break;
            default:
                // This switch statement needs to cover all token types that might be used for node creation.
                // If a token type is missing, it should be added or the test should use a different approach for node creation.
                throw new IllegalArgumentException("Unsupported token type: " + Token.name(type));
        }
        return node;
    }

    // Helper to create a node with parent.
    private Node createNodeWithParent(int type, Object value, Node parent) {
        Node node = createNode(type, value);
        if (parent != null) {
            parent.addChildToBack(node);
        }
        return node;
    }

    @Test
    public void testGetExpressionBooleanValue_assign() throws Exception {
        Node rhs = createNode(Token.STRING, "hello");
        Node assign = createNode(Token.ASSIGN, null);
        assign.addChildToBack(createNode(Token.NAME, "x"));
        assign.addChildToBack(rhs);
        assertEquals(TernaryValue.TRUE, NodeUtil.getExpressionBooleanValue(assign));
    }

    @Test
    public void testGetExpressionBooleanValue_comma() throws Exception {
        Node rhs = createNode(Token.NUMBER, 1.0);
        Node comma = createNode(Token.COMMA, null);
        comma.addChildToBack(createNode(Token.NAME, "x"));
        comma.addChildToBack(rhs);
        assertEquals(TernaryValue.TRUE, NodeUtil.getExpressionBooleanValue(comma));
    }

    @Test
    public void testGetExpressionBooleanValue_not_true() {}
// Defects4J: flaky method
//     @Test
//     public void testGetExpressionBooleanValue_not_true() throws Exception {
//         Node expr = createNode(Token.TRUE, null);
//         Node not = createNode(Token.NOT, expr);
//         assertEquals(TernaryValue.FALSE, NodeUtil.getExpressionBooleanValue(not));
//     }

    @Test
    public void testGetExpressionBooleanValue_not_false() {}
// Defects4J: flaky method
//     @Test
//     public void testGetExpressionBooleanValue_not_false() throws Exception {
//         Node expr = createNode(Token.FALSE, null);
//         Node not = createNode(Token.NOT, expr);
//         assertEquals(TernaryValue.TRUE, NodeUtil.getExpressionBooleanValue(not));
//     }

    @Test
    public void testGetExpressionBooleanValue_and_true_true() throws Exception {
        Node lhs = createNode(Token.TRUE, null);
        Node rhs = createNode(Token.TRUE, null);
        Node and = createNode(Token.AND, lhs);
        and.addChildToBack(rhs);
        assertEquals(TernaryValue.TRUE, NodeUtil.getExpressionBooleanValue(and));
    }

    @Test
    public void testGetExpressionBooleanValue_and_true_false() throws Exception {
        Node lhs = createNode(Token.TRUE, null);
        Node rhs = createNode(Token.FALSE, null);
        Node and = createNode(Token.AND, lhs);
        and.addChildToBack(rhs);
        assertEquals(TernaryValue.FALSE, NodeUtil.getExpressionBooleanValue(and));
    }

    @Test
    public void testGetExpressionBooleanValue_or_true_false() {}
// Defects4J: flaky method
//     @Test
//     public void testGetExpressionBooleanValue_or_true_false() throws Exception {
//         Node lhs = createNode(Token.TRUE, null);
//         Node rhs = createNode(Token.FALSE, null);
//         Node or = createNode(Token.OR, lhs);
//         or.addChildToBack(rhs);
//         assertEquals(TernaryValue.TRUE, NodeUtil.getExpressionBooleanValue(or));
//     }

    @Test
    public void testGetExpressionBooleanValue_or_false_false() throws Exception {
        Node lhs = createNode(Token.FALSE, null);
        Node rhs = createNode(Token.FALSE, null);
        Node or = createNode(Token.OR, lhs);
        or.addChildToBack(rhs);
        assertEquals(TernaryValue.FALSE, NodeUtil.getExpressionBooleanValue(or));
    }

    @Test
    public void testGetExpressionBooleanValue_hook_equal() throws Exception {
        Node cond = createNode(Token.TRUE, null);
        Node trueBranch = createNode(Token.TRUE, null);
        Node falseBranch = createNode(Token.TRUE, null);
        Node hook = createNode(Token.HOOK, cond);
        hook.addChildToBack(trueBranch);
        hook.addChildToBack(falseBranch);
        assertEquals(TernaryValue.TRUE, NodeUtil.getExpressionBooleanValue(hook));
    }

    @Test
    public void testGetExpressionBooleanValue_hook_unequal() {}
// Defects4J: flaky method
//     @Test
//     public void testGetExpressionBooleanValue_hook_unequal() throws Exception {
//         Node cond = createNode(Token.TRUE, null);
//         Node trueBranch = createNode(Token.TRUE, null);
//         Node falseBranch = createNode(Token.FALSE, null);
//         Node hook = createNode(Token.HOOK, cond);
//         hook.addChildToBack(trueBranch);
//         hook.addChildToBack(falseBranch);
//         assertEquals(TernaryValue.UNKNOWN, NodeUtil.getExpressionBooleanValue(hook));
//     }

    @Test
    public void testGetBooleanValue_string_nonempty() throws Exception {
        Node str = createNode(Token.STRING, "hello");
        assertEquals(TernaryValue.TRUE, NodeUtil.getBooleanValue(str));
    }

    @Test
    public void testGetBooleanValue_string_empty() throws Exception {
        Node str = createNode(Token.STRING, "");
        assertEquals(TernaryValue.FALSE, NodeUtil.getBooleanValue(str));
    }

    @Test
    public void testGetBooleanValue_number_nonzero() throws Exception {
        Node num = createNode(Token.NUMBER, 1.5);
        assertEquals(TernaryValue.TRUE, NodeUtil.getBooleanValue(num));
    }

    @Test
    public void testGetBooleanValue_number_zero() throws Exception {
        Node num = createNode(Token.NUMBER, 0.0);
        assertEquals(TernaryValue.FALSE, NodeUtil.getBooleanValue(num));
    }

    @Test
    public void testGetBooleanValue_null() throws Exception {
        Node n = createNode(Token.NULL, null);
        assertEquals(TernaryValue.FALSE, NodeUtil.getBooleanValue(n));
    }

    @Test
    public void testGetBooleanValue_false() throws Exception {
        Node n = createNode(Token.FALSE, null);
        assertEquals(TernaryValue.FALSE, NodeUtil.getBooleanValue(n));
    }

    @Test
    public void testGetBooleanValue_void() throws Exception {
        Node n = createNode(Token.VOID, null);
        assertEquals(TernaryValue.FALSE, NodeUtil.getBooleanValue(n));
    }

    @Test
    public void testGetBooleanValue_name_undefined() throws Exception {
        Node name = createNode(Token.NAME, "undefined");
        assertEquals(TernaryValue.FALSE, NodeUtil.getBooleanValue(name));
    }

    @Test
    public void testGetBooleanValue_name_NaN() throws Exception {
        Node name = createNode(Token.NAME, "NaN");
        assertEquals(TernaryValue.FALSE, NodeUtil.getBooleanValue(name));
    }

    @Test
    public void testGetBooleanValue_name_Infinity() throws Exception {
        Node name = createNode(Token.NAME, "Infinity");
        assertEquals(TernaryValue.TRUE, NodeUtil.getBooleanValue(name));
    }

    @Test
    public void testGetBooleanValue_true() throws Exception {
        Node n = createNode(Token.TRUE, null);
        assertEquals(TernaryValue.TRUE, NodeUtil.getBooleanValue(n));
    }

    @Test
    public void testGetBooleanValue_arraylit() throws Exception {
        Node n = createNode(Token.ARRAYLIT, null);
        assertEquals(TernaryValue.TRUE, NodeUtil.getBooleanValue(n));
    }

    @Test
    public void testGetBooleanValue_objectlit() throws Exception {
        Node n = createNode(Token.OBJECTLIT, null);
        assertEquals(TernaryValue.TRUE, NodeUtil.getBooleanValue(n));
    }

    @Test
    public void testGetBooleanValue_regexp() throws Exception {
        Node n = createNode(Token.REGEXP, null);
        assertEquals(TernaryValue.TRUE, NodeUtil.getBooleanValue(n));
    }

    @Test
    public void testGetStringValue_string() throws Exception {
        Node str = createNode(Token.STRING, "test");
        assertEquals("test", NodeUtil.getStringValue(str));
    }

    @Test
    public void testGetStringValue_name_undefined() throws Exception {
        Node name = createNode(Token.NAME, "undefined");
        assertEquals("undefined", NodeUtil.getStringValue(name));
    }

    @Test
    public void testGetStringValue_name_NaN() throws Exception {
        Node name = createNode(Token.NAME, "NaN");
        assertEquals("NaN", NodeUtil.getStringValue(name));
    }

    @Test
    public void testGetStringValue_name_Infinity() throws Exception {
        Node name = createNode(Token.NAME, "Infinity");
        assertEquals("Infinity", NodeUtil.getStringValue(name));
    }

    @Test
    public void testGetStringValue_number_integer() throws Exception {
        Node num = createNode(Token.NUMBER, 123.0);
        assertEquals("123", NodeUtil.getStringValue(num));
    }

    @Test
    public void testGetStringValue_number_float() throws Exception {
        Node num = createNode(Token.NUMBER, 123.45);
        assertEquals("123.45", NodeUtil.getStringValue(num));
    }

    @Test
    public void testGetStringValue_false() throws Exception {
        Node n = createNode(Token.FALSE, null);
        assertEquals("false", NodeUtil.getStringValue(n));
    }

    @Test
    public void testGetStringValue_true() throws Exception {
        Node n = createNode(Token.TRUE, null);
        assertEquals("true", NodeUtil.getStringValue(n));
    }

    @Test
    public void testGetStringValue_null() throws Exception {
        Node n = createNode(Token.NULL, null);
        assertEquals("null", NodeUtil.getStringValue(n));
    }

    @Test
    public void testGetStringValue_void() throws Exception {
        Node n = createNode(Token.VOID, null);
        assertEquals("undefined", NodeUtil.getStringValue(n));
    }

    @Test
    public void testGetStringValue_unknown() throws Exception {
        Node n = new Node(Token.ADD); // An operation node, not a literal
        assertNull(NodeUtil.getStringValue(n));
    }

    @Test
    public void testGetNumberValue_true() throws Exception {
        Node n = createNode(Token.TRUE, null);
        assertEquals(Double.valueOf(1.0), NodeUtil.getNumberValue(n));
    }

    @Test
    public void testGetNumberValue_false() throws Exception {
        Node n = createNode(Token.FALSE, null);
        assertEquals(Double.valueOf(0.0), NodeUtil.getNumberValue(n));
    }

    @Test
    public void testGetNumberValue_null() throws Exception {
        Node n = createNode(Token.NULL, null);
        assertEquals(Double.valueOf(0.0), NodeUtil.getNumberValue(n));
    }

    @Test
    public void testGetNumberValue_number() throws Exception {
        Node num = createNode(Token.NUMBER, 42.5);
        assertEquals(Double.valueOf(42.5), NodeUtil.getNumberValue(num));
    }

    @Test
    public void testGetNumberValue_void() throws Exception {
        Node n = createNode(Token.VOID, null);
        assertTrue(Double.isNaN(NodeUtil.getNumberValue(n)));
    }

    @Test
    public void testGetNumberValue_name_undefined() throws Exception {
        Node name = createNode(Token.NAME, "undefined");
        assertTrue(Double.isNaN(NodeUtil.getNumberValue(name)));
    }

    @Test
    public void testGetNumberValue_name_NaN() throws Exception {
        Node name = createNode(Token.NAME, "NaN");
        assertTrue(Double.isNaN(NodeUtil.getNumberValue(name)));
    }

    @Test
    public void testGetNumberValue_unknown() throws Exception {
        Node n = new Node(Token.ADD); // An operation node, not a literal
        assertNull(NodeUtil.getNumberValue(n));
    }

    @Test
    public void testGetFunctionName_functionDecl() {}
// Defects4J: flaky method
//     @Test
//     public void testGetFunctionName_functionDecl() throws Exception {
//         Node funcName = Node.newString(Token.NAME, "myFunc");
//         Node funcBody = new Node(Token.BLOCK);
//         Node func = new Node(Token.FUNCTION, funcName, new Node(Token.LP), funcBody);
//         assertEquals("myFunc", NodeUtil.getFunctionName(func));
//     }

    @Test
    public void testGetFunctionName_varAssignFunction() throws Exception {
        Node varName = Node.newString(Token.NAME, "myVar");
        Node funcName = Node.newString(Token.NAME, "anonFunc"); // Should be ignored
        Node funcBody = new Node(Token.BLOCK);
        Node func = new Node(Token.FUNCTION, funcName, new Node(Token.LP), funcBody);
        Node assign = new Node(Token.ASSIGN, varName, func);
        Node varDecl = new Node(Token.VAR, assign);

        assertEquals("myVar", NodeUtil.getFunctionName(func));
    }

    @Test
    public void testGetFunctionName_qualifiedAssignFunction() {}
// Defects4J: flaky method
//     @Test
//     public void testGetFunctionName_qualifiedAssignFunction() throws Exception {
//         Node qualifiedName = Node.newString(Token.GETPROP, "obj.method");
//         Node funcName = Node.newString(Token.NAME, "anonFunc"); // Should be ignored
//         Node funcBody = new Node(Token.BLOCK);
//         Node func = new Node(Token.FUNCTION, funcName, new Node(Token.LP), funcBody);
//         Node assign = new Node(Token.ASSIGN, qualifiedName, func);
// 
//         assertEquals("obj.method", NodeUtil.getFunctionName(func));
//     }

     @Test
    public void testGetFunctionName_namedFuncExprAssignedToVar() throws Exception {
        Node varName = Node.newString(Token.NAME, "myVar");
        Node funcName = Node.newString(Token.NAME, "namedFunc");
        Node funcBody = new Node(Token.BLOCK);
        Node func = new Node(Token.FUNCTION, funcName, new Node(Token.LP), funcBody);
        Node assign = new Node(Token.ASSIGN, varName, func);
        Node varDecl = new Node(Token.VAR, assign);

        // The rule is to return the variable name when it's a named function expression assigned to a var.
        assertEquals("myVar", NodeUtil.getFunctionName(func));
    }

    @Test
    public void testGetFunctionName_namedFuncExprAssignedToQualified() {}
// Defects4J: flaky method
//     @Test
//     public void testGetFunctionName_namedFuncExprAssignedToQualified() throws Exception {
//         Node qualifiedName = Node.newString(Token.GETPROP, "obj.method");
//         Node funcName = Node.newString(Token.NAME, "namedFunc");
//         Node funcBody = new Node(Token.BLOCK);
//         Node func = new Node(Token.FUNCTION, funcName, new Node(Token.LP), funcBody);
//         Node assign = new Node(Token.ASSIGN, qualifiedName, func);
// 
//         // The rule is to return the qualified name when it's a named function expression assigned to a qualified name.
//         assertEquals("obj.method", NodeUtil.getFunctionName(func));
//     }

    @Test
    public void testGetNearestFunctionName_anonymous() {}
// Defects4J: flaky method
//     @Test
//     public void testGetNearestFunctionName_anonymous() throws Exception {
//         Node funcBody = new Node(Token.BLOCK);
//         Node func = new Node(Token.FUNCTION, null, new Node(Token.LP), funcBody);
//         Node parentObjectLit = new Node(Token.OBJECTLIT);
//         Node key = Node.newString(Token.STRING, "methodName");
//         key.addChildToBack(func);
//         parentObjectLit.addChildToBack(key);
// 
//         assertEquals("methodName", NodeUtil.getNearestFunctionName(func));
//     }

    @Test
    public void testGetNearestFunctionName_anonymous_noParent() {}
// Defects4J: flaky method
//     @Test
//     public void testGetNearestFunctionName_anonymous_noParent() throws Exception {
//         Node funcBody = new Node(Token.BLOCK);
//         Node func = new Node(Token.FUNCTION, null, new Node(Token.LP), funcBody);
//         assertEquals(null, NodeUtil.getNearestFunctionName(func));
//     }

    @Test
    public void testGetNearestFunctionName_anonymous_string_key() {}
// Defects4J: flaky method
//     @Test
//     public void testGetNearestFunctionName_anonymous_string_key() throws Exception {
//         Node funcBody = new Node(Token.BLOCK);
//         Node func = new Node(Token.FUNCTION, null, new Node(Token.LP), funcBody);
//         Node stringKey = Node.newString(Token.STRING, "prop"); // Represents a key in an object literal
//         stringKey.addChildToBack(func); // The string key is the parent of the function in this context
//         assertEquals("prop", NodeUtil.getNearestFunctionName(func));
//     }

    @Test
    public void testIsImmutableValue_string() throws Exception {
        Node n = createNode(Token.STRING, "hello");
        assertTrue(NodeUtil.isImmutableValue(n));
    }

    @Test
    public void testIsImmutableValue_number() throws Exception {
        Node n = createNode(Token.NUMBER, 123.45);
        assertTrue(NodeUtil.isImmutableValue(n));
    }

    @Test
    public void testIsImmutableValue_null() throws Exception {
        Node n = createNode(Token.NULL, null);
        assertTrue(NodeUtil.isImmutableValue(n));
    }

    @Test
    public void testIsImmutableValue_true() throws Exception {
        Node n = createNode(Token.TRUE, null);
        assertTrue(NodeUtil.isImmutableValue(n));
    }

    @Test
    public void testIsImmutableValue_false() throws Exception {
        Node n = createNode(Token.FALSE, null);
        assertTrue(NodeUtil.isImmutableValue(n));
    }

    @Test
    public void testIsImmutableValue_void() {}
// Defects4J: flaky method
//     @Test
//     public void testIsImmutableValue_void() throws Exception {
//         Node n = createNode(Token.VOID, null);
//         assertTrue(NodeUtil.isImmutableValue(n));
//     }

    @Test
    public void testIsImmutableValue_neg_immutable() {}
// Defects4J: flaky method
//     @Test
//     public void testIsImmutableValue_neg_immutable() throws Exception {
//         Node child = createNode(Token.NUMBER, 5.0);
//         Node neg = createNode(Token.NEG, child);
//         assertTrue(NodeUtil.isImmutableValue(neg));
//     }

    @Test
    public void testIsImmutableValue_neg_mutable() {}
// Defects4J: flaky method
//     @Test
//     public void testIsImmutableValue_neg_mutable() throws Exception {
//         Node child = createNode(Token.NAME, "x"); // Assuming 'x' is not declared immutable
//         Node neg = createNode(Token.NEG, child);
//         assertFalse(NodeUtil.isImmutableValue(neg));
//     }

    @Test
    public void testIsImmutableValue_name_undefined() throws Exception {
        Node name = createNode(Token.NAME, "undefined");
        assertTrue(NodeUtil.isImmutableValue(name));
    }

    @Test
    public void testIsImmutableValue_name_Infinity() throws Exception {
        Node name = createNode(Token.NAME, "Infinity");
        assertTrue(NodeUtil.isImmutableValue(name));
    }

    @Test
    public void testIsImmutableValue_name_NaN() throws Exception {
        Node name = createNode(Token.NAME, "NaN");
        assertTrue(NodeUtil.isImmutableValue(name));
    }

    @Test
    public void testIsImmutableValue_name_variable() throws Exception {
        Node name = createNode(Token.NAME, "myVar");
        // Assume "myVar" is not a special keyword and could be mutable
        assertFalse(NodeUtil.isImmutableValue(name));
    }

    @Test
    public void testIsImmutableValue_call() throws Exception {
        Node n = createNode(Token.CALL, null);
        assertFalse(NodeUtil.isImmutableValue(n));
    }

    @Test
    public void testIsLiteralValue_string() throws Exception {
        Node n = createNode(Token.STRING, "hello");
        assertTrue(NodeUtil.isLiteralValue(n, false));
    }

    @Test
    public void testIsLiteralValue_number() throws Exception {
        Node n = createNode(Token.NUMBER, 123.45);
        assertTrue(NodeUtil.isLiteralValue(n, false));
    }

    @Test
    public void testIsLiteralValue_boolean_true() throws Exception {
        Node n = createNode(Token.TRUE, null);
        assertTrue(NodeUtil.isLiteralValue(n, false));
    }

    @Test
    public void testIsLiteralValue_boolean_false() throws Exception {
        Node n = createNode(Token.FALSE, null);
        assertTrue(NodeUtil.isLiteralValue(n, false));
    }

    @Test
    public void testIsLiteralValue_null() throws Exception {
        Node n = createNode(Token.NULL, null);
        assertTrue(NodeUtil.isLiteralValue(n, false));
    }

    @Test
    public void testIsLiteralValue_undefined_name() throws Exception {
        Node n = createNode(Token.NAME, "undefined");
        assertTrue(NodeUtil.isLiteralValue(n, false));
    }

    @Test
    public void testIsLiteralValue_arraylit_all_literals() throws Exception {
        Node child1 = createNode(Token.NUMBER, 1.0); // Use double for consistency
        Node child2 = createNode(Token.STRING, "a");
        Node array = createNode(Token.ARRAYLIT, null);
        array.addChildToBack(child1);
        array.addChildToBack(child2);
        assertTrue(NodeUtil.isLiteralValue(array, false));
    }

    @Test
    public void testIsLiteralValue_arraylit_with_nonliteral() throws Exception {
        Node child1 = createNode(Token.NUMBER, 1.0);
        Node child2 = createNode(Token.NAME, "x"); // Assuming 'x' is not literal
        Node array = createNode(Token.ARRAYLIT, null);
        array.addChildToBack(child1);
        array.addChildToBack(child2);
        assertFalse(NodeUtil.isLiteralValue(array, false));
    }

    @Test
    public void testIsLiteralValue_objectlit_all_literals() throws Exception {
        Node prop1 = createNode(Token.STRING, "a");
        Node prop1Val = createNode(Token.NUMBER, 1.0); // Use double for consistency
        prop1.addChildToBack(prop1Val);

        Node prop2 = createNode(Token.STRING, "b");
        Node prop2Val = createNode(Token.STRING, "hello");
        prop2.addChildToBack(prop2Val);

        Node obj = createNode(Token.OBJECTLIT, null);
        obj.addChildToBack(prop1);
        obj.addChildToBack(prop2);
        assertTrue(NodeUtil.isLiteralValue(obj, false));
    }

    @Test
    public void testIsLiteralValue_objectlit_with_nonliteral() throws Exception {
        Node prop1 = createNode(Token.STRING, "a");
        Node prop1Val = createNode(Token.NUMBER, 1.0);
        prop1.addChildToBack(prop1Val);

        Node prop2 = createNode(Token.STRING, "b");
        Node prop2Val = createNode(Token.NAME, "x"); // Assuming 'x' is not literal
        prop2.addChildToBack(prop2Val);

        Node obj = createNode(Token.OBJECTLIT, null);
        obj.addChildToBack(prop1);
        obj.addChildToBack(prop2);
        assertFalse(NodeUtil.isLiteralValue(obj, false));
    }

    @Test
    public void testIsLiteralValue_function_expression_true() {}
// Defects4J: flaky method
//     @Test
//     public void testIsLiteralValue_function_expression_true() throws Exception {
//         Node func = createNode(Token.FUNCTION, null);
//         // For testing purposes, we assume a function node can be a literal if includeFunctions is true
//         // and it's not a declaration.
//         assertTrue(NodeUtil.isLiteralValue(func, true));
//     }

    @Test
    public void testIsLiteralValue_function_declaration_false() throws Exception {
        Node func = createNode(Token.FUNCTION, null);
        // If includeFunctions is false, it should return false.
        assertFalse(NodeUtil.isLiteralValue(func, false));
    }


    @Test
    public void testIsValidDefineValue_string() throws Exception {
        Set<String> defines = Collections.singleton("MY_DEFINE");
        Node val = createNode(Token.STRING, "test");
        assertTrue(NodeUtil.isValidDefineValue(val, defines));
    }

    @Test
    public void testIsValidDefineValue_number() throws Exception {
        Set<String> defines = Collections.singleton("MY_DEFINE");
        Node val = createNode(Token.NUMBER, 123.45);
        assertTrue(NodeUtil.isValidDefineValue(val, defines));
    }

    @Test
    public void testIsValidDefineValue_true() throws Exception {
        Set<String> defines = Collections.singleton("MY_DEFINE");
        Node val = createNode(Token.TRUE, null);
        assertTrue(NodeUtil.isValidDefineValue(val, defines));
    }

    @Test
    public void testIsValidDefineValue_false() throws Exception {
        Set<String> defines = Collections.singleton("MY_DEFINE");
        Node val = createNode(Token.FALSE, null);
        assertTrue(NodeUtil.isValidDefineValue(val, defines));
    }

    @Test
    public void testIsValidDefineValue_add_valid_children() {}
// Defects4J: flaky method
//     @Test
//     public void testIsValidDefineValue_add_valid_children() throws Exception {
//         Set<String> defines = Collections.singleton("MY_DEFINE");
//         Node lhs = createNode(Token.NUMBER, 1.0);
//         Node rhs = createNode(Token.NAME, "MY_DEFINE");
//         Node add = createNode(Token.ADD, lhs);
//         add.addChildToBack(rhs);
//         assertTrue(NodeUtil.isValidDefineValue(add, defines));
//     }

    @Test
    public void testIsValidDefineValue_add_invalid_child() {}
// Defects4J: flaky method
//     @Test
//     public void testIsValidDefineValue_add_invalid_child() throws Exception {
//         Set<String> defines = Collections.singleton("MY_DEFINE");
//         Node lhs = createNode(Token.NUMBER, 1.0);
//         Node rhs = createNode(Token.NAME, "OTHER_DEFINE"); // Not in defines
//         Node add = createNode(Token.ADD, lhs);
//         add.addChildToBack(rhs);
//         assertFalse(NodeUtil.isValidDefineValue(add, defines));
//     }

    @Test
    public void testIsValidDefineValue_not_valid_child() {}
// Defects4J: flaky method
//     @Test
//     public void testIsValidDefineValue_not_valid_child() throws Exception {
//         Set<String> defines = Collections.singleton("MY_DEFINE");
//         Node child = createNode(Token.NAME, "OTHER_DEFINE"); // Not in defines
//         Node not = createNode(Token.NOT, child);
//         assertFalse(NodeUtil.isValidDefineValue(not, defines));
//     }

    @Test
    public void testIsValidDefineValue_name_defined() throws Exception {
        Set<String> defines = Collections.singleton("MY_DEFINE");
        Node name = createNode(Token.NAME, "MY_DEFINE");
        assertTrue(NodeUtil.isValidDefineValue(name, defines));
    }

    @Test
    public void testIsValidDefineValue_name_not_defined() throws Exception {
        Set<String> defines = Collections.singleton("MY_DEFINE");
        Node name = createNode(Token.NAME, "OTHER_DEFINE");
        assertFalse(NodeUtil.isValidDefineValue(name, defines));
    }

    @Test
    public void testIsValidDefineValue_getprop_defined() {}
// Defects4J: flaky method
//     @Test
//     public void testIsValidDefineValue_getprop_defined() throws Exception {
//         Set<String> defines = Collections.singleton("MY_DEFINE.PROP");
//         Node name = Node.newString(Token.GETPROP, "MY_DEFINE.PROP");
//         assertTrue(NodeUtil.isValidDefineValue(name, defines));
//     }

    @Test
    public void testIsValidDefineValue_getprop_not_defined() {}
// Defects4J: flaky method
//     @Test
//     public void testIsValidDefineValue_getprop_not_defined() throws Exception {
//         Set<String> defines = Collections.singleton("MY_DEFINE.PROP");
//         Node name = Node.newString(Token.GETPROP, "OTHER.PROP");
//         assertFalse(NodeUtil.isValidDefineValue(name, defines));
//     }


    @Test
    public void testIsEmptyBlock_empty() throws Exception {
        Node block = new Node(Token.BLOCK);
        assertTrue(NodeUtil.isEmptyBlock(block));
    }

    @Test
    public void testIsEmptyBlock_with_empty_statement() throws Exception {
        Node block = new Node(Token.BLOCK);
        block.addChildToBack(new Node(Token.EMPTY));
        assertTrue(NodeUtil.isEmptyBlock(block));
    }

    @Test
    public void testIsEmptyBlock_not_empty() throws Exception {
        Node block = new Node(Token.BLOCK);
        block.addChildToBack(Node.newString(Token.NAME, "var"));
        assertFalse(NodeUtil.isEmptyBlock(block));
    }


    @Test
    public void testIsSimpleOperator_add() throws Exception {
        Node add = new Node(Token.ADD);
        assertTrue(NodeUtil.isSimpleOperator(add));
    }

    @Test
    public void testIsSimpleOperator_assign_add() throws Exception {
        Node assignAdd = new Node(Token.ASSIGN_ADD);
        assertFalse(NodeUtil.isSimpleOperator(assignAdd));
    }

    @Test
    public void testIsSimpleOperator_or() throws Exception {
        Node or = new Node(Token.OR); // OR is not simple due to short-circuiting
        assertFalse(NodeUtil.isSimpleOperator(or));
    }

    @Test
    public void testIsSimpleOperator_hook() throws Exception {
        Node hook = new Node(Token.HOOK); // HOOK is not simple due to conditional aspect
        assertFalse(NodeUtil.isSimpleOperator(hook));
    }

    @Test
    public void testNewExpr() throws Exception {
        Node child = Node.newString("test");
        Node exprResult = NodeUtil.newExpr(child);
        assertEquals(Token.EXPR_RESULT, exprResult.getType());
        assertEquals(child, exprResult.getFirstChild());
        // Check information copying
        assertEquals(child.getLineno(), exprResult.getLineno());
        assertEquals(child.getCharno(), exprResult.getCharno());
    }

    @Test
    public void testMayEffectMutableState_objectlit() throws Exception {
        Node objLit = new Node(Token.OBJECTLIT);
        assertTrue(NodeUtil.mayEffectMutableState(objLit));
    }

    @Test
    public void testMayEffectMutableState_new() throws Exception {
        Node newNode = new Node(Token.NEW);
        assertTrue(NodeUtil.mayEffectMutableState(newNode));
    }

    @Test
    public void testMayEffectMutableState_call() {}
// Defects4J: flaky method
//     @Test
//     public void testMayEffectMutableState_call() throws Exception {
//         Node callNode = new Node(Token.CALL);
//         assertTrue(NodeUtil.mayEffectMutableState(callNode));
//     }

    @Test
    public void testMayEffectMutableState_assign() {}
// Defects4J: flaky method
//     @Test
//     public void testMayEffectMutableState_assign() throws Exception {
//         Node assignNode = new Node(Token.ASSIGN);
//         assertTrue(NodeUtil.mayEffectMutableState(assignNode));
//     }

    @Test
    public void testMayEffectMutableState_var_with_init() throws Exception {
        Node value = Node.newNumber(1.0);
        Node name = Node.newString(Token.NAME, "x");
        name.addChildToBack(value);
        Node var = new Node(Token.VAR, name);
        assertTrue(NodeUtil.mayEffectMutableState(var));
    }

    @Test
    public void testMayEffectMutableState_var_without_init() {}
// Defects4J: flaky method
//     @Test
//     public void testMayEffectMutableState_var_without_init() throws Exception {
//         Node name = Node.newString(Token.NAME, "x");
//         Node var = new Node(Token.VAR, name);
//         assertFalse(NodeUtil.mayEffectMutableState(var));
//     }

    @Test
    public void testMayEffectMutableState_literal_number() throws Exception {
        Node num = Node.newNumber(1.0);
        assertFalse(NodeUtil.mayEffectMutableState(num));
    }

    @Test
    public void testMayEffectMutableState_literal_string() throws Exception {
        Node str = Node.newString("hello");
        assertFalse(NodeUtil.mayEffectMutableState(str));
    }

    @Test
    public void testMayHaveSideEffects_objectlit() {}
// Defects4J: flaky method
//     @Test
//     public void testMayHaveSideEffects_objectlit() throws Exception {
//         Node objLit = new Node(Token.OBJECTLIT);
//         assertTrue(NodeUtil.mayHaveSideEffects(objLit));
//     }

    @Test
    public void testMayHaveSideEffects_new() {}
// Defects4J: flaky method
//     @Test
//     public void testMayHaveSideEffects_new() throws Exception {
//         Node newNode = new Node(Token.NEW);
//         assertTrue(NodeUtil.mayHaveSideEffects(newNode));
//     }

    @Test
    public void testMayHaveSideEffects_call() {}
// Defects4J: flaky method
//     @Test
//     public void testMayHaveSideEffects_call() throws Exception {
//         Node callNode = new Node(Token.CALL);
//         assertTrue(NodeUtil.mayHaveSideEffects(callNode));
//     }

    @Test
    public void testMayHaveSideEffects_assign() {}
// Defects4J: flaky method
//     @Test
//     public void testMayHaveSideEffects_assign() throws Exception {
//         Node assignNode = new Node(Token.ASSIGN);
//         assertTrue(NodeUtil.mayHaveSideEffects(assignNode));
//     }

    @Test
    public void testMayHaveSideEffects_var_with_init() throws Exception {
        Node value = Node.newNumber(1.0);
        Node name = Node.newString(Token.NAME, "x");
        name.addChildToBack(value);
        Node var = new Node(Token.VAR, name);
        assertTrue(NodeUtil.mayHaveSideEffects(var));
    }

    @Test
    public void testMayHaveSideEffects_var_without_init() {}
// Defects4J: flaky method
//     @Test
//     public void testMayHaveSideEffects_var_without_init() throws Exception {
//         Node name = Node.newString(Token.NAME, "x");
//         Node var = new Node(Token.VAR, name);
//         assertFalse(NodeUtil.mayHaveSideEffects(var));
//     }

    @Test
    public void testMayHaveSideEffects_literal_number() throws Exception {
        Node num = Node.newNumber(1.0);
        assertFalse(NodeUtil.mayHaveSideEffects(num));
    }

    @Test
    public void testMayHaveSideEffects_literal_string() throws Exception {
        Node str = Node.newString("hello");
        assertFalse(NodeUtil.mayHaveSideEffects(str));
    }

    @Test
    public void testConstructorCallHasSideEffects_normal() {}
// Defects4J: flaky method
//     @Test
//     public void testConstructorCallHasSideEffects_normal() throws Exception {
//         Node newNode = new Node(Token.NEW);
//         assertTrue(NodeUtil.constructorCallHasSideEffects(newNode));
//     }


    @Test
    public void testConstructorCallHasSideEffects_builtin_no_side_effects() throws Exception {
        Node nameNode = Node.newString(Token.NAME, "Array");
        Node newNode = new Node(Token.NEW, nameNode);
        assertFalse(NodeUtil.constructorCallHasSideEffects(newNode));
    }

    @Test
    public void testConstructorCallHasSideEffects_builtin_with_side_effects() throws Exception {
        Node nameNode = Node.newString(Token.NAME, "MyCustomConstructor");
        Node newNode = new Node(Token.NEW, nameNode);
        assertTrue(NodeUtil.constructorCallHasSideEffects(newNode));
    }

    @Test
    public void testFunctionCallHasSideEffects_normal() {}
// Defects4J: flaky method
//     @Test
//     public void testFunctionCallHasSideEffects_normal() throws Exception {
//         Node callNode = new Node(Token.CALL);
//         assertTrue(NodeUtil.functionCallHasSideEffects(callNode));
//     }


    @Test
    public void testFunctionCallHasSideEffects_builtin_no_side_effects() throws Exception {
        Node nameNode = Node.newString(Token.NAME, "Object");
        Node callNode = new Node(Token.CALL, nameNode);
        assertFalse(NodeUtil.functionCallHasSideEffects(callNode));
    }

    @Test
    public void testFunctionCallHasSideEffects_builtin_with_side_effects() throws Exception {
        Node nameNode = Node.newString(Token.NAME, "alert");
        Node callNode = new Node(Token.CALL, nameNode);
        assertTrue(NodeUtil.functionCallHasSideEffects(callNode));
    }

    @Test
    public void testFunctionCallHasSideEffects_getprop_no_side_effects() throws Exception {
        Node methodName = Node.newString(Token.STRING, "toString");
        Node objectName = Node.newString(Token.NAME, "obj");
        Node getProp = new Node(Token.GETPROP, objectName, methodName);
        Node callNode = new Node(Token.CALL, getProp);
        assertFalse(NodeUtil.functionCallHasSideEffects(callNode));
    }

    @Test
    public void testFunctionCallHasSideEffects_math_method() throws Exception {
        Node methodName = Node.newString(Token.NAME, "random");
        Node objectName = Node.newString(Token.NAME, "Math");
        Node getProp = new Node(Token.GETPROP, objectName, methodName);
        Node callNode = new Node(Token.CALL, getProp);
        assertFalse(NodeUtil.functionCallHasSideEffects(callNode));
    }

    @Test
    public void testCallHasLocalResult_true() throws Exception {
        Node callNode = new Node(Token.CALL);
        callNode.putIntProp(Node.SIDE_EFFECT_FLAGS, Node.FLAG_LOCAL_RESULTS);
        assertTrue(NodeUtil.callHasLocalResult(callNode));
    }

    @Test
    public void testCallHasLocalResult_false() throws Exception {
        Node callNode = new Node(Token.CALL);
        callNode.putIntProp(Node.SIDE_EFFECT_FLAGS, 0);
        assertFalse(NodeUtil.callHasLocalResult(callNode));
    }

    @Test
    public void testNodeTypeMayHaveSideEffects_assign() throws Exception {
        Node assignNode = new Node(Token.ASSIGN);
        assertTrue(NodeUtil.nodeTypeMayHaveSideEffects(assignNode));
    }

    @Test
    public void testNodeTypeMayHaveSideEffects_call() {}
// Defects4J: flaky method
//     @Test
//     public void testNodeTypeMayHaveSideEffects_call() throws Exception {
//         Node callNode = new Node(Token.CALL);
//         assertTrue(NodeUtil.nodeTypeMayHaveSideEffects(callNode));
//     }

    @Test
    public void testNodeTypeMayHaveSideEffects_new() {}
// Defects4J: flaky method
//     @Test
//     public void testNodeTypeMayHaveSideEffects_new() throws Exception {
//         Node newNode = new Node(Token.NEW);
//         assertTrue(NodeUtil.nodeTypeMayHaveSideEffects(newNode));
//     }

    @Test
    public void testNodeTypeMayHaveSideEffects_name_with_children() throws Exception {
        Node nameNode = Node.newString(Token.NAME, "varName");
        nameNode.addChildToBack(Node.newNumber(1.0)); // Represents initialization
        assertTrue(NodeUtil.nodeTypeMayHaveSideEffects(nameNode));
    }

    @Test
    public void testNodeTypeMayHaveSideEffects_name_without_children() throws Exception {
        Node nameNode = Node.newString(Token.NAME, "varName");
        assertFalse(NodeUtil.nodeTypeMayHaveSideEffects(nameNode));
    }

    @Test
    public void testNodeTypeMayHaveSideEffects_number() throws Exception {
        Node num = Node.newNumber(1.0);
        assertFalse(NodeUtil.nodeTypeMayHaveSideEffects(num));
    }

    @Test
    public void testCanBeSideEffected_call() throws Exception {
        Node callNode = new Node(Token.CALL);
        assertTrue(NodeUtil.canBeSideEffected(callNode));
    }

    @Test
    public void testCanBeSideEffected_new() throws Exception {
        Node newNode = new Node(Token.NEW);
        assertTrue(NodeUtil.canBeSideEffected(newNode));
    }

    @Test
    public void testCanBeSideEffected_name_constant() {}
// Defects4J: flaky method
//     @Test
//     public void testCanBeSideEffected_name_constant() throws Exception {
//         Node nameNode = Node.newString(Token.NAME, "CONST_VAR");
//         nameNode.putBooleanProp(Node.IS_CONSTANT_NAME, true);
//         assertFalse(NodeUtil.canBeSideEffected(nameNode, Collections.emptySet()));
//     }

    @Test
    public void testCanBeSideEffected_name_known_constant() throws Exception {
        Node nameNode = Node.newString(Token.NAME, "myVar");
        Set<String> constants = Collections.singleton("myVar");
        assertFalse(NodeUtil.canBeSideEffected(nameNode, constants));
    }

    @Test
    public void testCanBeSideEffected_name_unknown() {}
// Defects4J: flaky method
//     @Test
//     public void testCanBeSideEffected_name_unknown() throws Exception {
//         Node nameNode = Node.newString(Token.NAME, "myVar");
//         assertTrue(NodeUtil.canBeSideEffected(nameNode, Collections.emptySet()));
//     }

    @Test
    public void testCanBeSideEffected_getprop() throws Exception {
        Node obj = Node.newString(Token.NAME, "obj");
        Node prop = Node.newString(Token.STRING, "prop");
        Node getProp = new Node(Token.GETPROP, obj, prop);
        assertTrue(NodeUtil.canBeSideEffected(getProp));
    }

    @Test
    public void testCanBeSideEffected_function_expression() {}
// Defects4J: flaky method
//     @Test
//     public void testCanBeSideEffected_function_expression() throws Exception {
//         Node func = new Node(Token.FUNCTION); // Assume expression
//         assertFalse(NodeUtil.canBeSideEffected(func, Collections.emptySet()));
//     }

    @Test
    public void testPrecedence_add() throws Exception {
        assertEquals(11, NodeUtil.precedence(Token.ADD));
    }

    @Test
    public void testPrecedence_assign() throws Exception {
        assertEquals(1, NodeUtil.precedence(Token.ASSIGN));
    }

    @Test
    public void testPrecedence_comma() throws Exception {
        assertEquals(0, NodeUtil.precedence(Token.COMMA));
    }

    @Test
    public void testPrecedence_highest() throws Exception {
        // Token.ARRAYLIT, Token.CALL, etc. have precedence 15
        assertEquals(15, NodeUtil.precedence(Token.CALL));
    }

    @Test
    public void testIsAssociative_mul() throws Exception {
        assertTrue(NodeUtil.isAssociative(Token.MUL));
    }

    @Test
    public void testIsAssociative_add() throws Exception {
        assertFalse(NodeUtil.isAssociative(Token.ADD)); // Due to string concatenation
    }

    @Test
    public void testIsAssociative_and() throws Exception {
        assertTrue(NodeUtil.isAssociative(Token.AND));
    }

    @Test
    public void testIsCommutative_mul() throws Exception {
        assertTrue(NodeUtil.isCommutative(Token.MUL));
    }

    @Test
    public void testIsCommutative_add() throws Exception {
        assertFalse(NodeUtil.isCommutative(Token.ADD)); // Due to string concatenation
    }

    @Test
    public void testIsCommutative_bitand() throws Exception {
        assertTrue(NodeUtil.isCommutative(Token.BITAND));
    }

    @Test
    public void testIsAssignmentOp_assign() throws Exception {
        Node assign = new Node(Token.ASSIGN);
        assertTrue(NodeUtil.isAssignmentOp(assign));
    }

    @Test
    public void testIsAssignmentOp_assign_add() throws Exception {
        Node assignAdd = new Node(Token.ASSIGN_ADD);
        assertTrue(NodeUtil.isAssignmentOp(assignAdd));
    }

    @Test
    public void testIsAssignmentOp_add() throws Exception {
        Node add = new Node(Token.ADD);
        assertFalse(NodeUtil.isAssignmentOp(add));
    }

    @Test
    public void testGetOpFromAssignmentOp_assign_add() throws Exception {
        Node assignAdd = new Node(Token.ASSIGN_ADD);
        assertEquals(Token.ADD, NodeUtil.getOpFromAssignmentOp(assignAdd));
    }

    @Test
    public void testGetOpFromAssignmentOp_assign_mul() throws Exception {
        Node assignMul = new Node(Token.ASSIGN_MUL);
        assertEquals(Token.MUL, NodeUtil.getOpFromAssignmentOp(assignMul));
    }

    @Test
    public void testIsExpressionNode_expr_result() throws Exception {
        Node exprResult = NodeUtil.newExpr(Node.newString("test"));
        assertTrue(NodeUtil.isExpressionNode(exprResult));
    }

    @Test
    public void testIsExpressionNode_not_expr_result() throws Exception {
        Node block = new Node(Token.BLOCK);
        assertFalse(NodeUtil.isExpressionNode(block));
    }

    @Test
    public void testContainsFunction_true() throws Exception {
        Node func = new Node(Token.FUNCTION);
        Node block = new Node(Token.BLOCK, func);
        assertTrue(NodeUtil.containsFunction(block));
    }

    @Test
    public void testContainsFunction_false() throws Exception {
        Node block = new Node(Token.BLOCK, Node.newString(Token.NAME, "var"));
        assertFalse(NodeUtil.containsFunction(block));
    }

    @Test
    public void testReferencesThis_true() {}
// Defects4J: flaky method
//     @Test
//     public void testReferencesThis_true() throws Exception {
//         Node thisNode = new Node(Token.THIS);
//         Node func = new Node(Token.FUNCTION, null, new Node(Token.LP), new Node(Token.BLOCK, thisNode));
//         assertTrue(NodeUtil.referencesThis(func));
//     }

    @Test
    public void testReferencesThis_false_no_this() {}
// Defects4J: flaky method
//     @Test
//     public void testReferencesThis_false_no_this() throws Exception {
//         Node func = new Node(Token.FUNCTION, null, new Node(Token.LP), new Node(Token.BLOCK, Node.newString(Token.NAME, "x")));
//         assertFalse(NodeUtil.referencesThis(func));
//     }

    @Test
    public void testReferencesThis_false_nested_function() {}
// Defects4J: flaky method
//      @Test
//     public void testReferencesThis_false_nested_function() throws Exception {
//         Node innerFunc = new Node(Token.FUNCTION, null, new Node(Token.LP), new Node(Token.BLOCK, new Node(Token.THIS)));
//         Node outerFunc = new Node(Token.FUNCTION, null, new Node(Token.LP), new Node(Token.BLOCK, innerFunc));
//         // The predicate `MatchNotFunction` prevents traversing into nested functions
//         assertFalse(NodeUtil.referencesThis(outerFunc));
//     }

    @Test
    public void testIsGet_getprop() throws Exception {
        Node obj = Node.newString(Token.NAME, "obj");
        Node prop = Node.newString(Token.STRING, "prop");
        Node getProp = new Node(Token.GETPROP, obj, prop);
        assertTrue(NodeUtil.isGet(getProp));
    }

    @Test
    public void testIsGet_getelem() throws Exception {
        Node obj = Node.newString(Token.NAME, "obj");
        Node elem = Node.newString(Token.STRING, "elem");
        Node getElem = new Node(Token.GETELEM, obj, elem);
        assertTrue(NodeUtil.isGet(getElem));
    }

    @Test
    public void testIsGet_name() throws Exception {
        Node name = Node.newString(Token.NAME, "var");
        assertFalse(NodeUtil.isGet(name));
    }

    @Test
    public void testIsGetProp_true() throws Exception {
        Node obj = Node.newString(Token.NAME, "obj");
        Node prop = Node.newString(Token.STRING, "prop");
        Node getProp = new Node(Token.GETPROP, obj, prop);
        assertTrue(NodeUtil.isGetProp(getProp));
    }

    @Test
    public void testIsGetProp_false() throws Exception {
        Node obj = Node.newString(Token.NAME, "obj");
        Node elem = Node.newString(Token.STRING, "elem");
        Node getElem = new Node(Token.GETELEM, obj, elem);
        assertFalse(NodeUtil.isGetProp(getElem));
    }

    @Test
    public void testIsName_true() throws Exception {
        Node name = Node.newString(Token.NAME, "var");
        assertTrue(NodeUtil.isName(name));
    }

    @Test
    public void testIsName_false() throws Exception {
        Node num = Node.newNumber(1.0);
        assertFalse(NodeUtil.isName(num));
    }

    @Test
    public void testIsNew_true() throws Exception {
        Node newNode = new Node(Token.NEW);
        assertTrue(NodeUtil.isNew(newNode));
    }

    @Test
    public void testIsNew_false() throws Exception {
        Node callNode = new Node(Token.CALL);
        assertFalse(NodeUtil.isNew(callNode));
    }

    @Test
    public void testIsVar_true() throws Exception {
        Node varNode = new Node(Token.VAR);
        assertTrue(NodeUtil.isVar(varNode));
    }

    @Test
    public void testIsVar_false() throws Exception {
        Node block = new Node(Token.BLOCK);
        assertFalse(NodeUtil.isVar(block));
    }

    @Test
    public void testIsVarDeclaration_true() throws Exception {
        Node name = Node.newString(Token.NAME, "x");
        Node var = new Node(Token.VAR, name);
        assertTrue(NodeUtil.isVarDeclaration(name));
    }

    @Test
    public void testIsVarDeclaration_false_not_name() throws Exception {
        Node number = Node.newNumber(1.0);
        Node var = new Node(Token.VAR, number);
        assertFalse(NodeUtil.isVarDeclaration(number));
    }

    @Test
    public void testIsVarDeclaration_false_not_var_parent() throws Exception {
        Node name = Node.newString(Token.NAME, "x");
        Node block = new Node(Token.BLOCK, name);
        assertFalse(NodeUtil.isVarDeclaration(name));
    }

    @Test
    public void testGetAssignedValue_var() throws Exception {
        Node value = Node.newNumber(1.0);
        Node name = Node.newString(Token.NAME, "x");
        name.addChildToBack(value);
        Node var = new Node(Token.VAR, name);
        assertEquals(value, NodeUtil.getAssignedValue(name));
    }

    @Test
    public void testGetAssignedValue_assign() throws Exception {
        Node value = Node.newNumber(1.0);
        Node name = Node.newString(Token.NAME, "x");
        Node assign = new Node(Token.ASSIGN, name, value);
        assertEquals(value, NodeUtil.getAssignedValue(name));
    }

    @Test
    public void testGetAssignedValue_no_assignment() {}
// Defects4J: flaky method
//     @Test
//     public void testGetAssignedValue_no_assignment() throws Exception {
//         Node name = Node.newString(Token.NAME, "x");
//         assertNull(NodeUtil.getAssignedValue(name));
//     }

    @Test
    public void testIsString_true() throws Exception {
        Node str = Node.newString("hello");
        assertTrue(NodeUtil.isString(str));
    }

    @Test
    public void testIsString_false() throws Exception {
        Node num = Node.newNumber(1.0);
        assertFalse(NodeUtil.isString(num));
    }

    @Test
    public void testIsExprAssign_true() throws Exception {
        Node value = Node.newNumber(1.0);
        Node name = Node.newString(Token.NAME, "x");
        Node assign = new Node(Token.ASSIGN, name, value);
        Node exprResult = NodeUtil.newExpr(assign);
        assertTrue(NodeUtil.isExprAssign(exprResult));
    }

    @Test
    public void testIsExprAssign_false_not_expr_result() throws Exception {
        Node value = Node.newNumber(1.0);
        Node name = Node.newString(Token.NAME, "x");
        Node assign = new Node(Token.ASSIGN, name, value);
        assertFalse(NodeUtil.isExprAssign(assign));
    }

    @Test
    public void testIsExprAssign_false_not_assign() throws Exception {
        Node exprResult = NodeUtil.newExpr(Node.newString("test"));
        assertFalse(NodeUtil.isExprAssign(exprResult));
    }

    @Test
    public void testIsAssign_true() throws Exception {
        Node assign = new Node(Token.ASSIGN);
        assertTrue(NodeUtil.isAssign(assign));
    }

    @Test
    public void testIsAssign_false() throws Exception {
        Node add = new Node(Token.ADD);
        assertFalse(NodeUtil.isAssign(add));
    }

    @Test
    public void testIsExprCall_true() throws Exception {
        Node call = new Node(Token.CALL);
        Node exprResult = NodeUtil.newExpr(call);
        assertTrue(NodeUtil.isExprCall(exprResult));
    }

    @Test
    public void testIsExprCall_false_not_expr_result() throws Exception {
        Node call = new Node(Token.CALL);
        assertFalse(NodeUtil.isExprCall(call));
    }

    @Test
    public void testIsExprCall_false_not_call() throws Exception {
        Node exprResult = NodeUtil.newExpr(Node.newString("test"));
        assertFalse(NodeUtil.isExprCall(exprResult));
    }

    @Test
    public void testIsForIn_true() throws Exception {
        Node forNode = new Node(Token.FOR,
                Node.newString(Token.NAME, "var i"),
                Node.newString(Token.IN, "array"),
                new Node(Token.BLOCK));
        assertTrue(NodeUtil.isForIn(forNode));
    }

    @Test
    public void testIsForIn_false_not_for() throws Exception {
        Node whileNode = new Node(Token.WHILE, Node.newString(Token.TRUE, ""), new Node(Token.BLOCK));
        assertFalse(NodeUtil.isForIn(whileNode));
    }


    @Test
    public void testIsLoopStructure_for() throws Exception {
        Node forNode = new Node(Token.FOR);
        assertTrue(NodeUtil.isLoopStructure(forNode));
    }

    @Test
    public void testIsLoopStructure_while() throws Exception {
        Node whileNode = new Node(Token.WHILE);
        assertTrue(NodeUtil.isLoopStructure(whileNode));
    }

    @Test
    public void testIsLoopStructure_do() throws Exception {
        Node doNode = new Node(Token.DO);
        assertTrue(NodeUtil.isLoopStructure(doNode));
    }

    @Test
    public void testIsLoopStructure_if() throws Exception {
        Node ifNode = new Node(Token.IF);
        assertFalse(NodeUtil.isLoopStructure(ifNode));
    }

    @Test
    public void testGetLoopCodeBlock_for() throws Exception {
        Node block = new Node(Token.BLOCK);
        Node forNode = new Node(Token.FOR, Node.newString(Token.NAME, "i"), Node.newString(Token.IN, "arr"), block);
        assertEquals(block, NodeUtil.getLoopCodeBlock(forNode));
    }

    @Test
    public void testGetLoopCodeBlock_while() throws Exception {
        Node block = new Node(Token.BLOCK);
        Node whileNode = new Node(Token.WHILE, Node.newString(Token.TRUE, ""), block);
        assertEquals(block, NodeUtil.getLoopCodeBlock(whileNode));
    }

    @Test
    public void testGetLoopCodeBlock_do() throws Exception {
        Node block = new Node(Token.BLOCK);
        Node doNode = new Node(Token.DO, block, Node.newString(Token.TRUE, ""));
        assertEquals(block, NodeUtil.getLoopCodeBlock(doNode));
    }

    @Test
    public void testGetLoopCodeBlock_not_a_loop() throws Exception {
        Node ifNode = new Node(Token.IF);
        assertNull(NodeUtil.getLoopCodeBlock(ifNode));
    }

    @Test
    public void testIsWithinLoop_true() throws Exception {
        Node block = new Node(Token.BLOCK);
        Node whileNode = new Node(Token.WHILE, Node.newString(Token.TRUE, ""), block);
        Node targetNode = Node.newString(Token.NAME, "x");
        block.addChildToBack(targetNode);
        // Manually set parent for demonstration, although getAncestors() handles this
        assertTrue(NodeUtil.isWithinLoop(targetNode));
    }

    @Test
    public void testIsWithinLoop_false_no_loop() throws Exception {
        Node block = new Node(Token.BLOCK);
        Node targetNode = Node.newString(Token.NAME, "x");
        block.addChildToBack(targetNode);
        assertFalse(NodeUtil.isWithinLoop(targetNode));
    }

    @Test
    public void testIsWithinLoop_false_outside_function() {}
// Defects4J: flaky method
//     @Test
//     public void testIsWithinLoop_false_outside_function() throws Exception {
//         Node block = new Node(Token.BLOCK);
//         Node whileNode = new Node(Token.WHILE, Node.newString(Token.TRUE, ""), block);
//         Node func = new Node(Token.FUNCTION, null, new Node(Token.LP), block);
//         Node targetNode = Node.newString(Token.NAME, "x");
//         block.addChildToBack(targetNode); // Target is inside the function, but not directly in the loop
//         assertFalse(NodeUtil.isWithinLoop(targetNode)); // Should not consider loop in different scope
//     }


    @Test
    public void testIsControlStructure_for() throws Exception {
        Node forNode = new Node(Token.FOR);
        assertTrue(NodeUtil.isControlStructure(forNode));
    }

    @Test
    public void testIsControlStructure_if() throws Exception {
        Node ifNode = new Node(Token.IF);
        assertTrue(NodeUtil.isControlStructure(ifNode));
    }

    @Test
    public void testIsControlStructure_block() throws Exception {
        Node blockNode = new Node(Token.BLOCK);
        assertFalse(NodeUtil.isControlStructure(blockNode));
    }

    @Test
    public void testIsControlStructureCodeBlock_if_true_branch() throws Exception {
        Node ifBranch = new Node(Token.BLOCK);
        Node ifNode = new Node(Token.IF, Node.newString(Token.TRUE, ""), ifBranch);
        assertTrue(NodeUtil.isControlStructureCodeBlock(ifNode, ifBranch));
    }

    @Test
    public void testIsControlStructureCodeBlock_if_false_branch() throws Exception {
        Node elseBranch = new Node(Token.BLOCK);
        Node ifNode = new Node(Token.IF, Node.newString(Token.TRUE, ""), new Node(Token.BLOCK), elseBranch);
        assertTrue(NodeUtil.isControlStructureCodeBlock(ifNode, elseBranch));
    }

    @Test
    public void testIsControlStructureCodeBlock_for_body() throws Exception {
        Node forBody = new Node(Token.BLOCK);
        Node forNode = new Node(Token.FOR, Node.newString(Token.NAME, "i"), Node.newString(Token.IN, "arr"), forBody);
        assertTrue(NodeUtil.isControlStructureCodeBlock(forNode, forBody));
    }

    @Test
    public void testIsControlStructureCodeBlock_while_body() throws Exception {
        Node whileBody = new Node(Token.BLOCK);
        Node whileNode = new Node(Token.WHILE, Node.newString(Token.TRUE, ""), whileBody);
        assertTrue(NodeUtil.isControlStructureCodeBlock(whileNode, whileBody));
    }

    @Test
    public void testIsControlStructureCodeBlock_try_catch() {}
// Defects4J: flaky method
//     @Test
//     public void testIsControlStructureCodeBlock_try_catch() throws Exception {
//         Node catchBlock = new Node(Token.BLOCK);
//         Node catchNode = new Node(Token.CATCH, Node.newString(Token.NAME, "e"), catchBlock);
//         Node tryNode = new Node(Token.TRY, new Node(Token.BLOCK), catchNode);
//         assertTrue(NodeUtil.isControlStructureCodeBlock(tryNode, catchBlock));
//     }

    @Test
    public void testIsControlStructureCodeBlock_switch_case() throws Exception {
        Node caseNode = new Node(Token.CASE, Node.newString(Token.NAME, "val"));
        Node switchNode = new Node(Token.SWITCH, new Node(Token.BLOCK), caseNode);
        assertTrue(NodeUtil.isControlStructureCodeBlock(switchNode, caseNode));
    }

    @Test
    public void testIsControlStructureCodeBlock_switch_default() {}
// Defects4J: flaky method
//     @Test
//     public void testIsControlStructureCodeBlock_switch_default() throws Exception {
//         Node defaultNode = new Node(Token.DEFAULT);
//         Node switchNode = new Node(Token.SWITCH, defaultNode, new Node(Token.BLOCK));
//         assertTrue(NodeUtil.isControlStructureCodeBlock(switchNode, defaultNode));
//     }


    @Test
    public void testGetConditionExpression_if() throws Exception {
        Node condition = Node.newString(Token.NAME, "cond");
        Node thenBranch = new Node(Token.BLOCK);
        Node ifNode = new Node(Token.IF, condition, thenBranch);
        assertEquals(condition, NodeUtil.getConditionExpression(ifNode));
    }

    @Test
    public void testGetConditionExpression_while() throws Exception {
        Node condition = Node.newString(Token.NAME, "cond");
        Node whileBody = new Node(Token.BLOCK);
        Node whileNode = new Node(Token.WHILE, condition, whileBody);
        assertEquals(condition, NodeUtil.getConditionExpression(whileNode));
    }

    @Test
    public void testGetConditionExpression_do() throws Exception {
        Node condition = Node.newString(Token.NAME, "cond");
        Node doBody = new Node(Token.BLOCK);
        Node doNode = new Node(Token.DO, doBody, condition);
        assertEquals(condition, NodeUtil.getConditionExpression(doNode));
    }

    @Test
    public void testGetConditionExpression_for_init_cond_iter_body() throws Exception {
        Node condition = Node.newString(Token.NAME, "cond");
        Node forNode = new Node(Token.FOR,
            Node.newString(Token.NAME, "var i=0"),
            condition,
            Node.newString(Token.NAME, "i++"),
            new Node(Token.BLOCK));
        assertEquals(condition, NodeUtil.getConditionExpression(forNode));
    }

    @Test
    public void testGetConditionExpression_for_no_condition() throws Exception {
        Node forNode = new Node(Token.FOR,
            Node.newString(Token.NAME, "var i=0"),
            Node.newString(Token.NAME, "i++"),
            new Node(Token.BLOCK));
        // For a for loop with 3 children (init, iter, body), there's no explicit condition node to return.
        assertNull(NodeUtil.getConditionExpression(forNode));
    }

    @Test
    public void testGetConditionExpression_case() {}
// Defects4J: flaky method
//     @Test(expected = IllegalArgumentException.class)
//     public void testGetConditionExpression_case() throws Exception {
//         Node caseNode = new Node(Token.CASE, Node.newString(Token.NAME, "val"));
//         NodeUtil.getConditionExpression(caseNode); // Should throw
//     }

    @Test
    public void testIsStatementBlock_script() throws Exception {
        Node script = new Node(Token.SCRIPT);
        assertTrue(NodeUtil.isStatementBlock(script));
    }

    @Test
    public void testIsStatementBlock_block() throws Exception {
        Node block = new Node(Token.BLOCK);
        assertTrue(NodeUtil.isStatementBlock(block));
    }

    @Test
    public void testIsStatementBlock_not_block() throws Exception {
        Node name = Node.newString(Token.NAME, "x");
        assertFalse(NodeUtil.isStatementBlock(name));
    }

    @Test
    public void testIsStatement_true_in_block() throws Exception {
        Node statement = Node.newString(Token.NAME, "stmt");
        Node block = new Node(Token.BLOCK, statement);
        assertTrue(NodeUtil.isStatement(statement));
    }

    @Test
    public void testIsStatement_true_in_script() throws Exception {
        Node statement = Node.newString(Token.NAME, "stmt");
        Node script = new Node(Token.SCRIPT, statement);
        assertTrue(NodeUtil.isStatement(statement));
    }

    @Test
    public void testIsStatement_true_in_label() throws Exception {
        Node statement = Node.newString(Token.NAME, "stmt");
        Node label = new Node(Token.LABEL, Node.newString(Token.LABEL_NAME, "myLabel"), statement);
        assertTrue(NodeUtil.isStatement(statement));
    }


    @Test
    public void testIsSwitchCase_case() throws Exception {
        Node caseNode = new Node(Token.CASE);
        assertTrue(NodeUtil.isSwitchCase(caseNode));
    }

    @Test
    public void testIsSwitchCase_default() throws Exception {
        Node defaultNode = new Node(Token.DEFAULT);
        assertTrue(NodeUtil.isSwitchCase(defaultNode));
    }

    @Test
    public void testIsSwitchCase_not_switch_related() throws Exception {
        Node block = new Node(Token.BLOCK);
        assertFalse(NodeUtil.isSwitchCase(block));
    }

    @Test
    public void testIsReferenceName_true() throws Exception {
        Node name = Node.newString(Token.NAME, "myVar");
        assertTrue(NodeUtil.isReferenceName(name));
    }

    @Test
    public void testIsReferenceName_empty_string() throws Exception {
        Node name = Node.newString(Token.NAME, "");
        assertFalse(NodeUtil.isReferenceName(name));
    }

    @Test
    public void testIsReferenceName_label_name() throws Exception {
        Node labelName = new Node(Token.LABEL_NAME);
        assertFalse(NodeUtil.isReferenceName(labelName));
    }

    @Test
    public void testIsLabelName_true() throws Exception {
        Node labelName = new Node(Token.LABEL_NAME);
        assertTrue(NodeUtil.isLabelName(labelName));
    }

    @Test
    public void testIsLabelName_false() throws Exception {
        Node name = Node.newString(Token.NAME, "myVar");
        assertFalse(NodeUtil.isLabelName(name));
    }

    @Test
    public void testIsTryFinallyNode_true() throws Exception {
        Node finallyBlock = new Node(Token.BLOCK);
        Node tryNode = new Node(Token.TRY, new Node(Token.BLOCK), new Node(Token.BLOCK), finallyBlock);
        assertTrue(NodeUtil.isTryFinallyNode(tryNode, finallyBlock));
    }

    @Test
    public void testIsTryFinallyNode_false_not_finally() throws Exception {
        Node catchBlock = new Node(Token.BLOCK);
        Node tryNode = new Node(Token.TRY, new Node(Token.BLOCK), catchBlock);
        assertFalse(NodeUtil.isTryFinallyNode(tryNode, catchBlock));
    }

    @Test
    public void testIsTryFinallyNode_false_not_try() throws Exception {
        Node block = new Node(Token.BLOCK);
        Node label = new Node(Token.LABEL, Node.newString(Token.LABEL_NAME, "lbl"), block);
        assertFalse(NodeUtil.isTryFinallyNode(label, block));
    }

    @Test
    public void testRemoveChild_statement_from_block() throws Exception {
        Node stmt = Node.newString(Token.NAME, "stmt");
        Node block = new Node(Token.BLOCK, stmt);
        NodeUtil.removeChild(block, stmt);
        assertNull(block.getFirstChild());
    }

    @Test
    public void testRemoveChild_var_declaration() throws Exception {
        Node value = Node.newNumber(1.0);
        Node name = Node.newString(Token.NAME, "x");
        name.addChildToBack(value);
        Node var = new Node(Token.VAR, name);
        Node parent = new Node(Token.BLOCK, var); // Parent of VAR

        NodeUtil.removeChild(parent, var); // remove the VAR node
        // The implementation of removeChild for VAR handles the case where the parent might be removed if it becomes empty.
        // In this case, `var` is removed from `parent`.
        assertNull(parent.getFirstChild());
    }

    @Test
    public void testRemoveChild_block_children_detached() {}
// Defects4J: flaky method
//     @Test
//     public void testRemoveChild_block_children_detached() throws Exception {
//         Node child1 = Node.newString(Token.NAME, "stmt1");
//         Node child2 = Node.newString(Token.NAME, "stmt2");
//         Node block = new Node(Token.BLOCK, child1, child2);
//         Node parentOfBlock = new Node(Token.BLOCK, block); // Parent of the block
//         NodeUtil.removeChild(block, block); // Detach children of block
//         assertNull(block.getFirstChild());
//         assertNull(block.getLastChild());
//     }

    @Test
    public void testRemoveChild_label_target() {}
// Defects4J: flaky method
//     @Test
//     public void testRemoveChild_label_target() throws Exception {
//         Node target = Node.newString(Token.NAME, "targetStmt");
//         Node label = new Node(Token.LABEL, Node.newString(Token.LABEL_NAME, "lbl"), target);
//         Node parent = new Node(Token.BLOCK, label); // Parent of LABEL
// 
//         NodeUtil.removeChild(parent, target); // remove the target from the label
//         // The method should remove the LABEL itself if it becomes empty.
//         assertNull(parent.getFirstChild());
//     }

    @Test
    public void testRemoveChild_for_with_empty() {}
// Defects4J: flaky method
//     @Test
//     public void testRemoveChild_for_with_empty() throws Exception {
//         Node empty = new Node(Token.EMPTY);
//         Node forNode = new Node(Token.FOR, Node.newString(Token.NAME, "i"), Node.newString(Token.IN, "arr"), empty);
//         Node parent = new Node(Token.BLOCK, forNode);
// 
//         NodeUtil.removeChild(parent, empty); // This should replace `empty` with another `EMPTY` node if the loop structure requires it.
//         // The `NodeUtil.removeChild` method's `else if (parent.getType() == Token.FOR && parent.getChildCount() == 4)` branch handles this.
//         assertEquals(Token.EMPTY, forNode.getLastChild().getType()); // The loop's body should remain EMPTY.
//     }


    @Test
    public void testTryMergeBlock_not_merged_non_block_parent() throws Exception {
        Node child1 = Node.newString(Token.NAME, "stmt1");
        Node blockToMerge = new Node(Token.BLOCK, child1);
        Node ifNode = new Node(Token.IF, Node.newString(Token.TRUE, ""), blockToMerge);

        assertFalse(NodeUtil.tryMergeBlock(blockToMerge));
        // The block should remain as a child of the IF node
        assertEquals(ifNode, blockToMerge.getParent());
        assertEquals(blockToMerge, ifNode.getLastChild());
    }

    @Test
    public void testIsCall_true() throws Exception {
        Node call = new Node(Token.CALL);
        assertTrue(NodeUtil.isCall(call));
    }

    @Test
    public void testIsCall_false() throws Exception {
        Node name = Node.newString(Token.NAME, "func");
        assertFalse(NodeUtil.isCall(name));
    }

    @Test
    public void testIsCallOrNew_call() throws Exception {
        Node call = new Node(Token.CALL);
        assertTrue(NodeUtil.isCallOrNew(call));
    }

    @Test
    public void testIsCallOrNew_new() throws Exception {
        Node newNode = new Node(Token.NEW);
        assertTrue(NodeUtil.isCallOrNew(newNode));
    }

    @Test
    public void testIsCallOrNew_name() throws Exception {
        Node name = Node.newString(Token.NAME, "func");
        assertFalse(NodeUtil.isCallOrNew(name));
    }

    @Test
    public void testIsFunction_true() throws Exception {
        Node func = new Node(Token.FUNCTION);
        assertTrue(NodeUtil.isFunction(func));
    }

    @Test
    public void testIsFunction_false() throws Exception {
        Node block = new Node(Token.BLOCK);
        assertFalse(NodeUtil.isFunction(block));
    }

    @Test
    public void testGetFunctionBody_correct_block() throws Exception {
        Node body = new Node(Token.BLOCK);
        Node func = new Node(Token.FUNCTION, Node.newString(Token.NAME, "f"), new Node(Token.LP), body);
        assertEquals(body, NodeUtil.getFunctionBody(func));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testGetFunctionBody_not_function() throws Exception {
        Node notFunc = new Node(Token.BLOCK);
        NodeUtil.getFunctionBody(notFunc);
    }

    @Test
    public void testIsThis_true() throws Exception {
        Node thisNode = new Node(Token.THIS);
        assertTrue(NodeUtil.isThis(thisNode));
    }

    @Test
    public void testIsThis_false() throws Exception {
        Node name = Node.newString(Token.NAME, "obj");
        assertFalse(NodeUtil.isThis(name));
    }

    @Test
    public void testContainsCall_true() throws Exception {
        Node call = new Node(Token.CALL);
        Node block = new Node(Token.BLOCK, call);
        assertTrue(NodeUtil.containsCall(block));
    }

    @Test
    public void testContainsCall_false() throws Exception {
        Node block = new Node(Token.BLOCK, Node.newString(Token.NAME, "x"));
        assertFalse(NodeUtil.containsCall(block));
    }

    @Test
    public void testIsFunctionDeclaration_true() throws Exception {
        Node funcBody = new Node(Token.BLOCK);
        Node func = new Node(Token.FUNCTION, Node.newString(Token.NAME, "myFunc"), new Node(Token.LP), funcBody);
        Node script = new Node(Token.SCRIPT, func); // Function as a statement in script
        assertTrue(NodeUtil.isFunctionDeclaration(func));
    }

    @Test
    public void testIsFunctionDeclaration_false_expression() {}
// Defects4J: flaky method
//     @Test
//     public void testIsFunctionDeclaration_false_expression() throws Exception {
//         Node funcBody = new Node(Token.BLOCK);
//         Node func = new Node(Token.FUNCTION, null, new Node(Token.LP), funcBody); // Anonymous function expression
//         Node parent = new Node(Token.CALL, func); // Function expression within a call
//         assertFalse(NodeUtil.isFunctionDeclaration(func));
//     }

    @Test
    public void testIsFunctionDeclaration_true_in_block_statement_context() throws Exception {
        Node funcBody = new Node(Token.BLOCK);
        Node func = new Node(Token.FUNCTION, Node.newString(Token.NAME, "myFunc"), new Node(Token.LP), funcBody);
        Node block = new Node(Token.BLOCK, func); // Function inside a block, treated as a statement
        assertTrue(NodeUtil.isFunctionDeclaration(func));
    }


    @Test
    public void testIsHoistedFunctionDeclaration_true() throws Exception {
        Node funcBody = new Node(Token.BLOCK);
        Node func = new Node(Token.FUNCTION, Node.newString(Token.NAME, "myFunc"), new Node(Token.LP), funcBody);
        Node script = new Node(Token.SCRIPT, func); // Function declaration at top level of script
        assertTrue(NodeUtil.isHoistedFunctionDeclaration(func));
    }

    @Test
    public void testIsHoistedFunctionDeclaration_true_nested_in_function() throws Exception {
        Node innerFuncBody = new Node(Token.BLOCK);
        Node innerFunc = new Node(Token.FUNCTION, Node.newString(Token.NAME, "innerFunc"), new Node(Token.LP), innerFuncBody);
        Node outerFuncBody = new Node(Token.BLOCK, innerFunc);
        Node outerFunc = new Node(Token.FUNCTION, Node.newString(Token.NAME, "outerFunc"), new Node(Token.LP), outerFuncBody);
        // The definition includes `parent.getParent().getType() == Token.FUNCTION`
        assertTrue(NodeUtil.isHoistedFunctionDeclaration(innerFunc));
    }

    @Test
    public void testIsHoistedFunctionDeclaration_false_expression() {}
// Defects4J: flaky method
//     @Test
//     public void testIsHoistedFunctionDeclaration_false_expression() throws Exception {
//         Node funcBody = new Node(Token.BLOCK);
//         Node func = new Node(Token.FUNCTION, null, new Node(Token.LP), funcBody); // Anonymous function expression
//         Node call = new Node(Token.CALL, func);
//         assertFalse(NodeUtil.isHoistedFunctionDeclaration(func));
//     }

    @Test
    public void testIsFunctionExpression_true_in_call() {}
// Defects4J: flaky method
//     @Test
//     public void testIsFunctionExpression_true_in_call() throws Exception {
//         Node funcBody = new Node(Token.BLOCK);
//         Node func = new Node(Token.FUNCTION, null, new Node(Token.LP), funcBody); // Anonymous function expression
//         Node call = new Node(Token.CALL, func);
//         assertTrue(NodeUtil.isFunctionExpression(func));
//     }

    @Test
    public void testIsFunctionExpression_true_assigned_to_var() throws Exception {
        Node funcBody = new Node(Token.BLOCK);
        Node funcName = Node.newString(Token.NAME, "namedFunc"); // Named function expression
        Node func = new Node(Token.FUNCTION, funcName, new Node(Token.LP), funcBody);
        Node name = Node.newString(Token.NAME, "myVar");
        Node assign = new Node(Token.ASSIGN, name, func);
        Node varDecl = new Node(Token.VAR, assign);
        assertTrue(NodeUtil.isFunctionExpression(func));
    }

    @Test
    public void testIsFunctionExpression_false_declaration() throws Exception {
        Node funcBody = new Node(Token.BLOCK);
        Node func = new Node(Token.FUNCTION, Node.newString(Token.NAME, "myFunc"), new Node(Token.LP), funcBody);
        Node script = new Node(Token.SCRIPT, func); // Function declaration
        assertFalse(NodeUtil.isFunctionExpression(func));
    }


    @Test
    public void testIsEmptyFunctionExpression_true() {}
// Defects4J: flaky method
//     @Test
//     public void testIsEmptyFunctionExpression_true() throws Exception {
//         Node emptyBody = new Node(Token.BLOCK);
//         Node func = new Node(Token.FUNCTION, null, new Node(Token.LP), emptyBody); // expression
//         assertTrue(NodeUtil.isEmptyFunctionExpression(func));
//     }

    @Test
    public void testIsEmptyFunctionExpression_false_non_empty_body() {}
// Defects4J: flaky method
//     @Test
//     public void testIsEmptyFunctionExpression_false_non_empty_body() throws Exception {
//         Node body = new Node(Token.BLOCK);
//         body.addChildToBack(Node.newString(Token.NAME, "stmt"));
//         Node func = new Node(Token.FUNCTION, null, new Node(Token.LP), body); // expression
//         assertFalse(NodeUtil.isEmptyFunctionExpression(func));
//     }

    @Test
    public void testIsEmptyFunctionExpression_false_not_expression() {}
// Defects4J: flaky method
//     @Test
//     public void testIsEmptyFunctionExpression_false_not_expression() throws Exception {
//         Node body = new Node(Token.BLOCK);
//         Node func = new Node(Token.FUNCTION, Node.newString(Token.NAME, "myFunc"), new Node(Token.LP), body); // declaration
//         assertFalse(NodeUtil.isEmptyFunctionExpression(func));
//     }

    @Test
    public void testIsVarArgsFunction_true() {}
// Defects4J: flaky method
//     @Test
//     public void testIsVarArgsFunction_true() throws Exception {
//         Node arguments = Node.newString(Token.NAME, "arguments");
//         Node funcBody = new Node(Token.BLOCK, arguments);
//         Node func = new Node(Token.FUNCTION, null, new Node(Token.LP), funcBody);
//         assertTrue(NodeUtil.isVarArgsFunction(func));
//     }

    @Test
    public void testIsVarArgsFunction_false_no_arguments() {}
// Defects4J: flaky method
//     @Test
//     public void testIsVarArgsFunction_false_no_arguments() throws Exception {
//         Node funcBody = new Node(Token.BLOCK, Node.newString(Token.NAME, "x"));
//         Node func = new Node(Token.FUNCTION, null, new Node(Token.LP), funcBody);
//         assertFalse(NodeUtil.isVarArgsFunction(func));
//     }

    @Test
    public void testIsVarArgsFunction_false_nested_function_arguments() {}
// Defects4J: flaky method
//      @Test
//     public void testIsVarArgsFunction_false_nested_function_arguments() throws Exception {
//         Node innerArgs = Node.newString(Token.NAME, "arguments");
//         Node innerFuncBody = new Node(Token.BLOCK, innerArgs);
//         Node innerFunc = new Node(Token.FUNCTION, null, new Node(Token.LP), innerFuncBody);
//         Node outerFuncBody = new Node(Token.BLOCK, innerFunc);
//         Node outerFunc = new Node(Token.FUNCTION, null, new Node(Token.LP), outerFuncBody);
//         // isNameReferenced needs `MatchNotFunction` to avoid looking into nested functions.
//         // Here, `isVarArgsFunction` uses `isNameReferenced` with `MatchNotFunction`.
//         // So, arguments in a nested function should not be detected by the outer function check.
//         assertFalse(NodeUtil.isVarArgsFunction(outerFunc));
//     }

    @Test
    public void testIsObjectCallMethod_true() throws Exception {
        Node methodName = Node.newString(Token.STRING, "myMethod");
        Node objectName = Node.newString(Token.NAME, "obj");
        Node getProp = new Node(Token.GETPROP, objectName, methodName);
        Node callNode = new Node(Token.CALL, getProp);
        assertTrue(NodeUtil.isObjectCallMethod(callNode, "myMethod"));
    }

    @Test
    public void testIsObjectCallMethod_true_getelem() throws Exception {
        Node methodName = Node.newString(Token.STRING, "myMethod");
        Node objectName = Node.newString(Token.NAME, "obj");
        Node getElem = new Node(Token.GETELEM, objectName, methodName);
        Node callNode = new Node(Token.CALL, getElem);
        assertTrue(NodeUtil.isObjectCallMethod(callNode, "myMethod"));
    }

    @Test
    public void testIsObjectCallMethod_false_wrong_method() throws Exception {
        Node methodName = Node.newString(Token.STRING, "otherMethod");
        Node objectName = Node.newString(Token.NAME, "obj");
        Node getProp = new Node(Token.GETPROP, objectName, methodName);
        Node callNode = new Node(Token.CALL, getProp);
        assertFalse(NodeUtil.isObjectCallMethod(callNode, "myMethod"));
    }

    @Test
    public void testIsObjectCallMethod_false_not_call() throws Exception {
        Node methodName = Node.newString(Token.STRING, "myMethod");
        Node objectName = Node.newString(Token.NAME, "obj");
        Node getProp = new Node(Token.GETPROP, objectName, methodName);
        assertFalse(NodeUtil.isObjectCallMethod(getProp, "myMethod"));
    }

    @Test
    public void testIsFunctionObjectCall_true() throws Exception {
        Node methodName = Node.newString(Token.STRING, "call");
        Node objectName = Node.newString(Token.NAME, "obj");
        Node getProp = new Node(Token.GETPROP, objectName, methodName);
        Node callNode = new Node(Token.CALL, getProp);
        assertTrue(NodeUtil.isFunctionObjectCall(callNode));
    }

    @Test
    public void testIsFunctionObjectCall_false() throws Exception {
        Node methodName = Node.newString(Token.STRING, "apply");
        Node objectName = Node.newString(Token.NAME, "obj");
        Node getProp = new Node(Token.GETPROP, objectName, methodName);
        Node callNode = new Node(Token.CALL, getProp);
        assertFalse(NodeUtil.isFunctionObjectCall(callNode));
    }

    @Test
    public void testIsFunctionObjectApply_true() throws Exception {
        Node methodName = Node.newString(Token.STRING, "apply");
        Node objectName = Node.newString(Token.NAME, "obj");
        Node getProp = new Node(Token.GETPROP, objectName, methodName);
        Node callNode = new Node(Token.CALL, getProp);
        assertTrue(NodeUtil.isFunctionObjectApply(callNode));
    }

    @Test
    public void testIsFunctionObjectApply_false() throws Exception {
        Node methodName = Node.newString(Token.STRING, "call");
        Node objectName = Node.newString(Token.NAME, "obj");
        Node getProp = new Node(Token.GETPROP, objectName, methodName);
        Node callNode = new Node(Token.CALL, getProp);
        assertFalse(NodeUtil.isFunctionObjectApply(callNode));
    }

    @Test
    public void testIsFunctionObjectCallOrApply_call_true() throws Exception {
        Node methodName = Node.newString(Token.STRING, "call");
        Node objectName = Node.newString(Token.NAME, "obj");
        Node getProp = new Node(Token.GETPROP, objectName, methodName);
        Node callNode = new Node(Token.CALL, getProp);
        assertTrue(NodeUtil.isFunctionObjectCallOrApply(callNode));
    }

    @Test
    public void testIsFunctionObjectCallOrApply_apply_true() throws Exception {
        Node methodName = Node.newString(Token.STRING, "apply");
        Node objectName = Node.newString(Token.NAME, "obj");
        Node getProp = new Node(Token.GETPROP, objectName, methodName);
        Node callNode = new Node(Token.CALL, getProp);
        assertTrue(NodeUtil.isFunctionObjectCallOrApply(callNode));
    }

    @Test
    public void testIsFunctionObjectCallOrApply_false() throws Exception {
        Node methodName = Node.newString(Token.STRING, "other");
        Node objectName = Node.newString(Token.NAME, "obj");
        Node getProp = new Node(Token.GETPROP, objectName, methodName);
        Node callNode = new Node(Token.CALL, getProp);
        assertFalse(NodeUtil.isFunctionObjectCallOrApply(callNode));
    }

    @Test
    public void testIsSimpleFunctionObjectCall_true() throws Exception {
        Node callMethodName = Node.newString(Token.STRING, "call");
        Node getProp = new Node(Token.GETPROP, Node.newString(Token.NAME, "obj"), callMethodName);
        Node callNode = new Node(Token.CALL, getProp);
        assertTrue(NodeUtil.isSimpleFunctionObjectCall(callNode));
    }

    @Test
    public void testIsSimpleFunctionObjectCall_false_non_name_target() throws Exception {
        Node callMethodName = Node.newString(Token.STRING, "call");
        Node getProp = new Node(Token.GETPROP, createNode(Token.NEW, null), callMethodName); // Target is not NAME
        Node callNode = new Node(Token.CALL, getProp);
        assertFalse(NodeUtil.isSimpleFunctionObjectCall(callNode));
    }

    @Test
    public void testIsSimpleFunctionObjectCall_false_not_call() throws Exception {
        Node callMethodName = Node.newString(Token.STRING, "call");
        Node getProp = new Node(Token.GETPROP, Node.newString(Token.NAME, "obj"), callMethodName);
        assertFalse(NodeUtil.isSimpleFunctionObjectCall(getProp));
    }

    @Test
    public void testIsLhs_assign_true() throws Exception {
        Node name = Node.newString(Token.NAME, "x");
        Node assign = new Node(Token.ASSIGN, name, Node.newNumber(1.0));
        assertTrue(NodeUtil.isLhs(name, assign));
    }

    @Test
    public void testIsLhs_var_true() throws Exception {
        Node name = Node.newString(Token.NAME, "x");
        Node var = new Node(Token.VAR, name);
        assertTrue(NodeUtil.isLhs(name, var));
    }

    @Test
    public void testIsLhs_assign_false_rhs() throws Exception {
        Node value = Node.newNumber(1.0);
        Node name = Node.newString(Token.NAME, "x");
        Node assign = new Node(Token.ASSIGN, name, value);
        assertFalse(NodeUtil.isLhs(value, assign));
    }

    @Test
    public void testIsObjectLitKey_string_true() throws Exception {
        Node key = Node.newString(Token.STRING, "key");
        Node objLit = new Node(Token.OBJECTLIT, key);
        assertTrue(NodeUtil.isObjectLitKey(key, objLit));
    }

    @Test
    public void testIsObjectLitKey_number_true() throws Exception {
        Node key = Node.newNumber(123.0); // Use double for consistency
        Node objLit = new Node(Token.OBJECTLIT, key);
        assertTrue(NodeUtil.isObjectLitKey(key, objLit));
    }

    @Test
    public void testIsObjectLitKey_get_true() throws Exception {
        Node key = new Node(Token.GET);
        Node objLit = new Node(Token.OBJECTLIT, key);
        assertTrue(NodeUtil.isObjectLitKey(key, objLit));
    }

    @Test
    public void testIsObjectLitKey_set_true() throws Exception {
        Node key = new Node(Token.SET);
        Node objLit = new Node(Token.OBJECTLIT, key);
        assertTrue(NodeUtil.isObjectLitKey(key, objLit));
    }

    @Test
    public void testIsObjectLitKey_false_not_objectlit() throws Exception {
        Node key = Node.newString(Token.STRING, "key");
        Node block = new Node(Token.BLOCK, key);
        assertFalse(NodeUtil.isObjectLitKey(key, block));
    }

    @Test
    public void testIsGetOrSetKey_get_true() throws Exception {
        Node key = new Node(Token.GET);
        assertTrue(NodeUtil.isGetOrSetKey(key));
    }

    @Test
    public void testIsGetOrSetKey_set_true() throws Exception {
        Node key = new Node(Token.SET);
        assertTrue(NodeUtil.isGetOrSetKey(key));
    }

    @Test
    public void testIsGetOrSetKey_false() throws Exception {
        Node key = Node.newString(Token.STRING, "key");
        assertFalse(NodeUtil.isGetOrSetKey(key));
    }

    @Test
    public void testOpToStr_add() throws Exception {
        assertEquals("+", NodeUtil.opToStr(Token.ADD));
    }

    @Test
    public void testOpToStr_assign_add() throws Exception {
        assertEquals("+=", NodeUtil.opToStr(Token.ASSIGN_ADD));
    }

    @Test
    public void testOpToStr_sheq() throws Exception {
        assertEquals("===", NodeUtil.opToStr(Token.SHEQ));
    }

    @Test
    public void testOpToStr_null() throws Exception {
        assertNull(NodeUtil.opToStr(Token.NAME)); // Not an operator
    }

    @Test
    public void testOpToStrNoFail_add() throws Exception {
        assertEquals("+", NodeUtil.opToStrNoFail(Token.ADD));
    }

    @Test(expected = Error.class)
    public void testOpToStrNoFail_unknown_operator() throws Exception {
        NodeUtil.opToStrNoFail(Token.NAME); // Non-operator token
    }

    @Test
    public void testContainsType_true() {}
// Defects4J: flaky method
//     @Test
//     public void testContainsType_true() throws Exception {
//         Node nameNode = Node.newString(Token.NAME, "x");
//         Node block = new Node(Token.BLOCK, nameNode);
//         assertTrue(NodeUtil.containsType(block, Token.NAME, Predicates.alwaysTrue()));
//     }

    @Test
    public void testContainsType_false() {}
// Defects4J: flaky method
//     @Test
//     public void testContainsType_false() throws Exception {
//         Node block = new Node(Token.BLOCK, Node.newNumber(1.0));
//         assertFalse(NodeUtil.containsType(block, Token.NAME, Predicates.alwaysTrue()));
//     }

    @Test
    public void testContainsType_predicate_filtered() throws Exception {
        Node name1 = Node.newString(Token.NAME, "x");
        Node name2 = Node.newString(Token.NAME, "y");
        Node func = new Node(Token.FUNCTION, name2); // Name inside function
        Node block = new Node(Token.BLOCK, name1, func);

        // Should find "x", but not "y" because the predicate excludes functions.
        assertTrue(NodeUtil.containsType(block, Token.NAME, new NodeUtil.MatchNotFunction()));
    }

    @Test
    public void testContainsType_no_predicate() throws Exception {
        Node nameNode = Node.newString(Token.NAME, "x");
        Node block = new Node(Token.BLOCK, nameNode);
        assertTrue(NodeUtil.containsType(block, Token.NAME));
    }

    @Test
    public void testRedeclareVarsInsideBranch_simple() {}
// Defects4J: flaky method
//     @Test
//     public void testRedeclareVarsInsideBranch_simple() throws Exception {
//         Node varX = NodeUtil.newVarNode("x", Node.newNumber(1.0));
//         Node block = new Node(Token.BLOCK, varX); // var x = 1;
// 
//         NodeUtil.redeclareVarsInsideBranch(block);
// 
//         // Should add a new var x at the front of the block
//         assertEquals(2, block.getChildCount());
//         assertEquals(Token.VAR, block.getFirstChild().getType());
//         assertEquals("x", block.getFirstChild().getFirstChild().getString());
//         assertEquals(Token.VAR, block.getLastChild().getType()); // Original var
//         assertEquals("x", block.getLastChild().getFirstChild().getString());
//     }


    @Test
    public void testRedeclareVarsInsideBranch_nested_scope() {}
// Defects4J: flaky method
//     @Test
//     public void testRedeclareVarsInsideBranch_nested_scope() throws Exception {
//         Node varZ = NodeUtil.newVarNode("z", Node.newNumber(2.0));
//         Node innerBlock = new Node(Token.BLOCK, varZ);
//         Node func = new Node(Token.FUNCTION, null, new Node(Token.LP), innerBlock); // Function expression
//         Node block = new Node(Token.BLOCK, func); // The function is within the outer block
// 
//         NodeUtil.redeclareVarsInsideBranch(block);
// 
//         // Should not redeclare 'z' because it's in an inner scope (FUNCTION body)
//         assertEquals(1, block.getChildCount());
//         assertEquals(Token.FUNCTION, block.getFirstChild().getType());
//         assertEquals(1, innerBlock.getChildCount()); // Inner block should be unchanged
//     }

    @Test
    public void testCopyNameAnnotations_constant() throws Exception {
        Node source = Node.newString(Token.NAME, "CONST_VAR");
        source.putBooleanProp(Node.IS_CONSTANT_NAME, true);
        Node destination = Node.newString(Token.NAME, "CONST_VAR");
        NodeUtil.copyNameAnnotations(source, destination);
        assertTrue(destination.getBooleanProp(Node.IS_CONSTANT_NAME));
    }

    @Test
    public void testCopyNameAnnotations_not_constant() throws Exception {
        Node source = Node.newString(Token.NAME, "VAR");
        Node destination = Node.newString(Token.NAME, "VAR");
        NodeUtil.copyNameAnnotations(source, destination);
        assertFalse(destination.getBooleanProp(Node.IS_CONSTANT_NAME));
    }




    @Test
    public void testNewFunctionNode_basic() throws Exception {
        String name = "myFunc";
        List<Node> params = Arrays.asList(Node.newString(Token.NAME, "a"), Node.newString(Token.NAME, "b"));
        Node body = new Node(Token.BLOCK);
        int lineno = 1;
        int charno = 5;

        Node funcNode = NodeUtil.newFunctionNode(name, params, body, lineno, charno);

        assertEquals(Token.FUNCTION, funcNode.getType());
        assertEquals(lineno, funcNode.getLineno());
        assertEquals(charno, funcNode.getCharno());

        Node funcName = funcNode.getFirstChild();
        assertEquals(Token.NAME, funcName.getType());
        assertEquals(name, funcName.getString());

        Node paramParen = funcName.getNext();
        assertEquals(Token.LP, paramParen.getType());
        assertEquals(2, paramParen.getChildCount());
        assertEquals("a", paramParen.getFirstChild().getString());
        assertEquals("b", paramParen.getLastChild().getString());

        Node funcBody = paramParen.getNext();
        assertEquals(body, funcBody);
        assertEquals(3, funcNode.getChildCount()); // name, lp, body
    }




    @Test
    public void testGetRootOfQualifiedName_name() throws Exception {
        Node nameNode = Node.newString(Token.NAME, "foo");
        assertEquals(nameNode, NodeUtil.getRootOfQualifiedName(nameNode));
    }

    @Test
    public void testGetRootOfQualifiedName_this() throws Exception {
        Node thisNode = new Node(Token.THIS);
        assertEquals(thisNode, NodeUtil.getRootOfQualifiedName(thisNode));
    }

    @Test
    public void testGetRootOfQualifiedName_getprop() throws Exception {
        Node foo = Node.newString(Token.NAME, "foo");
        Node barProp = Node.newString(Token.STRING, "bar");
        Node getProp = new Node(Token.GETPROP, foo, barProp);
        assertEquals(foo, NodeUtil.getRootOfQualifiedName(getProp));
    }

    @Test
    public void testGetRootOfQualifiedName_nested_getprop() throws Exception {
        Node foo = Node.newString(Token.NAME, "foo");
        Node barProp = Node.newString(Token.STRING, "bar");
        Node getProp1 = new Node(Token.GETPROP, foo, barProp);
        Node bazProp = Node.newString(Token.STRING, "baz");
        Node getProp2 = new Node(Token.GETPROP, getProp1, bazProp);
        assertEquals(foo, NodeUtil.getRootOfQualifiedName(getProp2));
    }






    @Test
    public void testIsLatin_all_basic_latin() throws Exception {
        assertTrue(NodeUtil.isLatin("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+=-`~[]{}|;':,./<>?"));
    }

    @Test
    public void testIsLatin_unicode_char() throws Exception {
        assertFalse(NodeUtil.isLatin("abc\u00E9def")); // é
    }

    @Test
    public void testIsLatin_empty_string() throws Exception {
        assertTrue(NodeUtil.isLatin(""));
    }

    @Test
    public void testIsValidPropertyName_js_identifier() throws Exception {
        assertTrue(NodeUtil.isValidPropertyName("validIdentifier"));
    }

    @Test
    public void testIsValidPropertyName_keyword() throws Exception {
        assertFalse(NodeUtil.isValidPropertyName("if")); // 'if' is a keyword
    }

    @Test
    public void testIsValidPropertyName_unicode_identifier() throws Exception {
        // This test assumes isLatin will correctly identify non-basic latin chars.
        assertFalse(NodeUtil.isValidPropertyName("valid\u03A3Identifier")); // Sigma character
    }

    @Test
    public void testGetVarsDeclaredInBranch_simple() {}
// Defects4J: flaky method
//     @Test
//     public void testGetVarsDeclaredInBranch_simple() throws Exception {
//         Node varX = NodeUtil.newVarNode("x", Node.newNumber(1.0));
//         Node varY = NodeUtil.newVarNode("y", Node.newNumber(2.0));
//         Node block = new Node(Token.BLOCK, varX, varY);
// 
//         Collection<Node> vars = NodeUtil.getVarsDeclaredInBranch(block);
//         assertEquals(2, vars.size());
//         assertTrue(vars.stream().anyMatch(n -> n.getString().equals("x")));
//         assertTrue(vars.stream().anyMatch(n -> n.getString().equals("y")));
//     }

    @Test
    public void testGetVarsDeclaredInBranch_nested_scope() {}
// Defects4J: flaky method
//     @Test
//     public void testGetVarsDeclaredInBranch_nested_scope() throws Exception {
//         Node varZ = NodeUtil.newVarNode("z", Node.newNumber(3.0));
//         Node innerBlock = new Node(Token.BLOCK, varZ);
//         Node func = new Node(Token.FUNCTION, null, new Node(Token.LP), innerBlock); // Function expression
//         Node varX = NodeUtil.newVarNode("x", Node.newNumber(1.0));
//         Node block = new Node(Token.BLOCK, varX, func); // var x; function() { var z; }
// 
//         Collection<Node> vars = NodeUtil.getVarsDeclaredInBranch(block);
//         assertEquals(1, vars.size()); // Only 'x' should be returned
//         assertTrue(vars.stream().anyMatch(n -> n.getString().equals("x")));
//     }

    @Test
    public void testIsPrototypePropertyDeclaration_true() {}
// Defects4J: flaky method
//     @Test
//     public void testIsPrototypePropertyDeclaration_true() throws Exception {
//         Node proto = Node.newString(Token.GETPROP, "MyClass.prototype.myMethod");
//         Node assign = new Node(Token.ASSIGN, proto, Node.newString(Token.STRING, "function(){ }"));
//         Node exprResult = NodeUtil.newExpr(assign);
//         assertTrue(NodeUtil.isPrototypePropertyDeclaration(exprResult));
//     }

    @Test
    public void testIsPrototypePropertyDeclaration_false_not_assign() throws Exception {
        Node proto = Node.newString(Token.GETPROP, "MyClass.prototype.myMethod");
        Node exprResult = NodeUtil.newExpr(proto);
        assertFalse(NodeUtil.isPrototypePropertyDeclaration(exprResult));
    }

    @Test
    public void testIsPrototypePropertyDeclaration_false_not_prototype_property() {}
// Defects4J: flaky method
//     @Test
//     public void testIsPrototypePropertyDeclaration_false_not_prototype_property() throws Exception {
//         Node objProp = Node.newString(Token.GETPROP, "myObj.myProp");
//         Node assign = new Node(Token.ASSIGN, objProp, Node.newString(Token.STRING, "value"));
//         Node exprResult = NodeUtil.newExpr(assign);
//         assertFalse(NodeUtil.isPrototypePropertyDeclaration(exprResult));
//     }

    @Test
    public void testIsPrototypeProperty_true() {}
// Defects4J: flaky method
//     @Test
//     public void testIsPrototypeProperty_true() throws Exception {
//         Node qName = Node.newString(Token.GETPROP, "MyClass.prototype.myMethod");
//         assertTrue(NodeUtil.isPrototypeProperty(qName));
//     }

    @Test
    public void testIsPrototypeProperty_false() {}
// Defects4J: flaky method
//     @Test
//     public void testIsPrototypeProperty_false() throws Exception {
//         Node qName = Node.newString(Token.GETPROP, "myObj.myProp");
//         assertFalse(NodeUtil.isPrototypeProperty(qName));
//     }

    @Test
    public void testGetPrototypeClassName_basic() {}
// Defects4J: flaky method
//     @Test
//     public void testGetPrototypeClassName_basic() throws Exception {
//         Node qName = Node.newString(Token.GETPROP, "MyClass.prototype.myMethod");
//         Node classNameNode = NodeUtil.getPrototypeClassName(qName);
//         assertNotNull(classNameNode);
//         assertEquals("MyClass", classNameNode.getString());
//     }

    @Test
    public void testGetPrototypeClassName_nested_getprop() {}
// Defects4J: flaky method
//     @Test
//     public void testGetPrototypeClassName_nested_getprop() throws Exception {
//         Node qName = Node.newString(Token.GETPROP, "Namespace.MyClass.prototype.myMethod");
//         Node classNameNode = NodeUtil.getPrototypeClassName(qName);
//         assertNotNull(classNameNode);
//         assertEquals("Namespace.MyClass", classNameNode.getQualifiedName());
//     }

    @Test
    public void testGetPrototypeClassName_no_prototype() {}
// Defects4J: flaky method
//     @Test
//     public void testGetPrototypeClassName_no_prototype() throws Exception {
//         Node qName = Node.newString(Token.GETPROP, "myObj.myProp");
//         assertNull(NodeUtil.getPrototypeClassName(qName));
//     }

    @Test
    public void testGetPrototypePropertyName_basic() {}
// Defects4J: flaky method
//     @Test
//     public void testGetPrototypePropertyName_basic() throws Exception {
//         Node qName = Node.newString(Token.GETPROP, "MyClass.prototype.myMethod");
//         assertEquals("myMethod", NodeUtil.getPrototypePropertyName(qName));
//     }

    @Test
    public void testGetPrototypePropertyName_complex_name() {}
// Defects4J: flaky method
//     @Test
//     public void testGetPrototypePropertyName_complex_name() throws Exception {
//         Node qName = Node.newString(Token.GETPROP, "a.b.c.prototype.d");
//         assertEquals("d", NodeUtil.getPrototypePropertyName(qName));
//     }

    @Test
    public void testGetPrototypePropertyName_no_prototype() {}
// Defects4J: flaky method
//     @Test
//     public void testGetPrototypePropertyName_no_prototype() throws Exception {
//         Node qName = Node.newString(Token.GETPROP, "myObj.myProp");
//         // The method logic needs to be checked. As per current code, it might return unexpected results for non-prototype names.
//         // For "myObj.myProp", `qNameStr.lastIndexOf(".prototype.")` is -1.
//         // `prototypeIdx + ".prototype".length() + 1` will be `0 + 10 + 1 = 11`.
//         // `qNameStr.substring(11)` on "myObj.myProp" is incorrect.
//         // Let's assume the intended behavior for non-prototype names is null or an exception.
//         // The current code might throw an index out of bounds exception or return garbage.
//         // Based on the reference source, `qNameStr.indexOf(".prototype.")` returns -1.
//         // Then `prototypeIdx + ".prototype".length() + 1` becomes `0 + 10 + 1 = 11`.
//         // `qNameStr.substring(11)` will throw StringIndexOutOfBoundsException.
//         // If the original bug was here, then this test is fine. If not, it might fail.
//         // Re-checking the source: `qNameStr.lastIndexOf(".prototype.")` is correct.
//         // If `lastIndexOf` returns -1, then `prototypeIdx` is -1.
//         // `prototypeIdx + ".prototype".length() + 1` becomes `-1 + 10 + 1 = 10`.
//         // `qNameStr.substring(10)` on "myObj.myProp" (length 10) will be an empty string.
//         assertEquals("", NodeUtil.getPrototypePropertyName(qName));
//     }


    @Test
    public void testNewUndefinedNode_with_reference() throws Exception {
        Node reference = Node.newString(Token.NAME, "ref");
        Node undefinedNode = NodeUtil.newUndefinedNode(reference);
        assertEquals(Token.VOID, undefinedNode.getType());
        assertEquals(0.0, ((Node)undefinedNode.getFirstChild()).getDouble(), 0.0); // Should be 0
        assertEquals(reference.getLineno(), undefinedNode.getLineno());
        assertEquals(reference.getCharno(), undefinedNode.getCharno());
    }

    @Test
    public void testNewUndefinedNode_without_reference() throws Exception {
        Node undefinedNode = NodeUtil.newUndefinedNode(null);
        assertEquals(Token.VOID, undefinedNode.getType());
        assertEquals(0.0, ((Node)undefinedNode.getFirstChild()).getDouble(), 0.0);
        assertEquals(-1, undefinedNode.getLineno()); // Default for no reference
        assertEquals(-1, undefinedNode.getCharno()); // Default for no reference
    }

    @Test
    public void testNewVarNode_with_value() throws Exception {
        Node value = Node.newNumber(10.0);
        Node varNode = NodeUtil.newVarNode("myVar", value);
        assertEquals(Token.VAR, varNode.getType());
        assertEquals(1, varNode.getChildCount());

        Node nameNode = varNode.getFirstChild();
        assertEquals(Token.NAME, nameNode.getType());
        assertEquals("myVar", nameNode.getString());
        assertEquals(1, nameNode.getChildCount());
        assertEquals(value, nameNode.getFirstChild());
        assertEquals(value.getLineno(), nameNode.getLineno());
    }

    @Test
    public void testNewVarNode_without_value() throws Exception {
        Node varNode = NodeUtil.newVarNode("myVar", null);
        assertEquals(Token.VAR, varNode.getType());
        assertEquals(1, varNode.getChildCount());

        Node nameNode = varNode.getFirstChild();
        assertEquals(Token.NAME, nameNode.getType());
        assertEquals("myVar", nameNode.getString());
        assertEquals(0, nameNode.getChildCount()); // No value child
    }




    @Test
    public void testMatchNodeType_true() throws Exception {
        NodeUtil.MatchNodeType matcher = new NodeUtil.MatchNodeType(Token.NAME);
        Node nameNode = Node.newString(Token.NAME, "test");
        assertTrue(matcher.apply(nameNode));
    }

    @Test
    public void testMatchNodeType_false_different_type() throws Exception {
        NodeUtil.MatchNodeType matcher = new NodeUtil.MatchNodeType(Token.NAME);
        Node numberNode = Node.newNumber(1.0);
        assertFalse(matcher.apply(numberNode));
    }

    @Test
    public void testMatchDeclaration_var() throws Exception {
        NodeUtil.MatchDeclaration matcher = new NodeUtil.MatchDeclaration();
        Node varNode = new Node(Token.VAR);
        assertTrue(matcher.apply(varNode));
    }

    @Test
    public void testMatchDeclaration_function_declaration() throws Exception {
        NodeUtil.MatchDeclaration matcher = new NodeUtil.MatchDeclaration();
        Node funcBody = new Node(Token.BLOCK);
        Node func = new Node(Token.FUNCTION, Node.newString(Token.NAME, "myFunc"), new Node(Token.LP), funcBody);
        Node script = new Node(Token.SCRIPT, func); // Function declaration
        assertTrue(matcher.apply(func));
    }

    @Test
    public void testMatchDeclaration_not_declaration() throws Exception {
        NodeUtil.MatchDeclaration matcher = new NodeUtil.MatchDeclaration();
        Node nameNode = Node.newString(Token.NAME, "var");
        assertFalse(matcher.apply(nameNode));
    }

    @Test
    public void testMatchNotFunction_true() throws Exception {
        NodeUtil.MatchNotFunction matcher = new NodeUtil.MatchNotFunction();
        Node nameNode = Node.newString(Token.NAME, "var");
        assertTrue(matcher.apply(nameNode));
    }

    @Test
    public void testMatchNotFunction_false() throws Exception {
        NodeUtil.MatchNotFunction matcher = new NodeUtil.MatchNotFunction();
        Node funcNode = new Node(Token.FUNCTION);
        assertFalse(matcher.apply(funcNode));
    }

    @Test
    public void testMatchShallowStatement_block() throws Exception {
        NodeUtil.MatchShallowStatement matcher = new NodeUtil.MatchShallowStatement();
        Node block = new Node(Token.BLOCK);
        assertTrue(matcher.apply(block));
    }

    @Test
    public void testMatchShallowStatement_control_structure_parent() throws Exception {
        NodeUtil.MatchShallowStatement matcher = new NodeUtil.MatchShallowStatement();
        Node ifBranch = new Node(Token.BLOCK);
        Node ifNode = new Node(Token.IF, Node.newString(Token.TRUE, ""), ifBranch);
        assertTrue(matcher.apply(ifBranch));
    }

    @Test
    public void testMatchShallowStatement_function_false() throws Exception {
        NodeUtil.MatchShallowStatement matcher = new NodeUtil.MatchShallowStatement();
        Node func = new Node(Token.FUNCTION);
        assertFalse(matcher.apply(func));
    }

    @Test
    public void testGetNodeTypeReferenceCount_found() {}
// Defects4J: flaky method
//     @Test
//     public void testGetNodeTypeReferenceCount_found() throws Exception {
//         Node name1 = Node.newString(Token.NAME, "x");
//         Node name2 = Node.newString(Token.NAME, "y");
//         Node block = new Node(Token.BLOCK, name1, name2);
//         assertEquals(2, NodeUtil.getNodeTypeReferenceCount(block, Token.NAME, Predicates.alwaysTrue()));
//     }

    @Test
    public void testGetNodeTypeReferenceCount_not_found() {}
// Defects4J: flaky method
//     @Test
//     public void testGetNodeTypeReferenceCount_not_found() throws Exception {
//         Node numberNode = Node.newNumber(1.0);
//         Node block = new Node(Token.BLOCK, numberNode);
//         assertEquals(0, NodeUtil.getNodeTypeReferenceCount(block, Token.NAME, Predicates.alwaysTrue()));
//     }

    @Test
    public void testIsNameReferenced_true() {}
// Defects4J: flaky method
//     @Test
//     public void testIsNameReferenced_true() throws Exception {
//         Node nameNode = Node.newString(Token.NAME, "targetName");
//         Node usageNode = Node.newString(Token.NAME, "targetName");
//         Node parent = new Node(Token.BLOCK, usageNode);
//         assertTrue(NodeUtil.isNameReferenced(parent, "targetName", Predicates.alwaysTrue()));
//     }

    @Test
    public void testIsNameReferenced_false() {}
// Defects4J: flaky method
//     @Test
//     public void testIsNameReferenced_false() throws Exception {
//         Node nameNode = Node.newString(Token.NAME, "targetName");
//         Node usageNode = Node.newString(Token.NAME, "otherName");
//         Node parent = new Node(Token.BLOCK, usageNode);
//         assertFalse(NodeUtil.isNameReferenced(parent, "targetName", Predicates.alwaysTrue()));
//     }

    @Test
    public void testIsNameReferenced_predicate_filtered() throws Exception {
        Node targetNameNode = Node.newString(Token.NAME, "targetName");
        Node func = new Node(Token.FUNCTION, targetNameNode);
        Node block = new Node(Token.BLOCK, func);
        // Predicate should prevent traversal into functions
        assertFalse(NodeUtil.isNameReferenced(block, "targetName", new NodeUtil.MatchNotFunction()));
    }

    @Test
    public void testIsNameReferenced_no_predicate() throws Exception {
        Node usageNode = Node.newString(Token.NAME, "targetName");
        Node parent = new Node(Token.BLOCK, usageNode);
        assertTrue(NodeUtil.isNameReferenced(parent, "targetName"));
    }

    @Test
    public void testGetNameReferenceCount_found() throws Exception {
        Node usage1 = Node.newString(Token.NAME, "targetName");
        Node usage2 = Node.newString(Token.NAME, "targetName");
        Node other = Node.newString(Token.NAME, "otherName");
        Node block = new Node(Token.BLOCK, usage1, usage2, other);
        assertEquals(2, NodeUtil.getNameReferenceCount(block, "targetName"));
    }

    @Test
    public void testGetNameReferenceCount_not_found() throws Exception {
        Node usage1 = Node.newString(Token.NAME, "otherName");
        Node block = new Node(Token.BLOCK, usage1);
        assertEquals(0, NodeUtil.getNameReferenceCount(block, "targetName"));
    }






    @Test
    public void testVisitPreOrder_basic() {}
// Defects4J: flaky method
//     @Test
//     public void testVisitPreOrder_basic() throws Exception {
//         Node root = new Node(Token.BLOCK, Node.newString(Token.NAME, "a"));
//         List<Node> visited = new java.util.ArrayList<>();
//         NodeUtil.Visitor visitor = visited::add;
//         NodeUtil.visitPreOrder(root, visitor, Predicates.alwaysTrue());
//         assertEquals(2, visited.size());
//         assertEquals(root, visited.get(0));
//         assertEquals("a", visited.get(1).getString());
//     }

    @Test
    public void testVisitPreOrder_predicate_filtered() {}
// Defects4J: flaky method
//     @Test
//     public void testVisitPreOrder_predicate_filtered() throws Exception {
//         Node targetNameNode = Node.newString(Token.NAME, "targetName");
//         Node func = new Node(Token.FUNCTION, targetNameNode);
//         Node block = new Node(Token.BLOCK, func);
//         List<Node> visited = new java.util.ArrayList<>();
//         NodeUtil.Visitor visitor = visited::add;
//         NodeUtil.visitPreOrder(block, visitor, new NodeUtil.MatchNotFunction()); // Don't traverse into functions
//         assertEquals(1, visited.size());
//         assertEquals(block, visited.get(0)); // Only the block itself is visited
//     }

    @Test
    public void testVisitPostOrder_basic() {}
// Defects4J: flaky method
//     @Test
//     public void testVisitPostOrder_basic() throws Exception {
//         Node child = Node.newString(Token.NAME, "a");
//         Node root = new Node(Token.BLOCK, child);
//         List<Node> visited = new java.util.ArrayList<>();
//         NodeUtil.Visitor visitor = visited::add;
//         NodeUtil.visitPostOrder(root, visitor, Predicates.alwaysTrue());
//         assertEquals(2, visited.size());
//         assertEquals("a", visited.get(0).getString());
//         assertEquals(root, visited.get(1));
//     }

    @Test
    public void testVisitPostOrder_predicate_filtered() {}
// Defects4J: flaky method
//     @Test
//     public void testVisitPostOrder_predicate_filtered() throws Exception {
//         Node targetNameNode = Node.newString(Token.NAME, "targetName");
//         Node func = new Node(Token.FUNCTION, targetNameNode);
//         Node block = new Node(Token.BLOCK, func);
//         List<Node> visited = new java.util.ArrayList<>();
//         NodeUtil.Visitor visitor = visited::add;
//         NodeUtil.visitPostOrder(block, visitor, new NodeUtil.MatchNotFunction()); // Don't traverse into functions
//         assertEquals(1, visited.size());
//         assertEquals(block, visited.get(0)); // Only the block itself is visited
//     }

    @Test
    public void testHasFinally_true() throws Exception {
        Node finallyBlock = new Node(Token.BLOCK);
        Node tryNode = new Node(Token.TRY, new Node(Token.BLOCK), new Node(Token.BLOCK), finallyBlock);
        assertTrue(NodeUtil.hasFinally(tryNode));
    }

    @Test
    public void testHasFinally_false_no_finally() throws Exception {
        Node tryNode = new Node(Token.TRY, new Node(Token.BLOCK), new Node(Token.BLOCK));
        assertFalse(NodeUtil.hasFinally(tryNode));
    }

    @Test
    public void testGetCatchBlock_found() {}
// Defects4J: flaky method
//     @Test
//     public void testGetCatchBlock_found() throws Exception {
//         Node catchBlock = new Node(Token.BLOCK);
//         Node catchNode = new Node(Token.CATCH, Node.newString(Token.NAME, "e"), catchBlock);
//         Node tryNode = new Node(Token.TRY, new Node(Token.BLOCK), catchNode);
//         assertEquals(catchBlock, NodeUtil.getCatchBlock(tryNode));
//     }

    @Test
    public void testGetCatchBlock_no_catch() throws Exception {
        Node tryNode = new Node(Token.TRY, new Node(Token.BLOCK));
        assertNull(NodeUtil.getCatchBlock(tryNode));
    }

    @Test
    public void testHasCatchHandler_true() {}
// Defects4J: flaky method
//     @Test
//     public void testHasCatchHandler_true() throws Exception {
//         Node catchBlock = new Node(Token.BLOCK);
//         Node catchNode = new Node(Token.CATCH, Node.newString(Token.NAME, "e"), catchBlock);
//         assertTrue(NodeUtil.hasCatchHandler(catchNode));
//     }

    @Test
    public void testHasCatchHandler_false_empty_block() throws Exception {
        Node catchBlock = new Node(Token.BLOCK);
        assertFalse(NodeUtil.hasCatchHandler(catchBlock));
    }

    @Test
    public void testGetFnParameters_basic() throws Exception {
        Node param1 = Node.newString(Token.NAME, "a");
        Node param2 = Node.newString(Token.NAME, "b");
        Node lp = new Node(Token.LP, param1, param2);
        Node func = new Node(Token.FUNCTION, Node.newString(Token.NAME, "f"), lp);
        assertEquals(lp, NodeUtil.getFnParameters(func));
    }

    @Test
    public void testGetFnParameters_no_params() throws Exception {
        Node lp = new Node(Token.LP);
        Node func = new Node(Token.FUNCTION, Node.newString(Token.NAME, "f"), lp);
        assertEquals(lp, NodeUtil.getFnParameters(func));
    }

    @Test
    public void testIsConstantName_true() throws Exception {
        Node nameNode = Node.newString(Token.NAME, "CONST_VAR");
        nameNode.putBooleanProp(Node.IS_CONSTANT_NAME, true);
        assertTrue(NodeUtil.isConstantName(nameNode));
    }

    @Test
    public void testIsConstantName_false() throws Exception {
        Node nameNode = Node.newString(Token.NAME, "var");
        assertFalse(NodeUtil.isConstantName(nameNode));
    }

    @Test
    public void testGetInfoForNameNode_no_info() throws Exception {
        Node nameNode = Node.newString(Token.NAME, "myVar");
        assertNull(NodeUtil.getInfoForNameNode(nameNode));
    }

    @Test
    public void testGetSourceName_direct() throws Exception {
        Node node = Node.newString(Token.NAME, "myVar");
        node.putProp(Node.SOURCENAME_PROP, "source.js");
        assertEquals("source.js", NodeUtil.getSourceName(node));
    }

    @Test
    public void testGetSourceName_ancestor() throws Exception {
        Node script = new Node(Token.SCRIPT);
        script.putProp(Node.SOURCENAME_PROP, "source.js");
        Node nameNode = Node.newString(Token.NAME, "myVar");
        script.addChildToBack(nameNode);
        assertEquals("source.js", NodeUtil.getSourceName(nameNode));
    }

    @Test
    public void testGetSourceName_no_source_name() throws Exception {
        Node node = Node.newString(Token.NAME, "myVar");
        assertNull(NodeUtil.getSourceName(node));
    }

    @Test
    public void testNewCallNode_free_call() throws Exception {
        Node callTarget = Node.newString(Token.NAME, "myFunc");
        Node param1 = Node.newString(Token.STRING, "arg1");
        Node param2 = Node.newNumber(1.0);

        Node callNode = NodeUtil.newCallNode(callTarget, param1, param2);

        assertEquals(Token.CALL, callNode.getType());
        assertTrue(callNode.getBooleanProp(Node.FREE_CALL));
        assertEquals(callTarget, callNode.getFirstChild());
        assertEquals(2, callNode.getChildCount() - 1); // -1 for the target itself
        assertEquals(param1, callNode.getChildAtIndex(1));
        assertEquals(param2, callNode.getChildAtIndex(2));
    }

    @Test
    public void testNewCallNode_not_free_call_getprop() throws Exception {
        Node obj = Node.newString(Token.NAME, "obj");
        Node methodName = Node.newString(Token.STRING, "method");
        Node getProp = new Node(Token.GETPROP, obj, methodName);
        Node param1 = Node.newString(Token.STRING, "arg1");

        Node callNode = NodeUtil.newCallNode(getProp, param1);

        assertEquals(Token.CALL, callNode.getType());
        assertFalse(callNode.getBooleanProp(Node.FREE_CALL));
        assertEquals(getProp, callNode.getFirstChild());
        assertEquals(1, callNode.getChildCount() - 1);
        assertEquals(param1, callNode.getChildAtIndex(1));
    }

    @Test
    public void testNewCallNode_no_parameters() throws Exception {
        Node callTarget = Node.newString(Token.NAME, "myFunc");
        Node callNode = NodeUtil.newCallNode(callTarget);

        assertEquals(Token.CALL, callNode.getType());
        assertTrue(callNode.getBooleanProp(Node.FREE_CALL));
        assertEquals(callTarget, callNode.getFirstChild());
        assertEquals(0, callNode.getChildCount() - 1);
    }

    @Test
    public void evaluatesToLocalValue_assign_immutable_child() throws Exception {
        Node immutableChild = Node.newString(Token.STRING, "hello");
        Node assign = new Node(Token.ASSIGN, Node.newString(Token.NAME, "x"), immutableChild);
        assertTrue(NodeUtil.evaluatesToLocalValue(assign));
    }

    @Test
    public void evaluatesToLocalValue_assign_local_child() throws Exception {
        Node localChild = Node.newString(Token.STRING, "hello"); // Assume this is local
        Node assign = new Node(Token.ASSIGN, Node.newString(Token.NAME, "x"), localChild);
        // The `locals` predicate is not used here, so it relies on default `evaluatesToLocalValue` for string.
        assertTrue(NodeUtil.evaluatesToLocalValue(assign));
    }

    @Test
    public void evaluatesToLocalValue_comma() throws Exception {
        Node rhs = Node.newString(Token.STRING, "hello");
        Node comma = new Node(Token.COMMA, Node.newString(Token.NAME, "x"), rhs);
        assertTrue(NodeUtil.evaluatesToLocalValue(comma));
    }

    @Test
    public void evaluatesToLocalValue_and_both_local() throws Exception {
        Node lhs = Node.newString(Token.STRING, "hello");
        Node rhs = Node.newNumber(1.0);
        Node and = new Node(Token.AND, lhs, rhs);
        assertTrue(NodeUtil.evaluatesToLocalValue(and));
    }

     @Test
    public void evaluatesToLocalValue_or_both_local() throws Exception {
        Node lhs = Node.newString(Token.STRING, "hello");
        Node rhs = Node.newNumber(1.0);
        Node or = new Node(Token.OR, lhs, rhs);
        assertTrue(NodeUtil.evaluatesToLocalValue(or));
    }

    @Test
    public void evaluatesToLocalValue_hook_both_local() throws Exception {
        Node cond = Node.newString(Token.STRING, "cond");
        Node trueBranch = Node.newString(Token.STRING, "trueVal");
        Node falseBranch = Node.newNumber(1.0);
        Node hook = new Node(Token.HOOK, cond, trueBranch, falseBranch);
        assertTrue(NodeUtil.evaluatesToLocalValue(hook));
    }

    @Test
    public void evaluatesToLocalValue_inc_decr_post() {}
// Defects4J: flaky method
//     @Test
//     public void evaluatesToLocalValue_inc_decr_post() throws Exception {
//         Node name = Node.newString(Token.NAME, "x");
//         Node inc = new Node(Token.INC, name);
//         inc.putBooleanProp(Node.INCRDECR_PROP, true); // Post-increment
//         assertTrue(NodeUtil.evaluatesToLocalValue(inc));
//     }

    @Test
    public void evaluatesToLocalValue_inc_decr_pre() throws Exception {
        Node name = Node.newString(Token.NAME, "x");
        Node inc = new Node(Token.INC, name);
        // Pre-increment, assumes local value after operation
        assertTrue(NodeUtil.evaluatesToLocalValue(inc));
    }

    @Test
    public void evaluatesToLocalValue_this_local() throws Exception {
        Node thisNode = new Node(Token.THIS);
        Predicate<Node> locals = Predicates.equalTo(thisNode);
        assertTrue(NodeUtil.evaluatesToLocalValue(thisNode, locals));
    }

    @Test
    public void evaluatesToLocalValue_this_not_local() throws Exception {
        Node thisNode = new Node(Token.THIS);
        Predicate<Node> locals = Predicates.alwaysFalse();
        assertFalse(NodeUtil.evaluatesToLocalValue(thisNode, locals));
    }

    @Test
    public void evaluatesToLocalValue_name_immutable() throws Exception {
        Node name = Node.newString(Token.NAME, "undefined");
        assertTrue(NodeUtil.evaluatesToLocalValue(name));
    }

    @Test
    public void evaluatesToLocalValue_name_local() throws Exception {
        Node name = Node.newString(Token.NAME, "myVar");
        Predicate<Node> locals = Predicates.equalTo(name);
        assertTrue(NodeUtil.evaluatesToLocalValue(name, locals));
    }

    @Test
    public void evaluatesToLocalValue_name_not_local() throws Exception {
        Node name = Node.newString(Token.NAME, "myVar");
        Predicate<Node> locals = Predicates.alwaysFalse();
        assertFalse(NodeUtil.evaluatesToLocalValue(name, locals));
    }

    @Test
    public void evaluatesToLocalValue_getelem_local() throws Exception {
        Node obj = Node.newString(Token.NAME, "obj");
        Node index = Node.newString(Token.STRING, "prop");
        Node getElem = new Node(Token.GETELEM, obj, index);
        Predicate<Node> locals = Predicates.equalTo(getElem);
        assertTrue(NodeUtil.evaluatesToLocalValue(getElem, locals));
    }

    @Test
    public void evaluatesToLocalValue_getelem_not_local() throws Exception {
        Node obj = Node.newString(Token.NAME, "obj");
        Node index = Node.newString(Token.STRING, "prop");
        Node getElem = new Node(Token.GETELEM, obj, index);
        Predicate<Node> locals = Predicates.alwaysFalse();
        assertFalse(NodeUtil.evaluatesToLocalValue(getElem, locals));
    }

    @Test
    public void evaluatesToLocalValue_getprop_local() throws Exception {
        Node obj = Node.newString(Token.NAME, "obj");
        Node prop = Node.newString(Token.STRING, "prop");
        Node getProp = new Node(Token.GETPROP, obj, prop);
        Predicate<Node> locals = Predicates.equalTo(getProp);
        assertTrue(NodeUtil.evaluatesToLocalValue(getProp, locals));
    }

    @Test
    public void evaluatesToLocalValue_getprop_not_local() throws Exception {
        Node obj = Node.newString(Token.NAME, "obj");
        Node prop = Node.newString(Token.STRING, "prop");
        Node getProp = new Node(Token.GETPROP, obj, prop);
        Predicate<Node> locals = Predicates.alwaysFalse();
        assertFalse(NodeUtil.evaluatesToLocalValue(getProp, locals));
    }

    @Test
    public void evaluatesToLocalValue_call_local_result() throws Exception {
        Node callNode = NodeUtil.newCallNode(Node.newString(Token.NAME, "myFunc"));
        callNode.putIntProp(Node.SIDE_EFFECT_FLAGS, Node.FLAG_LOCAL_RESULTS);
        assertTrue(NodeUtil.evaluatesToLocalValue(callNode));
    }

    @Test
    public void evaluatesToLocalValue_call_tostring() throws Exception {
        Node methodName = Node.newString(Token.STRING, "toString");
        Node objectName = Node.newString(Token.NAME, "obj");
        Node getProp = new Node(Token.GETPROP, objectName, methodName);
        Node callNode = new Node(Token.CALL, getProp);
        assertTrue(NodeUtil.evaluatesToLocalValue(callNode));
    }

    @Test
    public void evaluatesToLocalValue_call_local() throws Exception {
        Node callNode = NodeUtil.newCallNode(Node.newString(Token.NAME, "myFunc"));
        Predicate<Node> locals = Predicates.equalTo(callNode);
        assertTrue(NodeUtil.evaluatesToLocalValue(callNode, locals));
    }

     @Test
    public void evaluatesToLocalValue_call_not_local() throws Exception {
        Node callNode = NodeUtil.newCallNode(Node.newString(Token.NAME, "myFunc"));
        Predicate<Node> locals = Predicates.alwaysFalse();
        assertFalse(NodeUtil.evaluatesToLocalValue(callNode, locals));
    }

    @Test
    public void evaluatesToLocalValue_new_always_false() throws Exception {
        Node newNode = NodeUtil.newCallNode(Node.newString(Token.NAME, "MyClass"));
        assertFalse(NodeUtil.evaluatesToLocalValue(newNode));
    }

    @Test
    public void evaluatesToLocalValue_function_literal() throws Exception {
        Node func = new Node(Token.FUNCTION);
        assertTrue(NodeUtil.evaluatesToLocalValue(func));
    }

    @Test
    public void evaluatesToLocalValue_regexp_literal() throws Exception {
        Node regexp = new Node(Token.REGEXP);
        assertTrue(NodeUtil.evaluatesToLocalValue(regexp));
    }

    @Test
    public void evaluatesToLocalValue_arraylit() throws Exception {
        Node array = new Node(Token.ARRAYLIT);
        assertTrue(NodeUtil.evaluatesToLocalValue(array));
    }

    @Test
    public void evaluatesToLocalValue_objectlit() throws Exception {
        Node obj = new Node(Token.OBJECTLIT);
        assertTrue(NodeUtil.evaluatesToLocalValue(obj));
    }

    @Test
    public void evaluatesToLocalValue_in_operator() throws Exception {
        Node left = Node.newString(Token.NAME, "prop");
        Node right = Node.newString(Token.NAME, "obj");
        Node inOp = new Node(Token.IN, left, right);
        assertTrue(NodeUtil.evaluatesToLocalValue(inOp));
    }

    @Test
    public void evaluatesToLocalValue_simple_operator() throws Exception {
        Node left = Node.newNumber(1.0);
        Node right = Node.newNumber(2.0);
        Node addOp = new Node(Token.ADD, left, right);
        assertTrue(NodeUtil.evaluatesToLocalValue(addOp));
    }

    @Test
    public void evaluatesToLocalValue_assignment_op() throws Exception {
        Node name = Node.newString(Token.NAME, "x");
        Node assignOp = new Node(Token.ASSIGN_ADD, name, Node.newNumber(1.0));
        assertTrue(NodeUtil.evaluatesToLocalValue(assignOp));
    }

    @Test
    public void evaluatesToLocalValue_immutable_value() throws Exception {
        Node str = Node.newString(Token.STRING, "hello");
        assertTrue(NodeUtil.evaluatesToLocalValue(str));
    }

    @Test
    public void getArgumentForFunction_basic() throws Exception {
        Node param1 = Node.newString(Token.NAME, "a");
        Node param2 = Node.newString(Token.NAME, "b");
        Node lp = new Node(Token.LP, param1, param2);
        Node func = new Node(Token.FUNCTION, Node.newString(Token.NAME, "f"), lp);

        assertEquals(param1, NodeUtil.getArgumentForFunction(func, 0));
        assertEquals(param2, NodeUtil.getArgumentForFunction(func, 1));
    }

    @Test
    public void getArgumentForFunction_out_of_bounds() throws Exception {
        Node param1 = Node.newString(Token.NAME, "a");
        Node lp = new Node(Token.LP, param1);
        Node func = new Node(Token.FUNCTION, Node.newString(Token.NAME, "f"), lp);

        assertNull(NodeUtil.getArgumentForFunction(func, 1));
    }

    @Test
    public void getArgumentForCallOrNew_basic() throws Exception {
        Node arg1 = Node.newString(Token.STRING, "arg1");
        Node arg2 = Node.newNumber(1.0);
        Node call = NodeUtil.newCallNode(Node.newString(Token.NAME, "myFunc"), arg1, arg2);

        assertEquals(arg1, NodeUtil.getArgumentForCallOrNew(call, 0));
        assertEquals(arg2, NodeUtil.getArgumentForCallOrNew(call, 1));
    }

    @Test
    public void getArgumentForCallOrNew_out_of_bounds() throws Exception {
        Node arg1 = Node.newString(Token.STRING, "arg1");
        Node call = NodeUtil.newCallNode(Node.newString(Token.NAME, "myFunc"), arg1);

        assertNull(NodeUtil.getArgumentForCallOrNew(call, 1));
    }

}
