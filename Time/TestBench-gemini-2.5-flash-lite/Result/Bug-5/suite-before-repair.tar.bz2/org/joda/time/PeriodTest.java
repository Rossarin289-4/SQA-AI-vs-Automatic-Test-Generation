package org.joda.time;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.Serializable;
import org.joda.convert.FromString;
import org.joda.time.base.BasePeriod;
import org.joda.time.chrono.ISOChronology;
import org.joda.time.field.FieldUtils;
import org.joda.time.format.ISOPeriodFormat;
import org.joda.time.format.PeriodFormatter;

public class PeriodTest {
    // test methods (as many as the instructions ask for), each exactly in this form:
    //     @Test
    //     public void testWhatItChecks() throws Exception { ... }

    @Test
    public void testZeroPeriod() throws Exception {
        Period period = Period.ZERO;
        assertNotNull(period);
        assertEquals(0, period.getYears());
        assertEquals(0, period.getMonths());
        assertEquals(0, period.getWeeks());
        assertEquals(0, period.getDays());
        assertEquals(0, period.getHours());
        assertEquals(0, period.getMinutes());
        assertEquals(0, period.getSeconds());
        assertEquals(0, period.getMillis());
    }

    @Test
    public void testParseStandard() throws Exception {
        Period period = Period.parse("P1Y2M3W4DT5H6M7S8MS");
        assertEquals(1, period.getYears());
        assertEquals(2, period.getMonths());
        assertEquals(3, period.getWeeks());
        assertEquals(4, period.getDays());
        assertEquals(5, period.getHours());
        assertEquals(6, period.getMinutes());
        assertEquals(7, period.getSeconds());
        assertEquals(8, period.getMillis());
    }
    
    @Test
    public void testParseWithFormatter() throws Exception {
        PeriodFormatter formatter = ISOPeriodFormat.standard();
        Period period = Period.parse("P1Y2M3W4DT5H6M7S8MS", formatter);
        assertEquals(1, period.getYears());
        assertEquals(2, period.getMonths());
        assertEquals(3, period.getWeeks());
        assertEquals(4, period.getDays());
        assertEquals(5, period.getHours());
        assertEquals(6, period.getMinutes());
        assertEquals(7, period.getSeconds());
        assertEquals(8, period.getMillis());
    }

    @Test
    public void testYearsFactory() throws Exception {
        Period period = Period.years(5);
        assertEquals(5, period.getYears());
        assertEquals(0, period.getMonths());
        assertEquals(0, period.getWeeks());
        assertEquals(0, period.getDays());
        assertEquals(0, period.getHours());
        assertEquals(0, period.getMinutes());
        assertEquals(0, period.getSeconds());
        assertEquals(0, period.getMillis());
    }

    @Test
    public void testMonthsFactory() throws Exception {
        Period period = Period.months(10);
        assertEquals(0, period.getYears());
        assertEquals(10, period.getMonths());
        assertEquals(0, period.getWeeks());
        assertEquals(0, period.getDays());
        assertEquals(0, period.getHours());
        assertEquals(0, period.getMinutes());
        assertEquals(0, period.getSeconds());
        assertEquals(0, period.getMillis());
    }

    @Test
    public void testWeeksFactory() throws Exception {
        Period period = Period.weeks(2);
        assertEquals(0, period.getYears());
        assertEquals(0, period.getMonths());
        assertEquals(2, period.getWeeks());
        assertEquals(0, period.getDays());
        assertEquals(0, period.getHours());
        assertEquals(0, period.getMinutes());
        assertEquals(0, period.getSeconds());
        assertEquals(0, period.getMillis());
    }

    @Test
    public void testDaysFactory() throws Exception {
        Period period = Period.days(15);
        assertEquals(0, period.getYears());
        assertEquals(0, period.getMonths());
        assertEquals(0, period.getWeeks());
        assertEquals(15, period.getDays());
        assertEquals(0, period.getHours());
        assertEquals(0, period.getMinutes());
        assertEquals(0, period.getSeconds());
        assertEquals(0, period.getMillis());
    }

    @Test
    public void testHoursFactory() throws Exception {
        Period period = Period.hours(7);
        assertEquals(0, period.getYears());
        assertEquals(0, period.getMonths());
        assertEquals(0, period.getWeeks());
        assertEquals(0, period.getDays());
        assertEquals(7, period.getHours());
        assertEquals(0, period.getMinutes());
        assertEquals(0, period.getSeconds());
        assertEquals(0, period.getMillis());
    }

    @Test
    public void testMinutesFactory() throws Exception {
        Period period = Period.minutes(45);
        assertEquals(0, period.getYears());
        assertEquals(0, period.getMonths());
        assertEquals(0, period.getWeeks());
        assertEquals(0, period.getDays());
        assertEquals(0, period.getHours());
        assertEquals(45, period.getMinutes());
        assertEquals(0, period.getSeconds());
        assertEquals(0, period.getMillis());
    }

    @Test
    public void testSecondsFactory() throws Exception {
        Period period = Period.seconds(30);
        assertEquals(0, period.getYears());
        assertEquals(0, period.getMonths());
        assertEquals(0, period.getWeeks());
        assertEquals(0, period.getDays());
        assertEquals(0, period.getHours());
        assertEquals(0, period.getMinutes());
        assertEquals(30, period.getSeconds());
        assertEquals(0, period.getMillis());
    }

    @Test
    public void testMillisFactory() throws Exception {
        Period period = Period.millis(500);
        assertEquals(0, period.getYears());
        assertEquals(0, period.getMonths());
        assertEquals(0, period.getWeeks());
        assertEquals(0, period.getDays());
        assertEquals(0, period.getHours());
        assertEquals(0, period.getMinutes());
        assertEquals(0, period.getSeconds());
        assertEquals(500, period.getMillis());
    }
    
    @Test
    public void testConstructorWithYearsMonthsWeeksDaysHoursMinutesSecondsMillis() throws Exception {
        Period period = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        assertEquals(1, period.getYears());
        assertEquals(2, period.getMonths());
        assertEquals(3, period.getWeeks());
        assertEquals(4, period.getDays());
        assertEquals(5, period.getHours());
        assertEquals(6, period.getMinutes());
        assertEquals(7, period.getSeconds());
        assertEquals(8, period.getMillis());
    }

    @Test
    public void testConstructorWithHoursMinutesSecondsMillis() throws Exception {
        Period period = new Period(5, 6, 7, 8);
        assertEquals(0, period.getYears());
        assertEquals(0, period.getMonths());
        assertEquals(0, period.getWeeks());
        assertEquals(0, period.getDays());
        assertEquals(5, period.getHours());
        assertEquals(6, period.getMinutes());
        assertEquals(7, period.getSeconds());
        assertEquals(8, period.getMillis());
    }
    
    @Test
    public void testConstructorWithDurationMillis() throws Exception {
        // 1 year = 365 days * 24 hours/day = 8760 hours
        // 1 month = 30 days * 24 hours/day = 720 hours (approx, for simplicity in test)
        // Using a duration that is roughly one year and a bit
        long durationMillis = (365L * DateTimeConstants.MILLIS_PER_DAY) + (10L * DateTimeConstants.MILLIS_PER_HOUR);
        Period period = new Period(durationMillis);
        // The constructor with only duration splits into precise fields (time fields)
        // 365 days * 24 hours/day = 8760 hours
        // 10 hours
        // Total = 8770 hours
        assertEquals(0, period.getYears());
        assertEquals(0, period.getMonths());
        assertEquals(0, period.getWeeks());
        assertEquals(0, period.getDays());
        assertEquals(8770, period.getHours()); // 8760 + 10
        assertEquals(0, period.getMinutes());
        assertEquals(0, period.getSeconds());
        assertEquals(0, period.getMillis());
    }

    @Test
    public void testConstructorWithDurationAndType() throws Exception {
        long durationMillis = 10 * DateTimeConstants.MILLIS_PER_HOUR + 30 * DateTimeConstants.MILLIS_PER_MINUTE; // 10 hours 30 minutes
        Period period = new Period(durationMillis, PeriodType.time());
        assertEquals(0, period.getYears());
        assertEquals(0, period.getMonths());
        assertEquals(0, period.getWeeks());
        assertEquals(0, period.getDays());
        assertEquals(10, period.getHours());
        assertEquals(30, period.getMinutes());
        assertEquals(0, period.getSeconds());
        assertEquals(0, period.getMillis());
    }

    @Test
    public void testConstructorWithStartAndEndMillis() throws Exception {
        long startMillis = 1000000000000L; // Arbitrary start
        long endMillis = startMillis + 2 * DateTimeConstants.MILLIS_PER_DAY + 3 * DateTimeConstants.MILLIS_PER_HOUR; // 2 days and 3 hours
        Period period = new Period(startMillis, endMillis);
        assertEquals(0, period.getYears());
        assertEquals(0, period.getMonths());
        assertEquals(0, period.getWeeks());
        assertEquals(2, period.getDays());
        assertEquals(3, period.getHours());
        assertEquals(0, period.getMinutes());
        assertEquals(0, period.getSeconds());
        assertEquals(0, period.getMillis());
    }
    
    @Test
    public void testConstructorWithStartAndEndDate() throws Exception {
        java.util.Date startDate = new java.util.Date(1000000000000L); // Arbitrary start
        java.util.Date endDate = new java.util.Date(1000000000000L + 10 * DateTimeConstants.MILLIS_PER_HOUR); // 10 hours later
        Period period = new Period(startDate.getTime(), endDate.getTime());
        assertEquals(0, period.getYears());
        assertEquals(0, period.getMonths());
        assertEquals(0, period.getWeeks());
        assertEquals(0, period.getDays());
        assertEquals(10, period.getHours());
        assertEquals(0, period.getMinutes());
        assertEquals(0, period.getSeconds());
        assertEquals(0, period.getMillis());
    }

    @Test
    public void testGetYears() throws Exception {
        Period period = new Period(5, 0, 0, 0, 0, 0, 0, 0);
        assertEquals(5, period.getYears());
    }

    @Test
    public void testGetMonths() throws Exception {
        Period period = new Period(0, 6, 0, 0, 0, 0, 0, 0);
        assertEquals(6, period.getMonths());
    }

    @Test
    public void testGetWeeks() throws Exception {
        Period period = new Period(0, 0, 3, 0, 0, 0, 0, 0);
        assertEquals(3, period.getWeeks());
    }

    @Test
    public void testGetDays() throws Exception {
        Period period = new Period(0, 0, 0, 7, 0, 0, 0, 0);
        assertEquals(7, period.getDays());
    }

    @Test
    public void testGetHours() throws Exception {
        Period period = new Period(0, 0, 0, 0, 12, 0, 0, 0);
        assertEquals(12, period.getHours());
    }

    @Test
    public void testGetMinutes() throws Exception {
        Period period = new Period(0, 0, 0, 0, 0, 50, 0, 0);
        assertEquals(50, period.getMinutes());
    }

    @Test
    public void testGetSeconds() throws Exception {
        Period period = new Period(0, 0, 0, 0, 0, 0, 25, 0);
        assertEquals(25, period.getSeconds());
    }

    @Test
    public void testGetMillis() throws Exception {
        Period period = new Period(0, 0, 0, 0, 0, 0, 0, 750);
        assertEquals(750, period.getMillis());
    }

    @Test
    public void testWithPeriodTypeStandard() throws Exception {
        Period period = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        Period newPeriod = period.withPeriodType(PeriodType.standard());
        assertSame(period, newPeriod); // Should be the same instance as type is standard
    }

    @Test
    public void testWithPeriodTypeTime() throws Exception {
        Period period = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        PeriodType timeType = PeriodType.time();
        Period newPeriod = period.withPeriodType(timeType);
        assertEquals(1, newPeriod.getYears()); // Default for unsupported fields is 0
        assertEquals(2, newPeriod.getMonths());
        assertEquals(3, newPeriod.getWeeks());
        assertEquals(4, newPeriod.getDays());
        assertEquals(5, newPeriod.getHours());
        assertEquals(6, newPeriod.getMinutes());
        assertEquals(7, newPeriod.getSeconds());
        assertEquals(8, newPeriod.getMillis());
        assertEquals(timeType, newPeriod.getPeriodType());
    }

    @Test
    public void testWithFields() throws Exception {
        Period period = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        Period fieldsToAdd = new Period(0, 0, 0, 0, 1, 1, 1, 1);
        Period newPeriod = period.withFields(fieldsToAdd);
        assertEquals(1, newPeriod.getYears());
        assertEquals(2, newPeriod.getMonths());
        assertEquals(3, newPeriod.getWeeks());
        assertEquals(4, newPeriod.getDays());
        assertEquals(6, newPeriod.getHours()); // 5 + 1
        assertEquals(7, newPeriod.getMinutes()); // 6 + 1
        assertEquals(8, newPeriod.getSeconds()); // 7 + 1
        assertEquals(9, newPeriod.getMillis()); // 8 + 1
    }

    @Test
    public void testWithFieldYears() throws Exception {
        Period period = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        Period newPeriod = period.withField(DurationFieldType.years(), 10);
        assertEquals(10, newPeriod.getYears());
        assertEquals(2, newPeriod.getMonths());
        assertEquals(3, newPeriod.getWeeks());
        assertEquals(4, newPeriod.getDays());
        assertEquals(5, newPeriod.getHours());
        assertEquals(6, newPeriod.getMinutes());
        assertEquals(7, newPeriod.getSeconds());
        assertEquals(8, newPeriod.getMillis());
    }

    @Test
    public void testWithFieldAddedYears() throws Exception {
        Period period = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        Period newPeriod = period.withFieldAdded(DurationFieldType.years(), 5);
        assertEquals(6, newPeriod.getYears()); // 1 + 5
        assertEquals(2, newPeriod.getMonths());
        assertEquals(3, newPeriod.getWeeks());
        assertEquals(4, newPeriod.getDays());
        assertEquals(5, newPeriod.getHours());
        assertEquals(6, newPeriod.getMinutes());
        assertEquals(7, newPeriod.getSeconds());
        assertEquals(8, newPeriod.getMillis());
    }
    
    @Test
    public void testWithYears() throws Exception {
        Period period = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        Period newPeriod = period.withYears(10);
        assertEquals(10, newPeriod.getYears());
        assertEquals(2, newPeriod.getMonths());
        assertEquals(3, newPeriod.getWeeks());
        assertEquals(4, newPeriod.getDays());
        assertEquals(5, newPeriod.getHours());
        assertEquals(6, newPeriod.getMinutes());
        assertEquals(7, newPeriod.getSeconds());
        assertEquals(8, newPeriod.getMillis());
    }

    @Test
    public void testWithMonths() throws Exception {
        Period period = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        Period newPeriod = period.withMonths(10);
        assertEquals(1, newPeriod.getYears());
        assertEquals(10, newPeriod.getMonths());
        assertEquals(3, newPeriod.getWeeks());
        assertEquals(4, newPeriod.getDays());
        assertEquals(5, newPeriod.getHours());
        assertEquals(6, newPeriod.getMinutes());
        assertEquals(7, newPeriod.getSeconds());
        assertEquals(8, newPeriod.getMillis());
    }

    @Test
    public void testWithWeeks() throws Exception {
        Period period = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        Period newPeriod = period.withWeeks(10);
        assertEquals(1, newPeriod.getYears());
        assertEquals(2, newPeriod.getMonths());
        assertEquals(10, newPeriod.getWeeks());
        assertEquals(4, newPeriod.getDays());
        assertEquals(5, newPeriod.getHours());
        assertEquals(6, newPeriod.getMinutes());
        assertEquals(7, newPeriod.getSeconds());
        assertEquals(8, newPeriod.getMillis());
    }

    @Test
    public void testWithDays() throws Exception {
        Period period = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        Period newPeriod = period.withDays(10);
        assertEquals(1, newPeriod.getYears());
        assertEquals(2, newPeriod.getMonths());
        assertEquals(3, newPeriod.getWeeks());
        assertEquals(10, newPeriod.getDays());
        assertEquals(5, newPeriod.getHours());
        assertEquals(6, newPeriod.getMinutes());
        assertEquals(7, newPeriod.getSeconds());
        assertEquals(8, newPeriod.getMillis());
    }
    
    @Test
    public void testWithHours() throws Exception {
        Period period = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        Period newPeriod = period.withHours(10);
        assertEquals(1, newPeriod.getYears());
        assertEquals(2, newPeriod.getMonths());
        assertEquals(3, newPeriod.getWeeks());
        assertEquals(4, newPeriod.getDays());
        assertEquals(10, newPeriod.getHours());
        assertEquals(6, newPeriod.getMinutes());
        assertEquals(7, newPeriod.getSeconds());
        assertEquals(8, newPeriod.getMillis());
    }

    @Test
    public void testWithMinutes() throws Exception {
        Period period = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        Period newPeriod = period.withMinutes(10);
        assertEquals(1, newPeriod.getYears());
        assertEquals(2, newPeriod.getMonths());
        assertEquals(3, newPeriod.getWeeks());
        assertEquals(4, newPeriod.getDays());
        assertEquals(5, newPeriod.getHours());
        assertEquals(10, newPeriod.getMinutes());
        assertEquals(7, newPeriod.getSeconds());
        assertEquals(8, newPeriod.getMillis());
    }

    @Test
    public void testWithSeconds() throws Exception {
        Period period = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        Period newPeriod = period.withSeconds(10);
        assertEquals(1, newPeriod.getYears());
        assertEquals(2, newPeriod.getMonths());
        assertEquals(3, newPeriod.getWeeks());
        assertEquals(4, newPeriod.getDays());
        assertEquals(5, newPeriod.getHours());
        assertEquals(6, newPeriod.getMinutes());
        assertEquals(10, newPeriod.getSeconds());
        assertEquals(8, newPeriod.getMillis());
    }

    @Test
    public void testWithMillis() throws Exception {
        Period period = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        Period newPeriod = period.withMillis(10);
        assertEquals(1, newPeriod.getYears());
        assertEquals(2, newPeriod.getMonths());
        assertEquals(3, newPeriod.getWeeks());
        assertEquals(4, newPeriod.getDays());
        assertEquals(5, newPeriod.getHours());
        assertEquals(6, newPeriod.getMinutes());
        assertEquals(7, newPeriod.getSeconds());
        assertEquals(10, newPeriod.getMillis());
    }

    @Test
    public void testPlusPeriod() throws Exception {
        Period period1 = new Period(1, 1, 1, 1, 1, 1, 1, 1);
        Period period2 = new Period(1, 1, 1, 1, 1, 1, 1, 1);
        Period result = period1.plus(period2);
        assertEquals(2, result.getYears());
        assertEquals(2, result.getMonths());
        assertEquals(2, result.getWeeks());
        assertEquals(2, result.getDays());
        assertEquals(2, result.getHours());
        assertEquals(2, result.getMinutes());
        assertEquals(2, result.getSeconds());
        assertEquals(2, result.getMillis());
    }

    @Test
    public void testPlusYears() throws Exception {
        Period period = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        Period newPeriod = period.plusYears(5);
        assertEquals(6, newPeriod.getYears()); // 1 + 5
        assertEquals(2, newPeriod.getMonths());
        assertEquals(3, newPeriod.getWeeks());
        assertEquals(4, newPeriod.getDays());
        assertEquals(5, newPeriod.getHours());
        assertEquals(6, newPeriod.getMinutes());
        assertEquals(7, newPeriod.getSeconds());
        assertEquals(8, newPeriod.getMillis());
    }

    @Test
    public void testPlusMonths() throws Exception {
        Period period = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        Period newPeriod = period.plusMonths(5);
        assertEquals(1, newPeriod.getYears());
        assertEquals(7, newPeriod.getMonths()); // 2 + 5
        assertEquals(3, newPeriod.getWeeks());
        assertEquals(4, newPeriod.getDays());
        assertEquals(5, newPeriod.getHours());
        assertEquals(6, newPeriod.getMinutes());
        assertEquals(7, newPeriod.getSeconds());
        assertEquals(8, newPeriod.getMillis());
    }

    @Test
    public void testPlusWeeks() throws Exception {
        Period period = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        Period newPeriod = period.plusWeeks(5);
        assertEquals(1, newPeriod.getYears());
        assertEquals(2, newPeriod.getMonths());
        assertEquals(8, newPeriod.getWeeks()); // 3 + 5
        assertEquals(4, newPeriod.getDays());
        assertEquals(5, newPeriod.getHours());
        assertEquals(6, newPeriod.getMinutes());
        assertEquals(7, newPeriod.getSeconds());
        assertEquals(8, newPeriod.getMillis());
    }

    @Test
    public void testPlusDays() throws Exception {
        Period period = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        Period newPeriod = period.plusDays(5);
        assertEquals(1, newPeriod.getYears());
        assertEquals(2, newPeriod.getMonths());
        assertEquals(3, newPeriod.getWeeks());
        assertEquals(9, newPeriod.getDays()); // 4 + 5
        assertEquals(5, newPeriod.getHours());
        assertEquals(6, newPeriod.getMinutes());
        assertEquals(7, newPeriod.getSeconds());
        assertEquals(8, newPeriod.getMillis());
    }

    @Test
    public void testPlusHours() throws Exception {
        Period period = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        Period newPeriod = period.plusHours(5);
        assertEquals(1, newPeriod.getYears());
        assertEquals(2, newPeriod.getMonths());
        assertEquals(3, newPeriod.getWeeks());
        assertEquals(4, newPeriod.getDays());
        assertEquals(10, newPeriod.getHours()); // 5 + 5
        assertEquals(6, newPeriod.getMinutes());
        assertEquals(7, newPeriod.getSeconds());
        assertEquals(8, newPeriod.getMillis());
    }

    @Test
    public void testPlusMinutes() throws Exception {
        Period period = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        Period newPeriod = period.plusMinutes(5);
        assertEquals(1, newPeriod.getYears());
        assertEquals(2, newPeriod.getMonths());
        assertEquals(3, newPeriod.getWeeks());
        assertEquals(4, newPeriod.getDays());
        assertEquals(5, newPeriod.getHours());
        assertEquals(11, newPeriod.getMinutes()); // 6 + 5
        assertEquals(7, newPeriod.getSeconds());
        assertEquals(8, newPeriod.getMillis());
    }

    @Test
    public void testPlusSeconds() throws Exception {
        Period period = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        Period newPeriod = period.plusSeconds(5);
        assertEquals(1, newPeriod.getYears());
        assertEquals(2, newPeriod.getMonths());
        assertEquals(3, newPeriod.getWeeks());
        assertEquals(4, newPeriod.getDays());
        assertEquals(5, newPeriod.getHours());
        assertEquals(6, newPeriod.getMinutes());
        assertEquals(12, newPeriod.getSeconds()); // 7 + 5
        assertEquals(8, newPeriod.getMillis());
    }

    @Test
    public void testPlusMillis() throws Exception {
        Period period = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        Period newPeriod = period.plusMillis(5);
        assertEquals(1, newPeriod.getYears());
        assertEquals(2, newPeriod.getMonths());
        assertEquals(3, newPeriod.getWeeks());
        assertEquals(4, newPeriod.getDays());
        assertEquals(5, newPeriod.getHours());
        assertEquals(6, newPeriod.getMinutes());
        assertEquals(7, newPeriod.getSeconds());
        assertEquals(13, newPeriod.getMillis()); // 8 + 5
    }

    @Test
    public void testMinusPeriod() throws Exception {
        Period period1 = new Period(5, 5, 5, 5, 5, 5, 5, 5);
        Period period2 = new Period(1, 1, 1, 1, 1, 1, 1, 1);
        Period result = period1.minus(period2);
        assertEquals(4, result.getYears());
        assertEquals(4, result.getMonths());
        assertEquals(4, result.getWeeks());
        assertEquals(4, result.getDays());
        assertEquals(4, result.getHours());
        assertEquals(4, result.getMinutes());
        assertEquals(4, result.getSeconds());
        assertEquals(4, result.getMillis());
    }

    @Test
    public void testMinusYears() throws Exception {
        Period period = new Period(10, 2, 3, 4, 5, 6, 7, 8);
        Period newPeriod = period.minusYears(5);
        assertEquals(5, newPeriod.getYears()); // 10 - 5
        assertEquals(2, newPeriod.getMonths());
        assertEquals(3, newPeriod.getWeeks());
        assertEquals(4, newPeriod.getDays());
        assertEquals(5, newPeriod.getHours());
        assertEquals(6, newPeriod.getMinutes());
        assertEquals(7, newPeriod.getSeconds());
        assertEquals(8, newPeriod.getMillis());
    }

    @Test
    public void testMinusMonths() throws Exception {
        Period period = new Period(1, 10, 3, 4, 5, 6, 7, 8);
        Period newPeriod = period.minusMonths(5);
        assertEquals(1, newPeriod.getYears());
        assertEquals(5, newPeriod.getMonths()); // 10 - 5
        assertEquals(3, newPeriod.getWeeks());
        assertEquals(4, newPeriod.getDays());
        assertEquals(5, newPeriod.getHours());
        assertEquals(6, newPeriod.getMinutes());
        assertEquals(7, newPeriod.getSeconds());
        assertEquals(8, newPeriod.getMillis());
    }

    @Test
    public void testMinusWeeks() throws Exception {
        Period period = new Period(1, 2, 10, 4, 5, 6, 7, 8);
        Period newPeriod = period.minusWeeks(5);
        assertEquals(1, newPeriod.getYears());
        assertEquals(2, newPeriod.getMonths());
        assertEquals(5, newPeriod.getWeeks()); // 10 - 5
        assertEquals(4, newPeriod.getDays());
        assertEquals(5, newPeriod.getHours());
        assertEquals(6, newPeriod.getMinutes());
        assertEquals(7, newPeriod.getSeconds());
        assertEquals(8, newPeriod.getMillis());
    }

    @Test
    public void testMinusDays() throws Exception {
        Period period = new Period(1, 2, 3, 10, 5, 6, 7, 8);
        Period newPeriod = period.minusDays(5);
        assertEquals(1, newPeriod.getYears());
        assertEquals(2, newPeriod.getMonths());
        assertEquals(3, newPeriod.getWeeks());
        assertEquals(5, newPeriod.getDays()); // 10 - 5
        assertEquals(5, newPeriod.getHours());
        assertEquals(6, newPeriod.getMinutes());
        assertEquals(7, newPeriod.getSeconds());
        assertEquals(8, newPeriod.getMillis());
    }

    @Test
    public void testMinusHours() throws Exception {
        Period period = new Period(1, 2, 3, 4, 10, 6, 7, 8);
        Period newPeriod = period.minusHours(5);
        assertEquals(1, newPeriod.getYears());
        assertEquals(2, newPeriod.getMonths());
        assertEquals(3, newPeriod.getWeeks());
        assertEquals(4, newPeriod.getDays());
        assertEquals(5, newPeriod.getHours()); // 10 - 5
        assertEquals(6, newPeriod.getMinutes());
        assertEquals(7, newPeriod.getSeconds());
        assertEquals(8, newPeriod.getMillis());
    }

    @Test
    public void testMinusMinutes() throws Exception {
        Period period = new Period(1, 2, 3, 4, 5, 10, 7, 8);
        Period newPeriod = period.minusMinutes(5);
        assertEquals(1, newPeriod.getYears());
        assertEquals(2, newPeriod.getMonths());
        assertEquals(3, newPeriod.getWeeks());
        assertEquals(4, newPeriod.getDays());
        assertEquals(5, newPeriod.getHours());
        assertEquals(5, newPeriod.getMinutes()); // 10 - 5
        assertEquals(7, newPeriod.getSeconds());
        assertEquals(8, newPeriod.getMillis());
    }

    @Test
    public void testMinusSeconds() throws Exception {
        Period period = new Period(1, 2, 3, 4, 5, 6, 10, 8);
        Period newPeriod = period.minusSeconds(5);
        assertEquals(1, newPeriod.getYears());
        assertEquals(2, newPeriod.getMonths());
        assertEquals(3, newPeriod.getWeeks());
        assertEquals(4, newPeriod.getDays());
        assertEquals(5, newPeriod.getHours());
        assertEquals(6, newPeriod.getMinutes());
        assertEquals(5, newPeriod.getSeconds()); // 10 - 5
        assertEquals(8, newPeriod.getMillis());
    }

    @Test
    public void testMinusMillis() throws Exception {
        Period period = new Period(1, 2, 3, 4, 5, 6, 7, 10);
        Period newPeriod = period.minusMillis(5);
        assertEquals(1, newPeriod.getYears());
        assertEquals(2, newPeriod.getMonths());
        assertEquals(3, newPeriod.getWeeks());
        assertEquals(4, newPeriod.getDays());
        assertEquals(5, newPeriod.getHours());
        assertEquals(6, newPeriod.getMinutes());
        assertEquals(7, newPeriod.getSeconds());
        assertEquals(5, newPeriod.getMillis()); // 10 - 5
    }

    @Test
    public void testMultipliedBy() throws Exception {
        Period period = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        Period multiplied = period.multipliedBy(3);
        assertEquals(3, multiplied.getYears());
        assertEquals(6, multiplied.getMonths());
        assertEquals(9, multiplied.getWeeks());
        assertEquals(12, multiplied.getDays());
        assertEquals(15, multiplied.getHours());
        assertEquals(18, multiplied.getMinutes());
        assertEquals(21, multiplied.getSeconds());
        assertEquals(24, multiplied.getMillis());
    }

    @Test
    public void testNegated() throws Exception {
        Period period = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        Period negated = period.negated();
        assertEquals(-1, negated.getYears());
        assertEquals(-2, negated.getMonths());
        assertEquals(-3, negated.getWeeks());
        assertEquals(-4, negated.getDays());
        assertEquals(-5, negated.getHours());
        assertEquals(-6, negated.getMinutes());
        assertEquals(-7, negated.getSeconds());
        assertEquals(-8, negated.getMillis());
    }

    @Test
    public void testToStandardWeeks() throws Exception {
        Period period = new Period(0, 0, 2, 3, 4, 5, 6, 7); // 2 weeks, 3 days, 4 hours, 5 minutes, 6 seconds, 7 millis
        // 2 weeks * 7 days/week = 14 days
        // Total days = 14 + 3 = 17 days
        // 17 days * 24 hours/day = 408 hours
        // 4 hours
        // Total hours = 408 + 4 = 412 hours
        // 412 hours * 60 minutes/hour = 24720 minutes
        // 5 minutes
        // Total minutes = 24720 + 5 = 24725 minutes
        // 24725 minutes * 60 seconds/minute = 1483500 seconds
        // 6 seconds
        // Total seconds = 1483500 + 6 = 1483506 seconds
        // 1483506 seconds * 1000 ms/second = 1483506000 ms
        // 7 millis
        // Total millis = 1483506007 ms
        // Total weeks = 1483506007 ms / (7 * 24 * 60 * 60 * 1000) ms/week = 1483506007 / 604800000 ~= 2.45
        // The method returns Weeks.weeks(fieldValue), and here it is the weeks field + milliseconds converted to weeks.
        // So it's 2 weeks + (3 days, 4 hours, 5 mins, 6 secs, 7 millis) converted to weeks.
        // 3 days = 3*24*60*60*1000 ms = 259,200,000 ms
        // 4 hours = 4*60*60*1000 ms = 14,400,000 ms
        // 5 minutes = 5*60*1000 ms = 300,000 ms
        // 6 seconds = 6*1000 ms = 6,000 ms
        // 7 millis = 7 ms
        // Total millis = 259200000 + 14400000 + 300000 + 6000 + 7 = 273,906,007 ms
        // Total weeks from this duration = 273906007 / 604800000 ~= 0.45
        // So total weeks = 2 + 0.45 = 2.45.
        // The toStandardWeeks() method is designed to sum up all fields into a total number of weeks.
        // 2 weeks + 3 days + 4 hours + 5 mins + 6 secs + 7 millis
        // = 2 weeks + (3 * 24 + 4) hours + 5 mins + 6 secs + 7 millis
        // = 2 weeks + 76 hours + 5 mins + 6 secs + 7 millis
        // = 2 weeks + (76*60 + 5) mins + 6 secs + 7 millis
        // = 2 weeks + 4565 mins + 6 secs + 7 millis
        // = 2 weeks + (4565*60 + 6) secs + 7 millis
        // = 2 weeks + 273906 secs + 7 millis
        // = 2 weeks + (273906 * 1000 + 7) ms
        // = 2 weeks + 273906007 ms
        // Convert millis to weeks: 273906007 / (7 * 24 * 60 * 60 * 1000) = 273906007 / 604800000 = 0.4529...
        // Total weeks = 2 + 0.4529... = 2.4529...
        // safeToInt will truncate.
        assertEquals(2, period.toStandardWeeks().getWeeks());
    }

    @Test
    public void testToStandardDays() throws Exception {
        Period period = new Period(0, 0, 0, 5, 6, 7, 8, 9); // 5 days, 6 hours, 7 minutes, 8 seconds, 9 millis
        // 5 days
        // 6 hours = 0.25 days
        // 7 minutes = 7/60 hours = 7/(60*24) days = 0.00486 days
        // 8 seconds = 8/3600 hours = 8/(3600*24) days = 0.000096 days
        // 9 millis = 9/86400000 days = 0.0000001 days
        // Total days = 5 + 0.25 + 0.00486 + 0.000096 + 0.0000001 = 5.2549561
        assertEquals(5, period.toStandardDays().getDays());
    }

    @Test
    public void testToStandardHours() throws Exception {
        Period period = new Period(0, 0, 0, 1, 2, 3, 4, 5); // 1 day, 2 hours, 3 minutes, 4 seconds, 5 millis
        // 1 day = 24 hours
        // 2 hours
        // 3 minutes = 3/60 hours = 0.05 hours
        // 4 seconds = 4/3600 hours = 0.00111 hours
        // 5 millis = 5/3600000 hours = 0.0000013 hours
        // Total hours = 24 + 2 + 0.05 + 0.00111 + 0.0000013 = 26.0511113
        assertEquals(26, period.toStandardHours().getHours());
    }
    
    @Test
    public void testToStandardMinutes() throws Exception {
        Period period = new Period(0, 0, 0, 0, 1, 2, 3, 4); // 1 hour, 2 minutes, 3 seconds, 4 millis
        // 1 hour = 60 minutes
        // 2 minutes
        // 3 seconds = 3/60 minutes = 0.05 minutes
        // 4 millis = 4/60000 minutes = 0.000066 minutes
        // Total minutes = 60 + 2 + 0.05 + 0.000066 = 62.050066
        assertEquals(62, period.toStandardMinutes().getMinutes());
    }

    @Test
    public void testToStandardSeconds() throws Exception {
        Period period = new Period(0, 0, 0, 0, 0, 1, 2, 3); // 1 minute, 2 seconds, 3 millis
        // 1 minute = 60 seconds
        // 2 seconds
        // 3 millis = 3/1000 seconds = 0.003 seconds
        // Total seconds = 60 + 2 + 0.003 = 62.003
        assertEquals(62, period.toStandardSeconds().getSeconds());
    }
    
    @Test
    public void testToStandardDuration() throws Exception {
        Period period = new Period(1, 2, 3, 4, 5, 6, 7, 8); // 1 year, 2 months, 3 weeks, 4 days, 5 hours, 6 minutes, 7 seconds, 8 millis
        // toStandardDuration ignores years and months and converts everything to millis
        // 3 weeks = 3 * 7 * 24 * 60 * 60 * 1000 ms = 1814400000 ms
        // 4 days = 4 * 24 * 60 * 60 * 1000 ms = 345600000 ms
        // 5 hours = 5 * 60 * 60 * 1000 ms = 18000000 ms
        // 6 minutes = 6 * 60 * 1000 ms = 360000 ms
        // 7 seconds = 7 * 1000 ms = 7000 ms
        // 8 millis = 8 ms
        // Total millis = 1814400000 + 345600000 + 18000000 + 360000 + 7000 + 8 = 2179907008 ms
        Duration duration = period.toStandardDuration();
        assertEquals(2179907008L, duration.getMillis());
    }

    @Test
    public void testNormalizedStandard() throws Exception {
        Period period = new Period(1, 13, 0, 40, 25, 61, 61, 1001); // 1 year, 13 months, 40 days, 25 hours, 61 minutes, 61 seconds, 1001 millis
        // Normalized should sum up fields based on standard definitions:
        // 1 year + 13 months = 2 years 1 month
        // 40 days = 5 weeks 5 days
        // 25 hours = 1 day 1 hour
        // 61 minutes = 1 hour 1 minute
        // 61 seconds = 1 minute 1 second
        // 1001 millis = 1 second 1 millis
        // Combining:
        // Years: 2
        // Months: 1
        // Days: 5 + 1 = 6
        // Hours: 1
        // Minutes: 1 + 1 = 2
        // Seconds: 1 + 1 = 2
        // Millis: 1
        // Then group day/time into weeks.
        // 6 days = 6 days
        // 1 hour
        // 2 minutes
        // 2 seconds
        // 1 millis
        // Total: 2 years, 1 month, 6 days, 1 hour, 2 minutes, 2 seconds, 1 millis
        // The normalizedStandard method groups days into weeks.
        // 6 days = 0 weeks and 6 days.
        Period normalized = period.normalizedStandard();
        assertEquals(2, normalized.getYears());
        assertEquals(1, normalized.getMonths());
        assertEquals(0, normalized.getWeeks()); // 6 days are not automatically converted to weeks in the final output if type is standard
        assertEquals(6, normalized.getDays());
        assertEquals(1, normalized.getHours());
        assertEquals(2, normalized.getMinutes());
        assertEquals(2, normalized.getSeconds());
        assertEquals(1, normalized.getMillis());
    }
    
    @Test
    public void testNormalizedStandardWithSpecificType() throws Exception {
        Period period = new Period(0, 0, 0, 40, 25, 61, 61, 1001); // 40 days, 25 hours, 61 minutes, 61 seconds, 1001 millis
        PeriodType type = PeriodType.dayTime(); // Does not support weeks
        
        // 40 days
        // 25 hours = 1 day 1 hour
        // 61 minutes = 1 hour 1 minute
        // 61 seconds = 1 minute 1 second
        // 1001 millis = 1 second 1 millis
        // Combining:
        // Days: 40 + 1 = 41
        // Hours: 1 + 1 = 2
        // Minutes: 1 + 1 = 2
        // Seconds: 1 + 1 = 2
        // Millis: 1
        // Total: 41 days, 2 hours, 2 minutes, 2 seconds, 1 millis
        Period normalized = period.normalizedStandard(type);
        assertEquals(41, normalized.getDays());
        assertEquals(2, normalized.getHours());
        assertEquals(2, normalized.getMinutes());
        assertEquals(2, normalized.getSeconds());
        assertEquals(1, normalized.getMillis());
    }

    @Test
    public void testMultipliedByZero() throws Exception {
        Period period = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        Period multiplied = period.multipliedBy(0);
        assertEquals(0, multiplied.getYears());
        assertEquals(0, multiplied.getMonths());
        assertEquals(0, multiplied.getWeeks());
        assertEquals(0, multiplied.getDays());
        assertEquals(0, multiplied.getHours());
        assertEquals(0, multiplied.getMinutes());
        assertEquals(0, multiplied.getSeconds());
        assertEquals(0, multiplied.getMillis());
    }
    
    @Test
    public void testMultipliedByOne() throws Exception {
        Period period = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        Period multiplied = period.multipliedBy(1);
        assertSame(period, multiplied); // Should return the same instance if scalar is 1
    }

    @Test
    public void testToString() throws Exception {
        Period period = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        String expected = "P1Y2M3W4DT5H6M7S8MS";
        assertEquals(expected, period.toString());
    }

    @Test
    public void testEqualsSamePeriod() throws Exception {
        Period period1 = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        Period period2 = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        assertTrue(period1.equals(period2));
        assertEquals(period1.hashCode(), period2.hashCode());
    }

    @Test
    public void testEqualsDifferentPeriod() throws Exception {
        Period period1 = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        Period period2 = new Period(1, 2, 3, 4, 5, 6, 7, 9);
        assertFalse(period1.equals(period2));
    }

    @Test
    public void testEqualsWithDifferentTypes() throws Exception {
        Period period1 = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        Period period2 = new Period(1, 2, 3, 4, 5, 6, 7, 8).withPeriodType(PeriodType.time());
        assertFalse(period1.equals(period2));
    }
}
