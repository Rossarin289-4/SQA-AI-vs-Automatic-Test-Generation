package org.joda.time;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.Serializable;
import org.joda.convert.FromString;
import org.joda.time.base.BasePeriod;
import org.joda.time.chrono.ISOChronology;
import org.joda.time.field.FieldUtils;
import org.joda.time.format.ISOPeriodFormat;
import org.joda.time.format.PeriodFormatter;

public class PeriodTest {
    @Test
    public void testStaticFieldFactories() throws Exception {
        assertEquals(2, Period.years(2).getYears());
        assertEquals(3, Period.months(3).getMonths());
        assertEquals(4, Period.weeks(4).getWeeks());
        assertEquals(5, Period.days(5).getDays());
    }

    @Test
    public void testTimeFieldFactories() throws Exception {
        assertEquals(6, Period.hours(6).getHours());
        assertEquals(7, Period.minutes(7).getMinutes());
        assertEquals(8, Period.seconds(8).getSeconds());
        assertEquals(9, Period.millis(9).getMillis());
    }

    @Test
    public void testFactoryIntEdges() throws Exception {
        assertEquals(Integer.MAX_VALUE, Period.years(Integer.MAX_VALUE).getYears());
        assertEquals(Integer.MIN_VALUE, Period.millis(Integer.MIN_VALUE).getMillis());
    }

    @Test
    public void testParseStandardPeriod() throws Exception {
        Period p = Period.parse("P1Y2M3DT4H5M6.007S");
        assertEquals(1, p.getYears());
        assertEquals(2, p.getMonths());
        assertEquals(3, p.getDays());
        assertEquals(4, p.getHours());
        assertEquals(5, p.getMinutes());
        assertEquals(6, p.getSeconds());
        assertEquals(7, p.getMillis());
    }

    @Test
    public void testParseZeroPeriod() throws Exception {
        assertEquals(Period.ZERO, Period.parse("PT0S"));
    }

    @Test
    public void testDefaultAndTimeConstructors() throws Exception {
        Period empty = new Period();
        assertEquals(0, empty.getYears());
        assertEquals(0, empty.getMillis());
        Period time = new Period(1, 2, 3, 4);
        assertEquals(1, time.getHours());
        assertEquals(2, time.getMinutes());
        assertEquals(3, time.getSeconds());
        assertEquals(4, time.getMillis());
    }

    @Test
    public void testEightFieldConstructor() throws Exception {
        Period p = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        assertEquals(1, p.getYears());
        assertEquals(2, p.getMonths());
        assertEquals(3, p.getWeeks());
        assertEquals(4, p.getDays());
        assertEquals(5, p.getHours());
        assertEquals(6, p.getMinutes());
        assertEquals(7, p.getSeconds());
        assertEquals(8, p.getMillis());
    }

    @Test
    public void testPeriodAsDurationAndStandardConversions() throws Exception {
        Period p = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        assertEquals(3 * 604800 + 4 * 86400 + 5 * 3600 + 6 * 60 + 7,
                p.withYears(0).withMonths(0).toStandardSeconds().getSeconds());
        assertEquals(8L + 7L * 1000 + 6L * 60000 + 5L * 3600000
                + 4L * 86400000 + 3L * 604800000,
                p.withYears(0).withMonths(0).toStandardDuration().getMillis());
    }

    @Test
    public void testStandardUnitConversionTruncatesSubunitRemainders() throws Exception {
        Period p = new Period(0, 0, 0, 0, 0, 1, 30, 500);
        assertEquals(1, p.toStandardMinutes().getMinutes());
        assertEquals(90, p.toStandardSeconds().getSeconds());
        assertEquals(90500L, p.toStandardDuration().getMillis());
    }

    @Test
    public void testStandardConversionsIncludeDaysWeeksAndHours() throws Exception {
        Period p = new Period(0, 0, 1, 2, 3, 0, 0, 0);
        assertEquals(9, p.toStandardDays().getDays());
        assertEquals(219, p.toStandardHours().getHours());
        assertEquals(13140, p.toStandardMinutes().getMinutes());
        assertEquals(788400, p.toStandardSeconds().getSeconds());
        assertEquals(788400000L, p.toStandardDuration().getMillis());
        assertEquals(1, p.toStandardWeeks().getWeeks());
    }

    @Test
    public void testRejectsStandardConversionWithMonthsOrYears() throws Exception {
        try {
            Period.months(1).toStandardDuration();
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) { }
        try {
            Period.years(1).toStandardWeeks();
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) { }
    }

    @Test
    public void testWithAndAddedFieldsPreserveImmutability() throws Exception {
        Period original = new Period(1, 2, 3, 4, 5, 6, 7, 8);
        Period changed = original.withYears(-2).withField(DurationFieldType.minutes(), 11);
        assertEquals(1, original.getYears());
        assertEquals(6, original.getMinutes());
        assertEquals(-2, changed.getYears());
        assertEquals(11, changed.getMinutes());
        assertEquals(8, original.withFieldAdded(DurationFieldType.millis(), 0).getMillis());
    }

    @Test
    public void testWithFieldsMergesFields() throws Exception {
        Period p = Period.days(2).withFields(Period.hours(3).withMinutes(4));
        assertEquals(0, p.getDays());
        assertEquals(3, p.getHours());
        assertEquals(4, p.getMinutes());
    }

    @Test
    public void testPlusAndMinusPeriods() throws Exception {
        Period start = new Period(1, 2, 0, 3, 4, 5, 6, 7);
        Period delta = new Period(2, 1, 0, 4, 3, 2, 1, 8);
        Period sum = start.plus(delta);
        Period difference = start.minus(delta);
        assertEquals(3, sum.getYears());
        assertEquals(3, sum.getMonths());
        assertEquals(7, sum.getDays());
        assertEquals(7, sum.getHours());
        assertEquals(7, sum.getMinutes());
        assertEquals(7, sum.getSeconds());
        assertEquals(15, sum.getMillis());
        assertEquals(-1, difference.getYears());
        assertEquals(1, difference.getMonths());
        assertEquals(-1, difference.getDays());
        assertEquals(1, difference.getHours());
    }

    @Test
    public void testIndividualPlusAndMinusMethods() throws Exception {
        Period p = Period.days(10).plusDays(3).minusDays(2)
                .plusHours(4).minusHours(1).plusMinutes(5).minusMinutes(2)
                .plusSeconds(7).minusSeconds(3).plusMillis(9).minusMillis(4);
        assertEquals(11, p.getDays());
        assertEquals(3, p.getHours());
        assertEquals(3, p.getMinutes());
        assertEquals(4, p.getSeconds());
        assertEquals(5, p.getMillis());
        assertEquals(Period.years(2), Period.years(1).plusYears(1));
        assertEquals(Period.months(1), Period.months(2).minusMonths(1));
        assertEquals(Period.weeks(2), Period.weeks(1).plusWeeks(1));
        assertEquals(Period.years(1), Period.years(2).minusYears(1));
    }

    @Test
    public void testScaleAndNegate() throws Exception {
        Period p = new Period(1, -2, 3, -4, 5, -6, 7, -8);
        Period doubled = p.multipliedBy(2);
        assertEquals(2, doubled.getYears());
        assertEquals(-4, doubled.getMonths());
        assertEquals(-8, doubled.getDays());
        assertEquals(-12, doubled.getMinutes());
        assertEquals(-16, doubled.getMillis());
        Period negated = p.negated();
        assertEquals(-1, negated.getYears());
        assertEquals(2, negated.getMonths());
        assertEquals(8, negated.getMillis());
    }

    @Test
    public void testMultiplicationAtIntegerEdges() throws Exception {
        assertEquals(Integer.MAX_VALUE, Period.millis(Integer.MAX_VALUE).multipliedBy(1).getMillis());
        try {
            Period.millis(Integer.MAX_VALUE).multipliedBy(2);
            fail("expected ArithmeticException");
        } catch (ArithmeticException expected) { }
        try {
            Period.millis(Integer.MIN_VALUE).negated();
            fail("expected ArithmeticException");
        } catch (ArithmeticException expected) { }
    }

    @Test
    public void testWithPeriodTypeAndToPeriod() throws Exception {
        Period p = Period.days(3);
        assertSame(p, p.toPeriod());
        assertSame(p, p.withPeriodType(PeriodType.standard()));
        assertEquals(3, p.withPeriodType(PeriodType.dayTime()).getDays());
    }

    @Test
    public void testNormalizedStandardMonthAndTimeFields() throws Exception {
        Period p = new Period(1, 15, 0, 0, 25, 61, 0, 0).normalizedStandard();
        assertEquals(2, p.getYears());
        assertEquals(3, p.getMonths());
        assertEquals(1, p.getDays());
        assertEquals(2, p.getHours());
        assertEquals(1, p.getMinutes());
    }

    @Test
    public void testNormalizedStandardCarriesWeeksIntoDays() throws Exception {
        Period p = new Period(0, 0, 1, 8, 0, 0, 0, 0).normalizedStandard();
        assertEquals(2, p.getWeeks());
        assertEquals(1, p.getDays());
    }

    @Test
    public void testFieldDifferenceRejectsNullAndMismatchedSizes() throws Exception {
        try {
            Period.fieldDifference(null, null);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) { }
        try {
            Period.fieldDifference(new LocalDate(2020, 1, 1), new LocalTime(0, 0));
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) { }
    }

    @Test
    public void testWithWeeksSetsValueAndPreservesOriginal() throws Exception {
        Period original = Period.weeks(2);
        Period changed = original.withWeeks(-3);
        assertEquals(2, original.getWeeks());
        assertEquals(-3, changed.getWeeks());
    }

    @Test
    public void testWithDaysSetsValue() throws Exception {
        assertEquals(Integer.MIN_VALUE, Period.days(1).withDays(Integer.MIN_VALUE).getDays());
    }

    @Test
    public void testWithHoursSetsValue() throws Exception {
        assertEquals(Integer.MAX_VALUE, Period.hours(0).withHours(Integer.MAX_VALUE).getHours());
    }

    @Test
    public void testWithSecondsSetsValue() throws Exception {
        assertEquals(-1, Period.seconds(4).withSeconds(-1).getSeconds());
    }

    @Test
    public void testWithMillisSetsValue() throws Exception {
        assertEquals(Integer.MIN_VALUE, Period.millis(0).withMillis(Integer.MIN_VALUE).getMillis());
    }

    @Test
    public void testPlusMonthsAddsAndSupportsNegativeValues() throws Exception {
        Period original = Period.months(2);
        Period result = original.plusMonths(-5);
        assertEquals(2, original.getMonths());
        assertEquals(-3, result.getMonths());
    }

    @Test
    public void testMinusWeeksSubtractsAndSupportsNegativeValues() throws Exception {
        Period original = Period.weeks(2);
        Period result = original.minusWeeks(-3);
        assertEquals(2, original.getWeeks());
        assertEquals(5, result.getWeeks());
    }
}
