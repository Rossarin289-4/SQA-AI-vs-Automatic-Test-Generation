package generated.algorithm;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import static org.junit.Assert.*;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class BinaryParticleSwarmGeneratedTest {
 @Test(timeout = 20000)
 public void generatedInput000() throws Throwable {
  Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "reset", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "reset", ""}});
  assertNull(actual);
  assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=!IllegalStateException, getTime=0}", SearchInputFactory_scaffolding.receiverState());
 }
 @Test(timeout = 20000)
 public void generatedInput001() throws Throwable {
  Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "toString", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "stop", ""}});
  assertNotNull(actual);
  assertEquals("java.lang.String", actual.getClass().getName());
  assertEquals("0:00:00.000", String.valueOf(actual));
  assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=!IllegalStateException, getTime=0}", SearchInputFactory_scaffolding.receiverState());
 }
 @Test(timeout = 20000)
 public void generatedInput002() throws Throwable {
  Throwable thrown = null;
  try { SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "suspend", new String[]{}, new String[]{}, false, 7, new String[][]{{"org.apache.commons.lang.time.StopWatch", "toSplitString", ""}}, 3); } catch (Throwable caught) { thrown = caught; }
  assertNotNull("expected an exception", thrown);
  assertEquals("java.lang.IllegalStateException", thrown.getClass().getName());
 }
 @Test(timeout = 20000)
 public void generatedInput003() throws Throwable {
  Throwable thrown = null;
  try { SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "stop", new String[]{}, new String[]{}, false, 1, new String[][]{}); } catch (Throwable caught) { thrown = caught; }
  assertNotNull("expected an exception", thrown);
  assertEquals("java.lang.IllegalStateException", thrown.getClass().getName());
 }
 @Test(timeout = 20000)
 public void generatedInput004() throws Throwable {
  Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "reset", new String[]{}, new String[]{}, false, 2, new String[][]{{"org.apache.commons.lang.time.StopWatch", "suspend", ""}}, 2);
  assertNull(actual);
  assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=!IllegalStateException, getTime=0}", SearchInputFactory_scaffolding.receiverState());
 }
 @Test(timeout = 20000)
 public void generatedInput005() throws Throwable {
  Throwable thrown = null;
  try { SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "split", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "resume", ""}}, 2); } catch (Throwable caught) { thrown = caught; }
  assertNotNull("expected an exception", thrown);
  assertEquals("java.lang.IllegalStateException", thrown.getClass().getName());
 }
 @Test(timeout = 20000)
 public void generatedInput006() throws Throwable {
  Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "getTime", new String[]{}, new String[]{}, false, 5, new String[][]{});
  assertNotNull(actual);
  assertEquals("java.lang.Long", actual.getClass().getName());
  assertEquals("0", String.valueOf(actual));
  assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=!IllegalStateException, getTime=0}", SearchInputFactory_scaffolding.receiverState());
 }
 @Test(timeout = 20000)
 public void generatedInput007() throws Throwable {
  Throwable thrown = null;
  try { SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "resume", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "suspend", ""}}, 3); } catch (Throwable caught) { thrown = caught; }
  assertNotNull("expected an exception", thrown);
  assertEquals("java.lang.IllegalStateException", thrown.getClass().getName());
 }
 @Test
 public void generatedInput008() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput008() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "start", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "stop", ""}}, 3);
//   assertNull(actual);
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=!IllegalStateException, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test(timeout = 20000)
 public void generatedInput009() throws Throwable {
  Throwable thrown = null;
  try { SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "suspend", new String[]{}, new String[]{}, false, 4, new String[][]{{"org.apache.commons.lang.time.StopWatch", "toString", ""}}, 1); } catch (Throwable caught) { thrown = caught; }
  assertNotNull("expected an exception", thrown);
  assertEquals("java.lang.IllegalStateException", thrown.getClass().getName());
 }
 @Test(timeout = 20000)
 public void generatedInput010() throws Throwable {
  Throwable thrown = null;
  try { SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "unsplit", new String[]{}, new String[]{}, false, 0, null, 3); } catch (Throwable caught) { thrown = caught; }
  assertNotNull("expected an exception", thrown);
  assertEquals("java.lang.IllegalStateException", thrown.getClass().getName());
 }
 @Test(timeout = 20000)
 public void generatedInput011() throws Throwable {
  Throwable thrown = null;
  try { SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "getSplitTime", new String[]{}, new String[]{}, false, 5, new String[][]{}); } catch (Throwable caught) { thrown = caught; }
  assertNotNull("expected an exception", thrown);
  assertEquals("java.lang.IllegalStateException", thrown.getClass().getName());
 }
 @Test(timeout = 20000)
 public void generatedInput012() throws Throwable {
  Throwable thrown = null;
  try { SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "unsplit", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "getTime", ""}}); } catch (Throwable caught) { thrown = caught; }
  assertNotNull("expected an exception", thrown);
  assertEquals("java.lang.IllegalStateException", thrown.getClass().getName());
 }
 @Test(timeout = 20000)
 public void generatedInput013() throws Throwable {
  Throwable thrown = null;
  try { SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "split", new String[]{}, new String[]{}, false); } catch (Throwable caught) { thrown = caught; }
  assertNotNull("expected an exception", thrown);
  assertEquals("java.lang.IllegalStateException", thrown.getClass().getName());
 }
 @Test(timeout = 20000)
 public void generatedInput014() throws Throwable {
  Throwable thrown = null;
  try { SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "resume", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}}, 2); } catch (Throwable caught) { thrown = caught; }
  assertNotNull("expected an exception", thrown);
  assertEquals("java.lang.IllegalStateException", thrown.getClass().getName());
 }
 @Test(timeout = 20000)
 public void generatedInput015() throws Throwable {
  Throwable thrown = null;
  try { SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "toSplitString", new String[]{}, new String[]{}, false); } catch (Throwable caught) { thrown = caught; }
  assertNotNull("expected an exception", thrown);
  assertEquals("java.lang.IllegalStateException", thrown.getClass().getName());
 }
 @Test(timeout = 20000)
 public void generatedInput016() throws Throwable {
  Throwable thrown = null;
  try { SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "start", new String[]{}, new String[]{}, false, 4, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}, {"org.apache.commons.lang.time.StopWatch", "split", ""}}); } catch (Throwable caught) { thrown = caught; }
  assertNotNull("expected an exception", thrown);
  assertEquals("java.lang.IllegalStateException", thrown.getClass().getName());
 }
 @Test(timeout = 20000)
 public void generatedInput017() throws Throwable {
  Throwable thrown = null;
  try { SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "suspend", new String[]{}, new String[]{}, false, 7, new String[][]{{"org.apache.commons.lang.time.StopWatch", "suspend", ""}, {"org.apache.commons.lang.time.StopWatch", "unsplit", ""}}, 2); } catch (Throwable caught) { thrown = caught; }
  assertNotNull("expected an exception", thrown);
  assertEquals("java.lang.IllegalStateException", thrown.getClass().getName());
 }
 @Test
 public void generatedInput018() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput018() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "start", new String[]{}, new String[]{}, false, 4, new String[][]{{"org.apache.commons.lang.time.StopWatch", "suspend", ""}, {"org.apache.commons.lang.time.StopWatch", "resume", ""}});
//   assertNull(actual);
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=!IllegalStateException, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test(timeout = 20000)
 public void generatedInput019() throws Throwable {
  Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "reset", new String[]{}, new String[]{}, false, 6, new String[][]{}, 3);
  assertNull(actual);
  assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=!IllegalStateException, getTime=0}", SearchInputFactory_scaffolding.receiverState());
 }
 @Test(timeout = 20000)
 public void generatedInput020() throws Throwable {
  Throwable thrown = null;
  try { SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "suspend", new String[]{}, new String[]{}, false, 6, new String[][]{{"org.apache.commons.lang.time.StopWatch", "resume", ""}}); } catch (Throwable caught) { thrown = caught; }
  assertNotNull("expected an exception", thrown);
  assertEquals("java.lang.IllegalStateException", thrown.getClass().getName());
 }
 @Test
 public void generatedInput021() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput021() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "start", new String[]{}, new String[]{}, false, 4, new String[][]{}, 2);
//   assertNull(actual);
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=!IllegalStateException, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test(timeout = 20000)
 public void generatedInput022() throws Throwable {
  Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "getTime", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "unsplit", ""}}, 3);
  assertNotNull(actual);
  assertEquals("java.lang.Long", actual.getClass().getName());
  assertEquals("0", String.valueOf(actual));
  assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=!IllegalStateException, getTime=0}", SearchInputFactory_scaffolding.receiverState());
 }
 @Test(timeout = 20000)
 public void generatedInput023() throws Throwable {
  Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "toString", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "toString", ""}}, 3);
  assertNotNull(actual);
  assertEquals("java.lang.String", actual.getClass().getName());
  assertEquals("0:00:00.000", String.valueOf(actual));
  assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=!IllegalStateException, getTime=0}", SearchInputFactory_scaffolding.receiverState());
 }
 @Test(timeout = 20000)
 public void generatedInput024() throws Throwable {
  Throwable thrown = null;
  try { SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "split", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "suspend", ""}}, 1); } catch (Throwable caught) { thrown = caught; }
  assertNotNull("expected an exception", thrown);
  assertEquals("java.lang.IllegalStateException", thrown.getClass().getName());
 }
 @Test(timeout = 20000)
 public void generatedInput025() throws Throwable {
  Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "reset", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "suspend", ""}, {"org.apache.commons.lang.time.StopWatch", "getTime", ""}}, 1);
  assertNull(actual);
  assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=!IllegalStateException, getTime=0}", SearchInputFactory_scaffolding.receiverState());
 }
 @Test(timeout = 20000)
 public void generatedInput026() throws Throwable {
  Throwable thrown = null;
  try { SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "getSplitTime", new String[]{}, new String[]{}, false, 0, null, 3); } catch (Throwable caught) { thrown = caught; }
  assertNotNull("expected an exception", thrown);
  assertEquals("java.lang.IllegalStateException", thrown.getClass().getName());
 }
 @Test(timeout = 20000)
 public void generatedInput027() throws Throwable {
  Throwable thrown = null;
  try { SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "toSplitString", new String[]{}, new String[]{}, false, 1, new String[][]{{"org.apache.commons.lang.time.StopWatch", "resume", ""}}, 2); } catch (Throwable caught) { thrown = caught; }
  assertNotNull("expected an exception", thrown);
  assertEquals("java.lang.IllegalStateException", thrown.getClass().getName());
 }
 @Test(timeout = 20000)
 public void generatedInput028() throws Throwable {
  Throwable thrown = null;
  try { SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "stop", new String[]{}, new String[]{}, false, 1, new String[][]{{"org.apache.commons.lang.time.StopWatch", "toString", ""}, {"org.apache.commons.lang.time.StopWatch", "getSplitTime", ""}}, 3); } catch (Throwable caught) { thrown = caught; }
  assertNotNull("expected an exception", thrown);
  assertEquals("java.lang.IllegalStateException", thrown.getClass().getName());
 }
 @Test(timeout = 20000)
 public void generatedInput029() throws Throwable {
  Throwable thrown = null;
  try { SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "resume", new String[]{}, new String[]{}, false, 0, null, 1); } catch (Throwable caught) { thrown = caught; }
  assertNotNull("expected an exception", thrown);
  assertEquals("java.lang.IllegalStateException", thrown.getClass().getName());
 }
 @Test(timeout = 20000)
 public void generatedInput030() throws Throwable {
  Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "getTime", new String[]{}, new String[]{}, false, 3, new String[][]{{"org.apache.commons.lang.time.StopWatch", "suspend", ""}}, 1);
  assertNotNull(actual);
  assertEquals("java.lang.Long", actual.getClass().getName());
  assertEquals("0", String.valueOf(actual));
  assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=!IllegalStateException, getTime=0}", SearchInputFactory_scaffolding.receiverState());
 }
 @Test(timeout = 20000)
 public void generatedInput031() throws Throwable {
  Throwable thrown = null;
  try { SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "split", new String[]{}, new String[]{}, false, 4, new String[][]{}, 3); } catch (Throwable caught) { thrown = caught; }
  assertNotNull("expected an exception", thrown);
  assertEquals("java.lang.IllegalStateException", thrown.getClass().getName());
 }
 @Test(timeout = 20000)
 public void generatedInput032() throws Throwable {
  Throwable thrown = null;
  try { SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "resume", new String[]{}, new String[]{}, false, 2, new String[][]{{"org.apache.commons.lang.time.StopWatch", "getSplitTime", ""}, {"org.apache.commons.lang.time.StopWatch", "reset", ""}}); } catch (Throwable caught) { thrown = caught; }
  assertNotNull("expected an exception", thrown);
  assertEquals("java.lang.IllegalStateException", thrown.getClass().getName());
 }
 @Test(timeout = 20000)
 public void generatedInput033() throws Throwable {
  Throwable thrown = null;
  try { SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "toSplitString", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "suspend", ""}}, 3); } catch (Throwable caught) { thrown = caught; }
  assertNotNull("expected an exception", thrown);
  assertEquals("java.lang.IllegalStateException", thrown.getClass().getName());
 }
 @Test(timeout = 20000)
 public void generatedInput034() throws Throwable {
  Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "toString", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "unsplit", ""}}, 1);
  assertNotNull(actual);
  assertEquals("java.lang.String", actual.getClass().getName());
  assertEquals("0:00:00.000", String.valueOf(actual));
  assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=!IllegalStateException, getTime=0}", SearchInputFactory_scaffolding.receiverState());
 }
 @Test(timeout = 20000)
 public void generatedInput035() throws Throwable {
  Throwable thrown = null;
  try { SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "unsplit", new String[]{}, new String[]{}, false, 4, new String[][]{}, 1); } catch (Throwable caught) { thrown = caught; }
  assertNotNull("expected an exception", thrown);
  assertEquals("java.lang.IllegalStateException", thrown.getClass().getName());
 }
 @Test(timeout = 20000)
 public void generatedInput036() throws Throwable {
  Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "toString", new String[]{}, new String[]{}, false, 6, new String[][]{{"org.apache.commons.lang.time.StopWatch", "stop", ""}}, 2);
  assertNotNull(actual);
  assertEquals("java.lang.String", actual.getClass().getName());
  assertEquals("0:00:00.000", String.valueOf(actual));
  assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=!IllegalStateException, getTime=0}", SearchInputFactory_scaffolding.receiverState());
 }
 @Test(timeout = 20000)
 public void generatedInput037() throws Throwable {
  Throwable thrown = null;
  try { SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "stop", new String[]{}, new String[]{}, false, 2, new String[][]{}, 2); } catch (Throwable caught) { thrown = caught; }
  assertNotNull("expected an exception", thrown);
  assertEquals("java.lang.IllegalStateException", thrown.getClass().getName());
 }
 @Test(timeout = 20000)
 public void generatedInput038() throws Throwable {
  Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "getTime", new String[]{}, new String[]{}, false, 2, new String[][]{{"org.apache.commons.lang.time.StopWatch", "toSplitString", ""}, {"org.apache.commons.lang.time.StopWatch", "resume", ""}}, 2);
  assertNotNull(actual);
  assertEquals("java.lang.Long", actual.getClass().getName());
  assertEquals("0", String.valueOf(actual));
  assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=!IllegalStateException, getTime=0}", SearchInputFactory_scaffolding.receiverState());
 }
 @Test
 public void generatedInput039() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput039() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "suspend", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}});
//   assertNull(actual);
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=!IllegalStateException, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test(timeout = 20000)
 public void generatedInput040() throws Throwable {
  Throwable thrown = null;
  try { SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "stop", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "getTime", ""}}, 1); } catch (Throwable caught) { thrown = caught; }
  assertNotNull("expected an exception", thrown);
  assertEquals("java.lang.IllegalStateException", thrown.getClass().getName());
 }
 @Test
 public void generatedInput041() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput041() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "split", new String[]{}, new String[]{}, false, 3, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}});
//   assertNull(actual);
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=0, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test(timeout = 20000)
 public void generatedInput042() throws Throwable {
  Throwable thrown = null;
  try { SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "getSplitTime", new String[]{}, new String[]{}, false, 2, new String[][]{}, 1); } catch (Throwable caught) { thrown = caught; }
  assertNotNull("expected an exception", thrown);
  assertEquals("java.lang.IllegalStateException", thrown.getClass().getName());
 }
 @Test
 public void generatedInput043() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput043() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "start", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "unsplit", ""}, {"org.apache.commons.lang.time.StopWatch", "toString", ""}}, 1);
//   assertNull(actual);
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=!IllegalStateException, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test
 public void generatedInput044() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput044() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "getTime", new String[]{}, new String[]{}, false, 2, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}, {"org.apache.commons.lang.time.StopWatch", "stop", ""}});
//   assertNotNull(actual);
//   assertEquals("java.lang.Long", actual.getClass().getName());
//   assertEquals("0", String.valueOf(actual));
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=!IllegalStateException, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test(timeout = 20000)
 public void generatedInput045() throws Throwable {
  Throwable thrown = null;
  try { SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "getSplitTime", new String[]{}, new String[]{}, false, 2, new String[][]{}, 2); } catch (Throwable caught) { thrown = caught; }
  assertNotNull("expected an exception", thrown);
  assertEquals("java.lang.IllegalStateException", thrown.getClass().getName());
 }
 @Test(timeout = 20000)
 public void generatedInput046() throws Throwable {
  Throwable thrown = null;
  try { SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "toSplitString", new String[]{}, new String[]{}, false, 4, new String[][]{{"org.apache.commons.lang.time.StopWatch", "suspend", ""}}, 1); } catch (Throwable caught) { thrown = caught; }
  assertNotNull("expected an exception", thrown);
  assertEquals("java.lang.IllegalStateException", thrown.getClass().getName());
 }
 @Test(timeout = 20000)
 public void generatedInput047() throws Throwable {
  Throwable thrown = null;
  try { SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "start", new String[]{}, new String[]{}, false, 5, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}}, 3); } catch (Throwable caught) { thrown = caught; }
  assertNotNull("expected an exception", thrown);
  assertEquals("java.lang.IllegalStateException", thrown.getClass().getName());
 }
 @Test
 public void generatedInput048() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput048() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "stop", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}, {"org.apache.commons.lang.time.StopWatch", "split", ""}});
//   assertNull(actual);
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=0, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test
 public void generatedInput049() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput049() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "stop", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}, {"org.apache.commons.lang.time.StopWatch", "unsplit", ""}});
//   assertNull(actual);
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=!IllegalStateException, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test
 public void generatedInput050() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput050() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "suspend", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "resume", ""}, {"org.apache.commons.lang.time.StopWatch", "start", ""}}, 2);
//   assertNull(actual);
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=!IllegalStateException, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test(timeout = 20000)
 public void generatedInput051() throws Throwable {
  Throwable thrown = null;
  try { SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "start", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}}, 2); } catch (Throwable caught) { thrown = caught; }
  assertNotNull("expected an exception", thrown);
  assertEquals("java.lang.IllegalStateException", thrown.getClass().getName());
 }
 @Test
 public void generatedInput052() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput052() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "getTime", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}, {"org.apache.commons.lang.time.StopWatch", "split", ""}});
//   assertNotNull(actual);
//   assertEquals("java.lang.Long", actual.getClass().getName());
//   assertEquals("0", String.valueOf(actual));
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=0, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test
 public void generatedInput053() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput053() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "stop", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}}, 3);
//   assertNull(actual);
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=!IllegalStateException, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test
 public void generatedInput054() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput054() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "stop", new String[]{}, new String[]{}, false, 1, new String[][]{{"org.apache.commons.lang.time.StopWatch", "getTime", ""}, {"org.apache.commons.lang.time.StopWatch", "start", ""}}, 1);
//   assertNull(actual);
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=!IllegalStateException, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test
 public void generatedInput055() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput055() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "stop", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}}, 2);
//   assertNull(actual);
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=!IllegalStateException, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test
 public void generatedInput056() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput056() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "split", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}, {"org.apache.commons.lang.time.StopWatch", "getSplitTime", ""}}, 2);
//   assertNull(actual);
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=0, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test(timeout = 20000)
 public void generatedInput057() throws Throwable {
  Throwable thrown = null;
  try { SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "unsplit", new String[]{}, new String[]{}, false, 4, new String[][]{{"org.apache.commons.lang.time.StopWatch", "toString", ""}, {"org.apache.commons.lang.time.StopWatch", "getSplitTime", ""}}, 2); } catch (Throwable caught) { thrown = caught; }
  assertNotNull("expected an exception", thrown);
  assertEquals("java.lang.IllegalStateException", thrown.getClass().getName());
 }
 @Test
 public void generatedInput058() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput058() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "suspend", new String[]{}, new String[]{}, false, 3, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}}, 1);
//   assertNull(actual);
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=!IllegalStateException, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test
 public void generatedInput059() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput059() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "split", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}, {"org.apache.commons.lang.time.StopWatch", "start", ""}}, 3);
//   assertNull(actual);
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=0, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test
 public void generatedInput060() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput060() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "split", new String[]{}, new String[]{}, false, 7, new String[][]{{"org.apache.commons.lang.time.StopWatch", "reset", ""}, {"org.apache.commons.lang.time.StopWatch", "start", ""}}, 1);
//   assertNull(actual);
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=0, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test
 public void generatedInput061() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput061() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "stop", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}, {"org.apache.commons.lang.time.StopWatch", "suspend", ""}});
//   assertNull(actual);
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=!IllegalStateException, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test
 public void generatedInput062() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput062() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "suspend", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}, {"org.apache.commons.lang.time.StopWatch", "split", ""}});
//   assertNull(actual);
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=0, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test(timeout = 20000)
 public void generatedInput063() throws Throwable {
  Throwable thrown = null;
  try { SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "start", new String[]{}, new String[]{}, false, 2, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}}, 1); } catch (Throwable caught) { thrown = caught; }
  assertNotNull("expected an exception", thrown);
  assertEquals("java.lang.IllegalStateException", thrown.getClass().getName());
 }
 @Test
 public void generatedInput064() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput064() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "suspend", new String[]{}, new String[]{}, false, 2, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}, {"org.apache.commons.lang.time.StopWatch", "start", ""}}, 3);
//   assertNull(actual);
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=!IllegalStateException, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test
 public void generatedInput065() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput065() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "toSplitString", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}, {"org.apache.commons.lang.time.StopWatch", "split", ""}});
//   assertNotNull(actual);
//   assertEquals("java.lang.String", actual.getClass().getName());
//   assertEquals("0:00:00.000", String.valueOf(actual));
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=0, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test
 public void generatedInput066() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput066() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "suspend", new String[]{}, new String[]{}, false, 4, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}, {"org.apache.commons.lang.time.StopWatch", "split", ""}}, 1);
//   assertNull(actual);
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=0, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test
 public void generatedInput067() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput067() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "stop", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}, {"org.apache.commons.lang.time.StopWatch", "split", ""}}, 3);
//   assertNull(actual);
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=0, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test
 public void generatedInput068() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput068() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "stop", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}, {"org.apache.commons.lang.time.StopWatch", "split", ""}}, 1);
//   assertNull(actual);
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=0, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test
 public void generatedInput069() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput069() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "split", new String[]{}, new String[]{}, false, 7, new String[][]{{"org.apache.commons.lang.time.StopWatch", "reset", ""}, {"org.apache.commons.lang.time.StopWatch", "start", ""}}, 3);
//   assertNull(actual);
//   assertEquals("receiver state after the call", "0:00:00.001 {getSplitTime=0, getTime=1}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test
 public void generatedInput070() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput070() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "stop", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}, {"org.apache.commons.lang.time.StopWatch", "split", ""}}, 2);
//   assertNull(actual);
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=0, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test(timeout = 20000)
 public void generatedInput071() throws Throwable {
  Throwable thrown = null;
  try { SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "start", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}, {"org.apache.commons.lang.time.StopWatch", "stop", ""}}); } catch (Throwable caught) { thrown = caught; }
  assertNotNull("expected an exception", thrown);
  assertEquals("java.lang.IllegalStateException", thrown.getClass().getName());
 }
 @Test
 public void generatedInput072() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput072() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "getTime", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}, {"org.apache.commons.lang.time.StopWatch", "split", ""}}, 1);
//   assertNotNull(actual);
//   assertEquals("java.lang.Long", actual.getClass().getName());
//   assertEquals("0", String.valueOf(actual));
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=0, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test
 public void generatedInput073() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput073() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "toString", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}, {"org.apache.commons.lang.time.StopWatch", "split", ""}});
//   assertNotNull(actual);
//   assertEquals("java.lang.String", actual.getClass().getName());
//   assertEquals("0:00:00.000", String.valueOf(actual));
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=0, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test
 public void generatedInput074() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput074() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "resume", new String[]{}, new String[]{}, false, 5, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}, {"org.apache.commons.lang.time.StopWatch", "suspend", ""}}, 1);
//   assertNull(actual);
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=!IllegalStateException, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test
 public void generatedInput075() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput075() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "getTime", new String[]{}, new String[]{}, false, 5, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}, {"org.apache.commons.lang.time.StopWatch", "split", ""}}, 2);
//   assertNotNull(actual);
//   assertEquals("java.lang.Long", actual.getClass().getName());
//   assertEquals("0", String.valueOf(actual));
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=0, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test
 public void generatedInput076() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput076() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "suspend", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}, {"org.apache.commons.lang.time.StopWatch", "split", ""}}, 2);
//   assertNull(actual);
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=0, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test
 public void generatedInput077() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput077() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "getSplitTime", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}, {"org.apache.commons.lang.time.StopWatch", "split", ""}}, 3);
//   assertNotNull(actual);
//   assertEquals("java.lang.Long", actual.getClass().getName());
//   assertEquals("0", String.valueOf(actual));
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=0, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test
 public void generatedInput078() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput078() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "suspend", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}, {"org.apache.commons.lang.time.StopWatch", "split", ""}}, 3);
//   assertNull(actual);
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=0, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test
 public void generatedInput079() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput079() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "getSplitTime", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}, {"org.apache.commons.lang.time.StopWatch", "split", ""}}, 2);
//   assertNotNull(actual);
//   assertEquals("java.lang.Long", actual.getClass().getName());
//   assertEquals("0", String.valueOf(actual));
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=0, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test
 public void generatedInput080() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput080() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "resume", new String[]{}, new String[]{}, false, 2, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}, {"org.apache.commons.lang.time.StopWatch", "suspend", ""}}, 3);
//   assertNull(actual);
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=!IllegalStateException, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test
 public void generatedInput081() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput081() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "unsplit", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}, {"org.apache.commons.lang.time.StopWatch", "split", ""}}, 1);
//   assertNull(actual);
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=!IllegalStateException, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test
 public void generatedInput082() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput082() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "toString", new String[]{}, new String[]{}, false, 2, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}, {"org.apache.commons.lang.time.StopWatch", "split", ""}}, 3);
//   assertNotNull(actual);
//   assertEquals("java.lang.String", actual.getClass().getName());
//   assertEquals("0:00:00.000", String.valueOf(actual));
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=0, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test
 public void generatedInput083() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput083() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "getTime", new String[]{}, new String[]{}, false, 4, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}, {"org.apache.commons.lang.time.StopWatch", "toString", ""}}, 3);
//   assertNotNull(actual);
//   assertEquals("java.lang.Long", actual.getClass().getName());
//   assertEquals("0", String.valueOf(actual));
//   assertEquals("receiver state after the call", "0:00:00.001 {getSplitTime=!IllegalStateException, getTime=1}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test
 public void generatedInput084() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput084() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "toSplitString", new String[]{}, new String[]{}, false, 3, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}, {"org.apache.commons.lang.time.StopWatch", "split", ""}}, 2);
//   assertNotNull(actual);
//   assertEquals("java.lang.String", actual.getClass().getName());
//   assertEquals("0:00:00.000", String.valueOf(actual));
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=0, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test
 public void generatedInput085() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput085() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "unsplit", new String[]{}, new String[]{}, false, 7, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}, {"org.apache.commons.lang.time.StopWatch", "split", ""}}, 2);
//   assertNull(actual);
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=!IllegalStateException, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test
 public void generatedInput086() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput086() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "unsplit", new String[]{}, new String[]{}, false, 3, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}, {"org.apache.commons.lang.time.StopWatch", "split", ""}}, 3);
//   assertNull(actual);
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=!IllegalStateException, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
 @Test
 public void generatedInput087() {}
// Defects4J: flaky method
//  @Test(timeout = 20000)
//  public void generatedInput087() throws Throwable {
//   Object actual = SearchInputFactory_scaffolding.call("org.apache.commons.lang.time.StopWatch", "org.apache.commons.lang.time.StopWatch", "toSplitString", new String[]{}, new String[]{}, false, 0, new String[][]{{"org.apache.commons.lang.time.StopWatch", "start", ""}, {"org.apache.commons.lang.time.StopWatch", "split", ""}}, 3);
//   assertNotNull(actual);
//   assertEquals("java.lang.String", actual.getClass().getName());
//   assertEquals("0:00:00.000", String.valueOf(actual));
//   assertEquals("receiver state after the call", "0:00:00.000 {getSplitTime=0, getTime=0}", SearchInputFactory_scaffolding.receiverState());
//  }
}
