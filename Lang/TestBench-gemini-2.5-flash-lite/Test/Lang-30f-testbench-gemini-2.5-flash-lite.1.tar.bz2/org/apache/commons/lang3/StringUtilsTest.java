package org.apache.commons.lang3;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import org.apache.commons.lang3.text.WordUtils;

public class StringUtilsTest {

    @Test
    public void testIsEmpty_null() throws Exception {
        assertTrue(StringUtils.isEmpty(null));
    }

    @Test
    public void testIsEmpty_empty() throws Exception {
        assertTrue(StringUtils.isEmpty(""));
    }

    @Test
    public void testIsEmpty_notEmpty() throws Exception {
        assertFalse(StringUtils.isEmpty(" "));
        assertFalse(StringUtils.isEmpty("bob"));
    }

    @Test
    public void testIsNotEmpty_null() throws Exception {
        assertFalse(StringUtils.isNotEmpty(null));
    }

    @Test
    public void testIsNotEmpty_empty() throws Exception {
        assertFalse(StringUtils.isNotEmpty(""));
    }

    @Test
    public void testIsNotEmpty_notEmpty() throws Exception {
        assertTrue(StringUtils.isNotEmpty(" "));
        assertTrue(StringUtils.isNotEmpty("bob"));
    }

    @Test
    public void testIsBlank_null() throws Exception {
        assertTrue(StringUtils.isBlank(null));
    }

    @Test
    public void testIsBlank_empty() throws Exception {
        assertTrue(StringUtils.isBlank(""));
    }

    @Test
    public void testIsBlank_whitespace() throws Exception {
        assertTrue(StringUtils.isBlank(" "));
        assertTrue(StringUtils.isBlank(" \t\n\r\f"));
    }

    @Test
    public void testIsBlank_notBlank() throws Exception {
        assertFalse(StringUtils.isBlank("bob"));
        assertFalse(StringUtils.isBlank(" bob "));
    }

    @Test
    public void testIsNotBlank_null() throws Exception {
        assertFalse(StringUtils.isNotBlank(null));
    }

    @Test
    public void testIsNotBlank_empty() throws Exception {
        assertFalse(StringUtils.isNotBlank(""));
    }

    @Test
    public void testIsNotBlank_whitespace() throws Exception {
        assertFalse(StringUtils.isNotBlank(" "));
        assertFalse(StringUtils.isNotBlank("\t\n\r\f"));
    }

    @Test
    public void testIsNotBlank_notBlank() throws Exception {
        assertTrue(StringUtils.isNotBlank("bob"));
        assertTrue(StringUtils.isNotBlank(" bob "));
    }

    @Test
    public void testTrim_null() throws Exception {
        assertNull(StringUtils.trim(null));
    }

    @Test
    public void testTrim_empty() throws Exception {
        assertEquals("", StringUtils.trim(""));
    }

    @Test
    public void testTrim_whitespaceOnly() throws Exception {
        assertEquals("", StringUtils.trim("   "));
    }

    @Test
    public void testTrim_noWhitespace() throws Exception {
        assertEquals("abc", StringUtils.trim("abc"));
    }

    @Test
    public void testTrim_leadingTrailingWhitespace() throws Exception {
        assertEquals("abc", StringUtils.trim("    abc    "));
    }

    @Test
    public void testTrimToNull_null() throws Exception {
        assertNull(StringUtils.trimToNull(null));
    }

    @Test
    public void testTrimToNull_empty() throws Exception {
        assertNull(StringUtils.trimToNull(""));
    }

    @Test
    public void testTrimToNull_whitespaceOnly() throws Exception {
        assertNull(StringUtils.trimToNull("     "));
    }

    @Test
    public void testTrimToNull_noWhitespace() throws Exception {
        assertEquals("abc", StringUtils.trimToNull("abc"));
    }

    @Test
    public void testTrimToNull_leadingTrailingWhitespace() throws Exception {
        assertEquals("abc", StringUtils.trimToNull("    abc    "));
    }

    @Test
    public void testTrimToEmpty_null() throws Exception {
        assertEquals("", StringUtils.trimToEmpty(null));
    }

    @Test
    public void testTrimToEmpty_empty() throws Exception {
        assertEquals("", StringUtils.trimToEmpty(""));
    }

    @Test
    public void testTrimToEmpty_whitespaceOnly() throws Exception {
        assertEquals("", StringUtils.trimToEmpty("   "));
    }

    @Test
    public void testTrimToEmpty_noWhitespace() throws Exception {
        assertEquals("abc", StringUtils.trimToEmpty("abc"));
    }

    @Test
    public void testTrimToEmpty_leadingTrailingWhitespace() throws Exception {
        assertEquals("abc", StringUtils.trimToEmpty("    abc    "));
    }

    @Test
    public void testStrip_null() throws Exception {
        assertNull(StringUtils.strip(null));
    }

    @Test
    public void testStrip_empty() throws Exception {
        assertEquals("", StringUtils.strip(""));
    }

    @Test
    public void testStrip_whitespaceOnly() throws Exception {
        assertEquals("", StringUtils.strip("   "));
    }

    @Test
    public void testStrip_noWhitespace() throws Exception {
        assertEquals("abc", StringUtils.strip("abc"));
    }

    @Test
    public void testStrip_leadingWhitespace() throws Exception {
        assertEquals("abc", StringUtils.strip("  abc"));
    }

    @Test
    public void testStrip_trailingWhitespace() throws Exception {
        assertEquals("abc", StringUtils.strip("abc  "));
    }

    @Test
    public void testStrip_leadingAndTrailingWhitespace() throws Exception {
        assertEquals("abc", StringUtils.strip(" abc "));
    }

    @Test
    public void testStrip_internalWhitespace() throws Exception {
        assertEquals("ab c", StringUtils.strip(" ab c "));
    }

    @Test
    public void testStripToNull_null() throws Exception {
        assertNull(StringUtils.stripToNull(null));
    }

    @Test
    public void testStripToNull_empty() throws Exception {
        assertNull(StringUtils.stripToNull(""));
    }

    @Test
    public void testStripToNull_whitespaceOnly() throws Exception {
        assertNull(StringUtils.stripToNull("   "));
    }

    @Test
    public void testStripToNull_noWhitespace() throws Exception {
        assertEquals("abc", StringUtils.stripToNull("abc"));
    }

    @Test
    public void testStripToNull_leadingWhitespace() throws Exception {
        assertEquals("abc", StringUtils.stripToNull("  abc"));
    }

    @Test
    public void testStripToNull_trailingWhitespace() throws Exception {
        assertEquals("abc", StringUtils.stripToNull("abc  "));
    }

    @Test
    public void testStripToNull_leadingAndTrailingWhitespace() throws Exception {
        assertEquals("abc", StringUtils.stripToNull(" abc "));
    }

    @Test
    public void testStripToNull_internalWhitespace() throws Exception {
        assertEquals("ab c", StringUtils.stripToNull(" ab c "));
    }

    @Test
    public void testStripToEmpty_null() throws Exception {
        assertEquals("", StringUtils.stripToEmpty(null));
    }

    @Test
    public void testStripToEmpty_empty() throws Exception {
        assertEquals("", StringUtils.stripToEmpty(""));
    }

    @Test
    public void testStripToEmpty_whitespaceOnly() throws Exception {
        assertEquals("", StringUtils.stripToEmpty("   "));
    }

    @Test
    public void testStripToEmpty_noWhitespace() throws Exception {
        assertEquals("abc", StringUtils.stripToEmpty("abc"));
    }

    @Test
    public void testStripToEmpty_leadingWhitespace() throws Exception {
        assertEquals("abc", StringUtils.stripToEmpty("  abc"));
    }

    @Test
    public void testStripToEmpty_trailingWhitespace() throws Exception {
        assertEquals("abc", StringUtils.stripToEmpty("abc  "));
    }

    @Test
    public void testStripToEmpty_leadingAndTrailingWhitespace() throws Exception {
        assertEquals("abc", StringUtils.stripToEmpty(" abc "));
    }

    @Test
    public void testStripToEmpty_internalWhitespace() throws Exception {
        assertEquals("ab c", StringUtils.stripToEmpty(" ab c "));
    }

    @Test
    public void testStrip_specificChars_nullString() throws Exception {
        assertNull(StringUtils.strip("abc", null)); // strip() uses null stripChars, strip(str, null)
    }
    
    @Test
    public void testStrip_specificChars_emptyString() throws Exception {
        assertEquals("", StringUtils.strip("", "abc"));
    }

    @Test
    public void testStrip_specificChars_emptyStripChars() throws Exception {
        assertEquals("abc", StringUtils.strip("abc", ""));
    }
    
    @Test
    public void testStrip_specificChars_noMatch() throws Exception {
        assertEquals("abc", StringUtils.strip("abc", "xyz"));
    }

    @Test
    public void testStrip_specificChars_leadingMatch() throws Exception {
        assertEquals("abc", StringUtils.strip("xyzabc", "xyz"));
    }

    @Test
    public void testStrip_specificChars_trailingMatch() throws Exception {
        assertEquals("abc", StringUtils.strip("abcxyz", "xyz"));
    }

    @Test
    public void testStrip_specificChars_bothMatch() throws Exception {
        assertEquals("abc", StringUtils.strip("xyzabcxyz", "xyz"));
    }

    @Test
    public void testStrip_specificChars_internalMatch() throws Exception {
        assertEquals("abcyx", StringUtils.strip("  abcyx", " xyz"));
    }
    
    @Test
    public void testStripStart_nullString() throws Exception {
        assertNull(StringUtils.stripStart(null, "abc"));
    }

    @Test
    public void testStripStart_emptyString() throws Exception {
        assertEquals("", StringUtils.stripStart("", "abc"));
    }

    @Test
    public void testStripStart_emptyStripChars() throws Exception {
        assertEquals("abc", StringUtils.stripStart("abc", ""));
    }

    @Test
    public void testStripStart_noMatch() throws Exception {
        assertEquals("abc", StringUtils.stripStart("abc", "xyz"));
    }

    @Test
    public void testStripStart_leadingMatch() throws Exception {
        assertEquals("abc", StringUtils.stripStart("xyzabc", "xyz"));
    }

    @Test
    public void testStripStart_trailingMatch() throws Exception {
        assertEquals("abc  ", StringUtils.stripStart("abc  ", "xyz"));
    }

    @Test
    public void testStripStart_bothMatch() throws Exception {
        assertEquals("abc  ", StringUtils.stripStart("xyzabc  ", "xyz"));
    }
    
    @Test
    public void testStripStart_nullStripChars() throws Exception {
        assertEquals("abc", StringUtils.stripStart("  abc", null));
    }

    @Test
    public void testStripEnd_nullString() throws Exception {
        assertNull(StringUtils.stripEnd(null, "abc"));
    }

    @Test
    public void testStripEnd_emptyString() throws Exception {
        assertEquals("", StringUtils.stripEnd("", "abc"));
    }

    @Test
    public void testStripEnd_emptyStripChars() throws Exception {
        assertEquals("abc", StringUtils.stripEnd("abc", ""));
    }

    @Test
    public void testStripEnd_noMatch() throws Exception {
        assertEquals("abc", StringUtils.stripEnd("abc", "xyz"));
    }

    @Test
    public void testStripEnd_leadingMatch() throws Exception {
        assertEquals("  abc", StringUtils.stripEnd("  abc", "xyz"));
    }

    @Test
    public void testStripEnd_trailingMatch() throws Exception {
        assertEquals("abc", StringUtils.stripEnd("abcxyz", "xyz"));
    }

    @Test
    public void testStripEnd_bothMatch() throws Exception {
        assertEquals("abc", StringUtils.stripEnd("  abcyx", "xyz"));
    }
    
    @Test
    public void testStripEnd_nullStripChars() throws Exception {
        assertEquals("abc", StringUtils.stripEnd("abc  ", null));
    }

    @Test
    public void testStripAll_nullArray() throws Exception {
        assertNull(StringUtils.stripAll((String[]) null));
    }

    @Test
    public void testStripAll_emptyArray() throws Exception {
        assertArrayEquals(new String[]{}, StringUtils.stripAll(new String[]{}));
    }

    @Test
    public void testStripAll_arrayWithNulls() throws Exception {
        String[] input = {"abc", null, "  def  "};
        String[] expected = {"abc", null, "def"};
        assertArrayEquals(expected, StringUtils.stripAll(input));
    }

    @Test
    public void testStripAll_withStripChars_nullArray() throws Exception {
        assertNull(StringUtils.stripAll((String[]) null, "xyz"));
    }

    @Test
    public void testStripAll_withStripChars_emptyArray() throws Exception {
        assertArrayEquals(new String[]{}, StringUtils.stripAll(new String[]{}, "xyz"));
    }
    
    @Test
    public void testStripAll_withStripChars_arrayWithNulls() throws Exception {
        String[] input = {"xyzabcxyz", null, "yzdefzyx", "abc"};
        String[] expected = {"abc", null, "def", "abc"};
        assertArrayEquals(expected, StringUtils.stripAll(input, "xyz"));
    }

    @Test
    public void testEquals_nullNull() throws Exception {
        assertTrue(StringUtils.equals(null, null));
    }

    @Test
    public void testEquals_nullNonNull() throws Exception {
        assertFalse(StringUtils.equals(null, "abc"));
    }

    @Test
    public void testEquals_nonNullNull() throws Exception {
        assertFalse(StringUtils.equals("abc", null));
    }

    @Test
    public void testEquals_equal() throws Exception {
        assertTrue(StringUtils.equals("abc", "abc"));
    }

    @Test
    public void testEquals_notEqual() throws Exception {
        assertFalse(StringUtils.equals("abc", "ABC"));
    }
    
    @Test
    public void testEqualsIgnoreCase_nullNull() throws Exception {
        assertTrue(StringUtils.equalsIgnoreCase(null, null));
    }

    @Test
    public void testEqualsIgnoreCase_nullNonNull() throws Exception {
        assertFalse(StringUtils.equalsIgnoreCase(null, "abc"));
    }

    @Test
    public void testEqualsIgnoreCase_nonNullNull() throws Exception {
        assertFalse(StringUtils.equalsIgnoreCase("abc", null));
    }

    @Test
    public void testEqualsIgnoreCase_equal() throws Exception {
        assertTrue(StringUtils.equalsIgnoreCase("abc", "abc"));
    }

    @Test
    public void testEqualsIgnoreCase_notEqualIgnoreCase() throws Exception {
        assertTrue(StringUtils.equalsIgnoreCase("abc", "ABC"));
    }

    @Test
    public void testIndexOf_nullString() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOf(null, 'a'));
    }

    @Test
    public void testIndexOf_emptyString() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOf("", 'a'));
    }

    @Test
    public void testIndexOf_charFound() throws Exception {
        assertEquals(0, StringUtils.indexOf("aabaabaa", 'a'));
        assertEquals(2, StringUtils.indexOf("aabaabaa", 'b'));
    }

    @Test
    public void testIndexOf_charNotFound() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOf("aabaabaa", 'z'));
    }

    @Test
    public void testIndexOf_nullStringWithPos() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOf(null, 'a', 0));
    }

    @Test
    public void testIndexOf_emptyStringWithPos() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOf("", 'a', 0));
    }

    @Test
    public void testIndexOf_charFoundWithPos() throws Exception {
        assertEquals(2, StringUtils.indexOf("aabaabaa", 'b', 0));
        assertEquals(5, StringUtils.indexOf("aabaabaa", 'b', 3));
    }

    @Test
    public void testIndexOf_charNotFoundWithPos() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOf("aabaabaa", 'b', 9));
    }

    @Test
    public void testIndexOf_charFoundNegativeStartPos() throws Exception {
        assertEquals(2, StringUtils.indexOf("aabaabaa", 'b', -1));
    }
    
    @Test
    public void testIndexOf_nullStringSub() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOf(null, "a"));
    }

    @Test
    public void testIndexOf_nullSub() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOf("abc", null));
    }

    @Test
    public void testIndexOf_emptyStringAndEmptySub() throws Exception {
        assertEquals(0, StringUtils.indexOf("", ""));
    }
    
    @Test
    public void testIndexOf_emptyString() throws Exception {
        assertEquals(-1, StringUtils.indexOf("", "a"));
    }
    
    @Test
    public void testIndexOf_stringFound() throws Exception {
        assertEquals(0, StringUtils.indexOf("aabaabaa", "a"));
        assertEquals(2, StringUtils.indexOf("aabaabaa", "b"));
        assertEquals(1, StringUtils.indexOf("aabaabaa", "ab"));
    }

    @Test
    public void testIndexOf_stringNotFound() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOf("aabaabaa", "z"));
    }

    @Test
    public void testIndexOf_emptySub() throws Exception {
        assertEquals(0, StringUtils.indexOf("aabaabaa", ""));
    }

    @Test
    public void testIndexOf_nullStringSubWithPos() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOf(null, "a", 0));
    }

    @Test
    public void testIndexOf_nullSubWithPos() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOf("abc", null, 0));
    }

    @Test
    public void testIndexOf_emptyStringAndEmptySubWithPos() throws Exception {
        assertEquals(0, StringUtils.indexOf("", "", 0));
    }
    
    @Test
    public void testIndexOf_emptyStringWithPos() throws Exception {
        assertEquals(-1, StringUtils.indexOf("", "a", 0));
    }

    @Test
    public void testIndexOf_stringFoundWithPos() throws Exception {
        assertEquals(0, StringUtils.indexOf("aabaabaa", "a", 0));
        assertEquals(2, StringUtils.indexOf("aabaabaa", "b", 0));
        assertEquals(1, StringUtils.indexOf("aabaabaa", "ab", 0));
    }

    @Test
    public void testIndexOf_stringFoundWithPosOffset() throws Exception {
        assertEquals(5, StringUtils.indexOf("aabaabaa", "b", 3));
    }

    @Test
    public void testIndexOf_stringNotFoundWithPos() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOf("aabaabaa", "b", 9));
    }

    @Test
    public void testIndexOf_stringFoundNegativeStartPos() throws Exception {
        assertEquals(2, StringUtils.indexOf("aabaabaa", "b", -1));
    }

    @Test
    public void testIndexOf_emptySubWithPos() throws Exception {
        assertEquals(2, StringUtils.indexOf("aabaabaa", "", 2));
    }

    @Test
    public void testIndexOf_emptySubBeyondLength() throws Exception {
        assertEquals(3, StringUtils.indexOf("abc", "", 9));
    }
    
    @Test
    public void testOrdinalIndexOf_nullString() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.ordinalIndexOf(null, "a", 1));
    }

    @Test
    public void testOrdinalIndexOf_nullSearchString() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.ordinalIndexOf("abc", null, 1));
    }

    @Test
    public void testOrdinalIndexOf_zeroOrdinal() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.ordinalIndexOf("abc", "a", 0));
    }

    @Test
    public void testOrdinalIndexOf_emptyStringAndEmptySearchString() throws Exception {
        assertEquals(0, StringUtils.ordinalIndexOf("", "", 1));
    }
    
    @Test
    public void testOrdinalIndexOf_emptyString() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.ordinalIndexOf("", "a", 1));
    }

    @Test
    public void testOrdinalIndexOf_emptySearchString() throws Exception {
        assertEquals(0, StringUtils.ordinalIndexOf("aabaabaa", "", 1));
        assertEquals(0, StringUtils.ordinalIndexOf("aabaabaa", "", 2));
    }

    @Test
    public void testOrdinalIndexOf_found() throws Exception {
        assertEquals(0, StringUtils.ordinalIndexOf("aabaabaa", "a", 1));
        assertEquals(1, StringUtils.ordinalIndexOf("aabaabaa", "a", 2));
        assertEquals(2, StringUtils.ordinalIndexOf("aabaabaa", "b", 1));
        assertEquals(5, StringUtils.ordinalIndexOf("aabaabaa", "b", 2));
        assertEquals(1, StringUtils.ordinalIndexOf("aabaabaa", "ab", 1));
        assertEquals(4, StringUtils.ordinalIndexOf("aabaabaa", "ab", 2));
    }

    @Test
    public void testOrdinalIndexOf_notFound() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.ordinalIndexOf("aabaabaa", "z", 1));
    }

    @Test
    public void testIndexOfIgnoreCase_nullString() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfIgnoreCase(null, "a"));
    }

    @Test
    public void testIndexOfIgnoreCase_nullSearchString() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfIgnoreCase("abc", null));
    }

    @Test
    public void testIndexOfIgnoreCase_emptyStringAndEmptySearchString() throws Exception {
        assertEquals(0, StringUtils.indexOfIgnoreCase("", ""));
    }

    @Test
    public void testIndexOfIgnoreCase_emptyString() throws Exception {
        assertEquals(-1, StringUtils.indexOfIgnoreCase("", "a"));
    }

    @Test
    public void testIndexOfIgnoreCase_stringFound() throws Exception {
        assertEquals(0, StringUtils.indexOfIgnoreCase("aabaabaa", "a"));
        assertEquals(2, StringUtils.indexOfIgnoreCase("aabaabaa", "b"));
        assertEquals(1, StringUtils.indexOfIgnoreCase("aabaabaa", "ab"));
    }

    @Test
    public void testIndexOfIgnoreCase_stringFoundIgnoreCase() throws Exception {
        assertEquals(0, StringUtils.indexOfIgnoreCase("aabaabaa", "A"));
        assertEquals(2, StringUtils.indexOfIgnoreCase("aabaabaa", "B"));
        assertEquals(1, StringUtils.indexOfIgnoreCase("aabaabaa", "AB"));
    }

    @Test
    public void testIndexOfIgnoreCase_stringNotFound() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfIgnoreCase("aabaabaa", "z"));
    }

    @Test
    public void testIndexOfIgnoreCase_emptySearchString() throws Exception {
        assertEquals(0, StringUtils.indexOfIgnoreCase("aabaabaa", ""));
    }

    @Test
    public void testIndexOfIgnoreCase_nullStringWithPos() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfIgnoreCase(null, "a", 0));
    }

    @Test
    public void testIndexOfIgnoreCase_nullSearchStringWithPos() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfIgnoreCase("abc", null, 0));
    }

    @Test
    public void testIndexOfIgnoreCase_emptyStringAndEmptySearchStringWithPos() throws Exception {
        assertEquals(0, StringUtils.indexOfIgnoreCase("", "", 0));
    }
    
    @Test
    public void testIndexOfIgnoreCase_emptyStringWithPos() throws Exception {
        assertEquals(-1, StringUtils.indexOfIgnoreCase("", "a", 0));
    }

    @Test
    public void testIndexOfIgnoreCase_stringFoundWithPos() throws Exception {
        assertEquals(0, StringUtils.indexOfIgnoreCase("aabaabaa", "A", 0));
        assertEquals(2, StringUtils.indexOfIgnoreCase("aabaabaa", "B", 0));
        assertEquals(1, StringUtils.indexOfIgnoreCase("aabaabaa", "AB", 0));
    }
    
    @Test
    public void testIndexOfIgnoreCase_stringFoundWithPosOffset() throws Exception {
        assertEquals(5, StringUtils.indexOfIgnoreCase("aabaabaa", "B", 3));
    }

    @Test
    public void testIndexOfIgnoreCase_stringNotFoundWithPos() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfIgnoreCase("aabaabaa", "B", 9));
    }

    @Test
    public void testIndexOfIgnoreCase_stringFoundNegativeStartPos() throws Exception {
        assertEquals(2, StringUtils.indexOfIgnoreCase("aabaabaa", "B", -1));
    }

    @Test
    public void testIndexOfIgnoreCase_emptySearchStringWithPos() throws Exception {
        assertEquals(2, StringUtils.indexOfIgnoreCase("aabaabaa", "", 2));
    }

    @Test
    public void testIndexOfIgnoreCase_emptySearchStringBeyondLength() throws Exception {
        assertEquals(3, StringUtils.indexOfIgnoreCase("abc", "", 9));
    }

    @Test
    public void testLastIndexOf_nullString() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.lastIndexOf(null, 'a'));
    }

    @Test
    public void testLastIndexOf_emptyString() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.lastIndexOf("", 'a'));
    }

    @Test
    public void testLastIndexOf_charFound() throws Exception {
        assertEquals(7, StringUtils.lastIndexOf("aabaabaa", 'a'));
        assertEquals(5, StringUtils.lastIndexOf("aabaabaa", 'b'));
    }

    @Test
    public void testLastIndexOf_charNotFound() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.lastIndexOf("aabaabaa", 'z'));
    }

    @Test
    public void testLastIndexOf_nullStringWithPos() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.lastIndexOf(null, 'a', 8));
    }

    @Test
    public void testLastIndexOf_emptyStringWithPos() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.lastIndexOf("", 'a', 0));
    }

    @Test
    public void testLastIndexOf_charFoundWithPos() throws Exception {
        assertEquals(5, StringUtils.lastIndexOf("aabaabaa", 'b', 8));
        assertEquals(2, StringUtils.lastIndexOf("aabaabaa", 'b', 4));
    }

    @Test
    public void testLastIndexOf_charFoundNegativeStartPos() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.lastIndexOf("aabaabaa", 'b', -1));
    }

    @Test
    public void testLastIndexOf_charFoundStartOfLongerString() throws Exception {
        assertEquals(0, StringUtils.lastIndexOf("aabaabaa", 'a', 0));
    }

    @Test
    public void testLastIndexOf_nullStringSub() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.lastIndexOf(null, "a"));
    }

    @Test
    public void testLastIndexOf_nullSub() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.lastIndexOf("abc", null));
    }

    @Test
    public void testLastIndexOf_emptyStringAndEmptySub() throws Exception {
        assertEquals(0, StringUtils.lastIndexOf("", ""));
    }

    @Test
    public void testLastIndexOf_stringFound() throws Exception {
        assertEquals(0, StringUtils.lastIndexOf("aabaabaa", "a"));
        assertEquals(2, StringUtils.lastIndexOf("aabaabaa", "b"));
        assertEquals(1, StringUtils.lastIndexOf("aabaabaa", "ab"));
    }

    @Test
    public void testLastIndexOf_emptySub() throws Exception {
        assertEquals(8, StringUtils.lastIndexOf("aabaabaa", ""));
    }

    @Test
    public void testLastIndexOf_nullStringSubWithPos() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.lastIndexOf(null, "a", 8));
    }

    @Test
    public void testLastIndexOf_nullSubWithPos() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.lastIndexOf("abc", null, 8));
    }

    @Test
    public void testLastIndexOf_stringFoundWithPos() throws Exception {
        assertEquals(7, StringUtils.lastIndexOf("aabaabaa", "a", 8));
        assertEquals(5, StringUtils.lastIndexOf("aabaabaa", "b", 8));
        assertEquals(4, StringUtils.lastIndexOf("aabaabaa", "ab", 8));
    }

    @Test
    public void testLastIndexOf_stringFoundNegativeStartPos() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.lastIndexOf("aabaabaa", "b", -1));
    }

    @Test
    public void testLastIndexOf_stringFoundStartOfLongerString() throws Exception {
        assertEquals(0, StringUtils.lastIndexOf("aabaabaa", "a", 0));
        assertEquals(-1, StringUtils.lastIndexOf("aabaabaa", "b", 0));
    }

    @Test
    public void testLastIndexOfIgnoreCase_nullString() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.lastIndexOfIgnoreCase(null, "a"));
    }

    @Test
    public void testLastIndexOfIgnoreCase_nullSearchString() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.lastIndexOfIgnoreCase("abc", null));
    }

    @Test
    public void testLastIndexOfIgnoreCase_stringFound() throws Exception {
        assertEquals(7, StringUtils.lastIndexOfIgnoreCase("aabaabaa", "A"));
        assertEquals(5, StringUtils.lastIndexOfIgnoreCase("aabaabaa", "B"));
        assertEquals(4, StringUtils.lastIndexOfIgnoreCase("aabaabaa", "AB"));
    }

    @Test
    public void testLastIndexOfIgnoreCase_stringNotFound() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.lastIndexOfIgnoreCase("aabaabaa", "Z"));
    }

    @Test
    public void testLastIndexOfIgnoreCase_emptySearchString() throws Exception {
        assertEquals(8, StringUtils.lastIndexOfIgnoreCase("aabaabaa", ""));
    }

    @Test
    public void testLastIndexOfIgnoreCase_nullStringWithPos() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.lastIndexOfIgnoreCase(null, "a", 8));
    }

    @Test
    public void testLastIndexOfIgnoreCase_nullSearchStringWithPos() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.lastIndexOfIgnoreCase("abc", null, 8));
    }

    @Test
    public void testLastIndexOfIgnoreCase_stringFoundWithPos() throws Exception {
        assertEquals(7, StringUtils.lastIndexOfIgnoreCase("aabaabaa", "A", 8));
        assertEquals(5, StringUtils.lastIndexOfIgnoreCase("aabaabaa", "B", 8));
        assertEquals(4, StringUtils.lastIndexOfIgnoreCase("aabaabaa", "AB", 8));
    }

    @Test
    public void testLastIndexOfIgnoreCase_stringFoundWithPosOffset() throws Exception {
        assertEquals(5, StringUtils.lastIndexOfIgnoreCase("aabaabaa", "B", 9)); // StartPos > length - suffix.length()
    }

    @Test
    public void testLastIndexOfIgnoreCase_stringFoundNegativeStartPos() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.lastIndexOfIgnoreCase("aabaabaa", "B", -1));
    }

    @Test
    public void testLastIndexOfIgnoreCase_stringFoundStartOfLongerString() throws Exception {
        assertEquals(0, StringUtils.lastIndexOfIgnoreCase("aabaabaa", "A", 0));
        assertEquals(INDEX_NOT_FOUND, StringUtils.lastIndexOfIgnoreCase("aabaabaa", "B", 0));
    }

    @Test
    public void testContains_nullString() throws Exception {
        assertFalse(StringUtils.contains(null, 'a'));
    }

    @Test
    public void testContains_emptyString() throws Exception {
        assertFalse(StringUtils.contains("", 'a'));
    }

    @Test
    public void testContains_charFound() throws Exception {
        assertTrue(StringUtils.contains("abc", 'a'));
    }

    @Test
    public void testContains_charNotFound() throws Exception {
        assertFalse(StringUtils.contains("abc", 'z'));
    }

    @Test
    public void testContains_nullStringSub() throws Exception {
        assertFalse(StringUtils.contains(null, "a"));
    }

    @Test
    public void testContains_nullSub() throws Exception {
        assertFalse(StringUtils.contains("abc", null));
    }

    @Test
    public void testContains_emptyStringAndEmptySub() throws Exception {
        assertTrue(StringUtils.contains("", ""));
    }

    @Test
    public void testContains_emptySub() throws Exception {
        assertTrue(StringUtils.contains("abc", ""));
    }

    @Test
    public void testContains_stringFound() throws Exception {
        assertTrue(StringUtils.contains("abc", "a"));
    }

    @Test
    public void testContains_stringNotFound() throws Exception {
        assertFalse(StringUtils.contains("abc", "z"));
    }

    @Test
    public void testContainsIgnoreCase_nullString() throws Exception {
        assertFalse(StringUtils.containsIgnoreCase(null, "a"));
    }

    @Test
    public void testContainsIgnoreCase_nullSearchString() throws Exception {
        assertFalse(StringUtils.containsIgnoreCase("abc", null));
    }

    @Test
    public void testContainsIgnoreCase_emptyStringAndEmptySearchString() throws Exception {
        assertTrue(StringUtils.containsIgnoreCase("", ""));
    }

    @Test
    public void testContainsIgnoreCase_emptyString() throws Exception {
        assertTrue(StringUtils.containsIgnoreCase("abc", ""));
    }

    @Test
    public void testContainsIgnoreCase_stringFound() throws Exception {
        assertTrue(StringUtils.containsIgnoreCase("abc", "a"));
        assertTrue(StringUtils.containsIgnoreCase("abc", "A"));
    }

    @Test
    public void testContainsIgnoreCase_stringNotFound() throws Exception {
        assertFalse(StringUtils.containsIgnoreCase("abc", "z"));
        assertFalse(StringUtils.containsIgnoreCase("abc", "Z"));
    }

    @Test
    public void testIndexOfAny_nullCharSequence() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAny(null, new char[]{'a'}));
    }

    @Test
    public void testIndexOfAny_emptyCharSequence() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAny("", new char[]{'a'}));
    }

    @Test
    public void testIndexOfAny_nullSearchChars() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAny("abc", null));
    }

    @Test
    public void testIndexOfAny_emptySearchChars() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAny("abc", new char[]{}));
    }

    @Test
    public void testIndexOfAny_found() throws Exception {
        assertEquals(0, StringUtils.indexOfAny("zzabyycdxx", new char[]{'z', 'a'}));
        assertEquals(3, StringUtils.indexOfAny("zzabyycdxx", new char[]{'b', 'y'}));
    }

    @Test
    public void testIndexOfAny_notFound() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAny("aba", new char[]{'z'}));
    }

    @Test
    public void testIndexOfAny_withSupplementaryChar() throws Exception {
        // U+1F4A9 (Pile of Poo)
        char highSurrogate = '\uD83D';
        char lowSurrogate = '\uDCA9';
        assertEquals(0, StringUtils.indexOfAny(new String(new char[]{highSurrogate, lowSurrogate, 'a'}), new char[]{highSurrogate, lowSurrogate}));
        assertEquals(2, StringUtils.indexOfAny(new String(new char[]{highSurrogate, lowSurrogate, 'a'}), new char[]{'a'}));
    }

    @Test
    public void testIndexOfAny_CharSequence_String_nullCharSequence() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAny(null, "za"));
    }

    @Test
    public void testIndexOfAny_CharSequence_String_emptyCharSequence() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAny("", "za"));
    }

    @Test
    public void testIndexOfAny_CharSequence_String_nullSearchString() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAny("abc", null));
    }

    @Test
    public void testIndexOfAny_CharSequence_String_emptySearchString() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAny("abc", ""));
    }

    @Test
    public void testIndexOfAny_CharSequence_String_found() throws Exception {
        assertEquals(0, StringUtils.indexOfAny("zzabyycdxx", "za"));
        assertEquals(3, StringUtils.indexOfAny("zzabyycdxx", "by"));
    }

    @Test
    public void testIndexOfAny_CharSequence_String_notFound() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAny("aba", "z"));
    }

    @Test
    public void testContainsAny_nullCharSequence() throws Exception {
        assertFalse(StringUtils.containsAny(null, new char[]{'a'}));
    }

    @Test
    public void testContainsAny_emptyCharSequence() throws Exception {
        assertFalse(StringUtils.containsAny("", new char[]{'a'}));
    }

    @Test
    public void testContainsAny_nullSearchChars() throws Exception {
        assertFalse(StringUtils.containsAny("abc", null));
    }

    @Test
    public void testContainsAny_emptySearchChars() throws Exception {
        assertFalse(StringUtils.containsAny("abc", new char[]{}));
    }

    @Test
    public void testContainsAny_found() throws Exception {
        assertTrue(StringUtils.containsAny("zzabyycdxx", new char[]{'z', 'a'}));
        assertTrue(StringUtils.containsAny("zzabyycdxx", new char[]{'b', 'y'}));
    }

    @Test
    public void testContainsAny_notFound() throws Exception {
        assertFalse(StringUtils.containsAny("aba", new char[]{'z'}));
    }

    @Test
    public void testContainsAny_withSupplementaryChar() throws Exception {
        char highSurrogate = '\uD83D';
        char lowSurrogate = '\uDCA9';
        assertTrue(StringUtils.containsAny(new String(new char[]{highSurrogate, lowSurrogate, 'a'}), new char[]{highSurrogate, lowSurrogate}));
        assertTrue(StringUtils.containsAny(new String(new char[]{highSurrogate, lowSurrogate, 'a'}), new char[]{'a'}));
        assertFalse(StringUtils.containsAny(new String(new char[]{highSurrogate, lowSurrogate, 'a'}), new char[]{'b'}));
    }

    @Test
    public void testContainsAny_String_nullCharSequence() throws Exception {
        assertFalse(StringUtils.containsAny(null, "za"));
    }

    @Test
    public void testContainsAny_String_emptyCharSequence() throws Exception {
        assertFalse(StringUtils.containsAny("", "za"));
    }

    @Test
    public void testContainsAny_String_nullSearchString() throws Exception {
        assertFalse(StringUtils.containsAny("abc", null));
    }

    @Test
    public void testContainsAny_String_found() throws Exception {
        assertTrue(StringUtils.containsAny("zzabyycdxx", "za"));
        assertTrue(StringUtils.containsAny("zzabyycdxx", "by"));
    }

    @Test
    public void testContainsAny_String_notFound() throws Exception {
        assertFalse(StringUtils.containsAny("aba", "z"));
    }

    @Test
    public void testIndexOfAnyBut_nullCharSequence() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAnyBut(null, new char[]{'a'}));
    }

    @Test
    public void testIndexOfAnyBut_emptyCharSequence() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAnyBut("", new char[]{'a'}));
    }

    @Test
    public void testIndexOfAnyBut_nullSearchChars() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAnyBut("abc", null));
    }

    @Test
    public void testIndexOfAnyBut_emptySearchChars() throws Exception {
        assertEquals(0, StringUtils.indexOfAnyBut("abc", new char[]{}));
    }

    @Test
    public void testIndexOfAnyBut_found() throws Exception {
        assertEquals(3, StringUtils.indexOfAnyBut("zzabyycdxx", new char[]{'z', 'a'}));
        assertEquals(0, StringUtils.indexOfAnyBut("zzabyycdxx", new char[]{'b', 'y'}));
    }

    @Test
    public void testIndexOfAnyBut_notFound() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAnyBut("aba", new char[]{'a', 'b'}));
    }

    @Test
    public void testIndexOfAnyBut_withSupplementaryChar() throws Exception {
        char highSurrogate = '\uD83D';
        char lowSurrogate = '\uDCA9';
        // Test where the supplementary char is the first character not in stripChars
        assertEquals(0, StringUtils.indexOfAnyBut(new String(new char[]{highSurrogate, lowSurrogate, 'a'}), new char[]{'a'}));
        // Test where a normal char is the first character not in stripChars
        assertEquals(2, StringUtils.indexOfAnyBut(new String(new char[]{highSurrogate, lowSurrogate, 'a'}), new char[]{highSurrogate, lowSurrogate}));
    }


    @Test
    public void testIndexOfAnyBut_String_nullCharSequence() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAnyBut(null, "za"));
    }

    @Test
    public void testIndexOfAnyBut_String_emptyCharSequence() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAnyBut("", "za"));
    }

    @Test
    public void testIndexOfAnyBut_String_nullSearchString() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAnyBut("abc", null));
    }

    @Test
    public void testIndexOfAnyBut_String_emptySearchString() throws Exception {
        assertEquals(0, StringUtils.indexOfAnyBut("zzabyycdxx", ""));
    }

    @Test
    public void testIndexOfAnyBut_String_found() throws Exception {
        assertEquals(3, StringUtils.indexOfAnyBut("zzabyycdxx", "za"));
        assertEquals(0, StringUtils.indexOfAnyBut("zzabyycdxx", "by"));
    }

    @Test
    public void testIndexOfAnyBut_String_notFound() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAnyBut("aba", "ab"));
    }
    
    @Test
    public void testContainsOnly_nullCharSequence() throws Exception {
        assertFalse(StringUtils.containsOnly(null, new char[]{'a'}));
    }

    @Test
    public void testContainsOnly_nullValidChars() throws Exception {
        assertFalse(StringUtils.containsOnly("abc", (char[]) null));
    }

    @Test
    public void testContainsOnly_emptyCharSequence() throws Exception {
        assertTrue(StringUtils.containsOnly("", new char[]{'a'}));
    }

    @Test
    public void testContainsOnly_emptyValidChars() throws Exception {
        assertFalse(StringUtils.containsOnly("ab", new char[]{}));
    }

    @Test
    public void testContainsOnly_validCharsMatch() throws Exception {
        assertTrue(StringUtils.containsOnly("abab", new char[]{'a', 'b'}));
    }

    @Test
    public void testContainsOnly_validCharsNoMatch() throws Exception {
        assertFalse(StringUtils.containsOnly("ab1", new char[]{'a', 'b'}));
    }
    
    @Test
    public void testContainsOnly_CharSequence_String_nullCharSequence() throws Exception {
        assertFalse(StringUtils.containsOnly(null, "abc"));
    }

    @Test
    public void testContainsOnly_CharSequence_String_nullValidChars() throws Exception {
        assertFalse(StringUtils.containsOnly("abc", null));
    }

    @Test
    public void testContainsOnly_CharSequence_String_emptyCharSequence() throws Exception {
        assertTrue(StringUtils.containsOnly("", "abc"));
    }

    @Test
    public void testContainsOnly_CharSequence_String_emptyValidChars() throws Exception {
        assertFalse(StringUtils.containsOnly("ab", ""));
    }

    @Test
    public void testContainsOnly_CharSequence_String_validCharsMatch() throws Exception {
        assertTrue(StringUtils.containsOnly("abab", "abc"));
    }

    @Test
    public void testContainsOnly_CharSequence_String_validCharsNoMatch() throws Exception {
        assertFalse(StringUtils.containsOnly("ab1", "abc"));
    }
    
    @Test
    public void testContainsNone_nullCharSequence() throws Exception {
        assertTrue(StringUtils.containsNone(null, new char[]{'a'}));
    }

    @Test
    public void testContainsNone_nullSearchChars() throws Exception {
        assertTrue(StringUtils.containsNone("abc", null));
    }

    @Test
    public void testContainsNone_emptyCharSequence() throws Exception {
        assertTrue(StringUtils.containsNone("", new char[]{'a'}));
    }

    @Test
    public void testContainsNone_emptySearchChars() throws Exception {
        assertTrue(StringUtils.containsNone("ab", new char[]{}));
    }

    @Test
    public void testContainsNone_foundInvalid() throws Exception {
        assertFalse(StringUtils.containsNone("abz", new char[]{'x', 'y', 'z'}));
    }

    @Test
    public void testContainsNone_noInvalidFound() throws Exception {
        assertTrue(StringUtils.containsNone("abab", new char[]{'x', 'y', 'z'}));
    }

    @Test
    public void testContainsNone_withSupplementaryChar() throws Exception {
        char highSurrogate = '\uD83D';
        char lowSurrogate = '\uDCA9';
        // String contains the supplementary character, searchChars does not
        assertTrue(StringUtils.containsNone(new String(new char[]{highSurrogate, lowSurrogate, 'a'}), new char[]{'b'}));
        // String contains the supplementary character, searchChars does contain it
        assertFalse(StringUtils.containsNone(new String(new char[]{highSurrogate, lowSurrogate, 'a'}), new char[]{highSurrogate, lowSurrogate}));
    }

    @Test
    public void testContainsNone_String_nullCharSequence() throws Exception {
        assertTrue(StringUtils.containsNone(null, "xyz"));
    }

    @Test
    public void testContainsNone_String_nullInvalidChars() throws Exception {
        assertTrue(StringUtils.containsNone("abc", null));
    }

    @Test
    public void testContainsNone_String_emptyCharSequence() throws Exception {
        assertTrue(StringUtils.containsNone("", "xyz"));
    }

    @Test
    public void testContainsNone_String_emptyInvalidChars() throws Exception {
        assertTrue(StringUtils.containsNone("ab", ""));
    }

    @Test
    public void testContainsNone_String_foundInvalid() throws Exception {
        assertFalse(StringUtils.containsNone("abz", "xyz"));
    }

    @Test
    public void testContainsNone_String_noInvalidFound() throws Exception {
        assertTrue(StringUtils.containsNone("abab", "xyz"));
    }

    @Test
    public void testIndexOfAny_StringArray_nullString() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAny(null, new String[]{"a"}));
    }

    @Test
    public void testIndexOfAny_StringArray_nullSearchStrs() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAny("abc", null));
    }

    @Test
    public void testIndexOfAny_StringArray_emptySearchStrs() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAny("abc", new String[]{}));
    }

    @Test
    public void testIndexOfAny_StringArray_searchStrsWithNull() throws Exception {
        assertEquals(2, StringUtils.indexOfAny("zzabyycdxx", new String[]{"ab", null, "cd"}));
    }
    
    @Test
    public void testIndexOfAny_StringArray_searchStrsWithEmpty() throws Exception {
        assertEquals(0, StringUtils.indexOfAny("zzabyycdxx", new String[]{"", "ab"}));
    }

    @Test
    public void testIndexOfAny_StringArray_found() throws Exception {
        assertEquals(2, StringUtils.indexOfAny("zzabyycdxx", new String[]{"ab", "cd"}));
        assertEquals(2, StringUtils.indexOfAny("zzabyycdxx", new String[]{"cd", "ab"}));
    }
    
    @Test
    public void testIndexOfAny_StringArray_foundEarlier() throws Exception {
        assertEquals(1, StringUtils.indexOfAny("zzabyycdxx", new String[]{"zab", "aby"}));
    }

    @Test
    public void testIndexOfAny_StringArray_notFound() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAny("zzabyycdxx", new String[]{"mn", "op"}));
    }

    @Test
    public void testLastIndexOfAny_StringArray_nullString() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.lastIndexOfAny(null, new String[]{"a"}));
    }

    @Test
    public void testLastIndexOfAny_StringArray_nullSearchStrs() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.lastIndexOfAny("abc", null));
    }

    @Test
    public void testLastIndexOfAny_StringArray_emptySearchStrs() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.lastIndexOfAny("abc", new String[]{}));
    }

    @Test
    public void testLastIndexOfAny_StringArray_searchStrsWithNull() throws Exception {
        assertEquals(6, StringUtils.lastIndexOfAny("zzabyycdxx", new String[]{null, "cd"}));
    }

    @Test
    public void testLastIndexOfAny_StringArray_searchStrsWithEmpty() throws Exception {
        assertEquals(10, StringUtils.lastIndexOfAny("zzabyycdxx", new String[]{"", "cd"}));
    }

    @Test
    public void testLastIndexOfAny_StringArray_found() throws Exception {
        assertEquals(6, StringUtils.lastIndexOfAny("zzabyycdxx", new String[]{"ab", "cd"}));
        assertEquals(6, StringUtils.lastIndexOfAny("zzabyycdxx", new String[]{"cd", "ab"}));
    }

    @Test
    public void testLastIndexOfAny_StringArray_notFound() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.lastIndexOfAny("zzabyycdxx", new String[]{"mn", "op"}));
    }
    
    @Test
    public void testSubstring_nullString() throws Exception {
        assertNull(StringUtils.substring(null, 1));
    }

    @Test
    public void testSubstring_emptyString() throws Exception {
        assertEquals("", StringUtils.substring("", 1));
    }

    @Test
    public void testSubstring_positiveStart() throws Exception {
        assertEquals("c", StringUtils.substring("abc", 2));
    }

    @Test
    public void testSubstring_startBeyondLength() throws Exception {
        assertEquals("", StringUtils.substring("abc", 4));
    }

    @Test
    public void testSubstring_negativeStart() throws Exception {
        assertEquals("bc", StringUtils.substring("abc", -2));
    }

    @Test
    public void testSubstring_negativeStartBeyondLength() throws Exception {
        assertEquals("abc", StringUtils.substring("abc", -4));
    }

    @Test
    public void testSubstring_nullStringStartEnd() throws Exception {
        assertNull(StringUtils.substring(null, 1, 2));
    }

    @Test
    public void testSubstring_emptyStringStartEnd() throws Exception {
        assertEquals("", StringUtils.substring("", 1, 2));
    }

    @Test
    public void testSubstring_startBeforeEnd() throws Exception {
        assertEquals("ab", StringUtils.substring("abc", 0, 2));
    }

    @Test
    public void testSubstring_startAfterEnd() throws Exception {
        assertEquals("", StringUtils.substring("abc", 2, 0));
    }

    @Test
    public void testSubstring_endBeyondLength() throws Exception {
        assertEquals("c", StringUtils.substring("abc", 2, 4));
    }

    @Test
    public void testSubstring_startBeyondLengthEnd() throws Exception {
        assertEquals("", StringUtils.substring("abc", 4, 6));
    }

    @Test
    public void testSubstring_startEqualsEnd() throws Exception {
        assertEquals("", StringUtils.substring("abc", 2, 2));
    }

    @Test
    public void testSubstring_negativeStartNegativeEnd() throws Exception {
        assertEquals("b", StringUtils.substring("abc", -2, -1));
    }

    @Test
    public void testSubstring_negativeStartPositiveEnd() throws Exception {
        assertEquals("ab", StringUtils.substring("abc", -4, 2));
    }

    @Test
    public void testLeft_nullString() throws Exception {
        assertNull(StringUtils.left(null, 2));
    }

    @Test
    public void testLeft_negativeLength() throws Exception {
        assertEquals("", StringUtils.left("abc", -1));
    }

    @Test
    public void testLeft_emptyString() throws Exception {
        assertEquals("", StringUtils.left("", 2));
    }

    @Test
    public void testLeft_zeroLength() throws Exception {
        assertEquals("", StringUtils.left("abc", 0));
    }

    @Test
    public void testLeft_lengthAvailable() throws Exception {
        assertEquals("ab", StringUtils.left("abc", 2));
    }

    @Test
    public void testLeft_lengthExceeds() throws Exception {
        assertEquals("abc", StringUtils.left("abc", 4));
    }

    @Test
    public void testRight_nullString() throws Exception {
        assertNull(StringUtils.right(null, 2));
    }

    @Test
    public void testRight_negativeLength() throws Exception {
        assertEquals("", StringUtils.right("abc", -1));
    }

    @Test
    public void testRight_emptyString() throws Exception {
        assertEquals("", StringUtils.right("", 2));
    }

    @Test
    public void testRight_zeroLength() throws Exception {
        assertEquals("", StringUtils.right("abc", 0));
    }

    @Test
    public void testRight_lengthAvailable() throws Exception {
        assertEquals("bc", StringUtils.right("abc", 2));
    }

    @Test
    public void testRight_lengthExceeds() throws Exception {
        assertEquals("abc", StringUtils.right("abc", 4));
    }

    @Test
    public void testMid_nullString() throws Exception {
        assertNull(StringUtils.mid(null, 0, 2));
    }

    @Test
    public void testMid_negativeLength() throws Exception {
        assertEquals("", StringUtils.mid("abc", 0, -1));
    }

    @Test
    public void testMid_posBeyondLength() throws Exception {
        assertEquals("", StringUtils.mid("abc", 4, 2));
    }

    @Test
    public void testMid_emptyString() throws Exception {
        assertEquals("", StringUtils.mid("", 0, 2));
    }

    @Test
    public void testMid_zeroPosTwoLength() throws Exception {
        assertEquals("ab", StringUtils.mid("abc", 0, 2));
    }

    @Test
    public void testMid_zeroPosFourLength() throws Exception {
        assertEquals("abc", StringUtils.mid("abc", 0, 4));
    }

    @Test
    public void testMid_posTwoLengthTwo() throws Exception {
        assertEquals("c", StringUtils.mid("abc", 2, 4));
    }

    @Test
    public void testMid_posFourLengthTwo() throws Exception {
        assertEquals("", StringUtils.mid("abc", 4, 2));
    }

    @Test
    public void testMid_negativePosTwoLength() throws Exception {
        assertEquals("ab", StringUtils.mid("abc", -2, 2));
    }

    @Test
    public void testSubstringBefore_nullString() throws Exception {
        assertNull(StringUtils.substringBefore(null, "a"));
    }

    @Test
    public void testSubstringBefore_emptyString() throws Exception {
        assertEquals("", StringUtils.substringBefore("", "a"));
    }

    @Test
    public void testSubstringBefore_nullSeparator() throws Exception {
        assertEquals("abc", StringUtils.substringBefore("abc", null));
    }

    @Test
    public void testSubstringBefore_emptySeparator() throws Exception {
        assertEquals("", StringUtils.substringBefore("abc", ""));
    }

    @Test
    public void testSubstringBefore_separatorNotFound() throws Exception {
        assertEquals("abc", StringUtils.substringBefore("abc", "d"));
    }

    @Test
    public void testSubstringBefore_separatorFound() throws Exception {
        assertEquals("", StringUtils.substringBefore("abc", "a"));
        assertEquals("a", StringUtils.substringBefore("abcba", "b"));
        assertEquals("ab", StringUtils.substringBefore("abc", "c"));
    }

    @Test
    public void testSubstringAfter_nullString() throws Exception {
        assertNull(StringUtils.substringAfter(null, "a"));
    }

    @Test
    public void testSubstringAfter_emptyString() throws Exception {
        assertEquals("", StringUtils.substringAfter("", "a"));
    }

    @Test
    public void testSubstringAfter_nullSeparator() throws Exception {
        assertEquals("", StringUtils.substringAfter("abc", null));
    }

    @Test
    public void testSubstringAfter_separatorNotFound() throws Exception {
        assertEquals("", StringUtils.substringAfter("abc", "d"));
    }

    @Test
    public void testSubstringAfter_separatorFound() throws Exception {
        assertEquals("bc", StringUtils.substringAfter("abc", "a"));
        assertEquals("cba", StringUtils.substringAfter("abcba", "b"));
        assertEquals("", StringUtils.substringAfter("abc", "c"));
    }

    @Test
    public void testSubstringAfter_emptySeparator() throws Exception {
        assertEquals("abc", StringUtils.substringAfter("abc", ""));
    }

    @Test
    public void testSubstringBeforeLast_nullString() throws Exception {
        assertNull(StringUtils.substringBeforeLast(null, "a"));
    }

    @Test
    public void testSubstringBeforeLast_emptyString() throws Exception {
        assertEquals("", StringUtils.substringBeforeLast("", "a"));
    }

    @Test
    public void testSubstringBeforeLast_emptySeparator() throws Exception {
        assertEquals("abc", StringUtils.substringBeforeLast("abc", ""));
    }
    
    @Test
    public void testSubstringBeforeLast_nullSeparator() throws Exception {
        assertEquals("abc", StringUtils.substringBeforeLast("abc", null));
    }

    @Test
    public void testSubstringBeforeLast_separatorNotFound() throws Exception {
        assertEquals("a", StringUtils.substringBeforeLast("a", "z"));
    }

    @Test
    public void testSubstringBeforeLast_separatorFound() throws Exception {
        assertEquals("abc", StringUtils.substringBeforeLast("abcba", "b"));
        assertEquals("ab", StringUtils.substringBeforeLast("abc", "c"));
        assertEquals("", StringUtils.substringBeforeLast("a", "a"));
    }

    @Test
    public void testSubstringAfterLast_nullString() throws Exception {
        assertNull(StringUtils.substringAfterLast(null, "a"));
    }

    @Test
    public void testSubstringAfterLast_emptyString() throws Exception {
        assertEquals("", StringUtils.substringAfterLast("", "a"));
    }

    @Test
    public void testSubstringAfterLast_emptySeparator() throws Exception {
        assertEquals("", StringUtils.substringAfterLast("abc", ""));
    }

    @Test
    public void testSubstringAfterLast_nullSeparator() throws Exception {
        assertEquals("", StringUtils.substringAfterLast("abc", null));
    }

    @Test
    public void testSubstringAfterLast_separatorNotFound() throws Exception {
        assertEquals("", StringUtils.substringAfterLast("a", "z"));
    }

    @Test
    public void testSubstringAfterLast_separatorFound() throws Exception {
        assertEquals("bc", StringUtils.substringAfterLast("abc", "a"));
        assertEquals("a", StringUtils.substringAfterLast("abcba", "b"));
        assertEquals("", StringUtils.substringAfterLast("abc", "c"));
        assertEquals("", StringUtils.substringAfterLast("a", "a"));
    }

    @Test
    public void testSubstringBetween_nullString() throws Exception {
        assertNull(StringUtils.substringBetween(null, "tag"));
    }

    @Test
    public void testSubstringBetween_nullTag() throws Exception {
        assertNull(StringUtils.substringBetween("tagabctag", null));
    }

    @Test
    public void testSubstringBetween_emptyTag() throws Exception {
        assertEquals("", StringUtils.substringBetween("tagabctag", ""));
    }

    @Test
    public void testSubstringBetween_emptyStringAndEmptyTag() throws Exception {
        assertEquals("", StringUtils.substringBetween("", ""));
    }

    @Test
    public void testSubstringBetween_emptyString() throws Exception {
        assertEquals(null, StringUtils.substringBetween("", "tag"));
    }

    @Test
    public void testSubstringBetween_noMatch() throws Exception {
        assertEquals(null, StringUtils.substringBetween("abc", "def"));
    }

    @Test
    public void testSubstringBetween_matchFound() throws Exception {
        assertEquals("abc", StringUtils.substringBetween("tagabctag", "tag"));
    }

    @Test
    public void testSubstringBetween_multipleTags_firstMatch() throws Exception {
        assertEquals("abc", StringUtils.substringBetween("tagabcANDtagdef", "tag", "AND"));
    }

    @Test
    public void testSubstringBetween_multipleTags_noCloseTag() throws Exception {
        assertEquals(null, StringUtils.substringBetween("tagabcDEF", "tag", "AND"));
    }

    @Test
    public void testSubstringBetween_multipleTags_openAndCloseNull() throws Exception {
        assertEquals(null, StringUtils.substringBetween("abc", null, null));
    }

    @Test
    public void testSubstringBetween_multipleTags_openNull() throws Exception {
        assertEquals(null, StringUtils.substringBetween("abc", null, "c"));
    }

    @Test
    public void testSubstringBetween_multipleTags_closeNull() throws Exception {
        assertEquals(null, StringUtils.substringBetween("abc", "a", null));
    }

    @Test
    public void testSubstringBetween_multipleTags_openEmpty() throws Exception {
        assertEquals("", StringUtils.substringBetween("abc", "", "c"));
    }

    @Test
    public void testSubstringBetween_multipleTags_closeEmpty() throws Exception {
        assertEquals("abc", StringUtils.substringBetween("abc", "a", ""));
    }
    
    @Test
    public void testSubstringBetween_multipleTags_openAndCloseEmpty() throws Exception {
        assertEquals("", StringUtils.substringBetween("abc", "", ""));
    }

    @Test
    public void testSubstringsBetween_nullString() throws Exception {
        assertNull(StringUtils.substringsBetween(null, "[", "]"));
    }

    @Test
    public void testSubstringsBetween_nullOpen() throws Exception {
        assertNull(StringUtils.substringsBetween("abc", null, "]"));
    }

    @Test
    public void testSubstringsBetween_nullClose() throws Exception {
        assertNull(StringUtils.substringsBetween("abc", "[", null));
    }

    @Test
    public void testSubstringsBetween_emptyOpen() throws Exception {
        assertNull(StringUtils.substringsBetween("abc", "", "]"));
    }

    @Test
    public void testSubstringsBetween_emptyClose() throws Exception {
        assertNull(StringUtils.substringsBetween("abc", "[", ""));
    }

    @Test
    public void testSubstringsBetween_emptyString() throws Exception {
        assertArrayEquals(new String[]{}, StringUtils.substringsBetween("", "[", "]"));
    }

    @Test
    public void testSubstringsBetween_noMatch() throws Exception {
        assertNull(StringUtils.substringsBetween("abc", "[", "]"));
    }

    @Test
    public void testSubstringsBetween_singleMatch() throws Exception {
        assertArrayEquals(new String[]{"a"}, StringUtils.substringsBetween("[a]", "[", "]"));
    }

    @Test
    public void testSubstringsBetween_multipleMatches() throws Exception {
        assertArrayEquals(new String[]{"a", "b", "c"}, StringUtils.substringsBetween("[a][b][c]", "[", "]"));
    }

    @Test
    public void testSubstringsBetween_overlappingTags() throws Exception {
        assertArrayEquals(new String[]{"a", "b", "c"}, StringUtils.substringsBetween("[a][b][c]", "[", "]"));
    }

    @Test
    public void testSubstringsBetween_nestedTags() throws Exception {
        assertArrayEquals(new String[]{"a", "b"}, StringUtils.substringsBetween("[a[b]]", "[", "]"));
    }

    @Test
    public void testSplit_nullString() throws Exception {
        assertNull(StringUtils.split(null));
    }

    @Test
    public void testSplit_emptyString() throws Exception {
        assertArrayEquals(new String[]{}, StringUtils.split(""));
    }

    @Test
    public void testSplit_simpleCase() throws Exception {
        assertArrayEquals(new String[]{"abc", "def"}, StringUtils.split("abc def"));
    }

    @Test
    public void testSplit_multipleSeparators() throws Exception {
        assertArrayEquals(new String[]{"abc", "def"}, StringUtils.split("abc  def"));
    }

    @Test
    public void testSplit_leadingAndTrailingSpaces() throws Exception {
        assertArrayEquals(new String[]{"abc"}, StringUtils.split(" abc "));
    }
    
    @Test
    public void testSplit_separatorChar_nullString() throws Exception {
        assertNull(StringUtils.split(null, '.'));
    }

    @Test
    public void testSplit_separatorChar_emptyString() throws Exception {
        assertArrayEquals(new String[]{}, StringUtils.split("", '.'));
    }

    @Test
    public void testSplit_separatorChar_simpleCase() throws Exception {
        assertArrayEquals(new String[]{"a", "b", "c"}, StringUtils.split("a.b.c", '.'));
    }

    @Test
    public void testSplit_separatorChar_multipleSeparators() throws Exception {
        assertArrayEquals(new String[]{"a", "b", "c"}, StringUtils.split("a..b.c", '.'));
    }

    @Test
    public void testSplit_separatorChar_noMatch() throws Exception {
        assertArrayEquals(new String[]{"a:b:c"}, StringUtils.split("a:b:c", '.'));
    }

    @Test
    public void testSplit_separatorChar_space() throws Exception {
        assertArrayEquals(new String[]{"a", "b", "c"}, StringUtils.split("a b c", ' '));
    }

    @Test
    public void testSplit_separatorString_nullString() throws Exception {
        assertNull(StringUtils.split(null, "."));
    }

    @Test
    public void testSplit_separatorString_emptyString() throws Exception {
        assertArrayEquals(new String[]{}, StringUtils.split("", "."));
    }

    @Test
    public void testSplit_separatorString_nullSeparator() throws Exception {
        assertArrayEquals(new String[]{"abc", "def"}, StringUtils.split("abc def", null));
    }

    @Test
    public void testSplit_separatorString_simpleCase() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef"}, StringUtils.split("ab:cd:ef", ":"));
    }

    @Test
    public void testSplit_separatorString_multipleSeparators() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef"}, StringUtils.split("ab  cd  ef", " "));
    }

    @Test
    public void testSplit_separatorString_complexSeparator() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef"}, StringUtils.split("ab-!-cd-!-ef", "-!-"));
    }
    
    @Test
    public void testSplit_separatorStringMax_nullString() throws Exception {
        assertNull(StringUtils.split(null, ".", 0));
    }

    @Test
    public void testSplit_separatorStringMax_emptyString() throws Exception {
        assertArrayEquals(new String[]{}, StringUtils.split("", ".", 0));
    }

    @Test
    public void testSplit_separatorStringMax_zeroMax() throws Exception {
        assertArrayEquals(new String[]{"ab", "de", "fg"}, StringUtils.split("ab de fg", null, 0));
    }

    @Test
    public void testSplit_separatorStringMax_multipleSeparatorsZeroMax() throws Exception {
        assertArrayEquals(new String[]{"ab", "de", "fg"}, StringUtils.split("ab   de fg", null, 0));
    }

    @Test
    public void testSplit_separatorStringMax_simpleCaseZeroMax() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef"}, StringUtils.split("ab:cd:ef", ":", 0));
    }

    @Test
    public void testSplit_separatorStringMax_limitedMax() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd:ef"}, StringUtils.split("ab:cd:ef", ":", 2));
    }

    @Test
    public void testSplitByWholeSeparator_nullString() throws Exception {
        assertNull(StringUtils.splitByWholeSeparator(null, ":"));
    }

    @Test
    public void testSplitByWholeSeparator_emptyString() throws Exception {
        assertArrayEquals(new String[]{}, StringUtils.splitByWholeSeparator("", ":"));
    }

    @Test
    public void testSplitByWholeSeparator_nullSeparator() throws Exception {
        assertArrayEquals(new String[]{"ab", "de", "fg"}, StringUtils.splitByWholeSeparator("ab de fg", null));
    }

    @Test
    public void testSplitByWholeSeparator_multipleSpacesSeparator() throws Exception {
        assertArrayEquals(new String[]{"ab", "de", "fg"}, StringUtils.splitByWholeSeparator("ab   de fg", null));
    }

    @Test
    public void testSplitByWholeSeparator_simpleSeparator() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef"}, StringUtils.splitByWholeSeparator("ab:cd:ef", ":"));
    }

    @Test
    public void testSplitByWholeSeparator_complexSeparator() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef"}, StringUtils.splitByWholeSeparator("ab-!-cd-!-ef", "-!-"));
    }

    @Test
    public void testSplitByWholeSeparator_emptySeparator() throws Exception {
        assertArrayEquals(new String[]{"a", "b", "c"}, StringUtils.splitByWholeSeparator("abc", ""));
    }

    @Test
    public void testSplitByWholeSeparatorPreserveAllTokens_nullString() throws Exception {
        assertNull(StringUtils.splitByWholeSeparatorPreserveAllTokens(null, ":"));
    }

    @Test
    public void testSplitByWholeSeparatorPreserveAllTokens_emptyString() throws Exception {
        assertArrayEquals(new String[]{}, StringUtils.splitByWholeSeparatorPreserveAllTokens("", ":"));
    }

    @Test
    public void testSplitByWholeSeparatorPreserveAllTokens_nullSeparator() throws Exception {
        assertArrayEquals(new String[]{"ab", "de", "fg"}, StringUtils.splitByWholeSeparatorPreserveAllTokens("ab de fg", null));
    }

    @Test
    public void testSplitByWholeSeparatorPreserveAllTokens_multipleSpacesSeparator() throws Exception {
        assertArrayEquals(new String[]{"ab", "", "", "de", "fg"}, StringUtils.splitByWholeSeparatorPreserveAllTokens("ab   de fg", null));
    }

    @Test
    public void testSplitByWholeSeparatorPreserveAllTokens_simpleSeparator() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef"}, StringUtils.splitByWholeSeparatorPreserveAllTokens("ab:cd:ef", ":"));
    }

    @Test
    public void testSplitByWholeSeparatorPreserveAllTokens_complexSeparator() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef"}, StringUtils.splitByWholeSeparatorPreserveAllTokens("ab-!-cd-!-ef", "-!-"));
    }

    @Test
    public void testSplitByWholeSeparatorPreserveAllTokens_emptySeparator() throws Exception {
        assertArrayEquals(new String[]{"a", "b", "c"}, StringUtils.splitByWholeSeparatorPreserveAllTokens("abc", ""));
    }

    @Test
    public void testSplitByWholeSeparatorPreserveAllTokens_trailingSeparator() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef", ""}, StringUtils.splitByWholeSeparatorPreserveAllTokens("ab:cd:ef:", ":"));
    }
    
    @Test
    public void testSplitByWholeSeparatorPreserveAllTokens_multipleTrailingSeparators() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef", "", ""}, StringUtils.splitByWholeSeparatorPreserveAllTokens("ab:cd:ef::", ":"));
    }

    @Test
    public void testSplitByWholeSeparatorPreserveAllTokens_internalSeparators() throws Exception {
        assertArrayEquals(new String[]{"ab", "", "cd", "ef"}, StringUtils.splitByWholeSeparatorPreserveAllTokens("ab::cd:ef", ":"));
    }

    @Test
    public void testSplitByWholeSeparatorPreserveAllTokens_leadingSeparator() throws Exception {
        assertArrayEquals(new String[]{"", "cd", "ef"}, StringUtils.splitByWholeSeparatorPreserveAllTokens(":cd:ef", ":"));
    }

    @Test
    public void testSplitByWholeSeparatorPreserveAllTokens_multipleLeadingSeparators() throws Exception {
        assertArrayEquals(new String[]{"", "", "cd", "ef"}, StringUtils.splitByWholeSeparatorPreserveAllTokens("::cd:ef", ":"));
    }

    @Test
    public void testSplitByWholeSeparatorPreserveAllTokens_leadingAndTrailingSeparators() throws Exception {
        assertArrayEquals(new String[]{"", "cd", "ef", ""}, StringUtils.splitByWholeSeparatorPreserveAllTokens(":cd:ef:", ":"));
    }
    
    @Test
    public void testSplitPreserveAllTokens_nullString() throws Exception {
        assertNull(StringUtils.splitPreserveAllTokens(null));
    }

    @Test
    public void testSplitPreserveAllTokens_emptyString() throws Exception {
        assertArrayEquals(new String[]{}, StringUtils.splitPreserveAllTokens(""));
    }

    @Test
    public void testSplitPreserveAllTokens_simpleCase() throws Exception {
        assertArrayEquals(new String[]{"abc", "def"}, StringUtils.splitPreserveAllTokens("abc def"));
    }

    @Test
    public void testSplitPreserveAllTokens_multipleSeparators() throws Exception {
        assertArrayEquals(new String[]{"abc", "", "def"}, StringUtils.splitPreserveAllTokens("abc  def"));
    }

    @Test
    public void testSplitPreserveAllTokens_leadingAndTrailingSpaces() throws Exception {
        assertArrayEquals(new String[]{"", "abc", ""}, StringUtils.splitPreserveAllTokens(" abc "));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorChar_nullString() throws Exception {
        assertNull(StringUtils.splitPreserveAllTokens(null, '.'));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorChar_emptyString() throws Exception {
        assertArrayEquals(new String[]{}, StringUtils.splitPreserveAllTokens("", '.'));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorChar_simpleCase() throws Exception {
        assertArrayEquals(new String[]{"a", "b", "c"}, StringUtils.splitPreserveAllTokens("a.b.c", '.'));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorChar_multipleSeparators() throws Exception {
        assertArrayEquals(new String[]{"a", "", "b", "c"}, StringUtils.splitPreserveAllTokens("a..b.c", '.'));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorChar_noMatch() throws Exception {
        assertArrayEquals(new String[]{"a:b:c"}, StringUtils.splitPreserveAllTokens("a:b:c", '.'));
    }
    
    @Test
    public void testSplitPreserveAllTokens_separatorChar_trailingSeparator() throws Exception {
        assertArrayEquals(new String[]{"a", "b", "c", ""}, StringUtils.splitPreserveAllTokens("a.b.c.", '.'));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorChar_multipleTrailingSeparators() throws Exception {
        assertArrayEquals(new String[]{"a", "b", "c", "", ""}, StringUtils.splitPreserveAllTokens("a.b.c..", '.'));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorChar_leadingSeparator() throws Exception {
        assertArrayEquals(new String[]{"", "b", "c"}, StringUtils.splitPreserveAllTokens(".b.c", '.'));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorChar_multipleLeadingSeparators() throws Exception {
        assertArrayEquals(new String[]{"", "", "b", "c"}, StringUtils.splitPreserveAllTokens("..b.c", '.'));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorChar_leadingAndTrailingSeparators() throws Exception {
        assertArrayEquals(new String[]{"", "b", "c", ""}, StringUtils.splitPreserveAllTokens(".b.c.", '.'));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorString_nullString() throws Exception {
        assertNull(StringUtils.splitPreserveAllTokens(null, "."));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorString_emptyString() throws Exception {
        assertArrayEquals(new String[]{}, StringUtils.splitPreserveAllTokens("", "."));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorString_nullSeparator() throws Exception {
        assertArrayEquals(new String[]{"abc", "def"}, StringUtils.splitPreserveAllTokens("abc def", null));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorString_multipleSeparators() throws Exception {
        assertArrayEquals(new String[]{"ab", "", "", "cd", "ef"}, StringUtils.splitPreserveAllTokens("ab   cd   ef", " "));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorString_simpleSeparator() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef"}, StringUtils.splitPreserveAllTokens("ab:cd:ef", ":"));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorString_complexSeparator() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef"}, StringUtils.splitByWholeSeparatorPreserveAllTokens("ab-!-cd-!-ef", "-!-"));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorString_trailingSeparator() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef", ""}, StringUtils.splitPreserveAllTokens("ab:cd:ef:", ":"));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorString_multipleTrailingSeparators() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef", "", ""}, StringUtils.splitPreserveAllTokens("ab:cd:ef::", ":"));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorString_leadingSeparator() throws Exception {
        assertArrayEquals(new String[]{"", "cd", "ef"}, StringUtils.splitPreserveAllTokens(":cd:ef", ":"));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorString_multipleLeadingSeparators() throws Exception {
        assertArrayEquals(new String[]{"", "", "cd", "ef"}, StringUtils.splitPreserveAllTokens("::cd:ef", ":"));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorString_leadingAndTrailingSeparators() throws Exception {
        assertArrayEquals(new String[]{"", "cd", "ef", ""}, StringUtils.splitPreserveAllTokens(":cd:ef:", ":"));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorStringMax_nullString() throws Exception {
        assertNull(StringUtils.splitPreserveAllTokens(null, ".", 0));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorStringMax_emptyString() throws Exception {
        assertArrayEquals(new String[]{}, StringUtils.splitPreserveAllTokens("", ".", 0));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorStringMax_zeroMax() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef"}, StringUtils.splitPreserveAllTokens("ab de fg", null, 0));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorStringMax_multipleSeparatorsZeroMax() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef"}, StringUtils.splitPreserveAllTokens("ab   de fg", null, 0));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorStringMax_simpleCaseZeroMax() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef"}, StringUtils.splitPreserveAllTokens("ab:cd:ef", ":", 0));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorStringMax_limitedMax() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd:ef"}, StringUtils.splitPreserveAllTokens("ab:cd:ef", ":", 2));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorStringMax_multipleSeparatorsLimitedMax() throws Exception {
        assertArrayEquals(new String[]{"ab", "", " de fg"}, StringUtils.splitPreserveAllTokens("ab   de fg", null, 2));
        assertArrayEquals(new String[]{"ab", "", "", "de fg"}, StringUtils.splitPreserveAllTokens("ab   de fg", null, 3));
        assertArrayEquals(new String[]{"ab", "", "", "de", "fg"}, StringUtils.splitPreserveAllTokens("ab   de fg", null, 4));
    }
    
    @Test
    public void testSplitByCharacterType_nullString() throws Exception {
        assertNull(StringUtils.splitByCharacterType(null));
    }

    @Test
    public void testSplitByCharacterType_emptyString() throws Exception {
        assertArrayEquals(new String[]{}, StringUtils.splitByCharacterType(""));
    }

    @Test
    public void testSplitByCharacterType_simpleCase() throws Exception {
        assertArrayEquals(new String[]{"ab", " ", "de", " ", "fg"}, StringUtils.splitByCharacterType("ab de fg"));
    }

    @Test
    public void testSplitByCharacterType_multipleSpaces() throws Exception {
        assertArrayEquals(new String[]{"ab", "   ", "de", " ", "fg"}, StringUtils.splitByCharacterType("ab   de fg"));
    }

    @Test
    public void testSplitByCharacterType_digits() throws Exception {
        assertArrayEquals(new String[]{"number", "5"}, StringUtils.splitByCharacterType("number5"));
    }
    
    @Test
    public void testSplitByCharacterType_camelCase() throws Exception {
        assertArrayEquals(new String[]{"foo", "B", "ar"}, StringUtils.splitByCharacterType("fooBar"));
    }
    
    @Test
    public void testSplitByCharacterType_camelCaseWithDigits() throws Exception {
        assertArrayEquals(new String[]{"foo", "200", "B", "ar"}, StringUtils.splitByCharacterType("foo200Bar"));
    }

    @Test
    public void testSplitByCharacterType_allUpperCase() throws Exception {
        assertArrayEquals(new String[]{"ASFR", "ules"}, StringUtils.splitByCharacterType("ASFRules"));
    }

    @Test
    public void testSplitByCharacterTypeCamelCase_nullString() throws Exception {
        assertNull(StringUtils.splitByCharacterTypeCamelCase(null));
    }

    @Test
    public void testSplitByCharacterTypeCamelCase_emptyString() throws Exception {
        assertArrayEquals(new String[]{}, StringUtils.splitByCharacterTypeCamelCase(""));
    }

    @Test
    public void testSplitByCharacterTypeCamelCase_simpleCase() throws Exception {
        assertArrayEquals(new String[]{"ab", " ", "de", " ", "fg"}, StringUtils.splitByCharacterTypeCamelCase("ab de fg"));
    }

    @Test
    public void testSplitByCharacterTypeCamelCase_multipleSpaces() throws Exception {
        assertArrayEquals(new String[]{"ab", "   ", "de", " ", "fg"}, StringUtils.splitByCharacterTypeCamelCase("ab   de fg"));
    }

    @Test
    public void testSplitByCharacterTypeCamelCase_digits() throws Exception {
        assertArrayEquals(new String[]{"number", "5"}, StringUtils.splitByCharacterTypeCamelCase("number5"));
    }
    
    @Test
    public void testSplitByCharacterTypeCamelCase_camelCase() throws Exception {
        assertArrayEquals(new String[]{"foo", "Bar"}, StringUtils.splitByCharacterTypeCamelCase("fooBar"));
    }
    
    @Test
    public void testSplitByCharacterTypeCamelCase_camelCaseWithDigits() throws Exception {
        assertArrayEquals(new String[]{"foo", "200", "Bar"}, StringUtils.splitByCharacterTypeCamelCase("foo200Bar"));
    }

    @Test
    public void testSplitByCharacterTypeCamelCase_allUpperCase() throws Exception {
        assertArrayEquals(new String[]{"ASF", "Rules"}, StringUtils.splitByCharacterTypeCamelCase("ASFRules"));
    }

    @Test
    public void testJoin_objectArray_null() throws Exception {
        assertNull(StringUtils.join((Object[]) null));
    }

    @Test
    public void testJoin_objectArray_empty() throws Exception {
        assertEquals("", StringUtils.join(new Object[]{}));
    }

    @Test
    public void testJoin_objectArray_singleNull() throws Exception {
        assertEquals("", StringUtils.join(new Object[]{null}));
    }

    @Test
    public void testJoin_objectArray_multipleElements() throws Exception {
        assertEquals("abc", StringUtils.join(new Object[]{"a", "b", "c"}));
    }

    @Test
    public void testJoin_objectArray_mixedNullAndEmpty() throws Exception {
        assertEquals("a", StringUtils.join(new Object[]{null, "", "a"}));
    }
    
    @Test
    public void testJoin_objectArray_charSeparator_null() throws Exception {
        assertNull(StringUtils.join((Object[]) null, ','));
    }

    @Test
    public void testJoin_objectArray_charSeparator_empty() throws Exception {
        assertEquals("", StringUtils.join(new Object[]{}, ','));
    }

    @Test
    public void testJoin_objectArray_charSeparator_singleNull() throws Exception {
        assertEquals("", StringUtils.join(new Object[]{null}, ','));
    }

    @Test
    public void testJoin_objectArray_charSeparator_multipleElements() throws Exception {
        assertEquals("a,b,c", StringUtils.join(new Object[]{"a", "b", "c"}, ','));
    }

    @Test
    public void testJoin_objectArray_charSeparator_mixedNullAndEmpty() throws Exception {
        assertEquals(";;a", StringUtils.join(new Object[]{null, "", "a"}, ','));
    }
    
    @Test
    public void testJoin_objectArray_charSeparatorRange_null() throws Exception {
        assertNull(StringUtils.join((Object[]) null, ',', 0, 0));
    }

    @Test
    public void testJoin_objectArray_charSeparatorRange_empty() throws Exception {
        assertEquals("", StringUtils.join(new Object[]{}, ',', 0, 0));
    }
    
    @Test
    public void testJoin_objectArray_charSeparatorRange_positive() throws Exception {
        assertEquals("b,c", StringUtils.join(new Object[]{"a", "b", "c", "d"}, ',', 1, 3));
    }

    @Test
    public void testJoin_objectArray_stringSeparator_null() throws Exception {
        assertNull(StringUtils.join((Object[]) null, "--"));
    }

    @Test
    public void testJoin_objectArray_stringSeparator_empty() throws Exception {
        assertEquals("", StringUtils.join(new Object[]{}, "--"));
    }

    @Test
    public void testJoin_objectArray_stringSeparator_singleNull() throws Exception {
        assertEquals("", StringUtils.join(new Object[]{null}, "--"));
    }

    @Test
    public void testJoin_objectArray_stringSeparator_multipleElements() throws Exception {
        assertEquals("a--b--c", StringUtils.join(new Object[]{"a", "b", "c"}, "--"));
    }

    @Test
    public void testJoin_objectArray_stringSeparator_mixedNullAndEmpty() throws Exception {
        assertEquals(",,a", StringUtils.join(new Object[]{null, "", "a"}, ','));
    }
    
    @Test
    public void testJoin_objectArray_stringSeparatorRange_null() throws Exception {
        assertNull(StringUtils.join((Object[]) null, "--", 0, 0));
    }

    @Test
    public void testJoin_objectArray_stringSeparatorRange_empty() throws Exception {
        assertEquals("", StringUtils.join(new Object[]{}, "--", 0, 0));
    }

    @Test
    public void testJoin_objectArray_stringSeparatorRange_positive() throws Exception {
        assertEquals("b--c", StringUtils.join(new Object[]{"a", "b", "c", "d"}, "--", 1, 3));
    }

    @Test
    public void testJoin_stringSeparator_null() throws Exception {
        assertNull(StringUtils.join((Object[]) null, "--"));
    }

    @Test
    public void testJoin_stringSeparator_empty() throws Exception {
        assertEquals("", StringUtils.join(new Object[]{}, "--"));
    }

    @Test
    public void testJoin_stringSeparator_singleNull() throws Exception {
        assertEquals("", StringUtils.join(new Object[]{null}, "--"));
    }

    @Test
    public void testJoin_stringSeparator_multipleElements() throws Exception {
        assertEquals("a--b--c", StringUtils.join(new Object[]{"a", "b", "c"}, "--"));
    }

    @Test
    public void testJoin_stringSeparator_mixedNullAndEmpty() throws Exception {
        assertEquals(",,a", StringUtils.join(new Object[]{null, "", "a"}, ','));
    }

    @Test
    public void testJoin_stringSeparator_nullSeparator() throws Exception {
        assertEquals("abc", StringUtils.join(new Object[]{"a", "b", "c"}, null));
    }

    @Test
    public void testJoin_stringSeparator_emptySeparator() throws Exception {
        assertEquals("abc", StringUtils.join(new Object[]{"a", "b", "c"}, ""));
    }
    
    @Test
    public void testDeleteWhitespace_nullString() throws Exception {
        assertNull(StringUtils.deleteWhitespace(null));
    }

    @Test
    public void testDeleteWhitespace_emptyString() throws Exception {
        assertEquals("", StringUtils.deleteWhitespace(""));
    }

    @Test
    public void testDeleteWhitespace_noWhitespace() throws Exception {
        assertEquals("abc", StringUtils.deleteWhitespace("abc"));
    }

    @Test
    public void testDeleteWhitespace_allWhitespace() throws Exception {
        assertEquals("", StringUtils.deleteWhitespace(" \t\n\r\f"));
    }

    @Test
    public void testDeleteWhitespace_mixedWhitespace() throws Exception {
        assertEquals("abc", StringUtils.deleteWhitespace("   ab  c  "));
    }

    @Test
    public void testRemoveStart_nullString() throws Exception {
        assertNull(StringUtils.removeStart(null, "www."));
    }

    @Test
    public void testRemoveStart_emptyString() throws Exception {
        assertEquals("", StringUtils.removeStart("", "www."));
    }

    @Test
    public void testRemoveStart_nullRemove() throws Exception {
        assertEquals("abc", StringUtils.removeStart("abc", null));
    }

    @Test
    public void testRemoveStart_emptyRemove() throws Exception {
        assertEquals("abc", StringUtils.removeStart("abc", ""));
    }

    @Test
    public void testRemoveStart_match() throws Exception {
        assertEquals("domain.com", StringUtils.removeStart("www.domain.com", "www."));
    }

    @Test
    public void testRemoveStart_noMatch() throws Exception {
        assertEquals("domain.com", StringUtils.removeStart("domain.com", "www."));
    }

    @Test
    public void testRemoveStart_noMatchDifferentString() throws Exception {
        assertEquals("www.domain.com", StringUtils.removeStart("www.domain.com", "domain"));
    }

    @Test
    public void testRemoveStartIgnoreCase_nullString() throws Exception {
        assertNull(StringUtils.removeStartIgnoreCase(null, "www."));
    }

    @Test
    public void testRemoveStartIgnoreCase_emptyString() throws Exception {
        assertEquals("", StringUtils.removeStartIgnoreCase("", "www."));
    }

    @Test
    public void testRemoveStartIgnoreCase_nullRemove() throws Exception {
        assertEquals("abc", StringUtils.removeStartIgnoreCase("abc", null));
    }

    @Test
    public void testRemoveStartIgnoreCase_emptyRemove() throws Exception {
        assertEquals("abc", StringUtils.removeStartIgnoreCase("abc", ""));
    }

    @Test
    public void testRemoveStartIgnoreCase_match() throws Exception {
        assertEquals("domain.com", StringUtils.removeStartIgnoreCase("www.domain.com", "www."));
    }

    @Test
    public void testRemoveStartIgnoreCase_matchIgnoreCase() throws Exception {
        assertEquals("domain.com", StringUtils.removeStartIgnoreCase("www.domain.com", "WWW."));
    }

    @Test
    public void testRemoveStartIgnoreCase_noMatch() throws Exception {
        assertEquals("domain.com", StringUtils.removeStartIgnoreCase("domain.com", "www."));
    }

    @Test
    public void testRemoveEnd_nullString() throws Exception {
        assertNull(StringUtils.removeEnd(null, ".com"));
    }

    @Test
    public void testRemoveEnd_emptyString() throws Exception {
        assertEquals("", StringUtils.removeEnd("", ".com"));
    }

    @Test
    public void testRemoveEnd_nullRemove() throws Exception {
        assertEquals("abc", StringUtils.removeEnd("abc", null));
    }

    @Test
    public void testRemoveEnd_emptyRemove() throws Exception {
        assertEquals("abc", StringUtils.removeEnd("abc", ""));
    }

    @Test
    public void testRemoveEnd_match() throws Exception {
        assertEquals("www.domain", StringUtils.removeEnd("www.domain.com", ".com"));
    }

    @Test
    public void testRemoveEnd_noMatch() throws Exception {
        assertEquals("www.domain.com", StringUtils.removeEnd("www.domain.com", ".org"));
    }

    @Test
    public void testRemoveEnd_noMatchDifferentString() throws Exception {
        assertEquals("www.domain.com", StringUtils.removeEnd("www.domain.com", "domain"));
    }

    @Test
    public void testRemoveEnd_noMatchSuffixTooLong() throws Exception {
        assertEquals("www.domain.com", StringUtils.removeEnd("www.domain.com", ".com."));
    }

    @Test
    public void testRemoveEndIgnoreCase_nullString() throws Exception {
        assertNull(StringUtils.removeEndIgnoreCase(null, ".com"));
    }

    @Test
    public void testRemoveEndIgnoreCase_emptyString() throws Exception {
        assertEquals("", StringUtils.removeEndIgnoreCase("", ".com"));
    }

    @Test
    public void testRemoveEndIgnoreCase_nullRemove() throws Exception {
        assertEquals("abc", StringUtils.removeEndIgnoreCase("abc", null));
    }

    @Test
    public void testRemoveEndIgnoreCase_emptyRemove() throws Exception {
        assertEquals("abc", StringUtils.removeEndIgnoreCase("abc", ""));
    }

    @Test
    public void testRemoveEndIgnoreCase_match() throws Exception {
        assertEquals("www.domain", StringUtils.removeEndIgnoreCase("www.domain.com", ".com"));
    }

    @Test
    public void testRemoveEndIgnoreCase_matchIgnoreCase() throws Exception {
        assertEquals("www.domain", StringUtils.removeEndIgnoreCase("www.domain.COM", ".com"));
        assertEquals("www.domain", StringUtils.removeEndIgnoreCase("www.domain.com", ".COM"));
    }

    @Test
    public void testRemoveEndIgnoreCase_noMatch() throws Exception {
        assertEquals("www.domain.com", StringUtils.removeEndIgnoreCase("www.domain.com", ".org"));
    }

    @Test
    public void testRemoveEndIgnoreCase_noMatchDifferentString() throws Exception {
        assertEquals("www.domain.com", StringUtils.removeEndIgnoreCase("www.domain.com", "domain"));
    }

    @Test
    public void testRemoveEndIgnoreCase_noMatchSuffixTooLong() throws Exception {
        assertEquals("www.domain.com", StringUtils.removeEndIgnoreCase("www.domain.com", ".com."));
    }
    
    @Test
    public void testRemove_nullString() throws Exception {
        assertNull(StringUtils.remove(null, "abc"));
    }

    @Test
    public void testRemove_emptyString() throws Exception {
        assertEquals("", StringUtils.remove("", "abc"));
    }

    @Test
    public void testRemove_nullRemove() throws Exception {
        assertEquals("abc", StringUtils.remove("abc", null));
    }

    @Test
    public void testRemove_emptyRemove() throws Exception {
        assertEquals("abc", StringUtils.remove("abc", ""));
    }

    @Test
    public void testRemove_match() throws Exception {
        assertEquals("qd", StringUtils.remove("queued", "ue"));
    }

    @Test
    public void testRemove_noMatch() throws Exception {
        assertEquals("queued", StringUtils.remove("queued", "zz"));
    }

    @Test
    public void testRemove_multipleMatches() throws Exception {
        assertEquals("qeed", StringUtils.remove("queueued", "ue"));
    }

    @Test
    public void testRemove_char_nullString() throws Exception {
        assertNull(StringUtils.remove(null, 'a'));
    }

    @Test
    public void testRemove_char_emptyString() throws Exception {
        assertEquals("", StringUtils.remove("", 'a'));
    }

    @Test
    public void testRemove_char_match() throws Exception {
        assertEquals("qeed", StringUtils.remove("queued", 'u'));
    }

    @Test
    public void testRemove_char_noMatch() throws Exception {
        assertEquals("queued", StringUtils.remove("queued", 'z'));
    }
    
    @Test
    public void testReplaceOnce_nullText() throws Exception {
        assertNull(StringUtils.replaceOnce(null, "a", "z"));
    }

    @Test
    public void testReplaceOnce_emptyText() throws Exception {
        assertEquals("", StringUtils.replaceOnce("", "a", "z"));
    }

    @Test
    public void testReplaceOnce_nullSearchString() throws Exception {
        assertEquals("any", StringUtils.replaceOnce("any", null, "z"));
    }

    @Test
    public void testReplaceOnce_nullReplacement() throws Exception {
        assertEquals("aba", StringUtils.replaceOnce("aba", "a", null));
    }

    @Test
    public void testReplaceOnce_emptySearchString() throws Exception {
        assertEquals("any", StringUtils.replaceOnce("any", "", "z"));
    }

    @Test
    public void testReplaceOnce_emptyReplacement() throws Exception {
        assertEquals("ba", StringUtils.replaceOnce("aba", "a", ""));
    }

    @Test
    public void testReplaceOnce_singleReplacement() throws Exception {
        assertEquals("zba", StringUtils.replaceOnce("aba", "a", "z"));
    }

    @Test
    public void testReplaceOnce_multipleOccurrences() throws Exception {
        assertEquals("zba", StringUtils.replaceOnce("aba", "a", "z")); // Only first 'a' is replaced
    }

    @Test
    public void testReplace_nullText() throws Exception {
        assertNull(StringUtils.replace(null, "a", "z"));
    }

    @Test
    public void testReplace_emptyText() throws Exception {
        assertEquals("", StringUtils.replace("", "a", "z"));
    }

    @Test
    public void testReplace_nullSearchString() throws Exception {
        assertEquals("any", StringUtils.replace("any", null, "z"));
    }

    @Test
    public void testReplace_nullReplacement() throws Exception {
        assertEquals("aba", StringUtils.replace("aba", "a", null));
    }

    @Test
    public void testReplace_emptySearchString() throws Exception {
        assertEquals("any", StringUtils.replace("any", "", "z"));
    }

    @Test
    public void testReplace_emptyReplacement() throws Exception {
        assertEquals("b", StringUtils.replace("aba", "a", ""));
    }

    @Test
    public void testReplace_singleReplacement() throws Exception {
        assertEquals("zbz", StringUtils.replace("aba", "a", "z"));
    }

    @Test
    public void testReplace_multipleOccurrences() throws Exception {
        assertEquals("zbzbz", StringUtils.replace("ababab", "ab", "z"));
    }
    
    @Test
    public void testReplace_max_nullText() throws Exception {
        assertNull(StringUtils.replace(null, "a", "z", -1));
    }

    @Test
    public void testReplace_max_emptyText() throws Exception {
        assertEquals("", StringUtils.replace("", "a", "z", -1));
    }

    @Test
    public void testReplace_max_nullSearchString() throws Exception {
        assertEquals("any", StringUtils.replace("any", null, "z", -1));
    }

    @Test
    public void testReplace_max_nullReplacement() throws Exception {
        assertEquals("abaa", StringUtils.replace("abaa", "a", null, -1));
    }

    @Test
    public void testReplace_max_emptySearchString() throws Exception {
        assertEquals("any", StringUtils.replace("any", "", "z", -1));
    }

    @Test
    public void testReplace_max_zeroMax() throws Exception {
        assertEquals("abaa", StringUtils.replace("abaa", "a", "z", 0));
    }

    @Test
    public void testReplace_max_emptyReplacement() throws Exception {
        assertEquals("b", StringUtils.replace("abaa", "a", "", -1));
    }

    @Test
    public void testReplace_max_oneReplacement() throws Exception {
        assertEquals("zbaa", StringUtils.replace("abaa", "a", "z", 1));
    }

    @Test
    public void testReplace_max_twoReplacements() throws Exception {
        assertEquals("zbza", StringUtils.replace("abaa", "a", "z", 2));
    }

    @Test
    public void testReplace_max_allReplacements() throws Exception {
        assertEquals("zbzz", StringUtils.replace("abaa", "a", "z", -1));
    }

    @Test
    public void testReplaceEach_nullText() throws Exception {
        assertNull(StringUtils.replaceEach(null, new String[]{"a"}, new String[]{"b"}));
    }

    @Test
    public void testReplaceEach_emptyText() throws Exception {
        assertEquals("", StringUtils.replaceEach("", new String[]{"a"}, new String[]{"b"}));
    }

    @Test
    public void testReplaceEach_nullSearchList() throws Exception {
        assertEquals("abc", StringUtils.replaceEach("abc", null, new String[]{"b"}));
    }

    @Test
    public void testReplaceEach_nullReplacementList() throws Exception {
        assertEquals("abc", StringUtils.replaceEach("abc", new String[]{"a"}, null));
    }

    @Test
    public void testReplaceEach_emptySearchList() throws Exception {
        assertEquals("abc", StringUtils.replaceEach("abc", new String[0], new String[]{"b"}));
    }

    @Test
    public void testReplaceEach_emptyReplacementList() throws Exception {
        assertEquals("abc", StringUtils.replaceEach("abc", new String[]{"a"}, new String[0]));
    }

    @Test
    public void testReplaceEach_searchNullInList() throws Exception {
        assertEquals("abc", StringUtils.replaceEach("abc", new String[]{null}, new String[]{"b"}));
    }

    @Test
    public void testReplaceEach_replacementNullInList() throws Exception {
        assertEquals("abc", StringUtils.replaceEach("abc", new String[]{"a"}, new String[]{null}));
    }
    
    @Test
    public void testReplaceEach_simpleReplacement() throws Exception {
        assertEquals("wcte", StringUtils.replaceEach("abcde", new String[]{"ab", "d"}, new String[]{"w", "t"}));
    }

    @Test
    public void testReplaceEach_noReplacement() throws Exception {
        assertEquals("abcde", StringUtils.replaceEach("abcde", new String[]{"x", "y"}, new String[]{"w", "t"}));
    }
    
    @Test
    public void testReplaceEachRepeatedly_nullText() throws Exception {
        assertNull(StringUtils.replaceEachRepeatedly(null, new String[]{"a"}, new String[]{"b"}));
    }

    @Test
    public void testReplaceEachRepeatedly_emptyText() throws Exception {
        assertEquals("", StringUtils.replaceEachRepeatedly("", new String[]{"a"}, new String[]{"b"}));
    }

    @Test
    public void testReplaceEachRepeatedly_nullSearchList() throws Exception {
        assertEquals("abc", StringUtils.replaceEachRepeatedly("abc", null, new String[]{"b"}));
    }

    @Test
    public void testReplaceEachRepeatedly_nullReplacementList() throws Exception {
        assertEquals("abc", StringUtils.replaceEachRepeatedly("abc", new String[]{"a"}, null));
    }

    @Test
    public void testReplaceEachRepeatedly_emptySearchList() throws Exception {
        assertEquals("abc", StringUtils.replaceEachRepeatedly("abc", new String[0], new String[]{"b"}));
    }

    @Test
    public void testReplaceEachRepeatedly_emptyReplacementList() throws Exception {
        assertEquals("abc", StringUtils.replaceEachRepeatedly("abc", new String[]{"a"}, new String[0]));
    }
    
    @Test
    public void testReplaceEachRepeatedly_simpleReplacement() throws Exception {
        assertEquals("wcte", StringUtils.replaceEachRepeatedly("abcde", new String[]{"ab", "d"}, new String[]{"w", "t"}));
    }

    @Test
    public void testReplaceEachRepeatedly_noReplacement() throws Exception {
        assertEquals("abcde", StringUtils.replaceEachRepeatedly("abcde", new String[]{"x", "y"}, new String[]{"w", "t"}));
    }
    
    @Test
    public void testReplaceEachRepeatedly_repeatedReplacement() throws Exception {
        assertEquals("tcte", StringUtils.replaceEachRepeatedly("abcde", new String[]{"ab", "d"}, new String[]{"d", "t"})); // ab->d, d->t => dcte. Repeatedly: ab->d->t => tcte
    }
    
    @Test
    public void testReplaceEachRepeatedly_noRepeat() throws Exception {
        assertEquals("dcte", StringUtils.replaceEachRepeatedly("abcde", new String[]{"ab", "d"}, new String[]{"d", "t"}, false, 0));
    }

    @Test
    public void testReplaceEachRepeatedly_repeatTrue() throws Exception {
        assertEquals("tcte", StringUtils.replaceEachRepeatedly("abcde", new String[]{"ab", "d"}, new String[]{"d", "t"}, true, 0));
    }
    
    @Test
    public void testReplaceChars_nullString() throws Exception {
        assertNull(StringUtils.replaceChars(null, 'a', 'b'));
    }

    @Test
    public void testReplaceChars_emptyString() throws Exception {
        assertEquals("", StringUtils.replaceChars("", 'a', 'b'));
    }

    @Test
    public void testReplaceChars_match() throws Exception {
        assertEquals("aycya", StringUtils.replaceChars("abcba", 'b', 'y'));
    }

    @Test
    public void testReplaceChars_noMatch() throws Exception {
        assertEquals("abcba", StringUtils.replaceChars("abcba", 'z', 'y'));
    }

    @Test
    public void testReplaceChars_stringAndString_nullString() throws Exception {
        assertNull(StringUtils.replaceChars(null, "abc", "def"));
    }

    @Test
    public void testReplaceChars_stringAndString_emptyString() throws Exception {
        assertEquals("", StringUtils.replaceChars("", "abc", "def"));
    }

    @Test
    public void testReplaceChars_stringAndString_nullSearchChars() throws Exception {
        assertEquals("abc", StringUtils.replaceChars("abc", null, "def"));
    }

    @Test
    public void testReplaceChars_stringAndString_emptySearchChars() throws Exception {
        assertEquals("abc", StringUtils.replaceChars("abc", "", "def"));
    }

    @Test
    public void testReplaceChars_stringAndString_nullReplaceChars() throws Exception {
        assertEquals("ac", StringUtils.replaceChars("abc", "b", null));
        assertEquals("ac", StringUtils.replaceChars("abc", "b", ""));
    }

    @Test
    public void testReplaceChars_stringAndString_searchLongerThanReplace() throws Exception {
        assertEquals("aycya", StringUtils.replaceChars("abcba", "bc", "yz"));
    }

    @Test
    public void testReplaceChars_stringAndString_searchShorterThanReplace() throws Exception {
        assertEquals("ayzya", StringUtils.replaceChars("abcba", "bc", "yzx"));
    }
    
    @Test
    public void testOverlay_nullString() throws Exception {
        assertNull(StringUtils.overlay(null, "zzzz", 2, 4));
    }

    @Test
    public void testOverlay_nullOverlay() throws Exception {
        assertEquals("abef", StringUtils.overlay("abcdef", null, 2, 4));
    }

    @Test
    public void testOverlay_emptyOverlay() throws Exception {
        assertEquals("abef", StringUtils.overlay("abcdef", "", 2, 4));
    }

    @Test
    public void testOverlay_startNegative() throws Exception {
        assertEquals("zzzzef", StringUtils.overlay("abcdef", "zzzz", -1, 4));
    }

    @Test
    public void testOverlay_endBeyondLength() throws Exception {
        assertEquals("abzzzz", StringUtils.overlay("abcdef", "zzzz", 2, 8));
    }

    @Test
    public void testOverlay_startBeyondLength() throws Exception {
        assertEquals("abcdefzzzz", StringUtils.overlay("abcdef", "zzzz", 8, 10));
    }

    @Test
    public void testOverlay_startGreaterThanEnd() throws Exception {
        assertEquals("abzzzzef", StringUtils.overlay("abcdef", "zzzz", 4, 2));
    }

    @Test
    public void testOverlay_negativeStartNegativeEnd() throws Exception {
        assertEquals("zzzzabcdef", StringUtils.overlay("abcdef", "zzzz", -2, -3));
    }
    
    @Test
    public void testOverlay_emptyString() throws Exception {
        assertEquals("abc", StringUtils.overlay("", "abc", 0, 0));
    }
    
    @Test
    public void testChomp_nullString() throws Exception {
        assertNull(StringUtils.chomp(null));
    }

    @Test
    public void testChomp_emptyString() throws Exception {
        assertEquals("", StringUtils.chomp(""));
    }

    @Test
    public void testChomp_singleCharLF() throws Exception {
        assertEquals("", StringUtils.chomp("\n"));
    }

    @Test
    public void testChomp_singleCharCR() throws Exception {
        assertEquals("", StringUtils.chomp("\r"));
    }

    @Test
    public void testChomp_CRLF() throws Exception {
        assertEquals("", StringUtils.chomp("\r\n"));
    }

    @Test
    public void testChomp_LF() throws Exception {
        assertEquals("abc", StringUtils.chomp("abc\n"));
    }

    @Test
    public void testChomp_CR() throws Exception {
        assertEquals("abc ", StringUtils.chomp("abc \r"));
    }

    @Test
    public void testChomp_CRLF_followedByContent() throws Exception {
        assertEquals("abc\n", StringUtils.chomp("abc\n\r"));
    }

    @Test
    public void testChomp_CRLF_atEnd() throws Exception {
        assertEquals("abc", StringUtils.chomp("abc\r\n"));
    }

    @Test
    public void testChomp_multipleCRLF() throws Exception {
        assertEquals("abc\r\n", StringUtils.chomp("abc\r\n\r\n"));
    }
    
    @Test
    public void testChomp_stringAndSeparator_nullString() throws Exception {
        assertNull(StringUtils.chomp(null, "bar"));
    }

    @Test
    public void testChomp_stringAndSeparator_emptyString() throws Exception {
        assertEquals("", StringUtils.chomp("", "bar"));
    }

    @Test
    public void testChomp_stringAndSeparator_nullSeparator() throws Exception {
        assertEquals("foobar", StringUtils.chomp("foobar", null));
    }

    @Test
    public void testChomp_stringAndSeparator_emptySeparator() throws Exception {
        assertEquals("foobar", StringUtils.chomp("foobar", ""));
    }

    @Test
    public void testChomp_stringAndSeparator_match() throws Exception {
        assertEquals("foo", StringUtils.chomp("foobar", "bar"));
    }

    @Test
    public void testChomp_stringAndSeparator_noMatch() throws Exception {
        assertEquals("foobar", StringUtils.chomp("foobar", "baz"));
    }

    @Test
    public void testChomp_stringAndSeparator_separatorIsWholeString() throws Exception {
        assertEquals("", StringUtils.chomp("foo", "foo"));
    }

    @Test
    public void testChomp_stringAndSeparator_separatorIsPrefix() throws Exception {
        assertEquals("foo ", StringUtils.chomp("foo ", "foo"));
    }

    @Test
    public void testChomp_stringAndSeparator_separatorIsSuffix() throws Exception {
        assertEquals(" ", StringUtils.chomp(" foo", "foo"));
    }

    @Test
    public void testChomp_stringAndSeparator_separatorLonger() throws Exception {
        assertEquals("foo", StringUtils.chomp("foo", "foooo"));
    }
    
    @Test
    public void testChop_nullString() throws Exception {
        assertNull(StringUtils.chop(null));
    }

    @Test
    public void testChop_emptyString() throws Exception {
        assertEquals("", StringUtils.chop(""));
    }

    @Test
    public void testChop_singleChar() throws Exception {
        assertEquals("", StringUtils.chop("a"));
    }

    @Test
    public void testChop_singleCharLF() throws Exception {
        assertEquals("", StringUtils.chop("\n"));
    }

    @Test
    public void testChop_singleCharCR() throws Exception {
        assertEquals("", StringUtils.chop("\r"));
    }

    @Test
    public void testChop_CRLF() throws Exception {
        assertEquals("", StringUtils.chop("\r\n"));
    }

    @Test
    public void testChop_normalString() throws Exception {
        assertEquals("ab", StringUtils.chop("abc"));
    }

    @Test
    public void testChop_endsInLF() throws Exception {
        assertEquals("abc", StringUtils.chop("abc\n"));
    }

    @Test
    public void testChop_endsInCR() throws Exception {
        assertEquals("abc ", StringUtils.chop("abc \r"));
    }

    @Test
    public void testChop_endsInCRLF() throws Exception {
        assertEquals("abc", StringUtils.chop("abc\r\n"));
    }

    @Test
    public void testChop_stringWithInternalLF() throws Exception {
        assertEquals("abc\nab", StringUtils.chop("abc\nabc"));
    }
    
    @Test
    public void testRepeat_nullString() throws Exception {
        assertNull(StringUtils.repeat(null, 2));
    }

    @Test
    public void testRepeat_emptyStringPositiveRepeat() throws Exception {
        assertEquals("", StringUtils.repeat("", 2));
    }

    @Test
    public void testRepeat_emptyStringZeroRepeat() throws Exception {
        assertEquals("", StringUtils.repeat("", 0));
    }

    @Test
    public void testRepeat_positiveRepeat() throws Exception {
        assertEquals("aaa", StringUtils.repeat("a", 3));
        assertEquals("abab", StringUtils.repeat("ab", 2));
    }

    @Test
    public void testRepeat_zeroRepeat() throws Exception {
        assertEquals("", StringUtils.repeat("a", 0));
    }

    @Test
    public void testRepeat_negativeRepeat() throws Exception {
        assertEquals("", StringUtils.repeat("a", -2));
    }
    
    @Test
    public void testRepeat_stringAndSeparator_nullString() throws Exception {
        assertNull(StringUtils.repeat(null, null, 2));
    }

    @Test
    public void testRepeat_stringAndSeparator_nullSeparator() throws Exception {
        assertEquals("aa", StringUtils.repeat("a", null, 2));
    }

    @Test
    public void testRepeat_stringAndSeparator_emptyString() throws Exception {
        assertEquals("", StringUtils.repeat("", "", 2));
    }

    @Test
    public void testRepeat_stringAndSeparator_emptySeparator() throws Exception {
        assertEquals("aa", StringUtils.repeat("a", "", 2));
    }

    @Test
    public void testRepeat_stringAndSeparator_positiveRepeat() throws Exception {
        assertEquals("?, ?, ?", StringUtils.repeat("?", ", ", 3));
    }

    @Test
    public void testRepeat_stringAndSeparator_zeroRepeat() throws Exception {
        assertEquals("", StringUtils.repeat("?", ", ", 0));
    }

    @Test
    public void testRepeat_stringAndSeparator_negativeRepeat() throws Exception {
        assertEquals("", StringUtils.repeat("?", ", ", -2));
    }

    @Test
    public void testRightPad_nullString() throws Exception {
        assertNull(StringUtils.rightPad(null, 3));
    }

    @Test
    public void testRightPad_emptyString() throws Exception {
        assertEquals("   ", StringUtils.rightPad("", 3));
    }

    @Test
    public void testRightPad_sizeEqualsLength() throws Exception {
        assertEquals("bat", StringUtils.rightPad("bat", 3));
    }

    @Test
    public void testRightPad_sizeLargerThanLength() throws Exception {
        assertEquals("bat  ", StringUtils.rightPad("bat", 5));
    }

    @Test
    public void testRightPad_sizeSmallerThanLength() throws Exception {
        assertEquals("bat", StringUtils.rightPad("bat", 1));
    }

    @Test
    public void testRightPad_negativeSize() throws Exception {
        assertEquals("bat", StringUtils.rightPad("bat", -1));
    }
    
    @Test
    public void testRightPad_char_nullString() throws Exception {
        assertNull(StringUtils.rightPad(null, 3, 'z'));
    }

    @Test
    public void testRightPad_char_emptyString() throws Exception {
        assertEquals("zzz", StringUtils.rightPad("", 3, 'z'));
    }

    @Test
    public void testRightPad_char_sizeEqualsLength() throws Exception {
        assertEquals("bat", StringUtils.rightPad("bat", 3, 'z'));
    }

    @Test
    public void testRightPad_char_sizeLargerThanLength() throws Exception {
        assertEquals("batzz", StringUtils.rightPad("bat", 5, 'z'));
    }

    @Test
    public void testRightPad_char_sizeSmallerThanLength() throws Exception {
        assertEquals("bat", StringUtils.rightPad("bat", 1, 'z'));
    }

    @Test
    public void testRightPad_char_negativeSize() throws Exception {
        assertEquals("bat", StringUtils.rightPad("bat", -1, 'z'));
    }
    
    @Test
    public void testRightPad_string_nullString() throws Exception {
        assertNull(StringUtils.rightPad(null, 5, "yz"));
    }

    @Test
    public void testRightPad_string_emptyString() throws Exception {
        assertEquals("yz", StringUtils.rightPad("", 2, "yz"));
        assertEquals("yzy", StringUtils.rightPad("", 3, "yz"));
    }
    
    @Test
    public void testRightPad_string_sizeEqualsLength() throws Exception {
        assertEquals("bat", StringUtils.rightPad("bat", 3, "yz"));
    }

    @Test
    public void testRightPad_string_sizeLargerThanLength() throws Exception {
        assertEquals("batyz", StringUtils.rightPad("bat", 5, "yz"));
        assertEquals("batyzyzy", StringUtils.rightPad("bat", 8, "yz"));
    }

    @Test
    public void testRightPad_string_sizeSmallerThanLength() throws Exception {
        assertEquals("bat", StringUtils.rightPad("bat", 1, "yz"));
    }

    @Test
    public void testRightPad_string_negativeSize() throws Exception {
        assertEquals("bat", StringUtils.rightPad("bat", -1, "yz"));
    }

    @Test
    public void testRightPad_string_nullPadString() throws Exception {
        assertEquals("  bat", StringUtils.rightPad("bat", 5, null));
    }

    @Test
    public void testRightPad_string_emptyPadString() throws Exception {
        assertEquals("  bat", StringUtils.rightPad("bat", 5, ""));
    }

    @Test
    public void testLeftPad_nullString() throws Exception {
        assertNull(StringUtils.leftPad(null, 3));
    }

    @Test
    public void testLeftPad_emptyString() throws Exception {
        assertEquals("   ", StringUtils.leftPad("", 3));
    }

    @Test
    public void testLeftPad_sizeEqualsLength() throws Exception {
        assertEquals("bat", StringUtils.leftPad("bat", 3));
    }

    @Test
    public void testLeftPad_sizeLargerThanLength() throws Exception {
        assertEquals("  bat", StringUtils.leftPad("bat", 5));
    }

    @Test
    public void testLeftPad_sizeSmallerThanLength() throws Exception {
        assertEquals("bat", StringUtils.leftPad("bat", 1));
    }

    @Test
    public void testLeftPad_negativeSize() throws Exception {
        assertEquals("bat", StringUtils.leftPad("bat", -1));
    }
    
    @Test
    public void testLeftPad_char_nullString() throws Exception {
        assertNull(StringUtils.leftPad(null, 3, 'z'));
    }

    @Test
    public void testLeftPad_char_emptyString() throws Exception {
        assertEquals("zzz", StringUtils.leftPad("", 3, 'z'));
    }

    @Test
    public void testLeftPad_char_sizeEqualsLength() throws Exception {
        assertEquals("bat", StringUtils.leftPad("bat", 3, 'z'));
    }

    @Test
    public void testLeftPad_char_sizeLargerThanLength() throws Exception {
        assertEquals("zzbat", StringUtils.leftPad("bat", 5, 'z'));
    }

    @Test
    public void testLeftPad_char_sizeSmallerThanLength() throws Exception {
        assertEquals("bat", StringUtils.leftPad("bat", 1, 'z'));
    }

    @Test
    public void testLeftPad_char_negativeSize() throws Exception {
        assertEquals("bat", StringUtils.leftPad("bat", -1, 'z'));
    }
    
    @Test
    public void testLeftPad_string_nullString() throws Exception {
        assertNull(StringUtils.leftPad(null, 5, "yz"));
    }

    @Test
    public void testLeftPad_string_emptyString() throws Exception {
        assertEquals("yz", StringUtils.leftPad("", 2, "yz"));
        assertEquals("yzy", StringUtils.leftPad("", 3, "yz"));
    }
    
    @Test
    public void testLeftPad_string_sizeEqualsLength() throws Exception {
        assertEquals("bat", StringUtils.leftPad("bat", 3, "yz"));
    }

    @Test
    public void testLeftPad_string_sizeLargerThanLength() throws Exception {
        assertEquals("yzbat", StringUtils.leftPad("bat", 5, "yz"));
        assertEquals("yzyzybat", StringUtils.leftPad("bat", 8, "yz"));
    }

    @Test
    public void testLeftPad_string_sizeSmallerThanLength() throws Exception {
        assertEquals("bat", StringUtils.leftPad("bat", 1, "yz"));
    }

    @Test
    public void testLeftPad_string_negativeSize() throws Exception {
        assertEquals("bat", StringUtils.leftPad("bat", -1, "yz"));
    }

    @Test
    public void testLeftPad_string_nullPadString() throws Exception {
        assertEquals("  bat", StringUtils.leftPad("bat", 5, null));
    }

    @Test
    public void testLeftPad_string_emptyPadString() throws Exception {
        assertEquals("  bat", StringUtils.leftPad("bat", 5, ""));
    }

    @Test
    public void testLength_nullCharSequence() throws Exception {
        assertEquals(0, StringUtils.length(null));
    }

    @Test
    public void testLength_emptyCharSequence() throws Exception {
        assertEquals(0, StringUtils.length(""));
    }

    @Test
    public void testLength_nonEmptyCharSequence() throws Exception {
        assertEquals(3, StringUtils.length("abc"));
    }

    @Test
    public void testCenter_nullString() throws Exception {
        assertNull(StringUtils.center(null, 4));
    }

    @Test
    public void testCenter_negativeSize() throws Exception {
        assertEquals("ab", StringUtils.center("ab", -1));
    }

    @Test
    public void testCenter_emptyString() throws Exception {
        assertEquals("    ", StringUtils.center("", 4));
    }

    @Test
    public void testCenter_sizeEqualsLength() throws Exception {
        assertEquals("abcd", StringUtils.center("abcd", 2));
    }

    @Test
    public void testCenter_evenPadding() throws Exception {
        assertEquals(" ab ", StringUtils.center("ab", 4));
    }

    @Test
    public void testCenter_oddPaddingLeft() throws Exception {
        assertEquals(" a  ", StringUtils.center("a", 4));
    }

    @Test
    public void testCenter_charPad_nullString() throws Exception {
        assertNull(StringUtils.center(null, 4, ' '));
    }

    @Test
    public void testCenter_charPad_negativeSize() throws Exception {
        assertEquals("ab", StringUtils.center("ab", -1, ' '));
    }

    @Test
    public void testCenter_charPad_emptyString() throws Exception {
        assertEquals("    ", StringUtils.center("", 4, ' '));
    }

    @Test
    public void testCenter_charPad_sizeEqualsLength() throws Exception {
        assertEquals("abcd", StringUtils.center("abcd", 2, ' '));
    }

    @Test
    public void testCenter_charPad_evenPadding() throws Exception {
        assertEquals(" ab ", StringUtils.center("ab", 4, ' '));
    }

    @Test
    public void testCenter_charPad_oddPaddingLeft() throws Exception {
        assertEquals(" a  ", StringUtils.center("a", 4, ' '));
    }

    @Test
    public void testCenter_charPad_customChar() throws Exception {
        assertEquals("yayy", StringUtils.center("a", 4, 'y'));
    }

    @Test
    public void testCenter_stringPad_nullString() throws Exception {
        assertNull(StringUtils.center(null, 4, "yz"));
    }

    @Test
    public void testCenter_stringPad_negativeSize() throws Exception {
        assertEquals("ab", StringUtils.center("ab", -1, "yz"));
    }

    @Test
    public void testCenter_stringPad_emptyString() throws Exception {
        assertEquals("    ", StringUtils.center("", 4, " "));
    }

    @Test
    public void testCenter_stringPad_sizeEqualsLength() throws Exception {
        assertEquals("abcd", StringUtils.center("abcd", 2, " "));
    }

    @Test
    public void testCenter_stringPad_evenPadding() throws Exception {
        assertEquals(" ab ", StringUtils.center("ab", 4, " "));
    }

    @Test
    public void testCenter_stringPad_oddPaddingLeft() throws Exception {
        assertEquals(" a  ", StringUtils.center("a", 4, " "));
    }

    @Test
    public void testCenter_stringPad_customString() throws Exception {
        assertEquals("yayz", StringUtils.center("a", 4, "yz"));
    }

    @Test
    public void testCenter_stringPad_nullPadString() throws Exception {
        assertEquals("  abc  ", StringUtils.center("abc", 7, null));
    }

    @Test
    public void testCenter_stringPad_emptyPadString() throws Exception {
        assertEquals("  abc  ", StringUtils.center("abc", 7, ""));
    }
    
    @Test
    public void testUpperCase_null() throws Exception {
        assertNull(StringUtils.upperCase(null));
    }

    @Test
    public void testUpperCase_empty() throws Exception {
        assertEquals("", StringUtils.upperCase(""));
    }

    @Test
    public void testUpperCase_mixedCase() throws Exception {
        assertEquals("ABC", StringUtils.upperCase("aBc"));
    }

    @Test
    public void testUpperCase_alreadyUpper() throws Exception {
        assertEquals("ABC", StringUtils.upperCase("ABC"));
    }

    @Test
    public void testUpperCase_locale_nullString() throws Exception {
        assertNull(StringUtils.upperCase(null, Locale.ENGLISH));
    }

    @Test
    public void testUpperCase_locale_emptyString() throws Exception {
        assertEquals("", StringUtils.upperCase("", Locale.ENGLISH));
    }

    @Test
    public void testUpperCase_locale_mixedCase() throws Exception {
        assertEquals("ABC", StringUtils.upperCase("aBc", Locale.ENGLISH));
    }

    @Test
    public void testLowerCase_null() throws Exception {
        assertNull(StringUtils.lowerCase(null));
    }

    @Test
    public void testLowerCase_empty() throws Exception {
        assertEquals("", StringUtils.lowerCase(""));
    }

    @Test
    public void testLowerCase_mixedCase() throws Exception {
        assertEquals("abc", StringUtils.lowerCase("aBc"));
    }

    @Test
    public void testLowerCase_alreadyLower() throws Exception {
        assertEquals("abc", StringUtils.lowerCase("abc"));
    }

    @Test
    public void testLowerCase_locale_nullString() throws Exception {
        assertNull(StringUtils.lowerCase(null, Locale.ENGLISH));
    }

    @Test
    public void testLowerCase_locale_emptyString() throws Exception {
        assertEquals("", StringUtils.lowerCase("", Locale.ENGLISH));
    }

    @Test
    public void testLowerCase_locale_mixedCase() throws Exception {
        assertEquals("abc", StringUtils.lowerCase("aBc", Locale.ENGLISH));
    }
    
    @Test
    public void testCapitalize_null() throws Exception {
        assertNull(StringUtils.capitalize(null));
    }

    @Test
    public void testCapitalize_empty() throws Exception {
        assertEquals("", StringUtils.capitalize(""));
    }

    @Test
    public void testCapitalize_lowercase() throws Exception {
        assertEquals("Cat", StringUtils.capitalize("cat"));
    }

    @Test
    public void testCapitalize_mixedCase() throws Exception {
        assertEquals("CAt", StringUtils.capitalize("cAt"));
    }

    @Test
    public void testCapitalize_alreadyCapitalized() throws Exception {
        assertEquals("Cat", StringUtils.capitalize("Cat"));
    }
    
    @Test
    public void testUncapitalize_null() throws Exception {
        assertNull(StringUtils.uncapitalize(null));
    }

    @Test
    public void testUncapitalize_empty() throws Exception {
        assertEquals("", StringUtils.uncapitalize(""));
    }

    @Test
    public void testUncapitalize_uppercase() throws Exception {
        assertEquals("cat", StringUtils.uncapitalize("Cat"));
    }

    @Test
    public void testUncapitalize_mixedCase() throws Exception {
        assertEquals("cAT", StringUtils.uncapitalize("CAT"));
    }

    @Test
    public void testUncapitalize_alreadyUncapitalized() throws Exception {
        assertEquals("cat", StringUtils.uncapitalize("cat"));
    }
    
    @Test
    public void testSwapCase_null() throws Exception {
        assertNull(StringUtils.swapCase(null));
    }

    @Test
    public void testSwapCase_empty() throws Exception {
        assertEquals("", StringUtils.swapCase(""));
    }

    @Test
    public void testSwapCase_mixedContent() throws Exception {
        assertEquals("tHE DOG HAS A bone", StringUtils.swapCase("The dog has a BONE"));
    }

    @Test
    public void testSwapCase_onlyUpper() throws Exception {
        assertEquals("abc", StringUtils.swapCase("ABC"));
    }

    @Test
    public void testSwapCase_onlyLower() throws Exception {
        assertEquals("ABC", StringUtils.swapCase("abc"));
    }

    @Test
    public void testCountMatches_nullString() throws Exception {
        assertEquals(0, StringUtils.countMatches(null, "a"));
    }

    @Test
    public void testCountMatches_emptyString() throws Exception {
        assertEquals(0, StringUtils.countMatches("", "a"));
    }

    @Test
    public void testCountMatches_nullSub() throws Exception {
        assertEquals(0, StringUtils.countMatches("abba", null));
    }

    @Test
    public void testCountMatches_emptySub() throws Exception {
        assertEquals(0, StringUtils.countMatches("abba", ""));
    }

    @Test
    public void testCountMatches_singleCharMatch() throws Exception {
        assertEquals(2, StringUtils.countMatches("abba", "a"));
    }

    @Test
    public void testCountMatches_subStringMatch() throws Exception {
        assertEquals(1, StringUtils.countMatches("abba", "ab"));
    }

    @Test
    public void testCountMatches_noMatch() throws Exception {
        assertEquals(0, StringUtils.countMatches("abba", "xxx"));
    }
    
    @Test
    public void testCountMatches_overlappingMatches() throws Exception {
        assertEquals(3, StringUtils.countMatches("aaaaa", "aa")); // aaaaa -> aa aa aa
    }

    @Test
    public void testIsAlpha_null() throws Exception {
        assertFalse(StringUtils.isAlpha(null));
    }

    @Test
    public void testIsAlpha_empty() throws Exception {
        assertTrue(StringUtils.isAlpha(""));
    }

    @Test
    public void testIsAlpha_whitespace() throws Exception {
        assertFalse(StringUtils.isAlpha("  "));
    }

    @Test
    public void testIsAlpha_lettersOnly() throws Exception {
        assertTrue(StringUtils.isAlpha("abc"));
    }

    @Test
    public void testIsAlpha_withDigit() throws Exception {
        assertFalse(StringUtils.isAlpha("ab2c"));
    }

    @Test
    public void testIsAlpha_withSymbol() throws Exception {
        assertFalse(StringUtils.isAlpha("ab-c"));
    }

    @Test
    public void testIsAlphaSpace_null() throws Exception {
        assertFalse(StringUtils.isAlphaSpace(null));
    }

    @Test
    public void testIsAlphaSpace_empty() throws Exception {
        assertTrue(StringUtils.isAlphaSpace(""));
    }

    @Test
    public void testIsAlphaSpace_whitespaceOnly() throws Exception {
        assertTrue(StringUtils.isAlphaSpace("  "));
    }

    @Test
    public void testIsAlphaSpace_lettersOnly() throws Exception {
        assertTrue(StringUtils.isAlphaSpace("abc"));
    }

    @Test
    public void testIsAlphaSpace_lettersAndSpace() throws Exception {
        assertTrue(StringUtils.isAlphaSpace("ab c"));
    }

    @Test
    public void testIsAlphaSpace_withDigit() throws Exception {
        assertFalse(StringUtils.isAlphaSpace("ab2c"));
    }

    @Test
    public void testIsAlphaSpace_withSymbol() throws Exception {
        assertFalse(StringUtils.isAlphaSpace("ab-c"));
    }

    @Test
    public void testIsAlphanumeric_null() throws Exception {
        assertFalse(StringUtils.isAlphanumeric(null));
    }

    @Test
    public void testIsAlphanumeric_empty() throws Exception {
        assertTrue(StringUtils.isAlphanumeric(""));
    }

    @Test
    public void testIsAlphanumeric_whitespace() throws Exception {
        assertFalse(StringUtils.isAlphanumeric("  "));
    }

    @Test
    public void testIsAlphanumeric_lettersOnly() throws Exception {
        assertTrue(StringUtils.isAlphanumeric("abc"));
    }

    @Test
    public void testIsAlphanumeric_lettersAndSpace() throws Exception {
        assertFalse(StringUtils.isAlphanumeric("ab c"));
    }

    @Test
    public void testIsAlphanumeric_lettersAndDigits() throws Exception {
        assertTrue(StringUtils.isAlphanumeric("ab2c"));
    }

    @Test
    public void testIsAlphanumeric_withSymbol() throws Exception {
        assertFalse(StringUtils.isAlphanumeric("ab-c"));
    }

    @Test
    public void testIsAlphanumericSpace_null() throws Exception {
        assertFalse(StringUtils.isAlphanumericSpace(null));
    }

    @Test
    public void testIsAlphanumericSpace_empty() throws Exception {
        assertTrue(StringUtils.isAlphanumericSpace(""));
    }

    @Test
    public void testIsAlphanumericSpace_whitespaceOnly() throws Exception {
        assertTrue(StringUtils.isAlphanumericSpace("  "));
    }

    @Test
    public void testIsAlphanumericSpace_lettersOnly() throws Exception {
        assertTrue(StringUtils.isAlphanumericSpace("abc"));
    }

    @Test
    public void testIsAlphanumericSpace_lettersAndSpace() throws Exception {
        assertTrue(StringUtils.isAlphanumericSpace("ab c"));
    }

    @Test
    public void testIsAlphanumericSpace_lettersAndDigits() throws Exception {
        assertTrue(StringUtils.isAlphanumericSpace("ab2c"));
    }

    @Test
    public void testIsAlphanumericSpace_withSymbol() throws Exception {
        assertFalse(StringUtils.isAlphanumericSpace("ab-c"));
    }
    
    @Test
    public void testIsAsciiPrintable_null() throws Exception {
        assertFalse(StringUtils.isAsciiPrintable(null));
    }

    @Test
    public void testIsAsciiPrintable_empty() throws Exception {
        assertTrue(StringUtils.isAsciiPrintable(""));
    }

    @Test
    public void testIsAsciiPrintable_space() throws Exception {
        assertTrue(StringUtils.isAsciiPrintable(" "));
    }

    @Test
    public void testIsAsciiPrintable_lettersAndDigits() throws Exception {
        assertTrue(StringUtils.isAsciiPrintable("ab2c"));
    }

    @Test
    public void testIsAsciiPrintable_symbols() throws Exception {
        assertTrue(StringUtils.isAsciiPrintable("!ab-c~"));
    }

    @Test
    public void testIsAsciiPrintable_maxPrintable() throws Exception {
        assertTrue(StringUtils.isAsciiPrintable("\u007e")); // '~'
    }

    @Test
    public void testIsAsciiPrintable_deleteChar() throws Exception {
        assertFalse(StringUtils.isAsciiPrintable("\u007f")); // DEL
    }

    @Test
    public void testIsAsciiPrintable_nonAscii() throws Exception {
        assertFalse(StringUtils.isAsciiPrintable("Ceki G\u00fclc\u00fc"));
    }
    
    @Test
    public void testIsNumeric_null() throws Exception {
        assertFalse(StringUtils.isNumeric(null));
    }

    @Test
    public void testIsNumeric_empty() throws Exception {
        assertTrue(StringUtils.isNumeric(""));
    }

    @Test
    public void testIsNumeric_whitespace() throws Exception {
        assertFalse(StringUtils.isNumeric("  "));
    }

    @Test
    public void testIsNumeric_digitsOnly() throws Exception {
        assertTrue(StringUtils.isNumeric("123"));
    }

    @Test
    public void testIsNumeric_withSpace() throws Exception {
        assertFalse(StringUtils.isNumeric("12 3"));
    }

    @Test
    public void testIsNumeric_withLetters() throws Exception {
        assertFalse(StringUtils.isNumeric("ab2c"));
    }

    @Test
    public void testIsNumeric_withSymbol() throws Exception {
        assertFalse(StringUtils.isNumeric("12-3"));
    }

    @Test
    public void testIsNumeric_withDecimal() throws Exception {
        assertFalse(StringUtils.isNumeric("12.3"));
    }
    
    @Test
    public void testIsNumericSpace_null() throws Exception {
        assertFalse(StringUtils.isNumericSpace(null));
    }

    @Test
    public void testIsNumericSpace_empty() throws Exception {
        assertTrue(StringUtils.isNumericSpace(""));
    }

    @Test
    public void testIsNumericSpace_whitespaceOnly() throws Exception {
        assertTrue(StringUtils.isNumericSpace("  "));
    }

    @Test
    public void testIsNumericSpace_digitsOnly() throws Exception {
        assertTrue(StringUtils.isNumericSpace("123"));
    }

    @Test
    public void testIsNumericSpace_digitsAndSpace() throws Exception {
        assertTrue(StringUtils.isNumericSpace("12 3"));
    }

    @Test
    public void testIsNumericSpace_withLetters() throws Exception {
        assertFalse(StringUtils.isNumericSpace("ab2c"));
    }

    @Test
    public void testIsNumericSpace_withSymbol() throws Exception {
        assertFalse(StringUtils.isNumericSpace("12-3"));
    }

    @Test
    public void testIsNumericSpace_withDecimal() throws Exception {
        assertFalse(StringUtils.isNumericSpace("12.3"));
    }
    
    @Test
    public void testIsWhitespace_null() throws Exception {
        assertFalse(StringUtils.isWhitespace(null));
    }

    @Test
    public void testIsWhitespace_empty() throws Exception {
        assertTrue(StringUtils.isWhitespace(""));
    }

    @Test
    public void testIsWhitespace_onlyWhitespace() throws Exception {
        assertTrue(StringUtils.isWhitespace("  "));
        assertTrue(StringUtils.isWhitespace("\t\n\r\f"));
    }

    @Test
    public void testIsWhitespace_nonWhitespace() throws Exception {
        assertFalse(StringUtils.isWhitespace("abc"));
    }

    @Test
    public void testIsWhitespace_mixed() throws Exception {
        assertFalse(StringUtils.isWhitespace("ab c"));
    }
    
    @Test
    public void testIsAllLowerCase_null() throws Exception {
        assertFalse(StringUtils.isAllLowerCase(null));
    }

    @Test
    public void testIsAllLowerCase_empty() throws Exception {
        assertFalse(StringUtils.isAllLowerCase(""));
    }

    @Test
    public void testIsAllLowerCase_whitespace() throws Exception {
        assertFalse(StringUtils.isAllLowerCase("  "));
    }

    @Test
    public void testIsAllLowerCase_allLower() throws Exception {
        assertTrue(StringUtils.isAllLowerCase("abc"));
    }

    @Test
    public void testIsAllLowerCase_mixedCase() throws Exception {
        assertFalse(StringUtils.isAllLowerCase("abC"));
    }
    
    @Test
    public void testIsAllUpperCase_null() throws Exception {
        assertFalse(StringUtils.isAllUpperCase(null));
    }

    @Test
    public void testIsAllUpperCase_empty() throws Exception {
        assertFalse(StringUtils.isAllUpperCase(""));
    }

    @Test
    public void testIsAllUpperCase_whitespace() throws Exception {
        assertFalse(StringUtils.isAllUpperCase("  "));
    }

    @Test
    public void testIsAllUpperCase_allUpper() throws Exception {
        assertTrue(StringUtils.isAllUpperCase("ABC"));
    }

    @Test
    public void testIsAllUpperCase_mixedCase() throws Exception {
        assertFalse(StringUtils.isAllUpperCase("aBC"));
    }
    
    @Test
    public void testDefaultString_null() throws Exception {
        assertEquals("", StringUtils.defaultString(null));
    }

    @Test
    public void testDefaultString_empty() throws Exception {
        assertEquals("", StringUtils.defaultString(""));
    }

    @Test
    public void testDefaultString_nonEmpty() throws Exception {
        assertEquals("bat", StringUtils.defaultString("bat"));
    }
    
    @Test
    public void testDefaultString_withDefault_null() throws Exception {
        assertEquals("NULL", StringUtils.defaultString(null, "NULL"));
    }

    @Test
    public void testDefaultString_withDefault_empty() throws Exception {
        assertEquals("", StringUtils.defaultString("", "NULL"));
    }

    @Test
    public void testDefaultString_withDefault_nonEmpty() throws Exception {
        assertEquals("bat", StringUtils.defaultString("bat", "NULL"));
    }

    @Test
    public void testDefaultString_withDefault_defaultNull() throws Exception {
        assertEquals("NULL", StringUtils.defaultString(null, null));
    }
    
    @Test
    public void testDefaultIfEmpty_nullInput() throws Exception {
        assertEquals("NULL", StringUtils.defaultIfEmpty(null, "NULL"));
    }

    @Test
    public void testDefaultIfEmpty_emptyInput() throws Exception {
        assertEquals("NULL", StringUtils.defaultIfEmpty("", "NULL"));
    }

    @Test
    public void testDefaultIfEmpty_nonEmptyInput() throws Exception {
        assertEquals("bat", StringUtils.defaultIfEmpty("bat", "NULL"));
    }

    @Test
    public void testDefaultIfEmpty_emptyInputDefaultNull() throws Exception {
        assertNull(StringUtils.defaultIfEmpty("", null));
    }
    
    @Test
    public void testReverse_null() throws Exception {
        assertNull(StringUtils.reverse(null));
    }

    @Test
    public void testReverse_empty() throws Exception {
        assertEquals("", StringUtils.reverse(""));
    }

    @Test
    public void testReverse_normal() throws Exception {
        assertEquals("tab", StringUtils.reverse("bat"));
    }
    
    @Test
    public void testReverseDelimited_null() throws Exception {
        assertNull(StringUtils.reverseDelimited(null, '.'));
    }

    @Test
    public void testReverseDelimited_empty() throws Exception {
        assertEquals("", StringUtils.reverseDelimited("", '.'));
    }

    @Test
    public void testReverseDelimited_noSeparator() throws Exception {
        assertEquals("a.b.c", StringUtils.reverseDelimited("a.b.c", 'x'));
    }

    @Test
    public void testReverseDelimited_simpleCase() throws Exception {
        assertEquals("c.b.a", StringUtils.reverseDelimited("a.b.c", '.'));
    }
    
    @Test
    public void testAbbreviate_nullString() throws Exception {
        assertNull(StringUtils.abbreviate(null, 10));
    }

    @Test
    public void testAbbreviate_emptyString() throws Exception {
        assertEquals("", StringUtils.abbreviate("", 4));
    }

    @Test
    public void testAbbreviate_shorterThanMaxWidth() throws Exception {
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 7));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 8));
    }

    @Test
    public void testAbbreviate_exactlyMaxWidth() throws Exception {
        assertEquals("abc...", StringUtils.abbreviate("abcdefg", 6));
    }

    @Test
    public void testAbbreviate_smallerThanFour() throws Exception {
        try {
            StringUtils.abbreviate("abcdefg", 3);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
        }
    }

    @Test
    public void testAbbreviate_verySmallWidth() throws Exception {
        assertEquals("a...", StringUtils.abbreviate("abcdefg", 4));
    }

    @Test
    public void testAbbreviate_offset_nullString() throws Exception {
        assertNull(StringUtils.abbreviate(null, 0, 10));
    }

    @Test
    public void testAbbreviate_offset_emptyString() throws Exception {
        assertEquals("", StringUtils.abbreviate("", 0, 4));
    }

    @Test
    public void testAbbreviate_offset_offsetTooLarge() throws Exception {
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 10, 10));
        assertEquals("abcdefg", StringUtils.abbreviate("abcdefg", 12, 10));
    }

    @Test
    public void testAbbreviate_offset_leftEdgeStartOfResult() throws Exception {
        assertEquals("abcdefg...", StringUtils.abbreviate("abcdefghijklmno", -1, 10));
        assertEquals("abcdefg...", StringUtils.abbreviate("abcdefghijklmno", 0, 10));
        assertEquals("abcdefg...", StringUtils.abbreviate("abcdefghijklmno", 1, 10));
        assertEquals("abcdefg...", StringUtils.abbreviate("abcdefghijklmno", 4, 10));
    }

    @Test
    public void testAbbreviate_offset_middleEllipsis() throws Exception {
        assertEquals("...fghi...", StringUtils.abbreviate("abcdefghijklmno", 5, 10));
    }
    
    @Test
    public void testAbbreviate_offset_rightEdgeEllipsis() throws Exception {
        assertEquals("...ijklmno", StringUtils.abbreviate("abcdefghijklmno", 8, 10));
        assertEquals("...ijklmno", StringUtils.abbreviate("abcdefghijklmno", 10, 10));
    }

    @Test
    public void testAbbreviate_offset_widthTooSmallForOffset() throws Exception {
        try {
            StringUtils.abbreviate("abcdefghij", 0, 3);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
        }
        try {
            StringUtils.abbreviate("abcdefghij", 5, 6);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
        }
    }

    @Test
    public void testAbbreviateMiddle_nullString() throws Exception {
        assertNull(StringUtils.abbreviateMiddle(null, ".", 0));
    }

    @Test
    public void testAbbreviateMiddle_nullMiddle() throws Exception {
        assertEquals("abc", StringUtils.abbreviateMiddle("abc", null, 0));
    }

    @Test
    public void testAbbreviateMiddle_emptyMiddle() throws Exception {
        assertEquals("abc", StringUtils.abbreviateMiddle("abc", ".", 0));
    }

    @Test
    public void testAbbreviateMiddle_lengthZero() throws Exception {
        assertEquals("abc", StringUtils.abbreviateMiddle("abc", ".", 0));
    }

    @Test
    public void testAbbreviateMiddle_lengthEqualsStringLength() throws Exception {
        assertEquals("abc", StringUtils.abbreviateMiddle("abc", ".", 3));
    }

    @Test
    public void testAbbreviateMiddle_lengthTooSmallForMiddle() throws Exception {
        assertEquals("abc", StringUtils.abbreviateMiddle("abc", ".", 2)); // Middle length + 2 chars = 1 + 2 = 3. Length must be >= 3.
    }

    @Test
    public void testAbbreviateMiddle_abbreviate() throws Exception {
        assertEquals("ab.f", StringUtils.abbreviateMiddle("abcdef", ".", 4));
    }

    @Test
    public void testAbbreviateMiddle_abbreviateWithLongMiddle() throws Exception {
        assertEquals("a...f", StringUtils.abbreviateMiddle("abcdef", "...", 4));
    }

    @Test
    public void testAbbreviateMiddle_abbreviateWithOddPadding() throws Exception {
        assertEquals("a.c", StringUtils.abbreviateMiddle("abcd", ".", 3));
    }
    
    @Test
    public void testDifference_nullNull() throws Exception {
        assertNull(StringUtils.difference(null, null));
    }

    @Test
    public void testDifference_emptyEmpty() throws Exception {
        assertEquals("", StringUtils.difference("", ""));
    }

    @Test
    public void testDifference_emptyFirst() throws Exception {
        assertEquals("abc", StringUtils.difference("", "abc"));
    }

    @Test
    public void testDifference_emptySecond() throws Exception {
        assertEquals("", StringUtils.difference("abc", ""));
    }

    @Test
    public void testDifference_equalStrings() throws Exception {
        assertEquals("", StringUtils.difference("abc", "abc"));
    }

    @Test
    public void testDifference_prefixMatch() throws Exception {
        assertEquals("xyz", StringUtils.difference("ab", "abxyz"));
        assertEquals("xyz", StringUtils.difference("abcde", "abxyz"));
    }

    @Test
    public void testDifference_noPrefixMatch() throws Exception {
        assertEquals("xyz", StringUtils.difference("abcde", "xyz"));
    }
    
    @Test
    public void testIndexOfDifference_nullNull() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfDifference(null, null));
    }

    @Test
    public void testIndexOfDifference_emptyEmpty() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfDifference("", ""));
    }

    @Test
    public void testIndexOfDifference_emptyFirst() throws Exception {
        assertEquals(0, StringUtils.indexOfDifference("", "abc"));
    }

    @Test
    public void testIndexOfDifference_emptySecond() throws Exception {
        assertEquals(0, StringUtils.indexOfDifference("abc", ""));
    }

    @Test
    public void testIndexOfDifference_equalStrings() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfDifference("abc", "abc"));
    }

    @Test
    public void testIndexOfDifference_prefixMatch() throws Exception {
        assertEquals(2, StringUtils.indexOfDifference("ab", "abxyz"));
        assertEquals(2, StringUtils.indexOfDifference("abcde", "abxyz"));
    }

    @Test
    public void testIndexOfDifference_noPrefixMatch() throws Exception {
        assertEquals(0, StringUtils.indexOfDifference("abcde", "xyz"));
    }
    
    @Test
    public void testIndexOfDifference_array_nullArray() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfDifference((CharSequence[]) null));
    }

    @Test
    public void testIndexOfDifference_array_emptyArray() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfDifference(new CharSequence[0]));
    }

    @Test
    public void testIndexOfDifference_array_singleElement() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfDifference(new String[]{"abc"}));
    }

    @Test
    public void testIndexOfDifference_array_allNull() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfDifference(new String[]{null, null}));
    }

    @Test
    public void testIndexOfDifference_array_allEmpty() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfDifference(new String[]{"", ""}));
    }

    @Test
    public void testIndexOfDifference_array_emptyAndNull() throws Exception {
        assertEquals(0, StringUtils.indexOfDifference(new String[]{"", null}));
        assertEquals(0, StringUtils.indexOfDifference(new String[]{null, ""}));
    }

    @Test
    public void testIndexOfDifference_array_someNulls() throws Exception {
        assertEquals(0, StringUtils.indexOfDifference(new String[]{"abc", null, null}));
        assertEquals(0, StringUtils.indexOfDifference(new String[]{null, null, "abc"}));
    }

    @Test
    public void testIndexOfDifference_array_equalStrings() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfDifference(new String[]{"abc", "abc"}));
    }

    @Test
    public void testIndexOfDifference_array_prefixMatch() throws Exception {
        assertEquals(1, StringUtils.indexOfDifference(new String[]{"abc", "a"}));
        assertEquals(2, StringUtils.indexOfDifference(new String[]{"ab", "abxyz"}));
        assertEquals(2, StringUtils.indexOfDifference(new String[]{"abcde", "abxyz"}));
    }

    @Test
    public void testIndexOfDifference_array_noPrefixMatch() throws Exception {
        assertEquals(0, StringUtils.indexOfDifference(new String[]{"abcde", "xyz"}));
        assertEquals(0, StringUtils.indexOfDifference(new String[]{"xyz", "abcde"}));
    }

    @Test
    public void testIndexOfDifference_array_multipleStrings() throws Exception {
        assertEquals(7, StringUtils.indexOfDifference(new String[]{"i am a machine", "i am a robot"}));
    }

    @Test
    public void testGetCommonPrefix_nullArray() throws Exception {
        assertEquals("", StringUtils.getCommonPrefix(null));
    }

    @Test
    public void testGetCommonPrefix_emptyArray() throws Exception {
        assertEquals("", StringUtils.getCommonPrefix(new String[]{}));
    }

    @Test
    public void testGetCommonPrefix_singleElement() throws Exception {
        assertEquals("abc", StringUtils.getCommonPrefix(new String[]{"abc"}));
    }

    @Test
    public void testGetCommonPrefix_allNull() throws Exception {
        assertEquals("", StringUtils.getCommonPrefix(new String[]{null, null}));
    }

    @Test
    public void testGetCommonPrefix_allEmpty() throws Exception {
        assertEquals("", StringUtils.getCommonPrefix(new String[]{"", ""}));
    }

    @Test
    public void testGetCommonPrefix_emptyAndNull() throws Exception {
        assertEquals("", StringUtils.getCommonPrefix(new String[]{"", null}));
        assertEquals("", StringUtils.getCommonPrefix(new String[]{null, ""}));
    }

    @Test
    public void testGetCommonPrefix_someNulls() throws Exception {
        assertEquals("", StringUtils.getCommonPrefix(new String[]{"abc", null, null}));
        assertEquals("", StringUtils.getCommonPrefix(new String[]{null, null, "abc"}));
    }

    @Test
    public void testGetCommonPrefix_equalStrings() throws Exception {
        assertEquals("abc", StringUtils.getCommonPrefix(new String[]{"abc", "abc"}));
    }

    @Test
    public void testGetCommonPrefix_prefixMatch() throws Exception {
        assertEquals("a", StringUtils.getCommonPrefix(new String[]{"abc", "a"}));
        assertEquals("ab", StringUtils.getCommonPrefix(new String[]{"ab", "abxyz"}));
        assertEquals("ab", StringUtils.getCommonPrefix(new String[]{"abcde", "abxyz"}));
    }

    @Test
    public void testGetCommonPrefix_noPrefixMatch() throws Exception {
        assertEquals("", StringUtils.getCommonPrefix(new String[]{"abcde", "xyz"}));
        assertEquals("", StringUtils.getCommonPrefix(new String[]{"xyz", "abcde"}));
    }

    @Test
    public void testGetCommonPrefix_multipleStrings() throws Exception {
        assertEquals("i am a ", StringUtils.getCommonPrefix(new String[]{"i am a machine", "i am a robot"}));
    }
    
    @Test
    public void testLevenshteinDistance_nullS() throws Exception {
        try {
            StringUtils.getLevenshteinDistance(null, "abc");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
        }
    }

    @Test
    public void testLevenshteinDistance_nullT() throws Exception {
        try {
            StringUtils.getLevenshteinDistance("abc", null);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
        }
    }

    @Test
    public void testLevenshteinDistance_emptyEmpty() throws Exception {
        assertEquals(0, StringUtils.getLevenshteinDistance("", ""));
    }

    @Test
    public void testLevenshteinDistance_emptyS() throws Exception {
        assertEquals(1, StringUtils.getLevenshteinDistance("", "a"));
    }

    @Test
    public void testLevenshteinDistance_emptyT() throws Exception {
        assertEquals(7, StringUtils.getLevenshteinDistance("aaapppp", ""));
    }

    @Test
    public void testLevenshteinDistance_simpleDifference() throws Exception {
        assertEquals(1, StringUtils.getLevenshteinDistance("frog", "fog"));
        assertEquals(3, StringUtils.getLevenshteinDistance("fly", "ant"));
        assertEquals(1, StringUtils.getLevenshteinDistance("hello", "hallo"));
    }

    @Test
    public void testLevenshteinDistance_complexDifference() throws Exception {
        assertEquals(7, StringUtils.getLevenshteinDistance("elephant", "hippo"));
        assertEquals(7, StringUtils.getLevenshteinDistance("hippo", "elephant"));
    }

    @Test
    public void testLevenshteinDistance_completelyDifferent() throws Exception {
        assertEquals(8, StringUtils.getLevenshteinDistance("hippo", "zzzzzzzz"));
    }
    
    @Test
    public void testStartsWith_nullString() throws Exception {
        assertTrue(StringUtils.startsWith(null, null));
    }

    @Test
    public void testStartsWith_nullPrefix() throws Exception {
        assertFalse(StringUtils.startsWith("abc", null));
    }

    @Test
    public void testStartsWith_stringNull() throws Exception {
        assertFalse(StringUtils.startsWith(null, "abc"));
    }

    @Test
    public void testStartsWith_prefixLonger() throws Exception {
        assertFalse(StringUtils.startsWith("abc", "abcd"));
    }

    @Test
    public void testStartsWith_match() throws Exception {
        assertTrue(StringUtils.startsWith("abcdef", "abc"));
    }

    @Test
    public void testStartsWith_noMatchCaseSensitive() throws Exception {
        assertFalse(StringUtils.startsWith("ABCDEF", "abc"));
    }
    
    @Test
    public void testStartsWithIgnoreCase_nullString() throws Exception {
        assertTrue(StringUtils.startsWithIgnoreCase(null, null));
    }

    @Test
    public void testStartsWithIgnoreCase_nullPrefix() throws Exception {
        assertFalse(StringUtils.startsWithIgnoreCase("abc", null));
    }

    @Test
    public void testStartsWithIgnoreCase_stringNull() throws Exception {
        assertFalse(StringUtils.startsWithIgnoreCase(null, "abc"));
    }

    @Test
    public void testStartsWithIgnoreCase_prefixLonger() throws Exception {
        assertFalse(StringUtils.startsWithIgnoreCase("abc", "abcd"));
    }

    @Test
    public void testStartsWithIgnoreCase_match() throws Exception {
        assertTrue(StringUtils.startsWithIgnoreCase("abcdef", "abc"));
    }

    @Test
    public void testStartsWithIgnoreCase_matchCaseInsensitive() throws Exception {
        assertTrue(StringUtils.startsWithIgnoreCase("ABCDEF", "abc"));
    }
    
    @Test
    public void testStartsWithAny_nullString() throws Exception {
        assertFalse(StringUtils.startsWithAny(null, new String[]{"abc"}));
    }

    @Test
    public void testStartsWithAny_nullSearchStrings() throws Exception {
        assertFalse(StringUtils.startsWithAny("abcxyz", null));
    }

    @Test
    public void testStartsWithAny_emptySearchStrings() throws Exception {
        assertFalse(StringUtils.startsWithAny("abcxyz", new String[]{}));
    }

    @Test
    public void testStartsWithAny_emptyPrefixInSearchStrings() throws Exception {
        assertFalse(StringUtils.startsWithAny("abcxyz", new String[]{""}));
    }

    @Test
    public void testStartsWithAny_match() throws Exception {
        assertTrue(StringUtils.startsWithAny("abcxyz", new String[]{"abc"}));
    }

    @Test
    public void testStartsWithAny_matchWithNullPrefix() throws Exception {
        assertTrue(StringUtils.startsWithAny("abcxyz", new String[]{null, "xyz", "abc"}));
    }

    @Test
    public void testStartsWithAny_noMatch() throws Exception {
        assertFalse(StringUtils.startsWithAny("abcxyz", new String[]{"def", "ghi"}));
    }
    
    @Test
    public void testEndsWith_nullString() throws Exception {
        assertTrue(StringUtils.endsWith(null, null));
    }

    @Test
    public void testEndsWith_nullSuffix() throws Exception {
        assertFalse(StringUtils.endsWith("abcdef", null));
    }

    @Test
    public void testEndsWith_stringNull() throws Exception {
        assertFalse(StringUtils.endsWith(null, "def"));
    }

    @Test
    public void testEndsWith_suffixLonger() throws Exception {
        assertFalse(StringUtils.endsWith("abcdef", "abcdefg"));
    }

    @Test
    public void testEndsWith_match() throws Exception {
        assertTrue(StringUtils.endsWith("abcdef", "def"));
    }

    @Test
    public void testEndsWith_noMatchCaseSensitive() throws Exception {
        assertFalse(StringUtils.endsWith("ABCDEF", "def"));
        assertFalse(StringUtils.endsWith("ABCDEF", "cde"));
    }
    
    @Test
    public void testEndsWithIgnoreCase_nullString() throws Exception {
        assertTrue(StringUtils.endsWithIgnoreCase(null, null));
    }

    @Test
    public void testEndsWithIgnoreCase_nullSuffix() throws Exception {
        assertFalse(StringUtils.endsWithIgnoreCase("abcdef", null));
    }

    @Test
    public void testEndsWithIgnoreCase_stringNull() throws Exception {
        assertFalse(StringUtils.endsWithIgnoreCase(null, "def"));
    }

    @Test
    public void testEndsWithIgnoreCase_suffixLonger() throws Exception {
        assertFalse(StringUtils.endsWithIgnoreCase("abcdef", "abcdefg"));
    }

    @Test
    public void testEndsWithIgnoreCase_match() throws Exception {
        assertTrue(StringUtils.endsWithIgnoreCase("abcdef", "def"));
    }

    @Test
    public void testEndsWithIgnoreCase_matchCaseInsensitive() throws Exception {
        assertTrue(StringUtils.endsWithIgnoreCase("ABCDEF", "def"));
        assertTrue(StringUtils.endsWithIgnoreCase("ABCDEF", "DEF"));
    }

    @Test
    public void testEndsWithIgnoreCase_noMatch() throws Exception {
        assertFalse(StringUtils.endsWithIgnoreCase("ABCDEF", "cde"));
    }
    
    @Test
    public void testContains_nullString() throws Exception {
        assertFalse(StringUtils.contains(null, 'a'));
    }

    @Test
    public void testContains_emptyString() throws Exception {
        assertFalse(StringUtils.contains("", 'a'));
    }

    @Test
    public void testContains_charFound() throws Exception {
        assertTrue(StringUtils.contains("abc", 'a'));
    }

    @Test
    public void testContains_charNotFound() throws Exception {
        assertFalse(StringUtils.contains("abc", 'z'));
    }

    @Test
    public void testContains_string_nullString() throws Exception {
        assertFalse(StringUtils.contains(null, "a"));
    }

    @Test
    public void testContains_string_nullSearchString() throws Exception {
        assertFalse(StringUtils.contains("abc", null));
    }

    @Test
    public void testContains_string_emptyStringAndEmptySearchString() throws Exception {
        assertTrue(StringUtils.contains("", ""));
    }

    @Test
    public void testContains_string_emptySearchString() throws Exception {
        assertTrue(StringUtils.contains("abc", ""));
    }

    @Test
    public void testContains_string_stringFound() throws Exception {
        assertTrue(StringUtils.contains("abc", "a"));
    }

    @Test
    public void testContains_string_stringNotFound() throws Exception {
        assertFalse(StringUtils.contains("abc", "z"));
    }

    @Test
    public void testContainsIgnoreCase_string_nullString() throws Exception {
        assertFalse(StringUtils.containsIgnoreCase(null, "a"));
    }

    @Test
    public void testContainsIgnoreCase_string_nullSearchString() throws Exception {
        assertFalse(StringUtils.containsIgnoreCase("abc", null));
    }

    @Test
    public void testContainsIgnoreCase_string_emptyStringAndEmptySearchString() throws Exception {
        assertTrue(StringUtils.containsIgnoreCase("", ""));
    }

    @Test
    public void testContainsIgnoreCase_string_emptySearchString() throws Exception {
        assertTrue(StringUtils.containsIgnoreCase("abc", ""));
    }

    @Test
    public void testContainsIgnoreCase_string_stringFound() throws Exception {
        assertTrue(StringUtils.containsIgnoreCase("abc", "a"));
        assertTrue(StringUtils.containsIgnoreCase("abc", "A"));
    }

    @Test
    public void testContainsIgnoreCase_string_stringNotFound() throws Exception {
        assertFalse(StringUtils.containsIgnoreCase("abc", "z"));
        assertFalse(StringUtils.containsIgnoreCase("abc", "Z"));
    }
    
    @Test
    public void testIndexOfAny_CharSequence_charArray_nullCharSequence() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAny(null, new char[]{'a'}));
    }

    @Test
    public void testIndexOfAny_CharSequence_charArray_emptyCharSequence() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAny("", new char[]{'a'}));
    }

    @Test
    public void testIndexOfAny_CharSequence_charArray_nullSearchChars() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAny("abc", null));
    }

    @Test
    public void testIndexOfAny_CharSequence_charArray_emptySearchChars() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAny("abc", new char[]{}));
    }

    @Test
    public void testIndexOfAny_CharSequence_charArray_found() throws Exception {
        assertEquals(0, StringUtils.indexOfAny("zzabyycdxx", new char[]{'z', 'a'}));
        assertEquals(3, StringUtils.indexOfAny("zzabyycdxx", new char[]{'b', 'y'}));
    }

    @Test
    public void testIndexOfAny_CharSequence_charArray_notFound() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAny("aba", new char[]{'z'}));
    }

    @Test
    public void testIndexOfAny_CharSequence_charArray_withSupplementaryChar() throws Exception {
        char highSurrogate = '\uD83D';
        char lowSurrogate = '\uDCA9';
        assertEquals(0, StringUtils.indexOfAny(new String(new char[]{highSurrogate, lowSurrogate, 'a'}), new char[]{highSurrogate, lowSurrogate}));
        assertEquals(2, StringUtils.indexOfAny(new String(new char[]{highSurrogate, lowSurrogate, 'a'}), new char[]{'a'}));
    }
    
    @Test
    public void testContainsAny_String_charArray_nullCharSequence() throws Exception {
        assertFalse(StringUtils.containsAny(null, new char[]{'a'}));
    }

    @Test
    public void testContainsAny_String_charArray_emptyCharSequence() throws Exception {
        assertFalse(StringUtils.containsAny("", new char[]{'a'}));
    }

    @Test
    public void testContainsAny_String_charArray_nullSearchChars() throws Exception {
        assertFalse(StringUtils.containsAny("abc", null));
    }

    @Test
    public void testContainsAny_String_charArray_emptySearchChars() throws Exception {
        assertFalse(StringUtils.containsAny("abc", new char[]{}));
    }

    @Test
    public void testContainsAny_String_charArray_found() throws Exception {
        assertTrue(StringUtils.containsAny("zzabyycdxx", new char[]{'z', 'a'}));
        assertTrue(StringUtils.containsAny("zzabyycdxx", new char[]{'b', 'y'}));
    }

    @Test
    public void testContainsAny_String_charArray_notFound() throws Exception {
        assertFalse(StringUtils.containsAny("aba", new char[]{'z'}));
    }

    @Test
    public void testContainsAny_String_charArray_withSupplementaryChar() throws Exception {
        char highSurrogate = '\uD83D';
        char lowSurrogate = '\uDCA9';
        assertTrue(StringUtils.containsAny(new String(new char[]{highSurrogate, lowSurrogate, 'a'}), new char[]{highSurrogate, lowSurrogate}));
        assertTrue(StringUtils.containsAny(new String(new char[]{highSurrogate, lowSurrogate, 'a'}), new char[]{'a'}));
        assertFalse(StringUtils.containsAny(new String(new char[]{highSurrogate, lowSurrogate, 'a'}), new char[]{'b'}));
    }
    
    @Test
    public void testIndexOfAnyBut_CharSequence_charArray_nullCharSequence() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAnyBut(null, new char[]{'a'}));
    }

    @Test
    public void testIndexOfAnyBut_CharSequence_charArray_emptyCharSequence() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAnyBut("", new char[]{'a'}));
    }

    @Test
    public void testIndexOfAnyBut_CharSequence_charArray_nullSearchChars() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAnyBut("abc", null));
    }

    @Test
    public void testIndexOfAnyBut_CharSequence_charArray_emptySearchChars() throws Exception {
        assertEquals(0, StringUtils.indexOfAnyBut("abc", new char[]{}));
    }

    @Test
    public void testIndexOfAnyBut_CharSequence_charArray_found() throws Exception {
        assertEquals(3, StringUtils.indexOfAnyBut("zzabyycdxx", new char[]{'z', 'a'}));
        assertEquals(0, StringUtils.indexOfAnyBut("zzabyycdxx", new char[]{'b', 'y'}));
    }

    @Test
    public void testIndexOfAnyBut_CharSequence_charArray_notFound() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAnyBut("aba", new char[]{'a', 'b'}));
    }

    @Test
    public void testIndexOfAnyBut_CharSequence_charArray_withSupplementaryChar() throws Exception {
        char highSurrogate = '\uD83D';
        char lowSurrogate = '\uDCA9';
        assertEquals(0, StringUtils.indexOfAnyBut(new String(new char[]{highSurrogate, lowSurrogate, 'a'}), new char[]{'a'}));
        assertEquals(2, StringUtils.indexOfAnyBut(new String(new char[]{highSurrogate, lowSurrogate, 'a'}), new char[]{highSurrogate, lowSurrogate}));
    }
    
    @Test
    public void testIndexOfAnyBut_String_String_nullString() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAnyBut(null, "za"));
    }

    @Test
    public void testIndexOfAnyBut_String_String_emptyString() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAnyBut("", "za"));
    }

    @Test
    public void testIndexOfAnyBut_String_String_nullSearchString() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAnyBut("abc", null));
    }

    @Test
    public void testIndexOfAnyBut_String_String_emptySearchString() throws Exception {
        assertEquals(0, StringUtils.indexOfAnyBut("zzabyycdxx", ""));
    }

    @Test
    public void testIndexOfAnyBut_String_String_found() throws Exception {
        assertEquals(3, StringUtils.indexOfAnyBut("zzabyycdxx", "za"));
        assertEquals(0, StringUtils.indexOfAnyBut("zzabyycdxx", "by"));
    }

    @Test
    public void testIndexOfAnyBut_String_String_notFound() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAnyBut("aba", "ab"));
    }

    @Test
    public void testContainsOnly_CharSequence_charArray_nullCharSequence() throws Exception {
        assertFalse(StringUtils.containsOnly(null, new char[]{'a'}));
    }

    @Test
    public void testContainsOnly_CharSequence_charArray_nullValidChars() throws Exception {
        assertFalse(StringUtils.containsOnly("abc", (char[]) null));
    }

    @Test
    public void testContainsOnly_CharSequence_charArray_emptyCharSequence() throws Exception {
        assertTrue(StringUtils.containsOnly("", new char[]{'a'}));
    }

    @Test
    public void testContainsOnly_CharSequence_charArray_emptyValidChars() throws Exception {
        assertFalse(StringUtils.containsOnly("ab", new char[]{}));
    }

    @Test
    public void testContainsOnly_CharSequence_charArray_validCharsMatch() throws Exception {
        assertTrue(StringUtils.containsOnly("abab", new char[]{'a', 'b'}));
    }

    @Test
    public void testContainsOnly_CharSequence_charArray_validCharsNoMatch() throws Exception {
        assertFalse(StringUtils.containsOnly("ab1", new char[]{'a', 'b'}));
    }
    
    @Test
    public void testContainsOnly_CharSequence_String_nullCharSequence() throws Exception {
        assertFalse(StringUtils.containsOnly(null, "abc"));
    }

    @Test
    public void testContainsOnly_CharSequence_String_nullValidChars() throws Exception {
        assertFalse(StringUtils.containsOnly("abc", null));
    }

    @Test
    public void testContainsOnly_CharSequence_String_emptyCharSequence() throws Exception {
        assertTrue(StringUtils.containsOnly("", "abc"));
    }

    @Test
    public void testContainsOnly_CharSequence_String_emptyValidChars() throws Exception {
        assertFalse(StringUtils.containsOnly("ab", ""));
    }

    @Test
    public void testContainsOnly_CharSequence_String_validCharsMatch() throws Exception {
        assertTrue(StringUtils.containsOnly("abab", "abc"));
    }

    @Test
    public void testContainsOnly_CharSequence_String_validCharsNoMatch() throws Exception {
        assertFalse(StringUtils.containsOnly("ab1", "abc"));
    }

    @Test
    public void testContainsNone_CharSequence_charArray_nullCharSequence() throws Exception {
        assertTrue(StringUtils.containsNone(null, new char[]{'a'}));
    }

    @Test
    public void testContainsNone_CharSequence_charArray_nullSearchChars() throws Exception {
        assertTrue(StringUtils.containsNone("abc", null));
    }

    @Test
    public void testContainsNone_CharSequence_charArray_emptyCharSequence() throws Exception {
        assertTrue(StringUtils.containsNone("", new char[]{'a'}));
    }

    @Test
    public void testContainsNone_CharSequence_charArray_emptySearchChars() throws Exception {
        assertTrue(StringUtils.containsNone("ab", new char[]{}));
    }

    @Test
    public void testContainsNone_CharSequence_charArray_foundInvalid() throws Exception {
        assertFalse(StringUtils.containsNone("abz", new char[]{'x', 'y', 'z'}));
    }

    @Test
    public void testContainsNone_CharSequence_charArray_noInvalidFound() throws Exception {
        assertTrue(StringUtils.containsNone("abab", new char[]{'x', 'y', 'z'}));
    }

    @Test
    public void testContainsNone_CharSequence_charArray_withSupplementaryChar() throws Exception {
        char highSurrogate = '\uD83D';
        char lowSurrogate = '\uDCA9';
        assertTrue(StringUtils.containsNone(new String(new char[]{highSurrogate, lowSurrogate, 'a'}), new char[]{'b'}));
        assertFalse(StringUtils.containsNone(new String(new char[]{highSurrogate, lowSurrogate, 'a'}), new char[]{highSurrogate, lowSurrogate}));
    }
    
    @Test
    public void testContainsNone_String_String_nullCharSequence() throws Exception {
        assertTrue(StringUtils.containsNone(null, "xyz"));
    }

    @Test
    public void testContainsNone_String_String_nullInvalidChars() throws Exception {
        assertTrue(StringUtils.containsNone("abc", null));
    }

    @Test
    public void testContainsNone_String_String_emptyCharSequence() throws Exception {
        assertTrue(StringUtils.containsNone("", "xyz"));
    }

    @Test
    public void testContainsNone_String_String_emptyInvalidChars() throws Exception {
        assertTrue(StringUtils.containsNone("ab", ""));
    }

    @Test
    public void testContainsNone_String_String_foundInvalid() throws Exception {
        assertFalse(StringUtils.containsNone("abz", "xyz"));
    }

    @Test
    public void testContainsNone_String_String_noInvalidFound() throws Exception {
        assertTrue(StringUtils.containsNone("abab", "xyz"));
    }

    @Test
    public void testIndexOfAny_StringArray_nullString() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAny(null, new String[]{"a"}));
    }

    @Test
    public void testIndexOfAny_StringArray_nullSearchStrs() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAny("abc", null));
    }

    @Test
    public void testIndexOfAny_StringArray_emptySearchStrs() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAny("abc", new String[]{}));
    }

    @Test
    public void testIndexOfAny_StringArray_searchStrsWithNull() throws Exception {
        assertEquals(2, StringUtils.indexOfAny("zzabyycdxx", new String[]{"ab", null, "cd"}));
    }
    
    @Test
    public void testIndexOfAny_StringArray_searchStrsWithEmpty() throws Exception {
        assertEquals(0, StringUtils.indexOfAny("zzabyycdxx", new String[]{"", "ab"}));
    }

    @Test
    public void testIndexOfAny_StringArray_found() throws Exception {
        assertEquals(2, StringUtils.indexOfAny("zzabyycdxx", new String[]{"ab", "cd"}));
        assertEquals(2, StringUtils.indexOfAny("zzabyycdxx", new String[]{"cd", "ab"}));
    }
    
    @Test
    public void testIndexOfAny_StringArray_foundEarlier() throws Exception {
        assertEquals(1, StringUtils.indexOfAny("zzabyycdxx", new String[]{"zab", "aby"}));
    }

    @Test
    public void testIndexOfAny_StringArray_notFound() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.indexOfAny("zzabyycdxx", new String[]{"mn", "op"}));
    }

    @Test
    public void testLastIndexOfAny_StringArray_nullString() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.lastIndexOfAny(null, new String[]{"a"}));
    }

    @Test
    public void testLastIndexOfAny_StringArray_nullSearchStrs() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.lastIndexOfAny("abc", null));
    }

    @Test
    public void testLastIndexOfAny_StringArray_emptySearchStrs() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.lastIndexOfAny("abc", new String[]{}));
    }

    @Test
    public void testLastIndexOfAny_StringArray_searchStrsWithNull() throws Exception {
        assertEquals(6, StringUtils.lastIndexOfAny("zzabyycdxx", new String[]{null, "cd"}));
    }

    @Test
    public void testLastIndexOfAny_StringArray_searchStrsWithEmpty() throws Exception {
        assertEquals(10, StringUtils.lastIndexOfAny("zzabyycdxx", new String[]{"", "cd"}));
    }

    @Test
    public void testLastIndexOfAny_StringArray_found() throws Exception {
        assertEquals(6, StringUtils.lastIndexOfAny("zzabyycdxx", new String[]{"ab", "cd"}));
        assertEquals(6, StringUtils.lastIndexOfAny("zzabyycdxx", new String[]{"cd", "ab"}));
    }

    @Test
    public void testLastIndexOfAny_StringArray_notFound() throws Exception {
        assertEquals(INDEX_NOT_FOUND, StringUtils.lastIndexOfAny("zzabyycdxx", new String[]{"mn", "op"}));
    }

    @Test
    public void testSubstring_nullString() throws Exception {
        assertNull(StringUtils.substring(null, 1));
    }

    @Test
    public void testSubstring_emptyString() throws Exception {
        assertEquals("", StringUtils.substring("", 1));
    }

    @Test
    public void testSubstring_positiveStart() throws Exception {
        assertEquals("c", StringUtils.substring("abc", 2));
    }

    @Test
    public void testSubstring_startBeyondLength() throws Exception {
        assertEquals("", StringUtils.substring("abc", 4));
    }

    @Test
    public void testSubstring_negativeStart() throws Exception {
        assertEquals("bc", StringUtils.substring("abc", -2));
    }

    @Test
    public void testSubstring_negativeStartBeyondLength() throws Exception {
        assertEquals("abc", StringUtils.substring("abc", -4));
    }

    @Test
    public void testSubstring_nullStringStartEnd() throws Exception {
        assertNull(StringUtils.substring(null, 1, 2));
    }

    @Test
    public void testSubstring_emptyStringStartEnd() throws Exception {
        assertEquals("", StringUtils.substring("", 1, 2));
    }

    @Test
    public void testSubstring_startBeforeEnd() throws Exception {
        assertEquals("ab", StringUtils.substring("abc", 0, 2));
    }

    @Test
    public void testSubstring_startAfterEnd() throws Exception {
        assertEquals("", StringUtils.substring("abc", 2, 0));
    }

    @Test
    public void testSubstring_endBeyondLength() throws Exception {
        assertEquals("c", StringUtils.substring("abc", 2, 4));
    }

    @Test
    public void testSubstring_startBeyondLengthEnd() throws Exception {
        assertEquals("", StringUtils.substring("abc", 4, 6));
    }

    @Test
    public void testSubstring_startEqualsEnd() throws Exception {
        assertEquals("", StringUtils.substring("abc", 2, 2));
    }

    @Test
    public void testSubstring_negativeStartNegativeEnd() throws Exception {
        assertEquals("b", StringUtils.substring("abc", -2, -1));
    }

    @Test
    public void testSubstring_negativeStartPositiveEnd() throws Exception {
        assertEquals("ab", StringUtils.substring("abc", -4, 2));
    }

    @Test
    public void testLeft_nullString() throws Exception {
        assertNull(StringUtils.left(null, 2));
    }

    @Test
    public void testLeft_negativeLength() throws Exception {
        assertEquals("", StringUtils.left("abc", -1));
    }

    @Test
    public void testLeft_emptyString() throws Exception {
        assertEquals("", StringUtils.left("", 2));
    }

    @Test
    public void testLeft_zeroLength() throws Exception {
        assertEquals("", StringUtils.left("abc", 0));
    }

    @Test
    public void testLeft_lengthAvailable() throws Exception {
        assertEquals("ab", StringUtils.left("abc", 2));
    }

    @Test
    public void testLeft_lengthExceeds() throws Exception {
        assertEquals("abc", StringUtils.left("abc", 4));
    }

    @Test
    public void testRight_nullString() throws Exception {
        assertNull(StringUtils.right(null, 2));
    }

    @Test
    public void testRight_negativeLength() throws Exception {
        assertEquals("", StringUtils.right("abc", -1));
    }

    @Test
    public void testRight_emptyString() throws Exception {
        assertEquals("", StringUtils.right("", 2));
    }

    @Test
    public void testRight_zeroLength() throws Exception {
        assertEquals("", StringUtils.right("abc", 0));
    }

    @Test
    public void testRight_lengthAvailable() throws Exception {
        assertEquals("bc", StringUtils.right("abc", 2));
    }

    @Test
    public void testRight_lengthExceeds() throws Exception {
        assertEquals("abc", StringUtils.right("abc", 4));
    }

    @Test
    public void testMid_nullString() throws Exception {
        assertNull(StringUtils.mid(null, 0, 2));
    }

    @Test
    public void testMid_negativeLength() throws Exception {
        assertEquals("", StringUtils.mid("abc", 0, -1));
    }

    @Test
    public void testMid_posBeyondLength() throws Exception {
        assertEquals("", StringUtils.mid("abc", 4, 2));
    }

    @Test
    public void testMid_emptyString() throws Exception {
        assertEquals("", StringUtils.mid("", 0, 2));
    }

    @Test
    public void testMid_zeroPosTwoLength() throws Exception {
        assertEquals("ab", StringUtils.mid("abc", 0, 2));
    }

    @Test
    public void testMid_zeroPosFourLength() throws Exception {
        assertEquals("abc", StringUtils.mid("abc", 0, 4));
    }

    @Test
    public void testMid_posTwoLengthTwo() throws Exception {
        assertEquals("c", StringUtils.mid("abc", 2, 4));
    }

    @Test
    public void testMid_posFourLengthTwo() throws Exception {
        assertEquals("", StringUtils.mid("abc", 4, 2));
    }

    @Test
    public void testMid_negativePosTwoLength() throws Exception {
        assertEquals("ab", StringUtils.mid("abc", -2, 2));
    }

    @Test
    public void testSubstringBefore_nullString() throws Exception {
        assertNull(StringUtils.substringBefore(null, "a"));
    }

    @Test
    public void testSubstringBefore_emptyString() throws Exception {
        assertEquals("", StringUtils.substringBefore("", "a"));
    }

    @Test
    public void testSubstringBefore_nullSeparator() throws Exception {
        assertEquals("abc", StringUtils.substringBefore("abc", null));
    }

    @Test
    public void testSubstringBefore_emptySeparator() throws Exception {
        assertEquals("", StringUtils.substringBefore("abc", ""));
    }

    @Test
    public void testSubstringBefore_separatorNotFound() throws Exception {
        assertEquals("abc", StringUtils.substringBefore("abc", "d"));
    }

    @Test
    public void testSubstringBefore_separatorFound() throws Exception {
        assertEquals("", StringUtils.substringBefore("abc", "a"));
        assertEquals("a", StringUtils.substringBefore("abcba", "b"));
        assertEquals("ab", StringUtils.substringBefore("abc", "c"));
    }

    @Test
    public void testSubstringAfter_nullString() throws Exception {
        assertNull(StringUtils.substringAfter(null, "a"));
    }

    @Test
    public void testSubstringAfter_emptyString() throws Exception {
        assertEquals("", StringUtils.substringAfter("", "a"));
    }

    @Test
    public void testSubstringAfter_nullSeparator() throws Exception {
        assertEquals("", StringUtils.substringAfter("abc", null));
    }

    @Test
    public void testSubstringAfter_separatorNotFound() throws Exception {
        assertEquals("", StringUtils.substringAfter("abc", "d"));
    }

    @Test
    public void testSubstringAfter_separatorFound() throws Exception {
        assertEquals("bc", StringUtils.substringAfter("abc", "a"));
        assertEquals("cba", StringUtils.substringAfter("abcba", "b"));
        assertEquals("", StringUtils.substringAfter("abc", "c"));
    }

    @Test
    public void testSubstringAfter_emptySeparator() throws Exception {
        assertEquals("abc", StringUtils.substringAfter("abc", ""));
    }

    @Test
    public void testSubstringBeforeLast_nullString() throws Exception {
        assertNull(StringUtils.substringBeforeLast(null, "a"));
    }

    @Test
    public void testSubstringBeforeLast_emptyString() throws Exception {
        assertEquals("", StringUtils.substringBeforeLast("", "a"));
    }

    @Test
    public void testSubstringBeforeLast_emptySeparator() throws Exception {
        assertEquals("abc", StringUtils.substringBeforeLast("abc", ""));
    }
    
    @Test
    public void testSubstringBeforeLast_nullSeparator() throws Exception {
        assertEquals("abc", StringUtils.substringBeforeLast("abc", null));
    }

    @Test
    public void testSubstringBeforeLast_separatorNotFound() throws Exception {
        assertEquals("a", StringUtils.substringBeforeLast("a", "z"));
    }

    @Test
    public void testSubstringBeforeLast_separatorFound() throws Exception {
        assertEquals("abc", StringUtils.substringBeforeLast("abcba", "b"));
        assertEquals("ab", StringUtils.substringBeforeLast("abc", "c"));
        assertEquals("", StringUtils.substringBeforeLast("a", "a"));
    }

    @Test
    public void testSubstringAfterLast_nullString() throws Exception {
        assertNull(StringUtils.substringAfterLast(null, "a"));
    }

    @Test
    public void testSubstringAfterLast_emptyString() throws Exception {
        assertEquals("", StringUtils.substringAfterLast("", "a"));
    }

    @Test
    public void testSubstringAfterLast_emptySeparator() throws Exception {
        assertEquals("", StringUtils.substringAfterLast("abc", ""));
    }

    @Test
    public void testSubstringAfterLast_nullSeparator() throws Exception {
        assertEquals("", StringUtils.substringAfterLast("abc", null));
    }

    @Test
    public void testSubstringAfterLast_separatorNotFound() throws Exception {
        assertEquals("", StringUtils.substringAfterLast("a", "z"));
    }

    @Test
    public void testSubstringAfterLast_separatorFound() throws Exception {
        assertEquals("bc", StringUtils.substringAfterLast("abc", "a"));
        assertEquals("a", StringUtils.substringAfterLast("abcba", "b"));
        assertEquals("", StringUtils.substringAfterLast("abc", "c"));
        assertEquals("", StringUtils.substringAfterLast("a", "a"));
    }

    @Test
    public void testSubstringBetween_nullString() throws Exception {
        assertNull(StringUtils.substringBetween(null, "tag"));
    }

    @Test
    public void testSubstringBetween_nullTag() throws Exception {
        assertNull(StringUtils.substringBetween("tagabctag", null));
    }

    @Test
    public void testSubstringBetween_emptyTag() throws Exception {
        assertEquals("", StringUtils.substringBetween("tagabctag", ""));
    }

    @Test
    public void testSubstringBetween_emptyStringAndEmptyTag() throws Exception {
        assertEquals("", StringUtils.substringBetween("", ""));
    }

    @Test
    public void testSubstringBetween_emptyString() throws Exception {
        assertEquals(null, StringUtils.substringBetween("", "tag"));
    }

    @Test
    public void testSubstringBetween_noMatch() throws Exception {
        assertEquals(null, StringUtils.substringBetween("abc", "def"));
    }

    @Test
    public void testSubstringBetween_matchFound() throws Exception {
        assertEquals("abc", StringUtils.substringBetween("tagabctag", "tag"));
    }

    @Test
    public void testSubstringBetween_multipleTags_firstMatch() throws Exception {
        assertEquals("abc", StringUtils.substringBetween("tagabcANDtagdef", "tag", "AND"));
    }

    @Test
    public void testSubstringBetween_multipleTags_noCloseTag() throws Exception {
        assertEquals(null, StringUtils.substringBetween("tagabcDEF", "tag", "AND"));
    }

    @Test
    public void testSubstringBetween_multipleTags_openAndCloseNull() throws Exception {
        assertEquals(null, StringUtils.substringBetween("abc", null, null));
    }

    @Test
    public void testSubstringBetween_multipleTags_openNull() throws Exception {
        assertEquals(null, StringUtils.substringBetween("abc", null, "c"));
    }

    @Test
    public void testSubstringBetween_multipleTags_closeNull() throws Exception {
        assertEquals(null, StringUtils.substringBetween("abc", "a", null));
    }

    @Test
    public void testSubstringBetween_multipleTags_openEmpty() throws Exception {
        assertEquals("", StringUtils.substringBetween("abc", "", "c"));
    }

    @Test
    public void testSubstringBetween_multipleTags_closeEmpty() throws Exception {
        assertEquals("abc", StringUtils.substringBetween("abc", "a", ""));
    }
    
    @Test
    public void testSubstringBetween_multipleTags_openAndCloseEmpty() throws Exception {
        assertEquals("", StringUtils.substringBetween("abc", "", ""));
    }

    @Test
    public void testSubstringsBetween_nullString() throws Exception {
        assertNull(StringUtils.substringsBetween(null, "[", "]"));
    }

    @Test
    public void testSubstringsBetween_nullOpen() throws Exception {
        assertNull(StringUtils.substringsBetween("abc", null, "]"));
    }

    @Test
    public void testSubstringsBetween_nullClose() throws Exception {
        assertNull(StringUtils.substringsBetween("abc", "[", null));
    }

    @Test
    public void testSubstringsBetween_emptyOpen() throws Exception {
        assertNull(StringUtils.substringsBetween("abc", "", "]"));
    }

    @Test
    public void testSubstringsBetween_emptyClose() throws Exception {
        assertNull(StringUtils.substringsBetween("abc", "[", ""));
    }

    @Test
    public void testSubstringsBetween_emptyString() throws Exception {
        assertArrayEquals(new String[]{}, StringUtils.substringsBetween("", "[", "]"));
    }

    @Test
    public void testSubstringsBetween_noMatch() throws Exception {
        assertNull(StringUtils.substringsBetween("abc", "[", "]"));
    }

    @Test
    public void testSubstringsBetween_singleMatch() throws Exception {
        assertArrayEquals(new String[]{"a"}, StringUtils.substringsBetween("[a]", "[", "]"));
    }

    @Test
    public void testSubstringsBetween_multipleMatches() throws Exception {
        assertArrayEquals(new String[]{"a", "b", "c"}, StringUtils.substringsBetween("[a][b][c]", "[", "]"));
    }

    @Test
    public void testSubstringsBetween_overlappingTags() throws Exception {
        assertArrayEquals(new String[]{"a", "b", "c"}, StringUtils.substringsBetween("[a][b][c]", "[", "]"));
    }

    @Test
    public void testSubstringsBetween_nestedTags() throws Exception {
        assertArrayEquals(new String[]{"a", "b"}, StringUtils.substringsBetween("[a[b]]", "[", "]"));
    }
    
    @Test
    public void testSplit_nullString() throws Exception {
        assertNull(StringUtils.split(null));
    }

    @Test
    public void testSplit_emptyString() throws Exception {
        assertArrayEquals(new String[]{}, StringUtils.split(""));
    }

    @Test
    public void testSplit_simpleCase() throws Exception {
        assertArrayEquals(new String[]{"abc", "def"}, StringUtils.split("abc def"));
    }

    @Test
    public void testSplit_multipleSeparators() throws Exception {
        assertArrayEquals(new String[]{"abc", "def"}, StringUtils.split("abc  def"));
    }

    @Test
    public void testSplit_leadingAndTrailingSpaces() throws Exception {
        assertArrayEquals(new String[]{"abc"}, StringUtils.split(" abc "));
    }
    
    @Test
    public void testSplit_separatorChar_nullString() throws Exception {
        assertNull(StringUtils.split(null, '.'));
    }

    @Test
    public void testSplit_separatorChar_emptyString() throws Exception {
        assertArrayEquals(new String[]{}, StringUtils.split("", '.'));
    }

    @Test
    public void testSplit_separatorChar_simpleCase() throws Exception {
        assertArrayEquals(new String[]{"a", "b", "c"}, StringUtils.split("a.b.c", '.'));
    }

    @Test
    public void testSplit_separatorChar_multipleSeparators() throws Exception {
        assertArrayEquals(new String[]{"a", "b", "c"}, StringUtils.split("a..b.c", '.'));
    }

    @Test
    public void testSplit_separatorChar_noMatch() throws Exception {
        assertArrayEquals(new String[]{"a:b:c"}, StringUtils.split("a:b:c", '.'));
    }

    @Test
    public void testSplit_separatorChar_space() throws Exception {
        assertArrayEquals(new String[]{"a", "b", "c"}, StringUtils.split("a b c", ' '));
    }

    @Test
    public void testSplit_separatorString_nullString() throws Exception {
        assertNull(StringUtils.split(null, "."));
    }

    @Test
    public void testSplit_separatorString_emptyString() throws Exception {
        assertArrayEquals(new String[]{}, StringUtils.split("", "."));
    }

    @Test
    public void testSplit_separatorString_nullSeparator() throws Exception {
        assertArrayEquals(new String[]{"abc", "def"}, StringUtils.split("abc def", null));
    }

    @Test
    public void testSplit_separatorString_simpleCase() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef"}, StringUtils.split("ab:cd:ef", ":"));
    }

    @Test
    public void testSplit_separatorString_multipleSeparators() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef"}, StringUtils.split("ab  cd  ef", " "));
    }

    @Test
    public void testSplit_separatorString_complexSeparator() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef"}, StringUtils.split("ab-!-cd-!-ef", "-!-"));
    }
    
    @Test
    public void testSplit_separatorStringMax_nullString() throws Exception {
        assertNull(StringUtils.split(null, ".", 0));
    }

    @Test
    public void testSplit_separatorStringMax_emptyString() throws Exception {
        assertArrayEquals(new String[]{}, StringUtils.split("", ".", 0));
    }

    @Test
    public void testSplit_separatorStringMax_zeroMax() throws Exception {
        assertArrayEquals(new String[]{"ab", "de", "fg"}, StringUtils.split("ab de fg", null, 0));
    }

    @Test
    public void testSplit_separatorStringMax_multipleSeparatorsZeroMax() throws Exception {
        assertArrayEquals(new String[]{"ab", "de", "fg"}, StringUtils.split("ab   de fg", null, 0));
    }

    @Test
    public void testSplit_separatorStringMax_simpleCaseZeroMax() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef"}, StringUtils.split("ab:cd:ef", ":", 0));
    }

    @Test
    public void testSplit_separatorStringMax_limitedMax() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd:ef"}, StringUtils.split("ab:cd:ef", ":", 2));
    }
    
    @Test
    public void testSplitByWholeSeparator_nullString() throws Exception {
        assertNull(StringUtils.splitByWholeSeparator(null, ":"));
    }

    @Test
    public void testSplitByWholeSeparator_emptyString() throws Exception {
        assertArrayEquals(new String[]{}, StringUtils.splitByWholeSeparator("", ":"));
    }

    @Test
    public void testSplitByWholeSeparator_nullSeparator() throws Exception {
        assertArrayEquals(new String[]{"ab", "de", "fg"}, StringUtils.splitByWholeSeparator("ab de fg", null));
    }

    @Test
    public void testSplitByWholeSeparator_multipleSpacesSeparator() throws Exception {
        assertArrayEquals(new String[]{"ab", "de", "fg"}, StringUtils.splitByWholeSeparator("ab   de fg", null));
    }

    @Test
    public void testSplitByWholeSeparator_simpleSeparator() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef"}, StringUtils.splitByWholeSeparator("ab:cd:ef", ":"));
    }

    @Test
    public void testSplitByWholeSeparator_complexSeparator() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef"}, StringUtils.splitByWholeSeparator("ab-!-cd-!-ef", "-!-"));
    }

    @Test
    public void testSplitByWholeSeparator_emptySeparator() throws Exception {
        assertArrayEquals(new String[]{"a", "b", "c"}, StringUtils.splitByWholeSeparator("abc", ""));
    }

    @Test
    public void testSplitByWholeSeparatorPreserveAllTokens_nullString() throws Exception {
        assertNull(StringUtils.splitByWholeSeparatorPreserveAllTokens(null, ":"));
    }

    @Test
    public void testSplitByWholeSeparatorPreserveAllTokens_emptyString() throws Exception {
        assertArrayEquals(new String[]{}, StringUtils.splitByWholeSeparatorPreserveAllTokens("", ":"));
    }

    @Test
    public void testSplitByWholeSeparatorPreserveAllTokens_nullSeparator() throws Exception {
        assertArrayEquals(new String[]{"ab", "de", "fg"}, StringUtils.splitByWholeSeparatorPreserveAllTokens("ab de fg", null));
    }

    @Test
    public void testSplitByWholeSeparatorPreserveAllTokens_multipleSpacesSeparator() throws Exception {
        assertArrayEquals(new String[]{"ab", "", "", "de", "fg"}, StringUtils.splitByWholeSeparatorPreserveAllTokens("ab   de fg", null));
    }

    @Test
    public void testSplitByWholeSeparatorPreserveAllTokens_simpleSeparator() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef"}, StringUtils.splitByWholeSeparatorPreserveAllTokens("ab:cd:ef", ":"));
    }

    @Test
    public void testSplitByWholeSeparatorPreserveAllTokens_complexSeparator() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef"}, StringUtils.splitByWholeSeparatorPreserveAllTokens("ab-!-cd-!-ef", "-!-"));
    }

    @Test
    public void testSplitByWholeSeparatorPreserveAllTokens_emptySeparator() throws Exception {
        assertArrayEquals(new String[]{"a", "b", "c"}, StringUtils.splitByWholeSeparatorPreserveAllTokens("abc", ""));
    }

    @Test
    public void testSplitByWholeSeparatorPreserveAllTokens_trailingSeparator() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef", ""}, StringUtils.splitByWholeSeparatorPreserveAllTokens("ab:cd:ef:", ":"));
    }
    
    @Test
    public void testSplitByWholeSeparatorPreserveAllTokens_multipleTrailingSeparators() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef", "", ""}, StringUtils.splitByWholeSeparatorPreserveAllTokens("ab:cd:ef::", ":"));
    }

    @Test
    public void testSplitByWholeSeparatorPreserveAllTokens_internalSeparators() throws Exception {
        assertArrayEquals(new String[]{"ab", "", "cd", "ef"}, StringUtils.splitByWholeSeparatorPreserveAllTokens("ab::cd:ef", ":"));
    }

    @Test
    public void testSplitByWholeSeparatorPreserveAllTokens_leadingSeparator() throws Exception {
        assertArrayEquals(new String[]{"", "cd", "ef"}, StringUtils.splitByWholeSeparatorPreserveAllTokens(":cd:ef", ":"));
    }

    @Test
    public void testSplitByWholeSeparatorPreserveAllTokens_multipleLeadingSeparators() throws Exception {
        assertArrayEquals(new String[]{"", "", "cd", "ef"}, StringUtils.splitByWholeSeparatorPreserveAllTokens("::cd:ef", ":"));
    }

    @Test
    public void testSplitByWholeSeparatorPreserveAllTokens_leadingAndTrailingSeparators() throws Exception {
        assertArrayEquals(new String[]{"", "cd", "ef", ""}, StringUtils.splitByWholeSeparatorPreserveAllTokens(":cd:ef:", ":"));
    }
    
    @Test
    public void testSplitPreserveAllTokens_nullString() throws Exception {
        assertNull(StringUtils.splitPreserveAllTokens(null));
    }

    @Test
    public void testSplitPreserveAllTokens_emptyString() throws Exception {
        assertArrayEquals(new String[]{}, StringUtils.splitPreserveAllTokens(""));
    }

    @Test
    public void testSplitPreserveAllTokens_simpleCase() throws Exception {
        assertArrayEquals(new String[]{"abc", "def"}, StringUtils.splitPreserveAllTokens("abc def"));
    }

    @Test
    public void testSplitPreserveAllTokens_multipleSeparators() throws Exception {
        assertArrayEquals(new String[]{"abc", "", "def"}, StringUtils.splitPreserveAllTokens("abc  def"));
    }

    @Test
    public void testSplitPreserveAllTokens_leadingAndTrailingSpaces() throws Exception {
        assertArrayEquals(new String[]{"", "abc", ""}, StringUtils.splitPreserveAllTokens(" abc "));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorChar_nullString() throws Exception {
        assertNull(StringUtils.splitPreserveAllTokens(null, '.'));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorChar_emptyString() throws Exception {
        assertArrayEquals(new String[]{}, StringUtils.splitPreserveAllTokens("", '.'));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorChar_simpleCase() throws Exception {
        assertArrayEquals(new String[]{"a", "b", "c"}, StringUtils.splitPreserveAllTokens("a.b.c", '.'));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorChar_multipleSeparators() throws Exception {
        assertArrayEquals(new String[]{"a", "", "b", "c"}, StringUtils.splitPreserveAllTokens("a..b.c", '.'));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorChar_noMatch() throws Exception {
        assertArrayEquals(new String[]{"a:b:c"}, StringUtils.splitPreserveAllTokens("a:b:c", '.'));
    }
    
    @Test
    public void testSplitPreserveAllTokens_separatorChar_trailingSeparator() throws Exception {
        assertArrayEquals(new String[]{"a", "b", "c", ""}, StringUtils.splitPreserveAllTokens("a.b.c.", '.'));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorChar_multipleTrailingSeparators() throws Exception {
        assertArrayEquals(new String[]{"a", "b", "c", "", ""}, StringUtils.splitPreserveAllTokens("a.b.c..", '.'));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorChar_leadingSeparator() throws Exception {
        assertArrayEquals(new String[]{"", "b", "c"}, StringUtils.splitPreserveAllTokens(".b.c", '.'));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorChar_multipleLeadingSeparators() throws Exception {
        assertArrayEquals(new String[]{"", "", "b", "c"}, StringUtils.splitPreserveAllTokens("..b.c", '.'));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorChar_leadingAndTrailingSeparators() throws Exception {
        assertArrayEquals(new String[]{"", "b", "c", ""}, StringUtils.splitPreserveAllTokens(".b.c.", '.'));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorString_nullString() throws Exception {
        assertNull(StringUtils.splitPreserveAllTokens(null, "."));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorString_emptyString() throws Exception {
        assertArrayEquals(new String[]{}, StringUtils.splitPreserveAllTokens("", "."));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorString_nullSeparator() throws Exception {
        assertArrayEquals(new String[]{"abc", "def"}, StringUtils.splitPreserveAllTokens("abc def", null));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorString_multipleSeparators() throws Exception {
        assertArrayEquals(new String[]{"ab", "", "", "cd", "ef"}, StringUtils.splitPreserveAllTokens("ab   cd   ef", " "));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorString_simpleSeparator() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef"}, StringUtils.splitPreserveAllTokens("ab:cd:ef", ":"));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorString_complexSeparator() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef"}, StringUtils.splitByWholeSeparatorPreserveAllTokens("ab-!-cd-!-ef", "-!-"));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorString_trailingSeparator() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef", ""}, StringUtils.splitPreserveAllTokens("ab:cd:ef:", ":"));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorString_multipleTrailingSeparators() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef", "", ""}, StringUtils.splitPreserveAllTokens("ab:cd:ef::", ":"));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorString_leadingSeparator() throws Exception {
        assertArrayEquals(new String[]{"", "cd", "ef"}, StringUtils.splitPreserveAllTokens(":cd:ef", ":"));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorString_multipleLeadingSeparators() throws Exception {
        assertArrayEquals(new String[]{"", "", "cd", "ef"}, StringUtils.splitPreserveAllTokens("::cd:ef", ":"));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorString_leadingAndTrailingSeparators() throws Exception {
        assertArrayEquals(new String[]{"", "cd", "ef", ""}, StringUtils.splitPreserveAllTokens(":cd:ef:", ":"));
    }
    
    @Test
    public void testSplitPreserveAllTokens_separatorStringMax_nullString() throws Exception {
        assertNull(StringUtils.splitPreserveAllTokens(null, ".", 0));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorStringMax_emptyString() throws Exception {
        assertArrayEquals(new String[]{}, StringUtils.splitPreserveAllTokens("", ".", 0));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorStringMax_zeroMax() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef"}, StringUtils.splitPreserveAllTokens("ab de fg", null, 0));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorStringMax_multipleSeparatorsZeroMax() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef"}, StringUtils.splitPreserveAllTokens("ab   de fg", null, 0));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorStringMax_simpleCaseZeroMax() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd", "ef"}, StringUtils.splitPreserveAllTokens("ab:cd:ef", ":", 0));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorStringMax_limitedMax() throws Exception {
        assertArrayEquals(new String[]{"ab", "cd:ef"}, StringUtils.splitPreserveAllTokens("ab:cd:ef", ":", 2));
    }

    @Test
    public void testSplitPreserveAllTokens_separatorStringMax_multipleSeparatorsLimitedMax() throws Exception {
        assertArrayEquals(new String[]{"ab", "", " de fg"}, StringUtils.splitPreserveAllTokens("ab   de fg", null, 2));
        assertArrayEquals(new String[]{"ab", "", "", "de fg"}, StringUtils.splitPreserveAllTokens("ab   de fg", null, 3));
        assertArrayEquals(new String[]{"ab", "", "", "de", "fg"}, StringUtils.splitPreserveAllTokens("ab   de fg", null, 4));
    }
    
    @Test
    public void testSplitByCharacterType_nullString() throws Exception {
        assertNull(StringUtils.splitByCharacterType(null));
    }

    @Test
    public void testSplitByCharacterType_emptyString() throws Exception {
        assertArrayEquals(new String[]{}, StringUtils.splitByCharacterType(""));
    }

    @Test
    public void testSplitByCharacterType_simpleCase() throws Exception {
        assertArrayEquals(new String[]{"ab", " ", "de", " ", "fg"}, StringUtils.splitByCharacterType("ab de fg"));
    }

    @Test
    public void testSplitByCharacterType_multipleSpaces() throws Exception {
        assertArrayEquals(new String[]{"ab", "   ", "de", " ", "fg"}, StringUtils.splitByCharacterType("ab   de fg"));
    }

    @Test
    public void testSplitByCharacterType_digits() throws Exception {
        assertArrayEquals(new String[]{"number", "5"}, StringUtils.splitByCharacterType("number5"));
    }
    
    @Test
    public void testSplitByCharacterType_camelCase() throws Exception {
        assertArrayEquals(new String[]{"foo", "B", "ar"}, StringUtils.splitByCharacterType("fooBar"));
    }
    
    @Test
    public void testSplitByCharacterType_camelCaseWithDigits() throws Exception {
        assertArrayEquals(new String[]{"foo", "200", "B", "ar"}, StringUtils.splitByCharacterType("foo200Bar"));
    }

    @Test
    public void testSplitByCharacterType_allUpperCase() throws Exception {
        assertArrayEquals(new String[]{"ASFR", "ules"}, StringUtils.splitByCharacterType("ASFRules"));
    }

    @Test
    public void testSplitByCharacterTypeCamelCase_nullString() throws Exception {
        assertNull(StringUtils.splitByCharacterTypeCamelCase(null));
    }

    @Test
    public void testSplitByCharacterTypeCamelCase_emptyString() throws Exception {
        assertArrayEquals(new String[]{}, StringUtils.splitByCharacterTypeCamelCase(""));
    }

    @Test
    public void testSplitByCharacterTypeCamelCase_simpleCase() throws Exception {
        assertArrayEquals(new String[]{"ab", " ", "de", " ", "fg"}, StringUtils.splitByCharacterTypeCamelCase("ab de fg"));
    }

    @Test
    public void testSplitByCharacterTypeCamelCase_multipleSpaces() throws Exception {
        assertArrayEquals(new String[]{"ab", "   ", "de", " ", "fg"}, StringUtils.splitByCharacterTypeCamelCase("ab   de fg"));
    }

    @Test
    public void testSplitByCharacterTypeCamelCase_digits() throws Exception {
        assertArrayEquals(new String[]{"number", "5"}, StringUtils.splitByCharacterTypeCamelCase("number5"));
    }
    
    @Test
    public void testSplitByCharacterTypeCamelCase_camelCase() throws Exception {
        assertArrayEquals(new String[]{"foo", "Bar"}, StringUtils.splitByCharacterTypeCamelCase("fooBar"));
    }
    
    @Test
    public void testSplitByCharacterTypeCamelCase_camelCaseWithDigits() throws Exception {
        assertArrayEquals(new String[]{"foo", "200", "Bar"}, StringUtils.splitByCharacterTypeCamelCase("foo200Bar"));
    }

    @Test
    public void testSplitByCharacterTypeCamelCase_allUpperCase() throws Exception {
        assertArrayEquals(new String[]{"ASF", "Rules"}, StringUtils.splitByCharacterTypeCamelCase("ASFRules"));
    }
    
    @Test
    public void testJoin_objectArray_null() throws Exception {
        assertNull(StringUtils.join((Object[]) null));
    }

    @Test
    public void testJoin_objectArray_empty() throws Exception {
        assertEquals("", StringUtils.join(new Object[]{}));
    }

    @Test
    public void testJoin_objectArray_singleNull() throws Exception {
        assertEquals("", StringUtils.join(new Object[]{null}));
    }

    @Test
    public void testJoin_objectArray_multipleElements() throws Exception {
        assertEquals("abc", StringUtils.join(new Object[]{"a", "b", "c"}));
    }

    @Test
    public void testJoin_objectArray_mixedNullAndEmpty() throws Exception {
        assertEquals("a", StringUtils.join(new Object[]{null, "", "a"}));
    }
    
    @Test
    public void testJoin_objectArray_charSeparator_null() throws Exception {
        assertNull(StringUtils.join((Object[]) null, ','));
    }

    @Test
    public void testJoin_objectArray_charSeparator_empty() throws Exception {
        assertEquals("", StringUtils.join(new Object[]{}, ','));
    }

    @Test
    public void testJoin_objectArray_charSeparator_singleNull() throws Exception {
        assertEquals("", StringUtils.join(new Object[]{null}, ','));
    }

    @Test
    public void testJoin_objectArray_charSeparator_multipleElements() throws Exception {
        assertEquals("a,b,c", StringUtils.join(new Object[]{"a", "b", "c"}, ','));
    }

    @Test
    public void testJoin_objectArray_charSeparator_mixedNullAndEmpty() throws Exception {
        assertEquals(";;a", StringUtils.join(new Object[]{null, "", "a"}, ','));
    }
    
    @Test
    public void testJoin_objectArray_charSeparatorRange_null() throws Exception {
        assertNull(StringUtils.join((Object[]) null, ',', 0, 0));
    }

    @Test
    public void testJoin_objectArray_charSeparatorRange_empty() throws Exception {
        assertEquals("", StringUtils.join(new Object[]{}, ',', 0, 0));
    }
    
    @Test
    public void testJoin_objectArray_charSeparatorRange_positive() throws Exception {
        assertEquals("b,c", StringUtils.join(new Object[]{"a", "b", "c", "d"}, ',', 1, 3));
    }

    @Test
    public void testJoin_objectArray_stringSeparator_null() throws Exception {
        assertNull(StringUtils.join((Object[]) null, "--"));
    }

    @Test
    public void testJoin_objectArray_stringSeparator_empty() throws Exception {
        assertEquals("", StringUtils.join(new Object[]{}, "--"));
    }

    @Test
    public void testJoin_objectArray_stringSeparator_singleNull() throws Exception {
        assertEquals("", StringUtils.join(new Object[]{null}, "--"));
    }

    @Test
    public void testJoin_objectArray_stringSeparator_multipleElements() throws Exception {
        assertEquals("a--b--c", StringUtils.join(new Object[]{"a", "b", "c"}, "--"));
    }

    @Test
    public void testJoin_objectArray_stringSeparator_mixedNullAndEmpty() throws Exception {
        assertEquals(",,a", StringUtils.join(new Object[]{null, "", "a"}, ','));
    }
    
    @Test
    public void testJoin_objectArray_stringSeparatorRange_null() throws Exception {
        assertNull(StringUtils.join((Object[]) null, "--", 0, 0));
    }

    @Test
    public void testJoin_objectArray_stringSeparatorRange_empty() throws Exception {
        assertEquals("", StringUtils.join(new Object[]{}, "--", 0, 0));
    }

    @Test
    public void testJoin_objectArray_stringSeparatorRange_positive() throws Exception {
        assertEquals("b--c", StringUtils.join(new Object[]{"a", "b", "c", "d"}, "--", 1, 3));
    }

    @Test
    public void testJoin_stringSeparator_null() throws Exception {
        assertNull(StringUtils.join((Object[]) null, "--"));
    }

    @Test
    public void testJoin_stringSeparator_empty() throws Exception {
        assertEquals("", StringUtils.join(new Object[]{}, "--"));
    }

    @Test
    public void testJoin_stringSeparator_singleNull() throws Exception {
        assertEquals("", StringUtils.join(new Object[]{null}, "--"));
    }

    @Test
    public void testJoin_stringSeparator_multipleElements() throws Exception {
        assertEquals("a--b--c", StringUtils.join(new Object[]{"a", "b", "c"}, "--"));
    }

    @Test
    public void testJoin_stringSeparator_mixedNullAndEmpty() throws Exception {
        assertEquals(",,a", StringUtils.join(new Object[]{null, "", "a"}, ','));
    }

    @Test
    public void testJoin_stringSeparator_nullSeparator() throws Exception {
        assertEquals("abc", StringUtils.join(new Object[]{"a", "b", "c"}, null));
    }

    @Test
    public void testJoin_stringSeparator_emptySeparator() throws Exception {
        assertEquals("abc", StringUtils.join(new Object[]{"a", "b", "c"}, ""));
    }
    
    @Test
    public void testDeleteWhitespace_nullString() throws Exception {
        assertNull(StringUtils.deleteWhitespace(null));
    }

    @Test
    public void testDeleteWhitespace_emptyString() throws Exception {
        assertEquals("", StringUtils.deleteWhitespace(""));
    }

    @Test
    public void testDeleteWhitespace_noWhitespace() throws Exception {
        assertEquals("abc", StringUtils.deleteWhitespace("abc"));
    }

    @Test
    public void testDeleteWhitespace_allWhitespace() throws Exception {
        assertEquals("", StringUtils.deleteWhitespace(" \t\n\r\f"));
    }

    @Test
    public void testDeleteWhitespace_mixedWhitespace() throws Exception {
        assertEquals("abc", StringUtils.deleteWhitespace("   ab  c  "));
    }

    @Test
    public void testRemoveStart_nullString() throws Exception {
        assertNull(StringUtils.removeStart(null, "www."));
    }

    @Test
    public void testRemoveStart_emptyString() throws Exception {
        assertEquals("", StringUtils.removeStart("", "www."));
    }

    @Test
    public void testRemoveStart_nullRemove() throws Exception {
        assertEquals("abc", StringUtils.removeStart("abc", null));
    }

    @Test
    public void testRemoveStart_emptyRemove() throws Exception {
        assertEquals("abc", StringUtils.removeStart("abc", ""));
    }

    @Test
    public void testRemoveStart_match() throws Exception {
        assertEquals("domain.com", StringUtils.removeStart("www.domain.com", "www."));
    }

    @Test
    public void testRemoveStart_noMatch() throws Exception {
        assertEquals("domain.com", StringUtils.removeStart("domain.com", "www."));
    }

    @Test
    public void testRemoveStart_noMatchDifferentString() throws Exception {
        assertEquals("www.domain.com", StringUtils.removeStart("www.domain.com", "domain"));
    }

    @Test
    public void testRemoveStartIgnoreCase_nullString() throws Exception {
        assertNull(StringUtils.removeStartIgnoreCase(null, "www."));
    }

    @Test
    public void testRemoveStartIgnoreCase_emptyString() throws Exception {
        assertEquals("", StringUtils.removeStartIgnoreCase("", "www."));
    }

    @Test
    public void testRemoveStartIgnoreCase_nullRemove() throws Exception {
        assertEquals("abc", StringUtils.removeStartIgnoreCase("abc", null));
    }

    @Test
    public void testRemoveStartIgnoreCase_emptyRemove() throws Exception {
        assertEquals("abc", StringUtils.removeStartIgnoreCase("abc", ""));
    }

    @Test
    public void testRemoveStartIgnoreCase_match() throws Exception {
        assertEquals("domain.com", StringUtils.removeStartIgnoreCase("www.domain.com", "www."));
    }

    @Test
    public void testRemoveStartIgnoreCase_matchIgnoreCase() throws Exception {
        assertEquals("domain.com", StringUtils.removeStartIgnoreCase("www.domain.com", "WWW."));
    }

    @Test
    public void testRemoveStartIgnoreCase_noMatch() throws Exception {
        assertEquals("domain.com", StringUtils.removeStartIgnoreCase("domain.com", "www."));
    }

    @Test
    public void testRemoveEnd_nullString() throws Exception {
        assertNull(StringUtils.removeEnd(null, ".com"));
    }

    @Test
    public void testRemoveEnd_emptyString() throws Exception {
        assertEquals("", StringUtils.removeEnd("", ".com"));
    }

    @Test
    public void testRemoveEnd_nullRemove() throws Exception {
        assertEquals("abc", StringUtils.removeEnd("abc", null));
    }

    @Test
    public void testRemoveEnd_emptyRemove() throws Exception {
        assertEquals("abc", StringUtils.removeEnd("abc", ""));
    }

    @Test
    public void testRemoveEnd_match() throws Exception {
        assertEquals("www.domain", StringUtils.removeEnd("www.domain.com", ".com"));
    }

    @Test
    public void testRemoveEnd_noMatch() throws Exception {
        assertEquals("www.domain.com", StringUtils.removeEnd("www.domain.com", ".org"));
    }

    @Test
    public void testRemoveEnd_noMatchDifferentString() throws Exception {
        assertEquals("www.domain.com", StringUtils.removeEnd("www.domain.com", "domain"));
    }

    @Test
    public void testRemoveEnd_noMatchSuffixTooLong() throws Exception {
        assertEquals("www.domain.com", StringUtils.removeEnd("www.domain.com", ".com."));
    }

    @Test
    public void testRemoveEndIgnoreCase_nullString() throws Exception {
        assertNull(StringUtils.removeEndIgnoreCase(null, ".com"));
    }

    @Test
    public void testRemoveEndIgnoreCase_emptyString() throws Exception {
        assertEquals("", StringUtils.removeEndIgnoreCase("", ".com"));
    }

    @Test
    public void testRemoveEndIgnoreCase_nullRemove() throws Exception {
        assertEquals("abc", StringUtils.removeEndIgnoreCase("abc", null));
    }

    @Test
    public void testRemoveEndIgnoreCase_emptyRemove() throws Exception {
        assertEquals("abc", StringUtils.removeEndIgnoreCase("abc", ""));
    }

    @Test
    public void testRemoveEndIgnoreCase_match() throws Exception {
        assertEquals("www.domain", StringUtils.removeEndIgnoreCase("www.domain.com", ".com"));
    }

    @Test
    public void testRemoveEndIgnoreCase_matchIgnoreCase() throws Exception {
        assertEquals("www.domain", StringUtils.removeEndIgnoreCase("www.domain.COM", ".com"));
        assertEquals("www.domain", StringUtils.removeEndIgnoreCase("www.domain.com", ".COM"));
    }

    @Test
    public void testRemoveEndIgnoreCase_noMatch() throws Exception {
        assertEquals("www.domain.com", StringUtils.removeEndIgnoreCase("www.domain.com", ".org"));
    }

    @Test
    public void testRemoveEndIgnoreCase_noMatchDifferentString() throws Exception {
        assertEquals("www.domain.com", StringUtils.removeEndIgnoreCase("www.domain.com", "domain"));
    }

    @Test
    public void testRemoveEndIgnoreCase_noMatchSuffixTooLong() throws Exception {
        assertEquals("www.domain.com", StringUtils.removeEndIgnoreCase("www.domain.com", ".com."));
    }
    
    @Test
    public void testRemove_nullString() throws Exception {
        assertNull(StringUtils.remove(null, "abc"));
    }

    @Test
    public void testRemove_emptyString() throws Exception {
        assertEquals("", StringUtils.remove("", "abc"));
    }

    @Test
    public void testRemove_nullRemove() throws Exception {
        assertEquals("abc", StringUtils.remove("abc", null));
    }

    @Test
    public void testRemove_emptyRemove() throws Exception {
        assertEquals("abc", StringUtils.remove("abc", ""));
    }

    @Test
    public void testRemove_match() throws Exception {
        assertEquals("qd", StringUtils.remove("queued", "ue"));
    }

    @Test
    public void testRemove_noMatch() throws Exception {
        assertEquals("queued", StringUtils.remove("queued", "zz"));
    }

    @Test
    public void testRemove_multipleMatches() throws Exception {
        assertEquals("qeed", StringUtils.remove("queueued", "ue"));
    }

    @Test
    public void testRemove_char_nullString() throws Exception {
        assertNull(StringUtils.remove(null, 'a'));
    }

    @Test
    public void testRemove_char_emptyString() throws Exception {
        assertEquals("", StringUtils.remove("", 'a'));
    }

    @Test
    public void testRemove_char_match() throws Exception {
        assertEquals("qeed", StringUtils.remove("queued", 'u'));
    }

    @Test
    public void testRemove_char_noMatch() throws Exception {
        assertEquals("queued", StringUtils.remove("queued", 'z'));
    }
    
    @Test
    public void testReplaceOnce_nullText() throws Exception {
        assertNull(StringUtils.replaceOnce(null, "a", "z"));
    }

    @Test
    public void testReplaceOnce_emptyText() throws Exception {
        assertEquals("", StringUtils.replaceOnce("", "a", "z"));
    }

    @Test
    public void testReplaceOnce_nullSearchString() throws Exception {
        assertEquals("any", StringUtils.replaceOnce("any", null, "z"));
    }

    @Test
    public void testReplaceOnce_nullReplacement() throws Exception {
        assertEquals("aba", StringUtils.replaceOnce("aba", "a", null));
    }

    @Test
    public void testReplaceOnce_emptySearchString() throws Exception {
        assertEquals("any", StringUtils.replaceOnce("any", "", "z"));
    }

    @Test
    public void testReplaceOnce_emptyReplacement() throws Exception {
        assertEquals("ba", StringUtils.replaceOnce("aba", "a", ""));
    }

    @Test
    public void testReplaceOnce_singleReplacement() throws Exception {
        assertEquals("zba", StringUtils.replaceOnce("aba", "a", "z"));
    }

    @Test
    public void testReplaceOnce_multipleOccurrences() throws Exception {
        assertEquals("zba", StringUtils.replaceOnce("aba", "a", "z")); // Only first 'a' is replaced
    }

    @Test
    public void testReplace_nullText() throws Exception {
        assertNull(StringUtils.replace(null, "a", "z"));
    }

    @Test
    public void testReplace_emptyText() throws Exception {
        assertEquals("", StringUtils.replace("", "a", "z"));
    }

    @Test
    public void testReplace_nullSearchString() throws Exception {
        assertEquals("any", StringUtils.replace("any", null, "z"));
    }

    @Test
    public void testReplace_nullReplacement() throws Exception {
        assertEquals("aba", StringUtils.replace("aba", "a", null));
    }

    @Test
    public void testReplace_emptySearchString() throws Exception {
        assertEquals("any", StringUtils.replace("any", "", "z"));
    }

    @Test
    public void testReplace_emptyReplacement() throws Exception {
        assertEquals("b", StringUtils.replace("aba", "a", ""));
    }

    @Test
    public void testReplace_singleReplacement() throws Exception {
        assertEquals("zbz", StringUtils.replace("aba", "a", "z"));
    }

    @Test
    public void testReplace_multipleOccurrences() throws Exception {
        assertEquals("zbzbz", StringUtils.replace("ababab", "ab", "z"));
    }
    
    @Test
    public void testReplace_max_nullText() throws Exception {
        assertNull(StringUtils.replace(null, "a", "z", -1));
    }

    @Test
    public void testReplace_max_emptyText() throws Exception {
        assertEquals("", StringUtils.replace("", "a", "z", -1));
    }

    @Test
    public void testReplace_max_nullSearchString() throws Exception {
        assertEquals("any", StringUtils.replace("any", null, "z", -1));
    }

    @Test
    public void testReplace_max_nullReplacement() throws Exception {
        assertEquals("abaa", StringUtils.replace("abaa", "a", null, -1));
    }

    @Test
    public void testReplace_max_emptySearchString() throws Exception {
        assertEquals("any", StringUtils.replace("any", "", "z", -1));
    }

    @Test
    public void testReplace_max_zeroMax() throws Exception {
        assertEquals("abaa", StringUtils.replace("abaa", "a", "z", 0));
    }

    @Test
    public void testReplace_max_emptyReplacement() throws Exception {
        assertEquals("b", StringUtils.replace("abaa", "a", "", -1));
    }

    @Test
    public void testReplace_max_oneReplacement() throws Exception {
        assertEquals("zbaa", StringUtils.replace("abaa", "a", "z", 1));
    }

    @Test
    public void testReplace_max_twoReplacements() throws Exception {
        assertEquals("zbza", StringUtils.replace("abaa", "a", "z", 2));
    }

    @Test
    public void testReplace_max_allReplacements() throws Exception {
        assertEquals("zbzz", StringUtils.replace("abaa", "a", "z", -1));
    }

    @Test
    public void testReplaceEach_nullText() throws Exception {
        assertNull(StringUtils.replaceEach(null, new String[]{"a"}, new String[]{"b"}));
    }

    @Test
    public void testReplaceEach_emptyText() throws Exception {
        assertEquals("", StringUtils.replaceEach("", new String[]{"a"}, new String[]{"b"}));
    }

    @Test
    public void testReplaceEach_nullSearchList() throws Exception {
        assertEquals("abc", StringUtils.replaceEach("abc", null, new String[]{"b"}));
    }

    @Test
    public void testReplaceEach_nullReplacementList() throws Exception {
        assertEquals("abc", StringUtils.replaceEach("abc", new String[]{"a"}, null));
    }

    @Test
    public void testReplaceEach_emptySearchList() throws Exception {
        assertEquals("abc", StringUtils.replaceEach("abc", new String[0], new String[]{"b"}));
    }

    @Test
    public void testReplaceEach_emptyReplacementList() throws Exception {
        assertEquals("abc", StringUtils.replaceEach("abc", new String[]{"a"}, new String[0]));
    }
    
    @Test
    public void testReplaceEach_searchNullInList() throws Exception {
        assertEquals("abc", StringUtils.replaceEach("abc", new String[]{null}, new String[]{"b"}));
    }

    @Test
    public void testReplaceEach_replacementNullInList() throws Exception {
        assertEquals("abc", StringUtils.replaceEach("abc", new String[]{"a"}, new String[]{null}));
    }
    
    @Test
    public void testReplaceEach_simpleReplacement() throws Exception {
        assertEquals("wcte", StringUtils.replaceEach("abcde", new String[]{"ab", "d"}, new String[]{"w", "t"}));
    }

    @Test
    public void testReplaceEach_noReplacement() throws Exception {
        assertEquals("abcde", StringUtils.replaceEach("abcde", new String[]{"x", "y"}, new String[]{"w", "t"}));
    }
    
    @Test
    public void testReplaceEachRepeatedly_nullText() throws Exception {
        assertNull(StringUtils.replaceEachRepeatedly(null, new String[]{"a"}, new String[]{"b"}));
    }

    @Test
    public void testReplaceEachRepeatedly_emptyText() throws Exception {
        assertEquals("", StringUtils.replaceEachRepeatedly("", new String[]{"a"}, new String[]{"b"}));
    }

    @Test
    public void testReplaceEachRepeatedly_nullSearchList() throws Exception {
        assertEquals("abc", StringUtils.replaceEachRepeatedly("abc", null, new String[]{"b"}));
    }

    @Test
    public void testReplaceEachRepeatedly_nullReplacementList() throws Exception {
        assertEquals("abc", StringUtils.replaceEachRepeatedly("abc", new String[]{"a"}, null));
    }

    @Test
    public void testReplaceEachRepeatedly_emptySearchList() throws Exception {
        assertEquals("abc", StringUtils.replaceEachRepeatedly("abc", new String[0], new String[]{"b"}));
    }

    @Test
    public void testReplaceEachRepeatedly_emptyReplacementList() throws Exception {
        assertEquals("abc", StringUtils.replaceEachRepeatedly("abc", new String[]{"a"}, new String[0]));
    }
    
    @Test
    public void testReplaceEachRepeatedly_simpleReplacement() throws Exception {
        assertEquals("wcte", StringUtils.replaceEachRepeatedly("abcde", new String[]{"ab", "d"}, new String[]{"w", "t"}));
    }

    @Test
    public void testReplaceEachRepeatedly_noReplacement() throws Exception {
        assertEquals("abcde", StringUtils.replaceEachRepeatedly("abcde", new String[]{"x", "y"}, new String[]{"w", "t"}));
    }
    
    @Test
    public void testReplaceEachRepeatedly_repeatedReplacement() throws Exception {
        assertEquals("tcte", StringUtils.replaceEachRepeatedly("abcde", new String[]{"ab", "d"}, new String[]{"d", "t"})); // ab->d, d->t => dcte. Repeatedly: ab->d->t => tcte
    }
    
    @Test
    public void testReplaceEachRepeatedly_noRepeat() throws Exception {
        assertEquals("dcte", StringUtils.replaceEachRepeatedly("abcde", new String[]{"ab", "d"}, new String[]{"d", "t"}, false, 0));
    }

    @Test
    public void testReplaceEachRepeatedly_repeatTrue() throws Exception {
        assertEquals("tcte", StringUtils.replaceEachRepeatedly("abcde", new String[]{"ab", "d"}, new String[]{"d", "t"}, true, 0));
    }
    
    @Test
    public void testReplaceChars_nullString() throws Exception {
        assertNull(StringUtils.replaceChars(null, 'a', 'b'));
    }

    @Test
    public void testReplaceChars_emptyString() throws Exception {
        assertEquals("", StringUtils.replaceChars("", 'a', 'b'));
    }

    @Test
    public void testReplaceChars_match() throws Exception {
        assertEquals("aycya", StringUtils.replaceChars("abcba", 'b', 'y'));
    }

    @Test
    public void testReplaceChars_noMatch() throws Exception {
        assertEquals("abcba", StringUtils.replaceChars("abcba", 'z', 'y'));
    }

    @Test
    public void testReplaceChars_stringAndString_nullString() throws Exception {
        assertNull(StringUtils.replaceChars(null, "abc", "def"));
    }

    @Test
    public void testReplaceChars_stringAndString_emptyString() throws Exception {
        assertEquals("", StringUtils.replaceChars("", "abc", "def"));
    }

    @Test
    public void testReplaceChars_stringAndString_nullSearchChars() throws Exception {
        assertEquals("abc", StringUtils.replaceChars("abc", null, "def"));
    }

    @Test
    public void testReplaceChars_stringAndString_emptySearchChars() throws Exception {
        assertEquals("abc", StringUtils.replaceChars("abc", "", "def"));
    }

    @Test
    public void testReplaceChars_stringAndString_nullReplaceChars() throws Exception {
        assertEquals("ac", StringUtils.replaceChars("abc", "b", null));
        assertEquals("ac", StringUtils.replaceChars("abc", "b", ""));
    }

    @Test
    public void testReplaceChars_stringAndString_searchLongerThanReplace() throws Exception {
        assertEquals("aycya", StringUtils.replaceChars("abcba", "bc", "yz"));
    }

    @Test
    public void testReplaceChars_stringAndString_searchShorterThanReplace() throws Exception {
        assertEquals("ayzya", StringUtils.replaceChars("abcba", "bc", "yzx"));
    }
    
    @Test
    public void testOverlay_nullString() throws Exception {
        assertNull(StringUtils.overlay(null, "zzzz", 2, 4));
    }

    @Test
    public void testOverlay_nullOverlay() throws Exception {
        assertEquals("abef", StringUtils.overlay("abcdef", null, 2, 4));
    }

    @Test
    public void testOverlay_emptyOverlay() throws Exception {
        assertEquals("abef", StringUtils.overlay("abcdef", "", 2, 4));
    }

    @Test
    public void testOverlay_startNegative() throws Exception {
        assertEquals("zzzzef", StringUtils.overlay("abcdef", "zzzz", -1, 4));
    }

    @Test
    public void testOverlay_endBeyondLength() throws Exception {
        assertEquals("abzzzz", StringUtils.overlay("abcdef", "zzzz", 2, 8));
    }

    @Test
    public void testOverlay_startBeyondLength() throws Exception {
        assertEquals("abcdefzzzz", StringUtils.overlay("abcdef", "zzzz", 8, 10));
    }

    @Test
    public void testOverlay_startGreaterThanEnd() throws Exception {
        assertEquals("abzzzzef", StringUtils.overlay("abcdef", "zzzz", 4, 2));
    }

    @Test
    public void testOverlay_negativeStartNegativeEnd() throws Exception {
        assertEquals("zzzzabcdef", StringUtils.overlay("abcdef", "zzzz", -2, -3));
    }
    
    @Test
    public void testOverlay_emptyString() throws Exception {
        assertEquals("abc", StringUtils.overlay("", "abc", 0, 0));
    }
    
    @Test
    public void testChomp_nullString() throws Exception {
        assertNull(StringUtils.chomp(null));
    }

    @Test
    public void testChomp_emptyString() throws Exception {
        assertEquals("", StringUtils.chomp(""));
    }

    @Test
    public void testChomp_singleCharLF() throws Exception {
        assertEquals("", StringUtils.chomp("\n"));
    }

    @Test
    public void testChomp_singleCharCR() throws Exception {
        assertEquals("", StringUtils.chomp("\r"));
    }

    @Test
    public void testChomp_CRLF() throws Exception {
        assertEquals("", StringUtils.chomp("\r\n"));
    }

    @Test
    public void testChomp_LF() throws Exception {
        assertEquals("abc", StringUtils.chomp("abc\n"));
    }

    @Test
    public void testChomp_CR() throws Exception {
        assertEquals("abc ", StringUtils.chomp("abc \r"));
    }

    @Test
    public void testChomp_CRLF_followedByContent() throws Exception {
        assertEquals("abc\n", StringUtils.chomp("abc\n\r"));
    }

    @Test
    public void testChomp_CRLF_atEnd() throws Exception {
        assertEquals("abc", StringUtils.chomp("abc\r\n"));
    }

    @Test
    public void testChomp_multipleCRLF() throws Exception {
        assertEquals("abc\r\n", StringUtils.chomp("abc\r\n\r\n"));
    }
    
    @Test
    public void testChomp_stringAndSeparator_nullString() throws Exception {
        assertNull(StringUtils.chomp(null, "bar"));
    }

    @Test
    public void testChomp_stringAndSeparator_emptyString() throws Exception {
        assertEquals("", StringUtils.chomp("", "bar"));
    }

    @Test
    public void testChomp_stringAndSeparator_nullSeparator() throws Exception {
        assertEquals("foobar", StringUtils.chomp("foobar", null));
    }

    @Test
    public void testChomp_stringAndSeparator_emptySeparator() throws Exception {
        assertEquals("foobar", StringUtils.chomp("foobar", ""));
    }

    @Test
    public void testChomp_stringAndSeparator_match() throws Exception {
        assertEquals("foo", StringUtils.chomp("foobar", "bar"));
    }

    @Test
    public void testChomp_stringAndSeparator_noMatch() throws Exception {
        assertEquals("foobar", StringUtils.chomp("foobar", "baz"));
    }

    @Test
    public void testChomp_stringAndSeparator_separatorIsWholeString() throws Exception {
        assertEquals("", StringUtils.chomp("foo", "foo"));
    }

    @Test
    public void testChomp_stringAndSeparator_separatorIsPrefix() throws Exception {
        assertEquals("foo ", StringUtils.chomp("foo ", "foo"));
    }

    @Test
    public void testChomp_stringAndSeparator_separatorIsSuffix() throws Exception {
        assertEquals(" ", StringUtils.chomp(" foo", "foo"));
    }

    @Test
    public void testChomp_stringAndSeparator_separatorLonger() throws Exception {
        assertEquals("foo", StringUtils.chomp("foo", "foooo"));
    }
    
    @Test
    public void testChop_nullString() throws Exception {
        assertNull(StringUtils.chop(null));
    }

    @Test
    public void testChop_emptyString() throws Exception {
        assertEquals("", StringUtils.chop(""));
    }

    @Test
    public void testChop_singleChar() throws Exception {
        assertEquals("", StringUtils.chop("a"));
    }

    @Test
    public void testChop_singleCharLF() throws Exception {
        assertEquals("", StringUtils.chop("\n"));
    }

    @Test
    public void testChop_singleCharCR() throws Exception {
        assertEquals("", StringUtils.chop("\r"));
    }

    @Test
    public void testChop_CRLF() throws Exception {
        assertEquals("", StringUtils.chop("\r\n"));
    }

    @Test
    public void testChop_normalString() throws Exception {
        assertEquals("ab", StringUtils.chop("abc"));
    }

    @Test
    public void testChop_endsInLF() throws Exception {
        assertEquals("abc", StringUtils.chop("abc\n"));
    }

    @Test
    public void testChop_endsInCR() throws Exception {
        assertEquals("abc ", StringUtils.chop("abc \r"));
    }

    @Test
    public void testChop_endsInCRLF() throws Exception {
        assertEquals("abc", StringUtils.chop("abc\r\n"));
    }

    @Test
    public void testChop_stringWithInternalLF() throws Exception {
        assertEquals("abc\nab", StringUtils.chop("abc\nabc"));
    }
    
    @Test
    public void testRepeat_nullString() throws Exception {
        assertNull(StringUtils.repeat(null, 2));
    }

    @Test
    public void testRepeat_emptyStringPositiveRepeat() throws Exception {
        assertEquals("", StringUtils.repeat("", 2));
    }

    @Test
    public void testRepeat_emptyStringZeroRepeat() throws Exception {
        assertEquals("", StringUtils.repeat("", 0));
    }

    @Test
    public void testRepeat_positiveRepeat() throws Exception {
        assertEquals("aaa", StringUtils.repeat("a", 3));
        assertEquals("abab", StringUtils.repeat("ab", 2));
    }

    @Test
    public void testRepeat_zeroRepeat() throws Exception {
        assertEquals("", StringUtils.repeat("a", 0));
    }

    @Test
    public void testRepeat_negativeRepeat() throws Exception {
        assertEquals("", StringUtils.repeat("a", -2));
    }
    
    @Test
    public void testRepeat_stringAndSeparator_nullString() throws Exception {
        assertNull(StringUtils.repeat(null, null, 2));
    }

    @Test
    public void testRepeat_stringAndSeparator_nullSeparator() throws Exception {
        assertEquals("aa", StringUtils.repeat("a", null, 2));
    }

    @Test
    public void testRepeat_stringAndSeparator_emptyString() throws Exception {
        assertEquals("", StringUtils.repeat("", "", 2));
    }

    @Test
    public void testRepeat_stringAndSeparator_emptySeparator() throws Exception {
        assertEquals("aa", StringUtils.repeat("a", "", 2));
    }

    @Test
    public void testRepeat_stringAndSeparator_positiveRepeat() throws Exception {
        assertEquals("?, ?, ?", StringUtils.repeat("?", ", ", 3));
    }

    @Test
    public void testRepeat_stringAndSeparator_zeroRepeat() throws Exception {
        assertEquals("", StringUtils.repeat("?", ", ", 0));
    }

    @Test
    public void testRepeat_stringAndSeparator_negativeRepeat() throws Exception {
        assertEquals("", StringUtils.repeat("?", ", ", -2));
    }

    @Test
    public void testRightPad_nullString() throws Exception {
        assertNull(StringUtils.rightPad(null, 3));
    }

    @Test
    public void testRightPad_emptyString() throws Exception {
        assertEquals("   ", StringUtils.rightPad("", 3));
    }

    @Test
    public void testRightPad_sizeEqualsLength() throws Exception {
        assertEquals("bat", StringUtils.rightPad("bat", 3));
    }

    @Test
    public void testRightPad_sizeLargerThanLength() throws Exception {
        assertEquals("bat  ", StringUtils.rightPad("bat", 5));
    }

    @Test
    public void testRightPad_sizeSmallerThanLength() throws Exception {
        assertEquals("bat", StringUtils.rightPad("bat", 1));
    }

    @Test
    public void testRightPad_negativeSize() throws Exception {
        assertEquals("bat", StringUtils.rightPad("bat", -1));
    }
    
    @Test
    public void testRightPad_char_nullString() throws Exception {
        assertNull(StringUtils.rightPad(null, 3, 'z'));
    }

    @Test
    public void testRightPad_char_emptyString() throws Exception {
        assertEquals("zzz", StringUtils.rightPad("", 3, 'z'));
    }

    @Test
    public void testRightPad_char_sizeEqualsLength() throws Exception {
        assertEquals("bat", StringUtils.rightPad("bat", 3, 'z'));
    }

    @Test
    public void testRightPad_char_sizeLargerThanLength() throws Exception {
        assertEquals("batzz", StringUtils.rightPad("bat", 5, 'z'));
    }

    @Test
    public void testRightPad_char_sizeSmallerThanLength() throws Exception {
        assertEquals("bat", StringUtils.rightPad("bat", 1, 'z'));
    }

    @Test
    public void testRightPad_char_negativeSize() throws Exception {
        assertEquals("bat", StringUtils.rightPad("bat", -1, 'z'));
    }
    
    @Test
    public void testRightPad_string_nullString() throws Exception {
        assertNull(StringUtils.rightPad(null, 5, "yz"));
    }

    @Test
    public void testRightPad_string_emptyString() throws Exception {
        assertEquals("yz", StringUtils.rightPad("", 2, "yz"));
        assertEquals("yzy", StringUtils.rightPad("", 3, "yz"));
    }
    
    @Test
    public void testRightPad_string_sizeEqualsLength() throws Exception {
        assertEquals("bat", StringUtils.rightPad("bat", 3, "yz"));
    }

    @Test
    public void testRightPad_string_sizeLargerThanLength() throws Exception {
        assertEquals("batyz", StringUtils.rightPad("bat", 5, "yz"));
        assertEquals("batyzyzy", StringUtils.rightPad("bat", 8, "yz"));
    }

    @Test
    public void testRightPad_string_sizeSmallerThanLength() throws Exception {
        assertEquals("bat", StringUtils.rightPad("bat", 1, "yz"));
    }

    @Test
    public void testRightPad_string_negativeSize() throws Exception {
        assertEquals("bat", StringUtils.rightPad("bat", -1, "yz"));
    }

    @Test
    public void testRightPad_string_nullPadString() throws Exception {
        assertEquals("  bat", StringUtils.rightPad("bat", 5, null));
    }

    @Test
    public void testRightPad_string_emptyPadString() throws Exception {
        assertEquals("  bat", StringUtils.rightPad("bat", 5, ""));
    }

    @Test
    public void testLeftPad_nullString() throws Exception {
        assertNull(StringUtils.leftPad(null, 3));
    }

    @Test
    public void testLeftPad_emptyString() throws Exception {
        assertEquals("   ", StringUtils.leftPad("", 3));
    }

    @Test
    public void testLeftPad_sizeEqualsLength() throws Exception {
        assertEquals("bat", StringUtils.leftPad("bat", 3));
    }

    @Test
    public void testLeftPad_sizeLargerThanLength() throws Exception {
        assertEquals("  bat", StringUtils.leftPad("bat", 5));
    }

    @Test
    public void testLeftPad_sizeSmallerThanLength() throws Exception {
        assertEquals("bat", StringUtils.leftPad("bat", 1));
    }

    @Test
    public void testLeftPad_negativeSize() throws Exception {
        assertEquals("bat", StringUtils.leftPad("bat", -1));
    }
    
    @Test
    public void testLeftPad_char_nullString() throws Exception {
        assertNull(StringUtils.leftPad(null, 3, 'z'));
    }

    @Test
    public void testLeftPad_char_emptyString() throws Exception {
        assertEquals("zzz", StringUtils.leftPad("", 3, 'z'));
    }

    @Test
    public void testLeftPad_char_sizeEqualsLength() throws Exception {
        assertEquals("bat", StringUtils.leftPad("bat", 3, 'z'));
    }

    @Test
    public void testLeftPad_char_sizeLargerThanLength() throws Exception {
        assertEquals("zzbat", StringUtils.leftPad("bat", 5, 'z'));
    }

    @Test
    public void testLeftPad_char_sizeSmallerThanLength() throws Exception {
        assertEquals("bat", StringUtils.leftPad("bat", 1, 'z'));
    }

    @Test
    public void testLeftPad_char_negativeSize() throws Exception {
        assertEquals("bat", StringUtils.leftPad("bat", -1, 'z'));
    }
    
    @Test
    public void testLeftPad_string_nullString() throws Exception {
        assertNull(StringUtils.leftPad(null, 5, "yz"));
    }

    @Test
    public void testLeftPad_string_emptyString() throws Exception {
        assertEquals("yz", StringUtils.leftPad("", 2, "yz"));
        assertEquals("yzy", StringUtils.leftPad("", 3, "yz"));
    }
    
    @Test
    public void testLeftPad_string_sizeEqualsLength() throws Exception {
        assertEquals("bat", StringUtils.leftPad("bat", 3, "yz"));
    }

    @Test
    public void testLeftPad_string_sizeLargerThanLength() throws Exception {
        assertEquals("yzbat", StringUtils.leftPad("bat", 5, "yz"));
        assertEquals("yzyzybat", StringUtils.leftPad("bat", 8, "yz"));
    }

    @Test
    public void testLeftPad_string_sizeSmallerThanLength() throws Exception {
        assertEquals("bat", StringUtils.leftPad("bat", 1, "yz"));
    }

    @Test
    public void testLeftPad_string_negativeSize() throws Exception {
        assertEquals("bat", StringUtils.leftPad("bat", -1, "yz"));
    }

    @Test
    public void testLeftPad_string_nullPadString() throws Exception {
        assertEquals("  bat", StringUtils.leftPad("bat", 5, null));
    }

    @Test
    public void testLeftPad_string_emptyPadString() throws Exception {
        assertEquals("  bat", StringUtils.leftPad("bat", 5, ""));
    }

    @Test
    public void testLength_nullCharSequence() throws Exception {
        assertEquals(0, StringUtils.length(null));
    }

    @Test
    public void testLength_emptyCharSequence() throws Exception {
        assertEquals(0, StringUtils.length(""));
    }

    @Test
    public void testLength_nonEmptyCharSequence() throws Exception {
        assertEquals(3, StringUtils.length("abc"));
    }

    @Test
    public void testCenter_nullString() throws Exception {
        assertNull(StringUtils.center(null, 4));
    }

    @Test
    public void testCenter_negativeSize() throws Exception {
        assertEquals("ab", StringUtils.center("ab", -1));
    }

    @Test
    public void testCenter_emptyString() throws Exception {
        assertEquals("    ", StringUtils.center("", 4));
    }

    @Test
    public void testCenter_sizeEqualsLength() throws Exception {
        assertEquals("abcd", StringUtils.center("abcd", 2));
    }

    @Test
    public void testCenter_evenPadding() throws Exception {
        assertEquals(" ab ", StringUtils.center("ab", 4));
    }

    @Test
    public void testCenter_oddPaddingLeft() throws Exception {
        assertEquals(" a  ", StringUtils.center("a", 4));
    }

    @Test
    public void testCenter_charPad_nullString() throws Exception {
        assertNull(StringUtils.center(null, 4, ' '));
    }

    @Test
    public void testCenter_charPad_negativeSize() throws Exception {
        assertEquals("ab", StringUtils.center("ab", -1, ' '));
    }

    @Test
    public void testCenter_charPad_emptyString() throws Exception {
        assertEquals("    ", StringUtils.center("", 4, ' '));
    }

    @Test
    public void testCenter_charPad_sizeEqualsLength() throws Exception {
        assertEquals("abcd", StringUtils.center("abcd", 2, ' '));
    }

    @Test
    public void testCenter_charPad_evenPadding() throws Exception {
        assertEquals(" ab ", StringUtils.center("ab", 4, ' '));
    }

    @Test
    public void testCenter_charPad_oddPaddingLeft() throws Exception {
        assertEquals(" a  ", StringUtils.center("a", 4, ' '));
    }

    @Test
    public void testCenter_charPad_customChar() throws Exception {
        assertEquals("yayy", StringUtils.center("a", 4, 'y'));
    }

    @Test
    public void testCenter_stringPad_nullString() throws Exception {
        assertNull(StringUtils.center(null, 4, "yz"));
    }

    @Test
    public void testCenter_stringPad_negativeSize() throws Exception {
        assertEquals("ab", StringUtils.center("ab", -1, "yz"));
    }

    @Test
    public void testCenter_stringPad_emptyString() throws Exception {
        assertEquals("    ", StringUtils.center("", 4, " "));
    }

    @Test
    public void testCenter_stringPad_sizeEqualsLength() throws Exception {
        assertEquals("abcd", StringUtils.center("abcd", 2, " "));
    }

    @Test
    public void testCenter_stringPad_evenPadding() throws Exception {
        assertEquals(" ab ", StringUtils.center("ab", 4, " "));
    }

    @Test
    public void testCenter_stringPad_oddPaddingLeft() throws Exception {
        assertEquals(" a  ", StringUtils.center("a", 4, " "));
    }

    @Test
    public void testCenter_stringPad_customString() throws Exception {
        assertEquals("yayz", StringUtils.center("a", 4, "yz"));
    }

    @Test
    public void testCenter_stringPad_nullPadString() throws Exception {
        assertEquals("  abc  ", StringUtils.center("abc", 7, null));
    }

    @Test
    public void testCenter_stringPad_emptyPadString() throws Exception {
        assertEquals("  abc  ", StringUtils.center("abc", 7, ""));
    }
    
    @Test
    public void testUpperCase_null() throws Exception {
        assertNull(StringUtils.upperCase(null));
    }

    @Test
    public void testUpperCase_empty() throws Exception {
        assertEquals("", StringUtils.upperCase(""));
    }

    @Test
    public void testUpperCase_mixedCase() throws Exception {
        assertEquals("ABC", StringUtils.upperCase("aBc"));
    }

    @Test
    public void testUpperCase_alreadyUpper() throws Exception {
        assertEquals("ABC", StringUtils.upperCase("ABC"));
    }

    @Test
    public void testUpperCase_locale_nullString() throws Exception {
        assertNull(StringUtils.upperCase(null, Locale.ENGLISH));
    }

    @Test
    public void testUpperCase_locale_emptyString() throws Exception {
        assertEquals("", StringUtils.upperCase("", Locale.ENGLISH));
    }

    @Test
    public void testUpperCase_locale_mixedCase() throws Exception {
        assertEquals("ABC", StringUtils.upperCase("aBc", Locale.ENGLISH));
    }

    @Test
    public void testLowerCase_null() throws Exception {
        assertNull(StringUtils.lowerCase(null));
    }

    @Test
    public void testLowerCase_empty() throws Exception {
        assertEquals("", StringUtils.lowerCase(""));
    }

    @Test
    public void testLowerCase_mixedCase() throws Exception {
        assertEquals("abc", StringUtils.lowerCase("aBc"));
    }

    @Test
    public void testLowerCase_alreadyLower() throws Exception {
        assertEquals("abc", StringUtils.lowerCase("abc"));
    }

    @Test
    public void testLowerCase_locale_nullString() throws Exception {
        assertNull(StringUtils.lowerCase(null, Locale.ENGLISH));
    }

    @Test
    public void testLowerCase_locale_emptyString() throws Exception {
        assertEquals("", StringUtils.lowerCase("", Locale.ENGLISH));
    }

    @Test
    public void testLowerCase_locale_mixedCase() throws Exception {
        assertEquals("abc", StringUtils.lowerCase("aBc", Locale.ENGLISH));
    }
    
    @Test
    public void testCapitalize_null() throws Exception {
        assertNull(StringUtils.capitalize(null));
    }

    @Test
    public void testCapitalize_empty() throws Exception {
        assertEquals("", StringUtils.capitalize(""));
    }

    @Test
    public void testCapitalize_lowercase() throws Exception {
        assertEquals("Cat", StringUtils.capitalize("cat"));
    }

    @Test
    public void testCapitalize_mixedCase() throws Exception {
        assertEquals("CAt", StringUtils.capitalize("cAt"));
    }

    @Test
    public void testCapitalize_alreadyCapitalized() throws Exception {
        assertEquals("Cat", StringUtils.capitalize("Cat"));
    }
    
    @Test
    public void testUncapitalize_null() throws Exception {
        assertNull(StringUtils.uncapitalize(null));
    }

    @Test
    public void testUncapitalize_empty() throws Exception {
        assertEquals("", StringUtils.uncapitalize(""));
    }

    @Test
    public void testUncapitalize_uppercase() throws Exception {
        assertEquals("cat", StringUtils.uncapitalize("Cat"));
    }


    







