package org.apache.commons.lang3.math;

import org.junit.Test;
import static org.junit.Assert.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import org.apache.commons.lang3.StringUtils;

public class NumberUtilsTest {
    @Test
    public void testToInt_NullString() throws Exception {
        assertEquals(0, NumberUtils.toInt(null));
    }

    @Test
    public void testToInt_EmptyString() throws Exception {
        assertEquals(0, NumberUtils.toInt(""));
    }

    @Test
    public void testToInt_ValidString() throws Exception {
        assertEquals(123, NumberUtils.toInt("123"));
    }

    @Test
    public void testToInt_InvalidString() throws Exception {
        assertEquals(0, NumberUtils.toInt("abc"));
    }

    @Test
    public void testToInt_DefaultValue() throws Exception {
        assertEquals(99, NumberUtils.toInt("abc", 99));
    }

    @Test
    public void testToLong_NullString() throws Exception {
        assertEquals(0L, NumberUtils.toLong(null));
    }

    @Test
    public void testToLong_EmptyString() throws Exception {
        assertEquals(0L, NumberUtils.toLong(""));
    }

    @Test
    public void testToLong_ValidString() throws Exception {
        assertEquals(1234567890123L, NumberUtils.toLong("1234567890123"));
    }

    @Test
    public void testToLong_InvalidString() throws Exception {
        assertEquals(0L, NumberUtils.toLong("abc"));
    }

    @Test
    public void testToLong_DefaultValue() throws Exception {
        assertEquals(99L, NumberUtils.toLong("abc", 99L));
    }

    @Test
    public void testToFloat_NullString() throws Exception {
        assertEquals(0.0f, NumberUtils.toFloat(null), 0.0f);
    }

    @Test
    public void testToFloat_EmptyString() throws Exception {
        assertEquals(0.0f, NumberUtils.toFloat(""), 0.0f);
    }

    @Test
    public void testToFloat_ValidString() throws Exception {
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), 0.0001f);
    }

    @Test
    public void testToFloat_InvalidString() throws Exception {
        assertEquals(0.0f, NumberUtils.toFloat("abc"), 0.0f);
    }

    @Test
    public void testToFloat_DefaultValue() throws Exception {
        assertEquals(1.1f, NumberUtils.toFloat("", 1.1f), 0.0f);
    }

    @Test
    public void testToDouble_NullString() throws Exception {
        assertEquals(0.0d, NumberUtils.toDouble(null), 0.0d);
    }

    @Test
    public void testToDouble_EmptyString() throws Exception {
        assertEquals(0.0d, NumberUtils.toDouble(""), 0.0d);
    }

    @Test
    public void testToDouble_ValidString() throws Exception {
        assertEquals(1.2345d, NumberUtils.toDouble("1.2345"), 0.0001d);
    }

    @Test
    public void testToDouble_InvalidString() throws Exception {
        assertEquals(0.0d, NumberUtils.toDouble("abc"), 0.0d);
    }

    @Test
    public void testToDouble_DefaultValue() throws Exception {
        assertEquals(1.1d, NumberUtils.toDouble(null, 1.1d), 0.0d);
    }

    @Test
    public void testToByte_NullString() throws Exception {
        assertEquals((byte) 0, NumberUtils.toByte(null));
    }

    @Test
    public void testToByte_EmptyString() throws Exception {
        assertEquals((byte) 0, NumberUtils.toByte(""));
    }

    @Test
    public void testToByte_ValidString() throws Exception {
        assertEquals((byte) 10, NumberUtils.toByte("10"));
    }

    @Test
    public void testToByte_InvalidString() throws Exception {
        assertEquals((byte) 0, NumberUtils.toByte("abc"));
    }

    @Test
    public void testToByte_DefaultValue() throws Exception {
        assertEquals((byte) 5, NumberUtils.toByte("", (byte) 5));
    }

    @Test
    public void testToShort_NullString() throws Exception {
        assertEquals((short) 0, NumberUtils.toShort(null));
    }

    @Test
    public void testToShort_EmptyString() throws Exception {
        assertEquals((short) 0, NumberUtils.toShort(""));
    }

    @Test
    public void testToShort_ValidString() throws Exception {
        assertEquals((short) 100, NumberUtils.toShort("100"));
    }

    @Test
    public void testToShort_InvalidString() throws Exception {
        assertEquals((short) 0, NumberUtils.toShort("abc"));
    }

    @Test
    public void testToShort_DefaultValue() throws Exception {
        assertEquals((short) 2, NumberUtils.toShort("", (short) 2));
    }

    @Test
    public void testCreateNumber_NullString() throws Exception {
        assertNull(NumberUtils.createNumber(null));
    }

    @Test
    public void testCreateNumber_BlankString() throws Exception {
        try {
            NumberUtils.createNumber("");
            fail("Expected NumberFormatException for blank string");
        } catch (NumberFormatException e) {
            // Expected
        }
    }

    @Test
    public void testCreateNumber_Integer() throws Exception {
        Number num = NumberUtils.createNumber("123");
        assertTrue(num instanceof Integer);
        assertEquals(123, num.intValue());
    }

    @Test
    public void testCreateNumber_Long() throws Exception {
        Number num = NumberUtils.createNumber("1234567890123");
        assertTrue(num instanceof Long);
        assertEquals(1234567890123L, num.longValue());
    }

    @Test
    public void testCreateNumber_BigInteger() throws Exception {
        String largeNumber = "123456789012345678901234567890";
        Number num = NumberUtils.createNumber(largeNumber);
        assertTrue(num instanceof BigInteger);
        assertEquals(new BigInteger(largeNumber), num);
    }

    @Test
    public void testCreateNumber_Float() throws Exception {
        Number num = NumberUtils.createNumber("1.5f");
        assertTrue(num instanceof Float);
        assertEquals(1.5f, num.floatValue(), 0.0001f);
    }

    @Test
    public void testCreateNumber_Double() throws Exception {
        Number num = NumberUtils.createNumber("1.5d");
        assertTrue(num instanceof Double);
        assertEquals(1.5d, num.doubleValue(), 0.0001d);
    }

    @Test
    public void testCreateNumber_BigDecimal() throws Exception {
        // According to the source, if no qualifier and a decimal point exists, it should create BigDecimal.
        Number num = NumberUtils.createNumber("1.5");
        assertTrue(num instanceof BigDecimal);
        assertEquals(new BigDecimal("1.5"), num);
    }

    @Test
    public void testCreateNumber_HexInteger() throws Exception {
        Number num = NumberUtils.createNumber("0xFF");
        assertTrue(num instanceof Integer);
        assertEquals(255, num.intValue());
    }

    @Test
    public void testCreateNumber_NegativeHexInteger() throws Exception {
        Number num = NumberUtils.createNumber("-0xFF");
        assertTrue(num instanceof Integer);
        assertEquals(-255, num.intValue());
    }

    @Test
    public void testCreateNumber_InvalidFormat() throws Exception {
        try {
            NumberUtils.createNumber("abc");
            fail("Expected NumberFormatException");
        } catch (NumberFormatException e) {
            // Expected
        }
    }
    
    @Test
    public void testCreateNumber_ScientificNotationDouble() throws Exception {
        Number num = NumberUtils.createNumber("1.2345e5");
        assertTrue(num instanceof Double); // It falls through to createDouble
        assertEquals(123450.0d, num.doubleValue(), 0.0001d);
    }

    @Test
    public void testCreateNumber_ScientificNotationFloat() throws Exception {
        Number num = NumberUtils.createNumber("1.2345e5f");
        assertTrue(num instanceof Float);
        assertEquals(123450.0f, num.floatValue(), 0.0001f);
    }

    @Test
    public void testCreateNumber_LongWithL() throws Exception {
        Number num = NumberUtils.createNumber("123L");
        assertTrue(num instanceof Long);
        assertEquals(123L, num.longValue());
    }
    
    @Test
    public void testCreateNumber_FloatWithF() throws Exception {
        Number num = NumberUtils.createNumber("123.45F");
        assertTrue(num instanceof Float);
        assertEquals(123.45f, num.floatValue(), 0.0001f);
    }

    @Test
    public void testCreateNumber_DoubleWithD() throws Exception {
        Number num = NumberUtils.createNumber("123.45D");
        assertTrue(num instanceof Double);
        assertEquals(123.45d, num.doubleValue(), 0.0001d);
    }

    @Test
    public void testCreateNumber_TooBigForLong() throws Exception {
        String tooBig = "9223372036854775808"; // Long.MAX_VALUE + 1
        Number num = NumberUtils.createNumber(tooBig);
        assertTrue(num instanceof BigInteger);
        assertEquals(new BigInteger(tooBig), num);
    }

    @Test
    public void testCreateNumber_TooBigForFloat() throws Exception {
        String largeFloatString = "3.4028235E38"; // Close to max float
        Number num = NumberUtils.createNumber(largeFloatString);
        assertTrue(num instanceof Float);
        assertEquals(Float.parseFloat(largeFloatString), num.floatValue(), 0.0001f);
    }

    @Test
    public void testCreateNumber_TooBigForDouble() throws Exception {
        String tooBig = "1.8E308"; // Max double value is approximately 1.8E308
        Number num = NumberUtils.createNumber(tooBig);
        assertTrue(num instanceof Double);
        assertEquals(Double.parseDouble(tooBig), num.doubleValue(), 0.0001d);
    }
    
    @Test
    public void testCreateNumber_BigDecimalWithExponent() throws Exception {
        Number num = NumberUtils.createNumber("12345E-2");
        assertTrue(num instanceof BigDecimal); // No type specifier, has decimal and exponent. Falls to BigDecimal.
        assertEquals(new BigDecimal("123.45"), num);
    }

    @Test
    public void testCreateNumber_HexLong() throws Exception {
        Number num = NumberUtils.createNumber("0x100000000"); // This exceeds Integer.MAX_VALUE
        assertTrue(num instanceof Long); // Integer.decode will parse it, but createInteger uses decode.
        assertEquals(0x100000000L, num.longValue());
    }

    @Test
    public void testCreateNumber_HexBigInteger() throws Exception {
        // A hex string that is too large for Long
        String hexTooBigForLong = "0x8000000000000000"; // Long.MIN_VALUE as hex
        Number num = NumberUtils.createNumber(hexTooBigForLong);
        // Integer.decode will throw NumberFormatException for values out of int range.
        // createInteger calls Integer.decode. So this should result in NumberFormatException.
        // However, the spec says "if the string starts with 0x or -0x, it will be interpreted as a hexadecimal integer"
        // The code path for createInteger->Integer.decode handles this.
        // For values larger than Integer.MAX_VALUE, Integer.decode does throw NFE.
        // The createNumber method has a fallback to createBigInteger if it fails to parse as Integer.
        // Let's re-evaluate createNumber logic.
        // If "0x" or "-0x", it calls createInteger.
        // createInteger calls Integer.decode.
        // Integer.decode throws NumberFormatException for values outside int range.
        // So, createNumber's path for "0x..." goes through createInteger, and if that fails, it *does not* fall back to createBigInteger.
        // The test below should be for NumberFormatException.
        
        // Re-evaluating: The test `testCreateNumber_HexLong` also uses `createInteger` and `Integer.decode`.
        // `Integer.decode("0x100000000")` results in `NumberFormatException`.
        // The `createNumber` method *does not* catch this exception for hex strings.
        // Therefore, this test should expect a NumberFormatException.
        try {
             NumberUtils.createNumber(hexTooBigForLong);
             fail("Expected NumberFormatException for hex string too big for Integer");
        } catch (NumberFormatException e) {
            // Expected
        }
    }

    @Test
    public void testCreateNumber_NumberFormatExceptionForDecimalInHex() throws Exception {
        try {
            NumberUtils.createNumber("0xFF.f");
            fail("Expected NumberFormatException");
        } catch (NumberFormatException e) {
            // Expected
        }
    }

    @Test
    public void testCreateNumber_NumberFormatExceptionForExpInHex() throws Exception {
        try {
            NumberUtils.createNumber("0xFFe1");
            fail("Expected NumberFormatException");
        } catch (NumberFormatException e) {
            // Expected
        }
    }

    @Test
    public void testCreateNumber_NumberFormatExceptionForSignAfterHexPrefix() throws Exception {
        try {
            NumberUtils.createNumber("0x-1");
            fail("Expected NumberFormatException");
        } catch (NumberFormatException e) {
            // Expected
        }
    }

    @Test
    public void testCreateNumber_SpecialCaseNegativeZero() throws Exception {
        Number num = NumberUtils.createNumber("-0.0");
        assertTrue(num instanceof BigDecimal);
        assertEquals(BigDecimal.ZERO, num); // -0.0 should be treated as 0
    }

    @Test
    public void testCreateNumber_SpecialCaseNegativeZeroF() throws Exception {
        Number num = NumberUtils.createNumber("-0.0f");
        assertTrue(num instanceof Float);
        assertEquals(-0.0f, num.floatValue(), 0.0001f); // Preserves negative zero for float
    }

    @Test
    public void testCreateNumber_SpecialCaseNegativeZeroD() throws Exception {
        Number num = NumberUtils.createNumber("-0.0d");
        assertTrue(num instanceof Double);
        assertEquals(-0.0d, num.doubleValue(), 0.0001d); // Preserves negative zero for double
    }

    @Test
    public void testIsDigits_Valid() throws Exception {
        assertTrue(NumberUtils.isDigits("12345"));
    }

    @Test
    public void testIsDigits_WithLeadingZero() throws Exception {
        assertTrue(NumberUtils.isDigits("012345"));
    }

    @Test
    public void testIsDigits_WithNegative() throws Exception {
        assertFalse(NumberUtils.isDigits("-123"));
    }

    @Test
    public void testIsDigits_WithDecimal() throws Exception {
        assertFalse(NumberUtils.isDigits("123.45"));
    }

    @Test
    public void testIsDigits_Empty() throws Exception {
        assertFalse(NumberUtils.isDigits(""));
    }

    @Test
    public void testIsDigits_Null() throws Exception {
        assertFalse(NumberUtils.isDigits(null));
    }

    @Test
    public void testIsNumber_Integer() throws Exception {
        assertTrue(NumberUtils.isNumber("123"));
    }

    @Test
    public void testIsNumber_NegativeInteger() throws Exception {
        assertTrue(NumberUtils.isNumber("-123"));
    }

    @Test
    public void testIsNumber_Hexadecimal() throws Exception {
        assertTrue(NumberUtils.isNumber("0xFF"));
    }

    @Test
    public void testIsNumber_NegativeHexadecimal() throws Exception {
        assertTrue(NumberUtils.isNumber("-0xFF"));
    }

    @Test
    public void testIsNumber_Float() throws Exception {
        assertTrue(NumberUtils.isNumber("1.5f"));
    }

    @Test
    public void testIsNumber_Double() throws Exception {
        assertTrue(NumberUtils.isNumber("1.5d"));
    }

    @Test
    public void testIsNumber_DoubleNoQualifier() throws Exception {
        assertTrue(NumberUtils.isNumber("1.5"));
    }

    @Test
    public void testIsNumber_ScientificNotation() throws Exception {
        assertTrue(NumberUtils.isNumber("1.2345e5"));
    }

    @Test
    public void testIsNumber_ScientificNotationWithSign() throws Exception {
        assertTrue(NumberUtils.isNumber("1.2345E+5"));
    }

    @Test
    public void testIsNumber_EmptyString() throws Exception {
        assertFalse(NumberUtils.isNumber(""));
    }

    @Test
    public void testIsNumber_NullString() throws Exception {
        assertFalse(NumberUtils.isNumber(null));
    }

    @Test
    public void testIsNumber_InvalidCharacters() throws Exception {
        assertFalse(NumberUtils.isNumber("123a"));
    }

    @Test
    public void testIsNumber_HexadecimalInvalidChars() throws Exception {
        assertFalse(NumberUtils.isNumber("0xG"));
    }

    @Test
    public void testIsNumber_DecimalPointAtEnd() throws Exception {
        assertTrue(NumberUtils.isNumber("123."));
    }

    @Test
    public void testIsNumber_DecimalPointAtStart() throws Exception {
        assertTrue(NumberUtils.isNumber(".123"));
    }

    @Test
    public void testIsNumber_ExponentWithoutDigits() throws Exception {
        assertFalse(NumberUtils.isNumber("123e"));
    }
    
    @Test
    public void testIsNumber_ExponentWithOnlySign() throws Exception {
        assertFalse(NumberUtils.isNumber("123e+"));
    }

    @Test
    public void testIsNumber_HexadecimalOnly() throws Exception {
        assertFalse(NumberUtils.isNumber("0x"));
    }
    
    @Test
    public void testIsNumber_NegativeHexadecimalOnly() throws Exception {
        assertFalse(NumberUtils.isNumber("-0x"));
    }

    @Test
    public void testIsNumber_DoubleQualifierAtEnd() throws Exception {
        assertTrue(NumberUtils.isNumber("1d"));
    }

    @Test
    public void testIsNumber_FloatQualifierAtEnd() throws Exception {
        assertTrue(NumberUtils.isNumber("1f"));
    }

    @Test
    public void testIsNumber_LongQualifierAtEnd() throws Exception {
        assertTrue(NumberUtils.isNumber("1L"));
    }

    @Test
    public void testIsNumber_LongQualifierAtEndWithExponent() throws Exception {
        // The logic in isNumber checks for type qualifiers *after* checking for exponent.
        // If it finds 'L' at the end, and hasExp is true, it returns false.
        assertFalse(NumberUtils.isNumber("1e5L"));
    }

    @Test
    public void testMin_LongArray() throws Exception {
        long[] array = {1L, 2L, 0L, -5L};
        assertEquals(-5L, NumberUtils.min(array));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMin_LongArrayNull() throws Exception {
        NumberUtils.min((long[]) null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMin_LongArrayEmpty() throws Exception {
        NumberUtils.min(new long[0]);
    }

    @Test
    public void testMin_IntArray() throws Exception {
        int[] array = {1, 2, 0, -5};
        assertEquals(-5, NumberUtils.min(array));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMin_IntArrayNull() throws Exception {
        NumberUtils.min((int[]) null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMin_IntArrayEmpty() throws Exception {
        NumberUtils.min(new int[0]);
    }

    @Test
    public void testMin_ShortArray() throws Exception {
        short[] array = {1, 2, 0, (short)-5};
        assertEquals((short)-5, NumberUtils.min(array));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMin_ShortArrayNull() throws Exception {
        NumberUtils.min((short[]) null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMin_ShortArrayEmpty() throws Exception {
        NumberUtils.min(new short[0]);
    }

    @Test
    public void testMin_ByteArray() throws Exception {
        byte[] array = {1, 2, 0, (byte)-5};
        assertEquals((byte)-5, NumberUtils.min(array));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMin_ByteArrayNull() throws Exception {
        NumberUtils.min((byte[]) null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMin_ByteArrayEmpty() throws Exception {
        NumberUtils.min(new byte[0]);
    }

    @Test
    public void testMin_DoubleArray() throws Exception {
        double[] array = {1.0, 2.0, 0.0, -5.5};
        assertEquals(-5.5d, NumberUtils.min(array), 0.0001d);
    }

    @Test
    public void testMin_DoubleArrayWithNaN() throws Exception {
        double[] array = {1.0, Double.NaN, 0.0, -5.5};
        assertEquals(Double.NaN, NumberUtils.min(array), 0.0001d);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMin_DoubleArrayNull() throws Exception {
        NumberUtils.min((double[]) null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMin_DoubleArrayEmpty() throws Exception {
        NumberUtils.min(new double[0]);
    }

    @Test
    public void testMin_FloatArray() throws Exception {
        float[] array = {1.0f, 2.0f, 0.0f, -5.5f};
        assertEquals(-5.5f, NumberUtils.min(array), 0.0001f);
    }

    @Test
    public void testMin_FloatArrayWithNaN() throws Exception {
        float[] array = {1.0f, Float.NaN, 0.0f, -5.5f};
        assertEquals(Float.NaN, NumberUtils.min(array), 0.0001f);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMin_FloatArrayNull() throws Exception {
        NumberUtils.min((float[]) null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMin_FloatArrayEmpty() throws Exception {
        NumberUtils.min(new float[0]);
    }

    @Test
    public void testMax_LongArray() throws Exception {
        long[] array = {1L, 2L, 0L, -5L};
        assertEquals(2L, NumberUtils.max(array));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMax_LongArrayNull() throws Exception {
        NumberUtils.max((long[]) null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMax_LongArrayEmpty() throws Exception {
        NumberUtils.max(new long[0]);
    }

    @Test
    public void testMax_IntArray() throws Exception {
        int[] array = {1, 2, 0, -5};
        assertEquals(2, NumberUtils.max(array));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMax_IntArrayNull() throws Exception {
        NumberUtils.max((int[]) null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMax_IntArrayEmpty() throws Exception {
        NumberUtils.max(new int[0]);
    }

    @Test
    public void testMax_ShortArray() throws Exception {
        short[] array = {1, 2, 0, (short)-5};
        assertEquals((short)2, NumberUtils.max(array));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMax_ShortArrayNull() throws Exception {
        NumberUtils.max((short[]) null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMax_ShortArrayEmpty() throws Exception {
        NumberUtils.max(new short[0]);
    }

    @Test
    public void testMax_ByteArray() throws Exception {
        byte[] array = {1, 2, 0, (byte)-5};
        assertEquals((byte)2, NumberUtils.max(array));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMax_ByteArrayNull() throws Exception {
        NumberUtils.max((byte[]) null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMax_ByteArrayEmpty() throws Exception {
        NumberUtils.max(new byte[0]);
    }

    @Test
    public void testMax_DoubleArray() throws Exception {
        double[] array = {1.0, 2.0, 0.0, -5.5};
        assertEquals(2.0d, NumberUtils.max(array), 0.0001d);
    }

    @Test
    public void testMax_DoubleArrayWithNaN() throws Exception {
        double[] array = {1.0, Double.NaN, 0.0, -5.5};
        assertEquals(Double.NaN, NumberUtils.max(array), 0.0001d);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMax_DoubleArrayNull() throws Exception {
        NumberUtils.max((double[]) null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMax_DoubleArrayEmpty() throws Exception {
        NumberUtils.max(new double[0]);
    }

    @Test
    public void testMax_FloatArray() throws Exception {
        float[] array = {1.0f, 2.0f, 0.0f, -5.5f};
        assertEquals(2.0f, NumberUtils.max(array), 0.0001f);
    }

    @Test
    public void testMax_FloatArrayWithNaN() throws Exception {
        float[] array = {1.0f, Float.NaN, 0.0f, -5.5f};
        assertEquals(Float.NaN, NumberUtils.max(array), 0.0001f);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMax_FloatArrayNull() throws Exception {
        NumberUtils.max((float[]) null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMax_FloatArrayEmpty() throws Exception {
        NumberUtils.max(new float[0]);
    }

    @Test
    public void testMin_ThreeLongs() throws Exception {
        assertEquals(-5L, NumberUtils.min(1L, -5L, 3L));
    }

    @Test
    public void testMin_ThreeInts() throws Exception {
        assertEquals(-5, NumberUtils.min(1, -5, 3));
    }

    @Test
    public void testMin_ThreeShorts() throws Exception {
        assertEquals((short)-5, NumberUtils.min((short)1, (short)-5, (short)3));
    }

    @Test
    public void testMin_ThreeBytes() throws Exception {
        assertEquals((byte)-5, NumberUtils.min((byte)1, (byte)-5, (byte)3));
    }

    @Test
    public void testMin_ThreeDoubles() throws Exception {
        assertEquals(-5.5d, NumberUtils.min(1.0d, -5.5d, 3.0d), 0.0001d);
    }

    @Test
    public void testMin_ThreeDoublesWithNaN() throws Exception {
        assertEquals(Double.NaN, NumberUtils.min(1.0d, Double.NaN, 3.0d), 0.0001d);
    }

    @Test
    public void testMin_ThreeFloats() throws Exception {
        assertEquals(-5.5f, NumberUtils.min(1.0f, -5.5f, 3.0f), 0.0001f);
    }

    @Test
    public void testMin_ThreeFloatsWithNaN() throws Exception {
        assertEquals(Float.NaN, NumberUtils.min(1.0f, Float.NaN, 3.0f), 0.0001f);
    }

    @Test
    public void testMax_ThreeLongs() throws Exception {
        assertEquals(3L, NumberUtils.max(1L, -5L, 3L));
    }

    @Test
    public void testMax_ThreeInts() throws Exception {
        assertEquals(3, NumberUtils.max(1, -5, 3));
    }

    @Test
    public void testMax_ThreeShorts() throws Exception {
        assertEquals((short)3, NumberUtils.max((short)1, (short)-5, (short)3));
    }

    @Test
    public void testMax_ThreeBytes() throws Exception {
        assertEquals((byte)3, NumberUtils.max((byte)1, (byte)-5, (byte)3));
    }

    @Test
    public void testMax_ThreeDoubles() throws Exception {
        assertEquals(3.0d, NumberUtils.max(1.0d, -5.5d, 3.0d), 0.0001d);
    }

    @Test
    public void testMax_ThreeDoublesWithNaN() throws Exception {
        assertEquals(Double.NaN, NumberUtils.max(1.0d, Double.NaN, 3.0d), 0.0001d);
    }

    @Test
    public void testMax_ThreeFloats() throws Exception {
        assertEquals(3.0f, NumberUtils.max(1.0f, -5.5f, 3.0f), 0.0001f);
    }

    @Test
    public void testMax_ThreeFloatsWithNaN() throws Exception {
        assertEquals(Float.NaN, NumberUtils.max(1.0f, Float.NaN, 3.0f), 0.0001f);
    }

    // New tests for methods not previously covered
    
    @Test
    public void testCreateFloat_Valid() throws Exception {
        assertEquals(Float.valueOf("1.23"), NumberUtils.createFloat("1.23"));
    }

    @Test
    public void testCreateFloat_Null() throws Exception {
        assertNull(NumberUtils.createFloat(null));
    }

    @Test
    public void testCreateFloat_Invalid() {
        try {
            NumberUtils.createFloat("abc");
            fail("Expected NumberFormatException");
        } catch (NumberFormatException e) {
            // Expected
        }
    }

    @Test
    public void testCreateDouble_Valid() throws Exception {
        assertEquals(Double.valueOf("1.2345"), NumberUtils.createDouble("1.2345"));
    }

    @Test
    public void testCreateDouble_Null() throws Exception {
        assertNull(NumberUtils.createDouble(null));
    }

    @Test
    public void testCreateDouble_Invalid() {
        try {
            NumberUtils.createDouble("abc");
            fail("Expected NumberFormatException");
        } catch (NumberFormatException e) {
            // Expected
        }
    }

    @Test
    public void testCreateInteger_Valid() throws Exception {
        assertEquals(Integer.valueOf(123), NumberUtils.createInteger("123"));
    }

    @Test
    public void testCreateInteger_HexValid() throws Exception {
        assertEquals(Integer.valueOf("FF", 16), NumberUtils.createInteger("0xFF"));
    }
    
    @Test
    public void testCreateInteger_OctalValid() throws Exception {
        assertEquals(Integer.valueOf("777", 8), NumberUtils.createInteger("0777"));
    }

    @Test
    public void testCreateInteger_Null() throws Exception {
        assertNull(NumberUtils.createInteger(null));
    }

    @Test
    public void testCreateInteger_Invalid() {
        try {
            NumberUtils.createInteger("abc");
            fail("Expected NumberFormatException");
        } catch (NumberFormatException e) {
            // Expected
        }
    }

    @Test
    public void testCreateLong_Valid() throws Exception {
        assertEquals(Long.valueOf(1234567890123L), NumberUtils.createLong("1234567890123"));
    }

    @Test
    public void testCreateLong_Null() throws Exception {
        assertNull(NumberUtils.createLong(null));
    }

    @Test
    public void testCreateLong_Invalid() {
        try {
            NumberUtils.createLong("abc");
            fail("Expected NumberFormatException");
        } catch (NumberFormatException e) {
            // Expected
        }
    }

    @Test
    public void testCreateBigInteger_Valid() throws Exception {
        assertEquals(new BigInteger("123456789012345678901234567890"), NumberUtils.createBigInteger("123456789012345678901234567890"));
    }

    @Test
    public void testCreateBigInteger_Null() throws Exception {
        assertNull(NumberUtils.createBigInteger(null));
    }

    @Test
    public void testCreateBigInteger_Invalid() {
        try {
            NumberUtils.createBigInteger("abc");
            fail("Expected NumberFormatException");
        } catch (NumberFormatException e) {
            // Expected
        }
    }

    @Test
    public void testCreateBigDecimal_Valid() throws Exception {
        assertEquals(new BigDecimal("123.456"), NumberUtils.createBigDecimal("123.456"));
    }

    @Test
    public void testCreateBigDecimal_Null() throws Exception {
        assertNull(NumberUtils.createBigDecimal(null));
    }

    @Test
    public void testCreateBigDecimal_BlankString() throws Exception {
        try {
            NumberUtils.createBigDecimal("");
            fail("Expected NumberFormatException");
        } catch (NumberFormatException e) {
            // Expected
        }
    }

    @Test
    public void testCreateBigDecimal_Invalid() {
        try {
            NumberUtils.createBigDecimal("abc");
            fail("Expected NumberFormatException");
        } catch (NumberFormatException e) {
            // Expected
        }
    }
}
