package org.apache.commons.lang3.math;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;

public class NumberUtilsGeneratedTest {

@Test
public void testDecimalPrecisionEightDigitsReturnsDouble() {
    String val = "0.12345678";
    Number result = NumberUtils.createNumber(val);
    assertTrue("Expected Double for 8 decimal digits, but got: " + (result == null ? "null" : result.getClass().getName()),
               result instanceof Double);
    assertEquals(Double.parseDouble(val), result.doubleValue(), 0.0);
}

@Test
public void testFloatPrecisionLimitCrossedReturnsDouble() {
    String val = "0.98765432";
    Number result = NumberUtils.createNumber(val);
    assertTrue("Expected Double when float precision is exceeded, but got: " + (result == null ? "null" : result.getClass().getName()),
               result instanceof Double);
    assertEquals(Double.parseDouble(val), result.doubleValue(), 0.0);
}

@Test
public void testDoubleBoundarySixteenDigitsReturnsDouble() {
    String val = "0.1234567890123456";
    Number result = NumberUtils.createNumber(val);
    assertTrue("Expected Double for 16 decimal digits, but got: " + (result == null ? "null" : result.getClass().getName()),
               result instanceof Double);
    assertEquals(Double.parseDouble(val), result.doubleValue(), 0.0);
}

@Test
public void testBigDecimalFallbackSeventeenDigitsReturnsBigDecimal() {
    String val = "0.12345678901234567";
    Number result = NumberUtils.createNumber(val);
    assertTrue("Expected BigDecimal for 17 decimal digits, but got: " + (result == null ? "null" : result.getClass().getName()),
               result instanceof BigDecimal);
    assertEquals(new BigDecimal(val), result);
}

@Test
public void testDecimalPrecisionNineDigitsReturnsDouble() {
    String val = "1.987654321";
    Number result = NumberUtils.createNumber(val);
    assertTrue("Expected Double for 9 decimal digits, but got: " + (result == null ? "null" : result.getClass().getName()),
               result instanceof Double);
    assertEquals(Double.parseDouble(val), result.doubleValue(), 0.0);
}

@Test
public void testPrecisionSensitiveValuePreservedAsDouble() {
    String val = "2.71828182";
    Number result = NumberUtils.createNumber(val);
    assertTrue("Expected Double for precision-sensitive value with 8 decimal digits, but got: " + (result == null ? "null" : result.getClass().getName()),
               result instanceof Double);
    assertEquals(Double.parseDouble(val), result.doubleValue(), 0.0);
}

}
