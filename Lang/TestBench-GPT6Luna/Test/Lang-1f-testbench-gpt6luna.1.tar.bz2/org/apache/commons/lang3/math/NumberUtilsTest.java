package org.apache.commons.lang3.math;

import org.junit.Test;
import static org.junit.Assert.*;
import java.lang.reflect.Array;
import java.math.BigDecimal;
import java.math.BigInteger;
import org.apache.commons.lang3.StringUtils;

public class NumberUtilsTest {
    @Test
    public void testToIntNullAndInvalidDefaults() throws Exception {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(0, NumberUtils.toInt(""));
    }

    @Test
    public void testToIntRangeEdges() throws Exception {
        assertEquals(Integer.MAX_VALUE, NumberUtils.toInt("2147483647"));
        assertEquals(7, NumberUtils.toInt("2147483648", 7));
        assertEquals(Integer.MIN_VALUE, NumberUtils.toInt("-2147483648"));
        assertEquals(7, NumberUtils.toInt("-2147483649", 7));
    }

    @Test
    public void testToLongNullAndInvalidDefaults() throws Exception {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(9L, NumberUtils.toLong("", 9L));
    }

    @Test
    public void testToLongRangeEdges() throws Exception {
        assertEquals(Long.MAX_VALUE, NumberUtils.toLong("9223372036854775807"));
        assertEquals(9L, NumberUtils.toLong("9223372036854775808", 9L));
        assertEquals(Long.MIN_VALUE, NumberUtils.toLong("-9223372036854775808"));
        assertEquals(9L, NumberUtils.toLong("-9223372036854775809", 9L));
    }

    @Test
    public void testToFloatDefaultAndValue() throws Exception {
        assertEquals(2.5f, NumberUtils.toFloat(null, 2.5f), 0.0f);
        assertEquals(1.5f, NumberUtils.toFloat("1.5"), 0.0f);
        assertEquals(2.5f, NumberUtils.toFloat("bad", 2.5f), 0.0f);
    }

    @Test
    public void testToDoubleDefaultAndValue() throws Exception {
        assertEquals(3.25, NumberUtils.toDouble(null, 3.25), 0.0);
        assertEquals(1.5, NumberUtils.toDouble("1.5"), 0.0);
        assertEquals(3.25, NumberUtils.toDouble("bad", 3.25), 0.0);
    }

    @Test
    public void testToByteRangeEdges() throws Exception {
        assertEquals((byte) 127, NumberUtils.toByte("127"));
        assertEquals((byte) 4, NumberUtils.toByte("128", (byte) 4));
        assertEquals((byte) -128, NumberUtils.toByte("-128"));
        assertEquals((byte) 4, NumberUtils.toByte("-129", (byte) 4));
    }

    @Test
    public void testToShortRangeEdges() throws Exception {
        assertEquals((short) 32767, NumberUtils.toShort("32767"));
        assertEquals((short) 4, NumberUtils.toShort("32768", (short) 4));
        assertEquals((short) -32768, NumberUtils.toShort("-32768"));
        assertEquals((short) 4, NumberUtils.toShort("-32769", (short) 4));
    }

    @Test
    public void testCreateNumberNullBlankAndDecimal() throws Exception {
        assertNull(NumberUtils.createNumber(null));
        try {
            NumberUtils.createNumber(" ");
            fail("expected NumberFormatException");
        } catch (NumberFormatException expected) { }
        assertEquals(Float.valueOf(1.25f), NumberUtils.createNumber("1.25"));
    }

    @Test
    public void testCreateNumberIntegerAndLongEdges() throws Exception {
        assertEquals(Integer.valueOf(Integer.MAX_VALUE), NumberUtils.createNumber("2147483647"));
        assertEquals(Long.valueOf(2147483648L), NumberUtils.createNumber("2147483648"));
        assertEquals(Long.valueOf(Long.MAX_VALUE), NumberUtils.createNumber("9223372036854775807"));
        assertEquals(new BigInteger("9223372036854775808"),
                NumberUtils.createNumber("9223372036854775808"));
    }

    @Test
    public void testCreateNumberRadixForms() throws Exception {
        assertEquals(Integer.valueOf(63), NumberUtils.createNumber("077"));
        assertEquals(Integer.valueOf(255), NumberUtils.createNumber("0xFF"));
        assertEquals(Integer.valueOf(-16), NumberUtils.createNumber("-#10"));
    }

    @Test
    public void testCreateNumberSuffixAndPrecision() throws Exception {
        assertEquals(Long.valueOf(12L), NumberUtils.createNumber("12L"));
        assertEquals(Float.valueOf(1.5f), NumberUtils.createNumber("1.5F"));
        assertEquals(new BigDecimal("1.12345678901234567"),
                NumberUtils.createNumber("1.12345678901234567"));
    }

    @Test
    public void testCreateFloatNullAndParse() throws Exception {
        assertNull(NumberUtils.createFloat(null));
        assertEquals(Float.valueOf(1.25f), NumberUtils.createFloat("1.25"));
    }

    @Test
    public void testCreateDoubleNullAndParse() throws Exception {
        assertNull(NumberUtils.createDouble(null));
        assertEquals(Double.valueOf(1.25), NumberUtils.createDouble("1.25"));
    }

    @Test
    public void testCreateIntegerDecodeEdges() throws Exception {
        assertNull(NumberUtils.createInteger(null));
        assertEquals(Integer.valueOf(127), NumberUtils.createInteger("0177"));
        assertEquals(Integer.valueOf(255), NumberUtils.createInteger("0xFF"));
        try {
            NumberUtils.createInteger("2147483648");
            fail("expected NumberFormatException");
        } catch (NumberFormatException expected) { }
    }

    @Test
    public void testCreateLongDecodeEdges() throws Exception {
        assertNull(NumberUtils.createLong(null));
        assertEquals(Long.valueOf(Long.MAX_VALUE), NumberUtils.createLong("9223372036854775807"));
        try {
            NumberUtils.createLong("9223372036854775808");
            fail("expected NumberFormatException");
        } catch (NumberFormatException expected) { }
    }

    @Test
    public void testCreateBigIntegerRadixAndSign() throws Exception {
        assertNull(NumberUtils.createBigInteger(null));
        assertEquals(new BigInteger("255"), NumberUtils.createBigInteger("0xFF"));
        assertEquals(new BigInteger("-255"), NumberUtils.createBigInteger("-#FF"));
        assertEquals(new BigInteger("63"), NumberUtils.createBigInteger("077"));
    }

    @Test
    public void testCreateBigDecimalNullBlankAndValue() throws Exception {
        assertNull(NumberUtils.createBigDecimal(null));
        try {
            NumberUtils.createBigDecimal("");
            fail("expected NumberFormatException");
        } catch (NumberFormatException expected) { }
        assertEquals(new BigDecimal("1.20"), NumberUtils.createBigDecimal("1.20"));
    }

    @Test
    public void testMinLongArray() throws Exception {
        assertEquals(-8L, NumberUtils.min(new long[] {3L, -8L, 2L}));
        assertEquals(Long.MIN_VALUE, NumberUtils.min(new long[] {0L, Long.MIN_VALUE}));
    }

    @Test
    public void testMaxLongArray() throws Exception {
        assertEquals(9L, NumberUtils.max(new long[] {-1L, 9L, 2L}));
        assertEquals(Long.MAX_VALUE, NumberUtils.max(new long[] {Long.MAX_VALUE, 0L}));
    }

    @Test
    public void testMinLongArrayRejectsNullAndEmpty() throws Exception {
        try {
            NumberUtils.min((long[]) null);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) { }
        try {
            NumberUtils.min(new long[0]);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) { }
    }

    @Test
    public void testMaxLongArrayRejectsNullAndEmpty() throws Exception {
        try {
            NumberUtils.max((long[]) null);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) { }
        try {
            NumberUtils.max(new long[0]);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) { }
    }

    @Test
    public void testIsDigitsForms() throws Exception {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
        assertTrue(NumberUtils.isDigits("123"));
        assertFalse(NumberUtils.isDigits("-1"));
    }

    @Test
    public void testIsNumberForms() throws Exception {
        assertFalse(NumberUtils.isNumber(null));
        assertFalse(NumberUtils.isNumber(""));
        assertTrue(NumberUtils.isNumber("0xFF"));
        assertTrue(NumberUtils.isNumber("1.2E-3"));
        assertTrue(NumberUtils.isNumber("12L"));
        assertFalse(NumberUtils.isNumber("1E"));
        assertFalse(NumberUtils.isNumber("1..2"));
    }
}
