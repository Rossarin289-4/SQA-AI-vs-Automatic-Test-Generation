package org.apache.commons.lang.time;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.FieldPosition;
import java.text.Format;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import org.apache.commons.lang.Validate;

public class FastDateFormatTest {
    @Test
    public void testFormatObjectDateAndExistingBuffer() throws Exception {
        FastDateFormat f = FastDateFormat.getInstance("yyyy-MM-dd", TimeZone.getTimeZone("UTC"), Locale.US);
        StringBuffer b = new StringBuffer("x");
        StringBuffer result = f.format(new Date(0L), b, new FieldPosition(0));
        assertSame(b, result);
        assertEquals("x1970-01-01", b.toString());
    }

    @Test
    public void testFormatObjectLong() throws Exception {
        FastDateFormat f = FastDateFormat.getInstance("yyyy-MM-dd", TimeZone.getTimeZone("UTC"), Locale.US);
        assertEquals("1970-01-01", f.format(Long.valueOf(0L), new StringBuffer(), new FieldPosition(0)).toString());
    }

    @Test
    public void testFormatObjectCalendarUsesItsZoneWhenNotForced() throws Exception {
        FastDateFormat f = FastDateFormat.getInstance("HH:mm", Locale.US);
        Calendar c = new GregorianCalendar(TimeZone.getTimeZone("GMT+02:00"));
        c.setTimeInMillis(0L);
        assertEquals("02:00", f.format(c, new StringBuffer()).toString());
    }

    @Test
    public void testFormatObjectRejectsUnknownInput() throws Exception {
        FastDateFormat f = FastDateFormat.getInstance("yyyy", Locale.US);
        try {
            f.format("x", new StringBuffer(), new FieldPosition(0));
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            assertEquals("FastDateFormat[yyyy]", f.toString());
        }
    }

    @Test
    public void testParseObjectReturnsNullAndResetsPosition() throws Exception {
        FastDateFormat f = FastDateFormat.getInstance("yyyy", Locale.US);
        ParsePosition p = new ParsePosition(4);
        p.setErrorIndex(6);
        assertNull(f.parseObject("1970", p));
        assertEquals(0, p.getIndex());
        assertEquals(0, p.getErrorIndex());
    }

    @Test
    public void testParseObjectEmptySourceAlsoResetsPosition() throws Exception {
        FastDateFormat f = FastDateFormat.getInstance("yyyy", Locale.US);
        ParsePosition p = new ParsePosition(2);
        assertNull(f.parseObject("", p));
        assertEquals(0, p.getIndex());
        assertEquals(0, p.getErrorIndex());
    }

    @Test
    public void testPatternGetterAndToString() throws Exception {
        FastDateFormat f = FastDateFormat.getInstance("yyyy", Locale.US);
        assertEquals("yyyy", f.getPattern());
        assertEquals("FastDateFormat[yyyy]", f.toString());
    }

    @Test
    public void testForcedTimeZoneAccessors() throws Exception {
        TimeZone zone = TimeZone.getTimeZone("UTC");
        FastDateFormat f = FastDateFormat.getInstance("HH", zone, Locale.US);
        assertEquals(zone, f.getTimeZone());
        assertTrue(f.getTimeZoneOverridesCalendar());
        assertEquals(Locale.US, f.getLocale());
    }

    @Test
    public void testUnforcedZoneFlagAndSpecifiedLocale() throws Exception {
        FastDateFormat f = FastDateFormat.getInstance("HH", Locale.US);
        assertFalse(f.getTimeZoneOverridesCalendar());
        assertEquals(Locale.US, f.getLocale());
    }

    @Test
    public void testCalendarFormattingForcedZoneDoesNotMutateCalendar() throws Exception {
        FastDateFormat f = FastDateFormat.getInstance("HH:mm", TimeZone.getTimeZone("UTC"), Locale.US);
        Calendar c = new GregorianCalendar(TimeZone.getTimeZone("GMT+02:00"));
        c.setTimeInMillis(0L);
        assertEquals("00:00", f.format(c));
        assertEquals(2 * 60 * 60 * 1000, c.getTimeZone().getRawOffset());
    }

    @Test
    public void testDateFormattingAndMaximumLengthEstimate() throws Exception {
        FastDateFormat f = FastDateFormat.getInstance("yyyy-MM-dd", TimeZone.getTimeZone("UTC"), Locale.US);
        assertEquals("1970-01-01", f.format(0L));
        assertEquals(10, f.getMaxLengthEstimate());
    }

    @Test
    public void testEqualityAndHashCodeForSameConfiguration() throws Exception {
        FastDateFormat a = FastDateFormat.getInstance("yyyy", TimeZone.getTimeZone("UTC"), Locale.US);
        FastDateFormat b = FastDateFormat.getInstance("yyyy", TimeZone.getTimeZone("UTC"), Locale.US);
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    public void testEqualityDistinguishesPatternsAndNonFormatter() throws Exception {
        FastDateFormat a = FastDateFormat.getInstance("yyyy", Locale.US);
        FastDateFormat b = FastDateFormat.getInstance("yy", Locale.US);
        assertFalse(a.equals(b));
        assertFalse(a.equals("yyyy"));
    }

    @Test
    public void testNumberWidthsAndMonthBoundaryValues() throws Exception {
        FastDateFormat f = FastDateFormat.getInstance("M MM dd D", TimeZone.getTimeZone("UTC"), Locale.US);
        Calendar c = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
        c.clear();
        c.set(2020, Calendar.JANUARY, 1);
        assertEquals("1 01 01 1", f.format(c));
        c.set(2020, Calendar.DECEMBER, 31);
        assertEquals("12 12 31 366", f.format(c));
    }

    @Test
    public void testQuotedAndEscapedLiterals() throws Exception {
        FastDateFormat f = FastDateFormat.getInstance("'day' '' yyyy", TimeZone.getTimeZone("UTC"), Locale.US);
        assertEquals("day ' 1970", f.format(0L));
    }

    @Test
    public void testTwentyFourAndTwelveHourMidnightEdges() throws Exception {
        FastDateFormat f = FastDateFormat.getInstance("k h H K", TimeZone.getTimeZone("UTC"), Locale.US);
        Calendar c = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
        c.clear();
        c.set(2020, Calendar.JANUARY, 1, 0, 0, 0);
        assertEquals("24 12 0 0", f.format(c));
        c.set(Calendar.HOUR_OF_DAY, 23);
        assertEquals("23 11 23 11", f.format(c));
    }

    @Test
    public void testTimeZoneNumericOffsetForms() throws Exception {
        FastDateFormat f = FastDateFormat.getInstance("Z ZZ", TimeZone.getTimeZone("GMT+05:30"), Locale.US);
        assertEquals("+0530 +05:30", f.format(0L));
    }

    @Test
    public void testTimeZoneNumericNegativeOffset() throws Exception {
        FastDateFormat f = FastDateFormat.getInstance("Z ZZ", TimeZone.getTimeZone("GMT-08:00"), Locale.US);
        assertEquals("-0800 -08:00", f.format(0L));
    }

    @Test
    public void testStyleFactoryMethodsReturnConfiguredFormats() throws Exception {
        FastDateFormat date = FastDateFormat.getDateInstance(FastDateFormat.SHORT, Locale.US);
        FastDateFormat time = FastDateFormat.getTimeInstance(FastDateFormat.SHORT, Locale.US);
        FastDateFormat dateTime = FastDateFormat.getDateTimeInstance(FastDateFormat.SHORT, FastDateFormat.SHORT, Locale.US);
        assertNotNull(date.getPattern());
        assertNotNull(time.getPattern());
        assertNotNull(dateTime.getPattern());
        assertEquals(date.getPattern(), FastDateFormat.getDateInstance(FastDateFormat.SHORT, Locale.US).getPattern());
    }

    @Test
    public void testDefaultFactoryProducesUsableFormatter() throws Exception {
        FastDateFormat f = FastDateFormat.getInstance();
        assertNotNull(f.getPattern());
        assertEquals(f.getPattern(), f.getPattern());
    }
}
