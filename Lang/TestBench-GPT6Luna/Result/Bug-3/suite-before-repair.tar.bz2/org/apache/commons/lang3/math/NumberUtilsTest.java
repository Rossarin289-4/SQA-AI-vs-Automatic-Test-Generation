package org.apache.commons.lang3.math;

import org.junit.Test;
import static org.junit.Assert.*;
import java.lang.reflect.Array;
import java.math.BigDecimal;
import java.math.BigInteger;
import org.apache.commons.lang3.StringUtils;

public class NumberUtilsTest {
    @Test
    public void testToIntFallbackAndBounds() throws Exception {
        assertEquals(0, NumberUtils.toInt(null));
        assertEquals(23, NumberUtils.toInt("", 23));
        assertEquals(Integer.MAX_VALUE, NumberUtils.toInt("2147483647", 23));
        assertEquals(23, NumberUtils.toInt("2147483648", 23));
    }

    @Test
    public void testToLongFallbackAndBounds() throws Exception {
        assertEquals(0L, NumberUtils.toLong(null));
        assertEquals(23L, NumberUtils.toLong("", 23L));
        assertEquals(Long.MAX_VALUE, NumberUtils.toLong("9223372036854775807", 23L));
        assertEquals(23L, NumberUtils.toLong("9223372036854775808", 23L));
    }

    @Test
    public void testToFloatFallbackAndParsing() throws Exception {
        assertEquals(4.25f, NumberUtils.toFloat("4.25"), 0.0f);
        assertEquals(2.5f, NumberUtils.toFloat(null, 2.5f), 0.0f);
        assertEquals(2.5f, NumberUtils.toFloat("bad", 2.5f), 0.0f);
    }

    @Test
    public void testToDoubleFallbackAndParsing() throws Exception {
        assertEquals(4.25d, NumberUtils.toDouble("4.25"), 0.0d);
        assertEquals(2.5d, NumberUtils.toDouble(null, 2.5d), 0.0d);
        assertEquals(2.5d, NumberUtils.toDouble("bad", 2.5d), 0.0d);
    }

    @Test
    public void testToByteBoundsAndFallback() throws Exception {
        assertEquals((byte) 127, NumberUtils.toByte("127"));
        assertEquals((byte) 9, NumberUtils.toByte("128", (byte) 9));
        assertEquals((byte) -128, NumberUtils.toByte("-128"));
        assertEquals((byte) 9, NumberUtils.toByte(null, (byte) 9));
    }

    @Test
    public void testToShortBoundsAndFallback() throws Exception {
        assertEquals((short) 32767, NumberUtils.toShort("32767"));
        assertEquals((short) 9, NumberUtils.toShort("32768", (short) 9));
        assertEquals((short) -32768, NumberUtils.toShort("-32768"));
        assertEquals((short) 9, NumberUtils.toShort(null, (short) 9));
    }

    @Test
    public void testCreateNumberIntegerLongAndBigIntegerRanges() throws Exception {
        assertEquals(Integer.valueOf(Integer.MAX_VALUE), NumberUtils.createNumber("2147483647"));
        assertEquals(Long.valueOf(2147483648L), NumberUtils.createNumber("2147483648"));
        assertEquals(Long.valueOf(Long.MAX_VALUE), NumberUtils.createNumber("9223372036854775807"));
        assertEquals(new BigInteger("9223372036854775808"), NumberUtils.createNumber("9223372036854775808"));
    }

    @Test
    public void testCreateNumberHexAndOctal() throws Exception {
        assertEquals(Integer.valueOf(255), NumberUtils.createNumber("0xFF"));
        assertEquals(Long.valueOf(2147483647L), NumberUtils.createNumber("0x7FFFFFFF"));
        assertEquals(Integer.valueOf(63), NumberUtils.createNumber("077"));
        assertEquals(Integer.valueOf(-255), NumberUtils.createNumber("-#FF"));
    }

    @Test
    public void testCreateNumberDecimalAndExponent() throws Exception {
        assertEquals(Float.valueOf(1.5f), NumberUtils.createNumber("1.5"));
        assertEquals(Double.valueOf(1.12345678d), NumberUtils.createNumber("1.12345678"));
        assertEquals(new BigDecimal("1.12345678901234567"),
                NumberUtils.createNumber("1.12345678901234567"));
        assertEquals(Float.valueOf(120.0f), NumberUtils.createNumber("1.2E2"));
    }

    @Test
    public void testCreateNumberInvalidAndNullInputs() throws Exception {
        assertNull(NumberUtils.createNumber(null));
        try {
            NumberUtils.createNumber(" ");
            fail("expected NumberFormatException");
        } catch (NumberFormatException expected) { }
        try {
            NumberUtils.createNumber("1 ");
            fail("expected NumberFormatException");
        } catch (NumberFormatException expected) { }
    }

    @Test
    public void testCreateFloatNullAndValue() throws Exception {
        assertNull(NumberUtils.createFloat(null));
        assertEquals(Float.valueOf(1.25f), NumberUtils.createFloat("1.25"));
    }

    @Test
    public void testCreateDoubleNullAndValue() throws Exception {
        assertNull(NumberUtils.createDouble(null));
        assertEquals(Double.valueOf(-2.5d), NumberUtils.createDouble("-2.5"));
    }

    @Test
    public void testCreateIntegerRadicesAndNull() throws Exception {
        assertNull(NumberUtils.createInteger(null));
        assertEquals(Integer.valueOf(255), NumberUtils.createInteger("0xFF"));
        assertEquals(Integer.valueOf(63), NumberUtils.createInteger("077"));
    }

    @Test
    public void testCreateLongRadicesAndNull() throws Exception {
        assertNull(NumberUtils.createLong(null));
        assertEquals(Long.valueOf(255L), NumberUtils.createLong("#FF"));
        assertEquals(Long.valueOf(-63L), NumberUtils.createLong("-077"));
    }

    @Test
    public void testCreateBigIntegerPrefixesAndNull() throws Exception {
        assertNull(NumberUtils.createBigInteger(null));
        assertEquals(new BigInteger("255"), NumberUtils.createBigInteger("0xFF"));
        assertEquals(new BigInteger("-63"), NumberUtils.createBigInteger("-077"));
    }

    @Test
    public void testCreateBigDecimalNullAndValue() throws Exception {
        assertNull(NumberUtils.createBigDecimal(null));
        assertEquals(new BigDecimal("1.25"), NumberUtils.createBigDecimal("1.25"));
        try {
            NumberUtils.createBigDecimal("--1");
            fail("expected NumberFormatException");
        } catch (NumberFormatException expected) { }
    }

    @Test
    public void testLongArrayMinMax() throws Exception {
        long[] values = { Long.MAX_VALUE, 0L, Long.MIN_VALUE };
        assertEquals(Long.MIN_VALUE, NumberUtils.min(values));
        assertEquals(Long.MAX_VALUE, NumberUtils.max(values));
    }

    @Test
    public void testLongArrayMinMaxSingleElementAndValidation() throws Exception {
        assertEquals(4L, NumberUtils.min(new long[] { 4L }));
        assertEquals(4L, NumberUtils.max(new long[] { 4L }));
        try {
            NumberUtils.min((long[]) null);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) { }
        try {
            NumberUtils.max(new long[0]);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) { }
    }

    @Test
    public void testIsDigitsForms() throws Exception {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
        assertTrue(NumberUtils.isDigits("0123"));
        assertFalse(NumberUtils.isDigits("12a"));
    }

    @Test
    public void testIsNumberIntegerHexAndQualifierForms() throws Exception {
        assertFalse(NumberUtils.isNumber(null));
        assertFalse(NumberUtils.isNumber(""));
        assertTrue(NumberUtils.isNumber("-12"));
        assertTrue(NumberUtils.isNumber("0xFF"));
        assertFalse(NumberUtils.isNumber("0x"));
        assertTrue(NumberUtils.isNumber("12L"));
        assertFalse(NumberUtils.isNumber("12.0L"));
    }

    @Test
    public void testIsNumberDecimalAndExponentBranches() throws Exception {
        assertTrue(NumberUtils.isNumber("1."));
        assertTrue(NumberUtils.isNumber(".5"));
        assertTrue(NumberUtils.isNumber("1.2E-3"));
        assertFalse(NumberUtils.isNumber("1E"));
        assertFalse(NumberUtils.isNumber("1E--2"));
        assertFalse(NumberUtils.isNumber("1.2.3"));
    }
}
