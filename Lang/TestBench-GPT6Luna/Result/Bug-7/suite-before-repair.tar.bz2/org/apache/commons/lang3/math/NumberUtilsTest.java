package org.apache.commons.lang3.math;

import org.junit.Test;
import static org.junit.Assert.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import org.apache.commons.lang3.StringUtils;

public class NumberUtilsTest {
    @Test
    public void testToIntFallbackAndBounds() throws Exception {
        assertEquals(23, NumberUtils.toInt(null, 23));
        assertEquals(23, NumberUtils.toInt("2147483648", 23));
        assertEquals(Integer.MIN_VALUE, NumberUtils.toInt("-2147483648"));
        assertEquals(Integer.MAX_VALUE, NumberUtils.toInt("2147483647"));
    }

    @Test
    public void testToLongFallbackAndBounds() throws Exception {
        assertEquals(23L, NumberUtils.toLong("", 23L));
        assertEquals(23L, NumberUtils.toLong("9223372036854775808", 23L));
        assertEquals(Long.MIN_VALUE, NumberUtils.toLong("-9223372036854775808"));
        assertEquals(Long.MAX_VALUE, NumberUtils.toLong("9223372036854775807"));
    }

    @Test
    public void testToFloat() throws Exception {
        assertEquals(0.0f, NumberUtils.toFloat(null), 0.0f);
        assertEquals(7.25f, NumberUtils.toFloat("7.25", 3.0f), 0.0f);
        assertEquals(3.0f, NumberUtils.toFloat("bad", 3.0f), 0.0f);
    }

    @Test
    public void testToDouble() throws Exception {
        assertEquals(0.0d, NumberUtils.toDouble(null), 0.0d);
        assertEquals(7.25d, NumberUtils.toDouble("7.25", 3.0d), 0.0d);
        assertEquals(3.0d, NumberUtils.toDouble("bad", 3.0d), 0.0d);
    }

    @Test
    public void testToByteAtBounds() throws Exception {
        assertEquals(Byte.MIN_VALUE, NumberUtils.toByte("-128"));
        assertEquals(Byte.MAX_VALUE, NumberUtils.toByte("127"));
        assertEquals((byte) 9, NumberUtils.toByte("128", (byte) 9));
        assertEquals((byte) 9, NumberUtils.toByte("-129", (byte) 9));
    }

    @Test
    public void testToShortAtBounds() throws Exception {
        assertEquals(Short.MIN_VALUE, NumberUtils.toShort("-32768"));
        assertEquals(Short.MAX_VALUE, NumberUtils.toShort("32767"));
        assertEquals((short) 9, NumberUtils.toShort("32768", (short) 9));
        assertEquals((short) 9, NumberUtils.toShort("-32769", (short) 9));
    }

    @Test
    public void testCreateNumberIntegerAndHexBoundaries() throws Exception {
        assertEquals(Integer.valueOf(Integer.MAX_VALUE), NumberUtils.createNumber("2147483647"));
        assertEquals(Long.valueOf(2147483648L), NumberUtils.createNumber("2147483648"));
        assertEquals(Integer.valueOf(Integer.MAX_VALUE), NumberUtils.createNumber("0x7FFFFFFF"));
        try {
            NumberUtils.createNumber("0x80000000");
            fail("expected NumberFormatException");
        } catch (NumberFormatException expected) { }
    }

    @Test
    public void testCreateNumberDecimalAndExponent() throws Exception {
        assertEquals(Float.valueOf(1.25f), NumberUtils.createNumber("1.25"));
        assertEquals(Float.valueOf(1.5f), NumberUtils.createNumber("1.5F"));
        assertEquals(Double.valueOf(1.5d), NumberUtils.createNumber("1.5D"));
        assertEquals(Float.valueOf(100.0f), NumberUtils.createNumber("1E2"));
    }

    @Test
    public void testCreateNumberNullBlankAndWhitespace() throws Exception {
        assertNull(NumberUtils.createNumber(null));
        try {
            NumberUtils.createNumber("");
            fail("expected NumberFormatException");
        } catch (NumberFormatException expected) { }
        try {
            NumberUtils.createNumber(" ");
            fail("expected NumberFormatException");
        } catch (NumberFormatException expected) { }
    }

    @Test
    public void testCreateFloatAndDouble() throws Exception {
        assertNull(NumberUtils.createFloat(null));
        assertEquals(Float.valueOf(1.25f), NumberUtils.createFloat("1.25"));
        assertNull(NumberUtils.createDouble(null));
        assertEquals(Double.valueOf(1.25d), NumberUtils.createDouble("1.25"));
    }

    @Test
    public void testCreateIntegerDecodeFormats() throws Exception {
        assertNull(NumberUtils.createInteger(null));
        assertEquals(Integer.valueOf(16), NumberUtils.createInteger("0x10"));
        assertEquals(Integer.valueOf(8), NumberUtils.createInteger("010"));
        assertEquals(Integer.valueOf(-10), NumberUtils.createInteger("-10"));
    }

    @Test
    public void testCreateLongDecodeFormats() throws Exception {
        assertNull(NumberUtils.createLong(null));
        assertEquals(Long.valueOf(16L), NumberUtils.createLong("0x10"));
        assertEquals(Long.valueOf(8L), NumberUtils.createLong("010"));
        assertEquals(Long.valueOf(Long.MAX_VALUE), NumberUtils.createLong("9223372036854775807"));
    }

    @Test
    public void testCreateBigInteger() throws Exception {
        assertNull(NumberUtils.createBigInteger(null));
        assertEquals(new BigInteger("12345678901234567890"),
                NumberUtils.createBigInteger("12345678901234567890"));
        assertEquals(new BigInteger("-42"), NumberUtils.createBigInteger("-42"));
    }

    @Test
    public void testCreateBigDecimalValidation() throws Exception {
        assertNull(NumberUtils.createBigDecimal(null));
        assertEquals(new BigDecimal("1.25"), NumberUtils.createBigDecimal("1.25"));
        try {
            NumberUtils.createBigDecimal("--1");
            fail("expected NumberFormatException");
        } catch (NumberFormatException expected) { }
    }

    @Test
    public void testMinAndMaxLongArrays() throws Exception {
        assertEquals(-9L, NumberUtils.min(new long[] { 4L, -9L, 2L }));
        assertEquals(4L, NumberUtils.max(new long[] { 4L, -9L, 2L }));
        assertEquals(Long.MIN_VALUE, NumberUtils.min(new long[] { Long.MAX_VALUE, Long.MIN_VALUE }));
        assertEquals(Long.MAX_VALUE, NumberUtils.max(new long[] { Long.MIN_VALUE, Long.MAX_VALUE }));
    }

    @Test
    public void testLongArrayNullAndEmptyValidation() throws Exception {
        try {
            NumberUtils.min((long[]) null);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) { }
        try {
            NumberUtils.max(new long[0]);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) { }
    }

    @Test
    public void testIsDigitsBoundaries() throws Exception {
        assertFalse(NumberUtils.isDigits(null));
        assertFalse(NumberUtils.isDigits(""));
        assertTrue(NumberUtils.isDigits("123"));
        assertFalse(NumberUtils.isDigits("12a"));
    }

    @Test
    public void testIsNumberSyntaxBranches() throws Exception {
        assertFalse(NumberUtils.isNumber(null));
        assertFalse(NumberUtils.isNumber(""));
        assertTrue(NumberUtils.isNumber("0xAf"));
        assertTrue(NumberUtils.isNumber("-12.5E+2"));
        assertTrue(NumberUtils.isNumber("12L"));
        assertFalse(NumberUtils.isNumber("1E"));
        assertFalse(NumberUtils.isNumber("1.2.3"));
        assertFalse(NumberUtils.isNumber("0x"));
    }
}
