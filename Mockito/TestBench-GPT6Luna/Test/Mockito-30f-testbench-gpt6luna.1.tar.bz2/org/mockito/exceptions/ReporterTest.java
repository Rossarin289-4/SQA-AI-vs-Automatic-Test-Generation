package org.mockito.exceptions;

import org.junit.Test;
import static org.junit.Assert.*;
import org.mockito.internal.stubbing.defaultanswers.ReturnsSmartNulls;
import java.util.List;
import org.mockito.exceptions.base.MockitoAssertionError;
import org.mockito.exceptions.base.MockitoException;
import org.mockito.exceptions.misusing.InvalidUseOfMatchersException;
import org.mockito.exceptions.misusing.MissingMethodInvocationException;
import org.mockito.exceptions.misusing.NotAMockException;
import org.mockito.exceptions.misusing.NullInsteadOfMockException;
import org.mockito.exceptions.misusing.UnfinishedStubbingException;
import org.mockito.exceptions.misusing.UnfinishedVerificationException;
import org.mockito.exceptions.misusing.WrongTypeOfReturnValue;
import org.mockito.exceptions.verification.ArgumentsAreDifferent;
import org.mockito.exceptions.verification.NeverWantedButInvoked;
import org.mockito.exceptions.verification.NoInteractionsWanted;
import org.mockito.exceptions.verification.SmartNullPointerException;
import org.mockito.exceptions.verification.TooLittleActualInvocations;
import org.mockito.exceptions.verification.TooManyActualInvocations;
import org.mockito.exceptions.verification.VerificationInOrderFailure;
import org.mockito.exceptions.verification.WantedButNotInvoked;
import org.mockito.exceptions.verification.junit.JUnitTool;
import org.mockito.internal.debugging.Location;
import org.mockito.internal.exceptions.VerificationAwareInvocation;
import org.mockito.internal.exceptions.util.ScenarioPrinter;
import org.mockito.internal.invocation.Invocation;
import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.Arrays;
import org.mockito.Mockito;
import org.mockito.cglib.proxy.MethodInterceptor;
import org.mockito.cglib.proxy.MethodProxy;
import org.mockito.exceptions.Reporter;
import org.mockito.internal.creation.jmock.ClassImposterizer;
import org.mockito.internal.util.ObjectMethodsGuru;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

public class ReporterTest {
    @Test
    public void checkedExceptionInvalidThrowsMockitoException() throws Exception {
        try {
            new Reporter().checkedExceptionInvalid(new Exception("checked"));
            fail("expected MockitoException");
        } catch (MockitoException expected) {
            assertTrue(expected.getMessage().contains("Checked exception is invalid"));
            assertTrue(expected.getMessage().contains("Invalid: java.lang.Exception: checked"));
        }
    }

    @Test
    public void cannotStubWithNullThrowableThrowsMockitoException() throws Exception {
        try {
            new Reporter().cannotStubWithNullThrowable();
            fail("expected MockitoException");
        } catch (MockitoException expected) {
            assertTrue(expected.getMessage().contains("Cannot stub with null throwable!"));
        }
    }

    @Test
    public void unfinishedStubbingThrowsItsSpecificException() throws Exception {
        try {
            new Reporter().unfinishedStubbing(new Location());
            fail("expected UnfinishedStubbingException");
        } catch (UnfinishedStubbingException expected) {
            assertTrue(expected.getMessage().contains("Unfinished stubbing detected here:"));
            assertTrue(expected.getMessage().contains("thenReturn() may be missing."));
        }
    }

    @Test
    public void missingMethodInvocationThrowsItsSpecificException() throws Exception {
        try {
            new Reporter().missingMethodInvocation();
            fail("expected MissingMethodInvocationException");
        } catch (MissingMethodInvocationException expected) {
            assertTrue(expected.getMessage().contains("when() requires an argument"));
        }
    }

    @Test
    public void unfinishedVerificationThrowsItsSpecificException() throws Exception {
        try {
            new Reporter().unfinishedVerificationException(new Location());
            fail("expected UnfinishedVerificationException");
        } catch (UnfinishedVerificationException expected) {
            assertTrue(expected.getMessage().contains("Missing method call for verify(mock) here:"));
        }
    }

    @Test
    public void notAMockVerifyReportsSimpleClassName() throws Exception {
        try {
            new Reporter().notAMockPassedToVerify(String.class);
            fail("expected NotAMockException");
        } catch (NotAMockException expected) {
            assertTrue(expected.getMessage().contains("type String"));
        }
    }

    @Test
    public void nullPassedToVerifyThrowsNullInsteadOfMock() throws Exception {
        try {
            new Reporter().nullPassedToVerify();
            fail("expected NullInsteadOfMockException");
        } catch (NullInsteadOfMockException expected) {
            assertTrue(expected.getMessage().contains("should be a mock but is null"));
        }
    }

    @Test
    public void notAMockWhenReportsMisuse() throws Exception {
        try {
            new Reporter().notAMockPassedToWhenMethod();
            fail("expected NotAMockException");
        } catch (NotAMockException expected) {
            assertTrue(expected.getMessage().contains("passed to when() is not a mock"));
        }
    }

    @Test
    public void nullWhenReportsMisuse() throws Exception {
        try {
            new Reporter().nullPassedToWhenMethod();
            fail("expected NullInsteadOfMockException");
        } catch (NullInsteadOfMockException expected) {
            assertTrue(expected.getMessage().contains("passed to when() is null"));
        }
    }

    @Test
    public void noMocksForVerifyNoMoreInteractionsThrowsMockitoException() throws Exception {
        try {
            new Reporter().mocksHaveToBePassedToVerifyNoMoreInteractions();
            fail("expected MockitoException");
        } catch (MockitoException expected) {
            assertTrue(expected.getMessage().contains("Method requires argument(s)!"));
        }
    }

    @Test
    public void notAMockForVerifyNoMoreInteractionsThrowsNotAMockException() throws Exception {
        try {
            new Reporter().notAMockPassedToVerifyNoMoreInteractions();
            fail("expected NotAMockException");
        } catch (NotAMockException expected) {
            assertTrue(expected.getMessage().contains("Argument(s) passed is not a mock"));
        }
    }

    @Test
    public void nullForVerifyNoMoreInteractionsThrowsNullInsteadOfMock() throws Exception {
        try {
            new Reporter().nullPassedToVerifyNoMoreInteractions();
            fail("expected NullInsteadOfMockException");
        } catch (NullInsteadOfMockException expected) {
            assertTrue(expected.getMessage().contains("Argument(s) passed is null"));
        }
    }

    @Test
    public void notAMockForInOrderThrowsNotAMockException() throws Exception {
        try {
            new Reporter().notAMockPassedWhenCreatingInOrder();
            fail("expected NotAMockException");
        } catch (NotAMockException expected) {
            assertTrue(expected.getMessage().contains("is not a mock"));
        }
    }

    @Test
    public void nullForInOrderThrowsNullInsteadOfMock() throws Exception {
        try {
            new Reporter().nullPassedWhenCreatingInOrder();
            fail("expected NullInsteadOfMockException");
        } catch (NullInsteadOfMockException expected) {
            assertTrue(expected.getMessage().contains("passed is null"));
        }
    }

    @Test
    public void noMocksForInOrderThrowsMockitoException() throws Exception {
        try {
            new Reporter().mocksHaveToBePassedWhenCreatingInOrder();
            fail("expected MockitoException");
        } catch (MockitoException expected) {
            assertTrue(expected.getMessage().contains("Method requires argument(s)!"));
        }
    }

    @Test
    public void inOrderRequiresFamiliarMockThrowsMockitoException() throws Exception {
        try {
            new Reporter().inOrderRequiresFamiliarMock();
            fail("expected MockitoException");
        } catch (MockitoException expected) {
            assertTrue(expected.getMessage().contains("only verify mocks that were passed in"));
        }
    }

    @Test
    public void invalidMatchersReportsBothCountsAtIntegerEdges() throws Exception {
        try {
            new Reporter().invalidUseOfMatchers(Integer.MAX_VALUE, Integer.MIN_VALUE);
            fail("expected InvalidUseOfMatchersException");
        } catch (InvalidUseOfMatchersException expected) {
            assertTrue(expected.getMessage().contains("2147483647 matchers expected, -2147483648 recorded."));
        }
    }

    @Test
    public void cannotMockFinalClassIncludesClassName() throws Exception {
        try {
            new Reporter().cannotMockFinalClass(String.class);
            fail("expected MockitoException");
        } catch (MockitoException expected) {
            assertTrue(expected.getMessage().contains("Cannot mock/spy class java.lang.String"));
        }
    }

    @Test
    public void cannotStubVoidMethodIncludesMethodName() throws Exception {
        try {
            new Reporter().cannotStubVoidMethodWithAReturnValue("save");
            fail("expected MockitoException");
        } catch (MockitoException expected) {
            assertTrue(expected.getMessage().contains("'save' is a *void method*"));
        }
    }

    @Test
    public void onlyVoidMethodsCanBeSetToDoNothingThrowsMockitoException() throws Exception {
        try {
            new Reporter().onlyVoidMethodsCanBeSetToDoNothing();
            fail("expected MockitoException");
        } catch (MockitoException expected) {
            assertTrue(expected.getMessage().contains("Only void methods can doNothing()!"));
        }
    }

    @Test
    public void wrongReturnTypeIncludesMethodAndBothTypes() throws Exception {
        try {
            new Reporter().wrongTypeOfReturnValue("Integer", "String", "count");
            fail("expected WrongTypeOfReturnValue");
        } catch (WrongTypeOfReturnValue expected) {
            assertTrue(expected.getMessage().contains("String cannot be returned by count()"));
            assertTrue(expected.getMessage().contains("count() should return Integer"));
        }
    }

    @Test
    public void wantedAtMostReportsBoundaryCounts() throws Exception {
        try {
            new Reporter().wantedAtMostX(0, 1);
            fail("expected MockitoAssertionError");
        } catch (MockitoAssertionError expected) {
            assertTrue(expected.getMessage().contains("Wanted at most 0"));
            assertTrue(expected.getMessage().contains("1"));
        }
    }

    @Test
    public void noArgumentValueCapturedThrowsMockitoException() throws Exception {
        try {
            new Reporter().noArgumentValueWasCaptured();
            fail("expected MockitoException");
        } catch (MockitoException expected) {
            assertTrue(expected.getMessage().contains("No argument value was captured!"));
        }
    }

    @Test
    public void extraInterfacesNullParametersThrowsMockitoException() throws Exception {
        try {
            new Reporter().extraInterfacesDoesNotAcceptNullParameters();
            fail("expected MockitoException");
        } catch (MockitoException expected) {
            assertTrue(expected.getMessage().contains("extraInterfaces() does not accept null parameters."));
        }
    }

    @Test
    public void extraInterfacesRejectsClassType() throws Exception {
        try {
            new Reporter().extraInterfacesAcceptsOnlyInterfaces(String.class);
            fail("expected MockitoException");
        } catch (MockitoException expected) {
            assertTrue(expected.getMessage().contains("String which is not an interface."));
        }
    }

    @Test
    public void extraInterfacesCannotRepeatMockedType() throws Exception {
        try {
            new Reporter().extraInterfacesCannotContainMockedType(List.class);
            fail("expected MockitoException");
        } catch (MockitoException expected) {
            assertTrue(expected.getMessage().contains("You mocked following type: List"));
            assertTrue(expected.getMessage().contains("same very interface"));
        }
    }

    @Test
    public void extraInterfacesRequiresAtLeastOneThrowsMockitoException() throws Exception {
        try {
            new Reporter().extraInterfacesRequiresAtLeastOneInterface();
            fail("expected MockitoException");
        } catch (MockitoException expected) {
            assertTrue(expected.getMessage().contains("requires at least one interface."));
        }
    }

    @Test
    public void cannotCallRealMethodOnInterfaceThrowsMockitoException() throws Exception {
        try {
            new Reporter().cannotCallRealMethodOnInterface();
            fail("expected MockitoException");
        } catch (MockitoException expected) {
            assertTrue(expected.getMessage().contains("Cannot call real method on java interface."));
        }
    }

    @Test
    public void cannotVerifyToStringThrowsMockitoException() throws Exception {
        try {
            new Reporter().cannotVerifyToString();
            fail("expected MockitoException");
        } catch (MockitoException expected) {
            assertTrue(expected.getMessage().contains("Mockito cannot verify toString()"));
        }
    }

    @Test
    public void misplacedMatcherReportsSpecificFailure() throws Exception {
        try {
            new Reporter().misplacedArgumentMatcher(new Location());
            fail("expected InvalidUseOfMatchersException");
        } catch (InvalidUseOfMatchersException expected) {
            assertTrue(expected.getMessage().contains("Misplaced argument matcher detected here:"));
        }
    }

    @Test
    public void inconsistentSpyTypesReportsBothTypes() throws Exception {
        try {
            new Reporter().mockedTypeIsInconsistentWithSpiedInstanceType(List.class, "x");
            fail("expected MockitoException");
        } catch (MockitoException expected) {
            assertTrue(expected.getMessage().contains("Mocked type must be: String, but is: List"));
        }
    }

    @Test
    public void multipleAnnotationsIncludesFieldName() throws Exception {
        try {
            new Reporter().moreThanOneAnnotationNotAllowed("field");
            fail("expected MockitoException");
        } catch (MockitoException expected) {
            assertTrue(expected.getMessage().contains("The field 'field' has multiple Mockito annotations."));
        }
    }

    @Test
    public void unsupportedAnnotationCombinationIncludesBothNames() throws Exception {
        try {
            new Reporter().unsupportedCombinationOfAnnotations("Mock", "Spy");
            fail("expected MockitoException");
        } catch (MockitoException expected) {
            assertTrue(expected.getMessage().contains("@Mock and @Spy"));
        }
    }

    @Test
    public void spyInitializationFailurePreservesCause() throws Exception {
        Exception cause = new Exception("failure");
        try {
            new Reporter().cannotInitializeForSpyAnnotation("item", cause);
            fail("expected MockitoException");
        } catch (MockitoException expected) {
            assertSame(cause, expected.getCause());
            assertTrue(expected.getMessage().contains("item"));
            assertTrue(expected.getMessage().contains("failure"));
        }
    }

    @Test
    public void injectMocksInitializationFailurePreservesCause() throws Exception {
        Exception cause = new Exception("failure");
        try {
            new Reporter().cannotInitializeForInjectMocksAnnotation("item", cause);
            fail("expected MockitoException");
        } catch (MockitoException expected) {
            assertSame(cause, expected.getCause());
            assertTrue(expected.getMessage().contains("item"));
            assertTrue(expected.getMessage().contains("failure"));
        }
    }
}
