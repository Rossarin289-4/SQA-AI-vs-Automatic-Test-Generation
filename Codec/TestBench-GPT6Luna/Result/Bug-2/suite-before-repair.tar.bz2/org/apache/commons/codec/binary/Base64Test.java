package org.apache.commons.codec.binary;

import org.junit.Test;
import static org.junit.Assert.*;
import org.apache.commons.codec.BinaryDecoder;
import org.apache.commons.codec.BinaryEncoder;
import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.EncoderException;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;

public class Base64Test {
    // test methods (as many as the instructions ask for), each exactly in this form:
    //     @Test
    //     public void testWhatItChecks() throws Exception { ... }

    @Test
    public void testUrlSafeConstructorMode() throws Exception {
        assertFalse(new Base64().isUrlSafe());
        assertTrue(new Base64(true).isUrlSafe());
    }

    @Test
    public void testBase64AlphabetBoundaries() throws Exception {
        assertFalse(Base64.isBase64((byte) 0));
        assertTrue(Base64.isBase64((byte) 'A'));
        assertTrue(Base64.isBase64((byte) 'z'));
        assertTrue(Base64.isBase64((byte) '+'));
        assertTrue(Base64.isBase64((byte) '/'));
        assertTrue(Base64.isBase64((byte) '='));
        assertFalse(Base64.isBase64((byte) '?'));
        assertFalse(Base64.isBase64((byte) -1));
    }

    @Test
    public void testArrayByteBase64WhitespaceAndEmpty() throws Exception {
        assertTrue(Base64.isArrayByteBase64(new byte[0]));
        assertTrue(Base64.isArrayByteBase64("A \r\n\t/=".getBytes("US-ASCII")));
        assertFalse(Base64.isArrayByteBase64("A?".getBytes("US-ASCII")));
    }

    @Test
    public void testStandardEncodingEmptyAndNull() throws Exception {
        assertNull(Base64.encodeBase64(null));
        assertArrayEquals(new byte[0], Base64.encodeBase64(new byte[0]));
    }

    @Test
    public void testStandardEncodingOneAndTwoBytes() throws Exception {
        assertArrayEquals("Zg==".getBytes("US-ASCII"),
                Base64.encodeBase64(new byte[] {'f'}));
        assertArrayEquals("Zm8=".getBytes("US-ASCII"),
                Base64.encodeBase64(new byte[] {'f', 'o'}));
    }

    @Test
    public void testStandardEncodingThreeBytes() throws Exception {
        assertArrayEquals("Zm9v".getBytes("US-ASCII"),
                Base64.encodeBase64(new byte[] {'f', 'o', 'o'}));
    }

    @Test
    public void testUrlSafeEncodingOmitsPadding() throws Exception {
        assertArrayEquals("Zg".getBytes("US-ASCII"),
                Base64.encodeBase64URLSafe(new byte[] {'f'}));
        assertArrayEquals("Zm8".getBytes("US-ASCII"),
                Base64.encodeBase64URLSafe(new byte[] {'f', 'o'}));
    }

    @Test
    public void testUrlSafeAlphabet() throws Exception {
        assertArrayEquals("-w".getBytes("US-ASCII"),
                Base64.encodeBase64URLSafe(new byte[] {(byte) 0xfb}));
        assertArrayEquals("_w".getBytes("US-ASCII"),
                Base64.encodeBase64URLSafe(new byte[] {(byte) 0xff}));
    }

    @Test
    public void testChunkedEncodingAtLineBoundary() throws Exception {
        byte[] input = new byte[57];
        byte[] output = Base64.encodeBase64Chunked(input);
        assertEquals(80, output.length);
        assertEquals('\r', output[76]);
        assertEquals('\n', output[77]);
    }

    @Test
    public void testDecodeBase64NullAndEmpty() throws Exception {
        assertNull(Base64.decodeBase64(null));
        assertArrayEquals(new byte[0], Base64.decodeBase64(new byte[0]));
    }

    @Test
    public void testDecodeBase64PaddedAndUnpadded() throws Exception {
        assertArrayEquals(new byte[] {'f'},
                Base64.decodeBase64("Zg==".getBytes("US-ASCII")));
        assertArrayEquals(new byte[] {'f'},
                Base64.decodeBase64("Zg".getBytes("US-ASCII")));
        assertArrayEquals(new byte[] {'f', 'o'},
                Base64.decodeBase64("Zm8".getBytes("US-ASCII")));
    }

    @Test
    public void testDecodeIgnoresNonAlphabetCharacters() throws Exception {
        assertArrayEquals(new byte[] {'f'},
                Base64.decodeBase64("Z?g!".getBytes("US-ASCII")));
    }

    @Test
    public void testDecodeAcceptsUrlSafeAlphabet() throws Exception {
        assertArrayEquals(new byte[] {(byte) 0xfb},
                Base64.decodeBase64("-w==".getBytes("US-ASCII")));
        assertArrayEquals(new byte[] {(byte) 0xff},
                Base64.decodeBase64("_w==".getBytes("US-ASCII")));
    }

    @Test
    public void testObjectDecodeRejectsNonByteArray() throws Exception {
        Base64 codec = new Base64();
        try {
            codec.decode("Zg==");
            fail("expected DecoderException");
        } catch (DecoderException expected) {
        }
    }

    @Test
    public void testObjectDecodeByteArray() throws Exception {
        Base64 codec = new Base64();
        assertArrayEquals(new byte[] {'f'},
                (byte[]) codec.decode("Zg==".getBytes("US-ASCII")));
    }

    @Test
    public void testObjectEncodeRejectsNonByteArray() throws Exception {
        Base64 codec = new Base64();
        try {
            codec.encode("f");
            fail("expected EncoderException");
        } catch (EncoderException expected) {
        }
    }

    @Test
    public void testObjectEncodeByteArray() throws Exception {
        Base64 codec = new Base64();
        assertArrayEquals("Zg==".getBytes("US-ASCII"),
                (byte[]) codec.encode(new byte[] {'f'}));
    }

    @Test
    public void testEncodeIntegerZeroAndSmallValue() throws Exception {
        assertArrayEquals(new byte[0], Base64.encodeInteger(BigInteger.ZERO));
        assertEquals(BigInteger.valueOf(5),
                Base64.decodeInteger(Base64.encodeInteger(BigInteger.valueOf(5))));
    }

    @Test
    public void testEncodeIntegerByteAlignedValues() throws Exception {
        BigInteger value = BigInteger.valueOf(128);
        assertEquals(value, Base64.decodeInteger(Base64.encodeInteger(value)));
        value = BigInteger.valueOf(255);
        assertEquals(value, Base64.decodeInteger(Base64.encodeInteger(value)));
    }

    @Test
    public void testEncodeIntegerAcrossByteBoundary() throws Exception {
        BigInteger value = BigInteger.valueOf(256);
        assertEquals(value, Base64.decodeInteger(Base64.encodeInteger(value)));
    }

    @Test
    public void testDecodeIntegerInterpretsBytesAsUnsigned() throws Exception {
        assertEquals(BigInteger.valueOf(255),
                Base64.decodeInteger("/w==".getBytes("US-ASCII")));
    }

    @Test
    public void testEncodeIntegerRejectsNull() throws Exception {
        try {
            Base64.encodeInteger(null);
            fail("expected NullPointerException");
        } catch (NullPointerException expected) {
        }
    }
}
