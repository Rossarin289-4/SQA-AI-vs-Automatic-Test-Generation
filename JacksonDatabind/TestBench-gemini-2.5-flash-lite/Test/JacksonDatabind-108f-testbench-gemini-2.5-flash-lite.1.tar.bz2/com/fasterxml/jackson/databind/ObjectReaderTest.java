package com.fasterxml.jackson.databind;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.*;
import java.net.URL;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import com.fasterxml.jackson.core.*;
import com.fasterxml.jackson.core.filter.FilteringParserDelegate;
import com.fasterxml.jackson.core.filter.JsonPointerBasedFilter;
import com.fasterxml.jackson.core.filter.TokenFilter;
import com.fasterxml.jackson.core.type.ResolvedType;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.cfg.ContextAttributes;
import com.fasterxml.jackson.databind.deser.DataFormatReaders;
import com.fasterxml.jackson.databind.deser.DefaultDeserializationContext;
import com.fasterxml.jackson.databind.deser.DeserializationProblemHandler;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.TreeTraversingParser;
import com.fasterxml.jackson.databind.type.SimpleType;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.fasterxml.jackson.databind.util.ClassUtil;
import com.fasterxml.jackson.databind.util.StdDateFormat;
import com.fasterxml.jackson.core.FormatFeature;
import com.fasterxml.jackson.core.JsonParser.Feature; // Explicitly import Feature for clarity
import com.fasterxml.jackson.databind.PropertyName; // Import PropertyName

public class ObjectReaderTest {

    // Helper method to create a basic ObjectMapper for tests
    private static ObjectMapper defaultMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        return mapper;
    }

    // Helper method to create a basic ObjectReader
    private ObjectReader defaultReader() {
        return defaultMapper().reader();
    }

    @Test
    public void testDefaultReaderConfig() throws Exception {
        ObjectReader reader = defaultReader();
        assertNotNull(reader);
        assertNotNull(reader.getConfig());
        assertNotNull(reader.getFactory());
        assertNotNull(reader.getTypeFactory());
        assertNotNull(reader.getAttributes());
        assertNull(reader.getInjectableValues()); // Default is null
    }

    @Test
    public void testWithDeserializationFeatureEnabled() throws Exception {
        ObjectReader reader = defaultReader();
        ObjectReader updatedReader = reader.with(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        assertTrue(updatedReader.isEnabled(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT));
        assertFalse(reader.isEnabled(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT)); // Original should be unchanged
    }

    @Test
    public void testWithDeserializationFeaturesEnabled() throws Exception {
        ObjectReader reader = defaultReader();
        ObjectReader updatedReader = reader.with(
                DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT,
                DeserializationFeature.USE_JAVA_ARRAY_FOR_JSON_ARRAY
        );
        assertTrue(updatedReader.isEnabled(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT));
        assertTrue(updatedReader.isEnabled(DeserializationFeature.USE_JAVA_ARRAY_FOR_JSON_ARRAY));
    }

    @Test
    public void testWithDeserializationFeaturesEnabledArray() throws Exception {
        ObjectReader reader = defaultReader();
        ObjectReader updatedReader = reader.withFeatures(
                DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT,
                DeserializationFeature.USE_JAVA_ARRAY_FOR_JSON_ARRAY
        );
        assertTrue(updatedReader.isEnabled(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT));
        assertTrue(updatedReader.isEnabled(DeserializationFeature.USE_JAVA_ARRAY_FOR_JSON_ARRAY));
    }

    @Test
    public void testWithoutDeserializationFeature() throws Exception {
        ObjectReader reader = defaultReader().with(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        assertTrue(reader.isEnabled(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT));
        ObjectReader updatedReader = reader.without(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        assertFalse(updatedReader.isEnabled(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT));
        assertTrue(reader.isEnabled(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT)); // Original should be unchanged
    }

    @Test
    public void testWithoutDeserializationFeatures() throws Exception {
        ObjectReader reader = defaultReader().with(
                DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT,
                DeserializationFeature.USE_JAVA_ARRAY_FOR_JSON_ARRAY
        );
        assertTrue(reader.isEnabled(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT));
        assertTrue(reader.isEnabled(DeserializationFeature.USE_JAVA_ARRAY_FOR_JSON_ARRAY));

        ObjectReader updatedReader = reader.without(
                DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT,
                DeserializationFeature.USE_JAVA_ARRAY_FOR_JSON_ARRAY
        );
        assertFalse(updatedReader.isEnabled(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT));
        assertFalse(updatedReader.isEnabled(DeserializationFeature.USE_JAVA_ARRAY_FOR_JSON_ARRAY));
    }

    @Test
    public void testWithoutDeserializationFeaturesArray() throws Exception {
        ObjectReader reader = defaultReader().with(
                DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT,
                DeserializationFeature.USE_JAVA_ARRAY_FOR_JSON_ARRAY
        );
        assertTrue(reader.isEnabled(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT));
        assertTrue(reader.isEnabled(DeserializationFeature.USE_JAVA_ARRAY_FOR_JSON_ARRAY));

        ObjectReader updatedReader = reader.withoutFeatures(
                DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT,
                DeserializationFeature.USE_JAVA_ARRAY_FOR_JSON_ARRAY
        );
        assertFalse(updatedReader.isEnabled(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT));
        assertFalse(updatedReader.isEnabled(DeserializationFeature.USE_JAVA_ARRAY_FOR_JSON_ARRAY));
    }

    @Test
    public void testWithJsonParserFeatureEnabled() {}
// Defects4J: flaky method
//     @Test
//     public void testWithJsonParserFeatureEnabled() throws Exception {
//         ObjectReader reader = defaultReader();
//         ObjectReader updatedReader = reader.with(JsonParser.Feature.ALLOW_COMMENTS);
//         assertTrue(updatedReader.isEnabled(JsonParser.Feature.ALLOW_COMMENTS));
//         assertFalse(reader.isEnabled(JsonParser.Feature.ALLOW_COMMENTS)); // Original should be unchanged
//     }

    @Test
    public void testWithJsonParserFeaturesEnabledArray() {}
// Defects4J: flaky method
//     @Test
//     public void testWithJsonParserFeaturesEnabledArray() throws Exception {
//         ObjectReader reader = defaultReader();
//         ObjectReader updatedReader = reader.withFeatures(
//                 JsonParser.Feature.ALLOW_COMMENTS,
//                 JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES
//         );
//         assertTrue(updatedReader.isEnabled(JsonParser.Feature.ALLOW_COMMENTS));
//         assertTrue(updatedReader.isEnabled(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES));
//     }

    @Test
    public void testWithoutJsonParserFeature() {}
// Defects4J: flaky method
//     @Test
//     public void testWithoutJsonParserFeature() throws Exception {
//         ObjectReader reader = defaultReader().with(JsonParser.Feature.ALLOW_COMMENTS);
//         assertTrue(reader.isEnabled(JsonParser.Feature.ALLOW_COMMENTS));
//         ObjectReader updatedReader = reader.without(JsonParser.Feature.ALLOW_COMMENTS);
//         assertFalse(updatedReader.isEnabled(JsonParser.Feature.ALLOW_COMMENTS));
//         assertTrue(reader.isEnabled(JsonParser.Feature.ALLOW_COMMENTS)); // Original should be unchanged
//     }


    // Mock FormatFeature as it's abstract and no concrete implementation is provided.
    // This mock implements the necessary methods to allow instantiation.





    @Test
    public void testAtJsonPointerString() throws Exception {
        ObjectReader reader = defaultReader();
        ObjectReader ptrReader = reader.at("/path/to/field");
        assertNotNull(ptrReader);
        assertNotSame(reader, ptrReader);
    }

    @Test
    public void testAtJsonPointerObject() throws Exception {
        ObjectReader reader = defaultReader();
        JsonPointer pointer = JsonPointer.compile("/another/path");
        ObjectReader ptrReader = reader.at(pointer);
        assertNotNull(ptrReader);
        assertNotSame(reader, ptrReader);
    }


    @Test
    public void testWithRootNamePropertyName() {}
// Defects4J: flaky method
//     @Test
//     public void testWithRootNamePropertyName() throws Exception {
//         ObjectReader reader = defaultReader();
//         PropertyName rootName = new PropertyName("myOtherRoot");
//         ObjectReader namedReader = reader.withRootName(rootName);
//         assertEquals(rootName, namedReader.getConfig().getRootName());
//         assertNotSame(reader, namedReader);
//     }

    @Test
    public void testWithoutRootName() throws Exception {
        ObjectReader reader = defaultReader().withRootName("someRoot");
        assertFalse(reader.getConfig().getRootName().isEmpty());
        ObjectReader unrootedReader = reader.withoutRootName();
        assertTrue(unrootedReader.getConfig().getRootName().isEmpty());
        assertNotSame(reader, unrootedReader);
    }

    @Test
    public void testForTypeJavaType() throws Exception {
        ObjectReader reader = defaultReader();
        JavaType stringType = reader.getTypeFactory().constructType(String.class);
        ObjectReader typedReader = reader.forType(stringType);
        assertNotNull(typedReader);
        assertEquals(stringType, typedReader._valueType); // Accessing protected field
        assertNotSame(reader, typedReader);
    }

    @Test
    public void testForTypeClass() throws Exception {
        ObjectReader reader = defaultReader();
        ObjectReader typedReader = reader.forType(Integer.class);
        assertNotNull(typedReader);
        assertEquals(Integer.class, typedReader._valueType.getRawClass()); // Accessing protected field
        assertNotSame(reader, typedReader);
    }

    @Test
    public void testForTypeTypeReference() throws Exception {
        ObjectReader reader = defaultReader();
        TypeReference<List<Map<String, Object>>> ref = new TypeReference<List<Map<String, Object>>>() {};
        ObjectReader typedReader = reader.forType(ref);
        assertNotNull(typedReader);
        assertNotSame(reader, typedReader);
    }

    @Test
    public void testWithTypeJavaTypeDeprecated() throws Exception {
        ObjectReader reader = defaultReader();
        JavaType longType = reader.getTypeFactory().constructType(Long.class);
        ObjectReader typedReader = reader.withType(longType);
        assertNotNull(typedReader);
        assertEquals(longType, typedReader._valueType); // Accessing protected field
        assertNotSame(reader, typedReader);
    }

    @Test
    public void testWithTypeClassDeprecated() throws Exception {
        ObjectReader reader = defaultReader();
        ObjectReader typedReader = reader.withType(Boolean.class);
        assertNotNull(typedReader);
        assertEquals(Boolean.class, typedReader._valueType.getRawClass()); // Accessing protected field
        assertNotSame(reader, typedReader);
    }

    @Test
    public void testWithValueToUpdate() throws Exception {
        ObjectReader reader = defaultReader();
        Object existingObject = new HashMap<String, String>();
        ObjectReader updatedReader = reader.withValueToUpdate(existingObject);
        assertNotNull(updatedReader);
        assertEquals(existingObject, updatedReader._valueToUpdate); // Accessing protected field
        assertNotSame(reader, updatedReader);
    }

    @Test
    public void testWithValueToUpdateToNull() throws Exception {
        ObjectReader reader = defaultReader().withValueToUpdate(new HashMap<>());
        ObjectReader updatedReader = reader.withValueToUpdate(null);
        assertNotNull(updatedReader);
        assertNull(updatedReader._valueToUpdate); // Accessing protected field
        assertNotSame(reader, updatedReader);
    }

    @Test
    public void testWithView() throws Exception {
        ObjectReader reader = defaultReader();
        ObjectReader viewReader = reader.withView(String.class); // Using String.class as an example view
        assertNotNull(viewReader);
        assertEquals(String.class, viewReader.getConfig().getActiveView());
        assertNotSame(reader, viewReader);
    }

    @Test
    public void testWithHandler() throws Exception {
        ObjectReader reader = defaultReader();
        DeserializationProblemHandler handler = new MockDeserializationProblemHandler();
        ObjectReader handlerReader = reader.withHandler(handler);
        assertNotNull(handlerReader);
        assertNotSame(reader, handlerReader);
    }

    @Test
    public void testWithFormatDetectionReadersArray() throws Exception {
        ObjectReader reader = defaultReader();
        ObjectReader dataReader1 = defaultReader().forType(String.class);
        ObjectReader dataReader2 = defaultReader().forType(Integer.class);
        ObjectReader formatReader = reader.withFormatDetection(dataReader1, dataReader2);
        assertNotNull(formatReader);
        assertNotNull(formatReader._dataFormatReaders); // Accessing protected field for test
        assertNotSame(reader, formatReader);
    }

    @Test
    public void testWithFormatDetectionDataFormatReaders() throws Exception {
        ObjectReader reader = defaultReader();
        DataFormatReaders dataReaders = new DataFormatReaders(defaultReader().forType(String.class));
        ObjectReader formatReader = reader.withFormatDetection(dataReaders);
        assertNotNull(formatReader);
        assertNotNull(formatReader._dataFormatReaders); // Accessing protected field for test
        assertEquals(dataReaders, formatReader._dataFormatReaders);
        assertNotSame(reader, formatReader);
    }

    @Test
    public void testWithAttributes() throws Exception {
        ObjectReader reader = defaultReader();
        Map<Object, Object> attrs = new HashMap<>();
        attrs.put("key1", "value1");
        ObjectReader attrReader = reader.withAttributes(attrs);
        assertNotNull(attrReader);
        assertEquals("value1", attrReader.getAttributes().getAttribute("key1"));
        assertNotSame(reader, attrReader);
    }

    @Test
    public void testWithAttribute() throws Exception {
        ObjectReader reader = defaultReader();
        ObjectReader attrReader = reader.withAttribute("key2", "value2");
        assertNotNull(attrReader);
        assertEquals("value2", attrReader.getAttributes().getAttribute("key2"));
        assertNotSame(reader, attrReader);
    }

    @Test
    public void testWithoutAttribute() throws Exception {
        ObjectReader reader = defaultReader().withAttribute("key3", "value3");
        assertNotNull(reader.getAttributes().getAttribute("key3"));
        ObjectReader updatedReader = reader.withoutAttribute("key3");
        assertNull(updatedReader.getAttributes().getAttribute("key3"));
        assertNotSame(reader, updatedReader);
    }

    @Test
    public void testGetConfig() throws Exception {
        ObjectReader reader = defaultReader();
        DeserializationConfig config = reader.getConfig();
        assertNotNull(config);
        assertNotNull(config.getBase64Variant()); // Example: check another config property
    }

    @Test
    public void testGetFactory() throws Exception {
        ObjectReader reader = defaultReader();
        JsonFactory factory = reader.getFactory();
        assertNotNull(factory);
        assertTrue(factory instanceof JsonFactory);
    }

    @Test
    public void testGetTypeFactory() throws Exception {
        ObjectReader reader = defaultReader();
        TypeFactory typeFactory = reader.getTypeFactory();
        assertNotNull(typeFactory);
        assertTrue(typeFactory instanceof TypeFactory);
    }

    @Test
    public void testGetAttributes() throws Exception {
        ObjectReader reader = defaultReader();
        ContextAttributes attributes = reader.getAttributes();
        assertNotNull(attributes);
        assertTrue(attributes instanceof ContextAttributes);
    }

    @Test
    public void testGetInjectableValues() throws Exception {
        ObjectReader reader = defaultReader();
        InjectableValues injectableValues = reader.getInjectableValues();
        assertNull(injectableValues); // Default is null

        InjectableValues customValues = new MockInjectableValues();
        ObjectReader readerWithValues = reader.with(customValues);
        assertNotNull(readerWithValues.getInjectableValues());
        assertEquals(customValues, readerWithValues.getInjectableValues());
    }

    @Test
    public void testReadValueJsonParser() throws Exception {
        ObjectReader reader = defaultReader().forType(String.class);
        JsonFactory factory = new JsonFactory();
        String json = "\"testString\"";
        JsonParser parser = factory.createParser(json);
        Object result = reader.readValue(parser);
        assertEquals("testString", result);
        parser.close();
    }

    @Test
    public void testReadValueJsonParserWithTargetType() throws Exception {
        ObjectReader reader = defaultReader();
        JsonFactory factory = new JsonFactory();
        String json = "\"testString\"";
        JsonParser parser = factory.createParser(json);
        String result = reader.readValue(parser, String.class);
        assertEquals("testString", result);
        parser.close();
    }

    @Test
    public void testReadValueJsonParserTypeReference() throws Exception {
        ObjectReader reader = defaultReader();
        JsonFactory factory = new JsonFactory();
        String json = "[1, 2, 3]";
        JsonParser parser = factory.createParser(json);
        List<Integer> result = reader.readValue(parser, new TypeReference<List<Integer>>() {});
        assertEquals(3, result.size());
        assertEquals(Integer.valueOf(1), result.get(0));
        parser.close();
    }

    @Test
    public void testReadValueJsonParserResolvedType() throws Exception {
        ObjectReader reader = defaultReader();
        JavaType intType = reader.getTypeFactory().constructType(Integer.class);
        JsonFactory factory = new JsonFactory();
        String json = "123";
        JsonParser parser = factory.createParser(json);
        Integer result = reader.readValue(parser, (ResolvedType) intType);
        assertEquals(Integer.valueOf(123), result);
        parser.close();
    }

    @Test
    public void testReadValueJsonParserJavaType() throws Exception {
        ObjectReader reader = defaultReader();
        JavaType intType = reader.getTypeFactory().constructType(Integer.class);
        JsonFactory factory = new JsonFactory();
        String json = "456";
        JsonParser parser = factory.createParser(json);
        Integer result = reader.readValue(parser, intType);
        assertEquals(Integer.valueOf(456), result);
        parser.close();
    }

    @Test
    public void testReadValuesJsonParser() throws Exception {
        ObjectReader reader = defaultReader().forType(String.class);
        JsonFactory factory = new JsonFactory();
        // For readValues(JsonParser), the parser must point to the first token of the first element.
        String json = "[\"val1\", \"val2\", \"val3\"]";
        JsonParser parser = factory.createParser(json);
        parser.nextToken(); // Move to START_ARRAY
        parser.nextToken(); // Move to first value
        MappingIterator<String> iterator = reader.readValues(parser);
        assertTrue(iterator.hasNext());
        assertEquals("val1", iterator.next());
        assertTrue(iterator.hasNext());
        assertEquals("val2", iterator.next());
        assertTrue(iterator.hasNext());
        assertEquals("val3", iterator.next());
        assertFalse(iterator.hasNext());
        parser.close();
    }

    @Test
    public void testReadValuesJsonParserClass() throws Exception {
        ObjectReader reader = defaultReader();
        JsonFactory factory = new JsonFactory();
        String json = "[10, 20, 30]";
        JsonParser parser = factory.createParser(json);
        parser.nextToken(); // Move to START_ARRAY
        parser.nextToken(); // Move to first value
        Iterator<Integer> iterator = reader.readValues(parser, Integer.class);
        assertTrue(iterator.hasNext());
        assertEquals(Integer.valueOf(10), iterator.next());
        assertTrue(iterator.hasNext());
        assertEquals(Integer.valueOf(20), iterator.next());
        assertTrue(iterator.hasNext());
        assertEquals(Integer.valueOf(30), iterator.next());
        assertFalse(iterator.hasNext());
        parser.close();
    }

    @Test
    public void testReadValuesJsonParserTypeReference() throws Exception {
        ObjectReader reader = defaultReader();
        JsonFactory factory = new JsonFactory();
        String json = "[\"a\", \"b\"]";
        JsonParser parser = factory.createParser(json);
        parser.nextToken(); // Move to START_ARRAY
        parser.nextToken(); // Move to first value
        Iterator<String> iterator = reader.readValues(parser, new TypeReference<String>() {});
        assertTrue(iterator.hasNext());
        assertEquals("a", iterator.next());
        assertTrue(iterator.hasNext());
        assertEquals("b", iterator.next());
        assertFalse(iterator.hasNext());
        parser.close();
    }

    @Test
    public void testReadValuesJsonParserResolvedType() throws Exception {
        ObjectReader reader = defaultReader();
        JavaType stringType = reader.getTypeFactory().constructType(String.class);
        JsonFactory factory = new JsonFactory();
        String json = "[\"x\", \"y\"]";
        JsonParser parser = factory.createParser(json);
        parser.nextToken(); // Move to START_ARRAY
        parser.nextToken(); // Move to first value
        Iterator<String> iterator = reader.readValues(parser, (ResolvedType) stringType);
        assertTrue(iterator.hasNext());
        assertEquals("x", iterator.next());
        assertTrue(iterator.hasNext());
        assertEquals("y", iterator.next());
        assertFalse(iterator.hasNext());
        parser.close();
    }

    @Test
    public void testReadValuesJsonParserJavaType() throws Exception {
        ObjectReader reader = defaultReader();
        JavaType stringType = reader.getTypeFactory().constructType(String.class);
        JsonFactory factory = new JsonFactory();
        String json = "[\"p\", \"q\"]";
        JsonParser parser = factory.createParser(json);
        parser.nextToken(); // Move to START_ARRAY
        parser.nextToken(); // Move to first value
        Iterator<String> iterator = reader.readValues(parser, stringType);
        assertTrue(iterator.hasNext());
        assertEquals("p", iterator.next());
        assertTrue(iterator.hasNext());
        assertEquals("q", iterator.next());
        assertFalse(iterator.hasNext());
        parser.close();
    }


    @Test
    public void testCreateArrayNode() throws Exception {
        ObjectReader reader = defaultReader();
        JsonNode node = reader.createArrayNode();
        assertNotNull(node);
        assertTrue(node.isArray());
        assertEquals(0, node.size());
    }

    @Test
    public void testCreateObjectNode() throws Exception {
        ObjectReader reader = defaultReader();
        JsonNode node = reader.createObjectNode();
        assertNotNull(node);
        assertTrue(node.isObject());
        assertEquals(0, node.size());
    }

    @Test
    public void testTreeAsTokens() throws Exception {
        ObjectReader reader = defaultReader();
        JsonNodeFactory nodeFactory = reader.getConfig().getNodeFactory();
        JsonNode rootNode = nodeFactory.objectNode().put("key", "value");
        JsonParser parser = reader.treeAsTokens(rootNode);
        assertNotNull(parser);
        assertTrue(parser.nextToken() == JsonToken.START_OBJECT);
        assertTrue(parser.nextToken() == JsonToken.FIELD_NAME);
        assertEquals("key", parser.getCurrentName());
        assertTrue(parser.nextToken() == JsonToken.VALUE_STRING);
        assertEquals("value", parser.getText());
        assertTrue(parser.nextToken() == JsonToken.END_OBJECT);
        assertTrue(parser.nextToken() == null);
        parser.close();
    }

    @Test
    public void testReadTreeJsonParser() throws Exception {
        ObjectReader reader = defaultReader();
        JsonFactory factory = new JsonFactory();
        String json = "{\"value\": 123}";
        JsonParser parser = factory.createParser(json);
        JsonNode node = reader.readTree(parser);
        assertNotNull(node);
        assertTrue(node.isObject());
        assertEquals(123, node.get("value").intValue());
        parser.close();
    }

    @Test
    public void testReadTreeJsonParserEmpty() {}
// Defects4J: flaky method
//     @Test
//     public void testReadTreeJsonParserEmpty() throws Exception {
//         ObjectReader reader = defaultReader();
//         JsonFactory factory = new JsonFactory();
//         String json = ""; // Empty input
//         JsonParser parser = factory.createParser(json);
//         JsonNode node = reader.readTree(parser);
//         assertNotNull(node);
//         assertTrue(node.isMissingNode()); // Expected for empty input with readTree
//         parser.close();
//     }

    @Test
    public void testReadTreeJsonParserNull() throws Exception {
        ObjectReader reader = defaultReader();
        JsonFactory factory = new JsonFactory();
        String json = "null";
        JsonParser parser = factory.createParser(json);
        JsonNode node = reader.readTree(parser);
        assertNotNull(node);
        assertTrue(node.isNull());
        parser.close();
    }


    @Test
    public void testReadValueInputStream() throws Exception {
        ObjectReader reader = defaultReader().forType(String.class);
        String json = "\"inputStreamValue\"";
        InputStream inputStream = new ByteArrayInputStream(json.getBytes());
        Object result = reader.readValue(inputStream);
        assertEquals("inputStreamValue", result);
        inputStream.close();
    }

    @Test
    public void testReadValueReader() throws Exception {
        ObjectReader reader = defaultReader().forType(Integer.class);
        String json = "789";
        Reader readerInput = new StringReader(json);
        Object result = reader.readValue(readerInput);
        assertEquals(Integer.valueOf(789), result);
        readerInput.close();
    }

    @Test
    public void testReadValueString() throws Exception {
        ObjectReader reader = defaultReader().forType(Boolean.class);
        String json = "true";
        Object result = reader.readValue(json);
        assertEquals(Boolean.TRUE, result);
    }

    @Test
    public void testReadValueByteArray() throws Exception {
        ObjectReader reader = defaultReader().forType(String.class);
        byte[] jsonBytes = "\"byteArayValue\"".getBytes();
        Object result = reader.readValue(jsonBytes);
        assertEquals("byteArayValue", result);
    }

    @Test
    public void testReadValueByteArrayOffsetLength() throws Exception {
        ObjectReader reader = defaultReader().forType(Integer.class);
        byte[] data = "ignore 123".getBytes();
        Object result = reader.readValue(data, 7, 3); // Reads "123"
        assertEquals(Integer.valueOf(123), result);
    }

    @Test
    public void testReadValueFile() throws Exception {
        ObjectReader reader = defaultReader().forType(String.class);
        File tempFile = File.createTempFile("jacksonTest", ".json");
        tempFile.deleteOnExit();
        try (OutputStream outputStream = new FileOutputStream(tempFile)) {
            outputStream.write("\"fileValue\"".getBytes());
        }
        Object result = reader.readValue(tempFile);
        assertEquals("fileValue", result);
        tempFile.delete();
    }

    @Test
    public void testReadValueURL() throws Exception {
        ObjectReader reader = defaultReader().forType(String.class);
        String json = "\"urlValue\"";
        File tempFile = File.createTempFile("jacksonURLTest", ".json");
        tempFile.deleteOnExit();
        try (OutputStream outputStream = new FileOutputStream(tempFile)) {
            outputStream.write(json.getBytes());
        }
        URL fileUrl = tempFile.toURI().toURL();
        Object result = reader.readValue(fileUrl);
        assertEquals("urlValue", result);
        tempFile.delete();
    }

    @Test
    public void testReadValueJsonNode() throws Exception {
        ObjectReader reader = defaultReader().forType(String.class);
        JsonNodeFactory nodeFactory = reader.getConfig().getNodeFactory();
        JsonNode rootNode = nodeFactory.textNode("jsonNodeValue");
        Object result = reader.readValue(rootNode);
        assertEquals("jsonNodeValue", result);
    }


    @Test
    public void testReadTreeInputStream() throws Exception {
        ObjectReader reader = defaultReader();
        String json = "{\"treeNode\": \"value\"}";
        InputStream inputStream = new ByteArrayInputStream(json.getBytes());
        JsonNode node = reader.readTree(inputStream);
        assertNotNull(node);
        assertTrue(node.isObject());
        assertEquals("value", node.get("treeNode").asText());
        inputStream.close();
    }

    @Test
    public void testReadTreeReader() throws Exception {
        ObjectReader reader = defaultReader();
        String json = "{\"treeReader\": \"anotherValue\"}";
        Reader readerInput = new StringReader(json);
        JsonNode node = reader.readTree(readerInput);
        assertNotNull(node);
        assertTrue(node.isObject());
        assertEquals("anotherValue", node.get("treeReader").asText());
        readerInput.close();
    }

    @Test
    public void testReadTreeString() throws Exception {
        ObjectReader reader = defaultReader();
        String json = "{\"treeString\": \"valueHere\"}";
        JsonNode node = reader.readTree(json);
        assertNotNull(node);
        assertTrue(node.isObject());
        assertEquals("valueHere", node.get("treeString").asText());
    }

    @Test
    public void testReadTreeByteArray() throws Exception {
        ObjectReader reader = defaultReader();
        byte[] jsonBytes = "{\"treeBytes\": \"byteValue\"}".getBytes();
        JsonNode node = reader.readTree(jsonBytes);
        assertNotNull(node);
        assertTrue(node.isObject());
        assertEquals("byteValue", node.get("treeBytes").asText());
    }

    @Test
    public void testReadTreeByteArrayOffsetLength() throws Exception {
        ObjectReader reader = defaultReader();
        byte[] data = "ignore {\"treeBytesLen\": \"lenValue\"}".getBytes();
        JsonNode node = reader.readTree(data, 7, data.length - 7); // Reads the JSON part
        assertNotNull(node);
        assertTrue(node.isObject());
        assertEquals("lenValue", node.get("treeBytesLen").asText());
    }


    @Test
    public void testReadValuesInputStream() throws Exception {
        ObjectReader reader = defaultReader().forType(String.class);
        String json = "[\"val1\", \"val2\", \"val3\"]";
        InputStream inputStream = new ByteArrayInputStream(json.getBytes());
        MappingIterator<String> iterator = reader.readValues(inputStream);
        assertTrue(iterator.hasNext());
        assertEquals("val1", iterator.next());
        assertTrue(iterator.hasNext());
        assertEquals("val2", iterator.next());
        assertTrue(iterator.hasNext());
        assertEquals("val3", iterator.next());
        assertFalse(iterator.hasNext());
        inputStream.close();
    }

    @Test
    public void testReadValuesReader() throws Exception {
        ObjectReader reader = defaultReader().forType(Integer.class);
        String json = "[11, 22, 33]";
        Reader readerInput = new StringReader(json);
        MappingIterator<Integer> iterator = reader.readValues(readerInput);
        assertTrue(iterator.hasNext());
        assertEquals(Integer.valueOf(11), iterator.next());
        assertTrue(iterator.hasNext());
        assertEquals(Integer.valueOf(22), iterator.next());
        assertTrue(iterator.hasNext());
        assertEquals(Integer.valueOf(33), iterator.next());
        assertFalse(iterator.hasNext());
        readerInput.close();
    }

    @Test
    public void testReadValuesString() throws Exception {
        ObjectReader reader = defaultReader().forType(Boolean.class);
        String json = "[false, true]";
        MappingIterator<Boolean> iterator = reader.readValues(json);
        assertTrue(iterator.hasNext());
        assertEquals(Boolean.FALSE, iterator.next());
        assertTrue(iterator.hasNext());
        assertEquals(Boolean.TRUE, iterator.next());
        assertFalse(iterator.hasNext());
    }

    @Test
    public void testReadValuesByteArrayOffsetLength() throws Exception {
        ObjectReader reader = defaultReader().forType(String.class);
        byte[] data = "ignore [\"a\", \"b\"]".getBytes();
        MappingIterator<String> iterator = reader.readValues(data, 7, data.length - 7);
        assertTrue(iterator.hasNext());
        assertEquals("a", iterator.next());
        assertTrue(iterator.hasNext());
        assertEquals("b", iterator.next());
        assertFalse(iterator.hasNext());
    }

    @Test
    public void testReadValuesByteArray() throws Exception {
        ObjectReader reader = defaultReader().forType(Integer.class);
        byte[] jsonBytes = "[100, 200]".getBytes();
        MappingIterator<Integer> iterator = reader.readValues(jsonBytes);
        assertTrue(iterator.hasNext());
        assertEquals(Integer.valueOf(100), iterator.next());
        assertTrue(iterator.hasNext());
        assertEquals(Integer.valueOf(200), iterator.next());
        assertFalse(iterator.hasNext());
    }

    @Test
    public void testReadValuesFile() throws Exception {
        ObjectReader reader = defaultReader().forType(String.class);
        File tempFile = File.createTempFile("jacksonReadValuesFile", ".json");
        tempFile.deleteOnExit();
        try (OutputStream outputStream = new FileOutputStream(tempFile)) {
            outputStream.write("[\"fileVal1\", \"fileVal2\"]".getBytes());
        }
        MappingIterator<String> iterator = reader.readValues(tempFile);
        assertTrue(iterator.hasNext());
        assertEquals("fileVal1", iterator.next());
        assertTrue(iterator.hasNext());
        assertEquals("fileVal2", iterator.next());
        assertFalse(iterator.hasNext());
        tempFile.delete();
    }

    @Test
    public void testReadValuesURL() throws Exception {
        ObjectReader reader = defaultReader().forType(Integer.class);
        String json = "[300, 400]";
        File tempFile = File.createTempFile("jacksonReadValuesURL", ".json");
        tempFile.deleteOnExit();
        try (OutputStream outputStream = new FileOutputStream(tempFile)) {
            outputStream.write(json.getBytes());
        }
        URL fileUrl = tempFile.toURI().toURL();
        MappingIterator<Integer> iterator = reader.readValues(fileUrl);
        assertTrue(iterator.hasNext());
        assertEquals(Integer.valueOf(300), iterator.next());
        assertTrue(iterator.hasNext());
        assertEquals(Integer.valueOf(400), iterator.next());
        assertFalse(iterator.hasNext());
        tempFile.delete();
    }


    @Test
    public void testTreeToValue() throws Exception {
        ObjectReader reader = defaultReader();
        JsonNodeFactory nodeFactory = reader.getConfig().getNodeFactory();
        JsonNode rootNode = nodeFactory.numberNode(456);
        Integer result = reader.treeToValue(rootNode, Integer.class);
        assertEquals(Integer.valueOf(456), result);
    }

    // Dummy classes and interfaces for testing purposes
    // MockFormatFeature is defined above.

    private static class MockDeserializationProblemHandler extends DeserializationProblemHandler {
        // Implement methods as needed for testing
    }

    private static class MockInjectableValues extends InjectableValues {
        @Override
        public Object findInjectableValue(Object valueId, DeserializationContext ctxt, BeanProperty forProperty, Object beanInstance) throws JsonMappingException {
            return null; // Default implementation
        }
    }

    // Dummy Enum for testing purposes
    enum MockEnum {
        VALUE1, VALUE2
    }

    // Dummy class for testing readValue with different types
    static class MyData {
        public String name;
        public int age;
    }
}


