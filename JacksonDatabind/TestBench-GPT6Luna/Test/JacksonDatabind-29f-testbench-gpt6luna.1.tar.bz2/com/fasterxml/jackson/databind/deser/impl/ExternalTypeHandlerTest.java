package com.fasterxml.jackson.databind.deser.impl;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.*;
import com.fasterxml.jackson.core.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
import com.fasterxml.jackson.databind.util.TokenBuffer;

public class ExternalTypeHandlerTest {
    @Test
    public void testStartReturnsHandler() throws Exception {
        ExternalTypeHandler handler = new ExternalTypeHandler.Builder().build();
        assertNotNull(handler.start());
    }

    @Test
    public void testStartReturnsIndependentHandler() throws Exception {
        ExternalTypeHandler handler = new ExternalTypeHandler.Builder().build();
        assertNotSame(handler, handler.start());
    }
}
