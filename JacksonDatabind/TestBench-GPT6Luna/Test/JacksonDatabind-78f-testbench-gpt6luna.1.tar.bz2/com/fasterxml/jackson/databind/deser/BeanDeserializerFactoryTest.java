package com.fasterxml.jackson.databind.deser;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.*;
import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig;
import com.fasterxml.jackson.databind.cfg.ConfigOverride;
import com.fasterxml.jackson.databind.deser.impl.*;
import com.fasterxml.jackson.databind.deser.std.ThrowableDeserializer;
import com.fasterxml.jackson.databind.introspect.*;
import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
import com.fasterxml.jackson.databind.util.ClassUtil;
import com.fasterxml.jackson.databind.util.SimpleBeanPropertyDefinition;

public class BeanDeserializerFactoryTest {
    @Test
    public void testWithSameConfigReturnsSameFactory() throws Exception {
        DeserializerFactoryConfig config = new DeserializerFactoryConfig();
        BeanDeserializerFactory factory = new BeanDeserializerFactory(config);
        assertSame(factory, factory.withConfig(config));
    }

    @Test
    public void testWithDifferentConfigReturnsDifferentFactory() throws Exception {
        BeanDeserializerFactory factory = new BeanDeserializerFactory(new DeserializerFactoryConfig());
        DeserializerFactory result = factory.withConfig(new DeserializerFactoryConfig());
        assertNotSame(factory, result);
        assertNotNull(result);
    }

    @Test
    public void testFactorySingletonIsStable() throws Exception {
        assertSame(BeanDeserializerFactory.instance, BeanDeserializerFactory.instance);
    }

    @Test
    public void testCreateDeserializerForStringType() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        JavaType type = mapper.constructType(String.class);
        JsonDeserializer<Object> result = BeanDeserializerFactory.instance.createBeanDeserializer(
                mapper.getDeserializationContext(), type, mapper.getDeserializationConfig().introspect(type));
        assertNotNull(result);
    }

    @Test
    public void testCreateDeserializerForPrimitiveType() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        JavaType type = mapper.constructType(int.class);
        JsonDeserializer<Object> result = BeanDeserializerFactory.instance.createBeanDeserializer(
                mapper.getDeserializationContext(), type, mapper.getDeserializationConfig().introspect(type));
        assertNotNull(result);
    }

    @Test
    public void testCreateDeserializerForEnumType() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        JavaType type = mapper.constructType(Thread.State.class);
        try {
            BeanDeserializerFactory.instance.createBeanDeserializer(
                    mapper.getDeserializationContext(), type, mapper.getDeserializationConfig().introspect(type));
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            assertTrue(expected.getMessage().contains("enum"));
        }
    }

    @Test
    public void testCreateDeserializerForOrdinaryBean() {}
// Defects4J: flaky method
//     @Test
//     public void testCreateDeserializerForOrdinaryBean() throws Exception {
//         ObjectMapper mapper = new ObjectMapper();
//         JavaType type = mapper.constructType(TestBean.class);
//         JsonDeserializer<Object> result = BeanDeserializerFactory.instance.createBeanDeserializer(
//                 mapper.getDeserializationContext(), type, mapper.getDeserializationConfig().introspect(type));
//         assertNotNull(result);
//     }

    @Test
    public void testCreateDeserializerForThrowable() {}
// Defects4J: flaky method
//     @Test
//     public void testCreateDeserializerForThrowable() throws Exception {
//         ObjectMapper mapper = new ObjectMapper();
//         JavaType type = mapper.constructType(IllegalArgumentException.class);
//         JsonDeserializer<Object> result = BeanDeserializerFactory.instance.createBeanDeserializer(
//                 mapper.getDeserializationContext(), type, mapper.getDeserializationConfig().introspect(type));
//         assertNotNull(result);
//     }

    @Test
    public void testBuilderBasedDeserializerConstruction() {}
// Defects4J: flaky method
//     @Test
//     public void testBuilderBasedDeserializerConstruction() throws Exception {
//         ObjectMapper mapper = new ObjectMapper();
//         JavaType valueType = mapper.constructType(TestBean.class);
//         BeanDescription desc = mapper.getDeserializationConfig().introspect(valueType);
//         JsonDeserializer<Object> result = BeanDeserializerFactory.instance.createBuilderBasedDeserializer(
//                 mapper.getDeserializationContext(), valueType, desc, TestBuilder.class);
//         assertNotNull(result);
//     }

    @Test
    public void testBuildBeanDeserializerDirectly() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        JavaType type = mapper.constructType(TestBean.class);
        try {
            BeanDeserializerFactory.instance.buildBeanDeserializer(
                    mapper.getDeserializationContext(), type, mapper.getDeserializationConfig().introspect(type));
            fail("expected NullPointerException");
        } catch (NullPointerException expected) {
            assertTrue(true);
        }
    }

    @Test
    public void testBuildThrowableDeserializerDirectly() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        JavaType type = mapper.constructType(IllegalStateException.class);
        try {
            BeanDeserializerFactory.instance.buildThrowableDeserializer(
                    mapper.getDeserializationContext(), type, mapper.getDeserializationConfig().introspect(type));
            fail("expected NullPointerException");
        } catch (NullPointerException expected) {
            assertTrue(true);
        }
    }

    @Test
    public void testCreateBeanDeserializerUsesStandardDeserializerForInteger() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        JavaType type = mapper.constructType(Integer.class);
        JsonDeserializer<Object> result = BeanDeserializerFactory.instance.createBeanDeserializer(
                mapper.getDeserializationContext(), type, mapper.getDeserializationConfig().introspect(type));
        assertNotNull(result);
    }

    @Test
    public void testCreateBeanDeserializerForArray() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        JavaType type = mapper.constructType(String[].class);
        try {
            BeanDeserializerFactory.instance.createBeanDeserializer(
                    mapper.getDeserializationContext(), type, mapper.getDeserializationConfig().introspect(type));
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) {
            assertTrue(expected.getMessage().contains("array"));
        }
    }

    @Test
    public void testCreateBeanDeserializerForBooleanPrimitive() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        JavaType type = mapper.constructType(boolean.class);
        JsonDeserializer<Object> result = BeanDeserializerFactory.instance.createBeanDeserializer(
                mapper.getDeserializationContext(), type, mapper.getDeserializationConfig().introspect(type));
        assertNotNull(result);
    }

    @Test
    public void testCreateDeserializerRepeatedForSameBean() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        JavaType type = mapper.constructType(TestBean.class);
        BeanDescription desc = mapper.getDeserializationConfig().introspect(type);
        try {
            BeanDeserializerFactory.instance.createBeanDeserializer(
                    mapper.getDeserializationContext(), type, desc);
            fail("expected NullPointerException");
        } catch (NullPointerException expected) {
            assertTrue(true);
        }
    }

    public static class TestBean {
        public int value;

        public TestBean() {
        }
    }

    @JsonPOJOBuilder
    public static class TestBuilder {
        private int value;

        public TestBuilder withValue(int value) {
            this.value = value;
            return this;
        }

        public TestBean build() {
            TestBean result = new TestBean();
            result.value = value;
            return result;
        }
    }
}
