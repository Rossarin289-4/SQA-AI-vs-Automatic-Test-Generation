package com.fasterxml.jackson.databind.deser.std;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.util.*;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.io.NumberInput;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
import com.fasterxml.jackson.databind.util.ClassUtil;
import com.fasterxml.jackson.databind.util.EnumResolver;
import com.fasterxml.jackson.databind.util.TokenBuffer;

public class StdKeyDeserializerTest {
    @Test
    public void testForTypeSupportedAndUnsupportedClasses() throws Exception {
        assertNotNull(StdKeyDeserializer.forType(Integer.class));
        assertNotNull(StdKeyDeserializer.forType(String.class));
        assertNull(StdKeyDeserializer.forType(StdKeyDeserializerTest.class));
    }

    @Test
    public void testStringKeyAndKeyClass() throws Exception {
        StdKeyDeserializer d = StdKeyDeserializer.forType(String.class);
        assertEquals(String.class, d.getKeyClass());
        assertEquals("abc", d.deserializeKey("abc", null));
    }

    @Test
    public void testStringKeyNull() throws Exception {
        assertNull(StdKeyDeserializer.forType(String.class).deserializeKey(null, null));
    }

    @Test
    public void testObjectKeyPreservesText() throws Exception {
        StdKeyDeserializer d = StdKeyDeserializer.forType(Object.class);
        assertEquals(Object.class, d.getKeyClass());
        assertEquals("17", d.deserializeKey("17", null));
    }

    @Test
    public void testIntegerKey() throws Exception {
        assertEquals(Integer.valueOf(42),
                StdKeyDeserializer.forType(Integer.class).deserializeKey("42", null));
    }

    @Test
    public void testIntegerMaximum() throws Exception {
        assertEquals(Integer.valueOf(Integer.MAX_VALUE),
                StdKeyDeserializer.forType(Integer.class).deserializeKey("2147483647", null));
    }

    @Test
    public void testIntegerMinimum() throws Exception {
        assertEquals(Integer.valueOf(Integer.MIN_VALUE),
                StdKeyDeserializer.forType(Integer.class).deserializeKey("-2147483648", null));
    }

    @Test
    public void testLongMaximum() throws Exception {
        assertEquals(Long.valueOf(Long.MAX_VALUE),
                StdKeyDeserializer.forType(Long.class).deserializeKey("9223372036854775807", null));
    }

    @Test
    public void testLongMinimum() throws Exception {
        assertEquals(Long.valueOf(Long.MIN_VALUE),
                StdKeyDeserializer.forType(Long.class).deserializeKey("-9223372036854775808", null));
    }

    @Test
    public void testBooleanTrue() throws Exception {
        assertEquals(Boolean.TRUE,
                StdKeyDeserializer.forType(Boolean.class).deserializeKey("true", null));
    }

    @Test
    public void testBooleanFalse() throws Exception {
        assertEquals(Boolean.FALSE,
                StdKeyDeserializer.forType(Boolean.class).deserializeKey("false", null));
    }

    @Test
    public void testCharacterSingleCharacter() throws Exception {
        assertEquals(Character.valueOf('x'),
                StdKeyDeserializer.forType(Character.class).deserializeKey("x", null));
    }

    @Test
    public void testByteUpperUnsignedBoundary() throws Exception {
        assertEquals(Byte.valueOf((byte) -1),
                StdKeyDeserializer.forType(Byte.class).deserializeKey("255", null));
    }

    @Test
    public void testByteLowerBoundary() throws Exception {
        assertEquals(Byte.valueOf(Byte.MIN_VALUE),
                StdKeyDeserializer.forType(Byte.class).deserializeKey("-128", null));
    }

    @Test
    public void testShortMaximum() throws Exception {
        assertEquals(Short.valueOf(Short.MAX_VALUE),
                StdKeyDeserializer.forType(Short.class).deserializeKey("32767", null));
    }

    @Test
    public void testShortMinimum() throws Exception {
        assertEquals(Short.valueOf(Short.MIN_VALUE),
                StdKeyDeserializer.forType(Short.class).deserializeKey("-32768", null));
    }

    @Test
    public void testFloatValue() throws Exception {
        Float value = (Float) StdKeyDeserializer.forType(Float.class).deserializeKey("1.5", null);
        assertEquals(1.5, value.doubleValue(), 1e-6);
    }

    @Test
    public void testDoubleValue() throws Exception {
        Double value = (Double) StdKeyDeserializer.forType(Double.class).deserializeKey("2.25", null);
        assertEquals(2.25, value.doubleValue(), 1e-12);
    }

    @Test
    public void testUriKey() throws Exception {
        assertEquals(URI.create("urn:test"), StdKeyDeserializer.forType(URI.class)
                .deserializeKey("urn:test", null));
    }

    @Test
    public void testUrlKey() throws Exception {
        assertEquals(new URL("http://example.com/"), StdKeyDeserializer.forType(URL.class)
                .deserializeKey("http://example.com/", null));
    }

    @Test
    public void testUuidKey() throws Exception {
        UUID expected = UUID.fromString("123e4567-e89b-12d3-a456-426614174000");
        assertEquals(expected, StdKeyDeserializer.forType(UUID.class)
                .deserializeKey("123e4567-e89b-12d3-a456-426614174000", null));
    }

    @Test
    public void testClassKey() throws Exception {
        assertNull(StdKeyDeserializer.forType(Class.class).deserializeKey(null, null));
    }
}
