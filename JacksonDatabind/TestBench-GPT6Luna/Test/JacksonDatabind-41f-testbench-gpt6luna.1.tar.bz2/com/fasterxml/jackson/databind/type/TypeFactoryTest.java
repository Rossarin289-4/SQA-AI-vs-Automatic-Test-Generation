package com.fasterxml.jackson.databind.type;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;
import java.lang.reflect.*;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.util.ArrayBuilders;
import com.fasterxml.jackson.databind.util.ClassUtil;
import com.fasterxml.jackson.databind.util.LRUMap;

public class TypeFactoryTest {
    @Test
    public void testDefaultFactoryAndUnknownType() throws Exception {
        assertSame(TypeFactory.defaultInstance(), TypeFactory.defaultInstance());
        assertSame(TypeFactory.unknownType(), TypeFactory.unknownType());
        assertEquals(Object.class, TypeFactory.unknownType().getRawClass());
    }

    @Test
    public void testClassLoaderConfiguration() throws Exception {
        TypeFactory factory = TypeFactory.defaultInstance().withClassLoader(null);
        assertNull(factory.getClassLoader());
    }

    @Test
    public void testWithNullModifierCreatesUsableFactory() throws Exception {
        TypeFactory factory = TypeFactory.defaultInstance().withModifier(null);
        assertEquals(String.class, factory.constructType(String.class).getRawClass());
    }

    @Test
    public void testRawClassForClassInput() throws Exception {
        assertEquals(String.class, TypeFactory.rawClass(String.class));
        assertEquals(int.class, TypeFactory.rawClass(int.class));
    }

    @Test
    public void testFindPrimitiveClassNames() throws Exception {
        TypeFactory factory = TypeFactory.defaultInstance();
        assertEquals(int.class, factory.findClass("int"));
        assertEquals(void.class, factory.findClass("void"));
    }

    @Test
    public void testFindRegularClassName() throws Exception {
        assertEquals(String.class, TypeFactory.defaultInstance().findClass("java.lang.String"));
    }

    @Test
    public void testConstructArrayTypeFromClass() throws Exception {
        ArrayType type = TypeFactory.defaultInstance().constructArrayType(String.class);
        assertEquals(String[].class, type.getRawClass());
        assertEquals(String.class, type.getContentType().getRawClass());
    }

    @Test
    public void testConstructCollectionType() throws Exception {
        CollectionType type = TypeFactory.defaultInstance()
                .constructCollectionType(ArrayList.class, String.class);
        assertEquals(ArrayList.class, type.getRawClass());
        assertEquals(String.class, type.getContentType().getRawClass());
    }

    @Test
    public void testConstructRawCollectionType() throws Exception {
        CollectionType type = TypeFactory.defaultInstance().constructRawCollectionType(ArrayList.class);
        assertEquals(ArrayList.class, type.getRawClass());
        assertEquals(Object.class, type.getContentType().getRawClass());
    }

    @Test
    public void testConstructCollectionLikeTypeForIterable() throws Exception {
        CollectionLikeType type = TypeFactory.defaultInstance()
                .constructCollectionLikeType(Iterable.class, String.class);
        assertEquals(Iterable.class, type.getRawClass());
        assertEquals(String.class, type.getContentType().getRawClass());
    }

    @Test
    public void testConstructRawCollectionLikeType() throws Exception {
        CollectionLikeType type = TypeFactory.defaultInstance()
                .constructRawCollectionLikeType(Iterable.class);
        assertEquals(Iterable.class, type.getRawClass());
        assertEquals(Object.class, type.getContentType().getRawClass());
    }

    @Test
    public void testConstructMapType() throws Exception {
        MapType type = TypeFactory.defaultInstance()
                .constructMapType(HashMap.class, String.class, Integer.class);
        assertEquals(HashMap.class, type.getRawClass());
        assertEquals(String.class, type.getKeyType().getRawClass());
        assertEquals(Integer.class, type.getContentType().getRawClass());
    }

    @Test
    public void testPropertiesUsesStringTypes() throws Exception {
        JavaType type = TypeFactory.defaultInstance().constructType(Properties.class);
        assertEquals(Properties.class, type.getRawClass());
        assertEquals(String.class, type.getKeyType().getRawClass());
        assertEquals(String.class, type.getContentType().getRawClass());
    }

    @Test
    public void testConstructRawMapType() throws Exception {
        MapType type = TypeFactory.defaultInstance().constructRawMapType(HashMap.class);
        assertEquals(HashMap.class, type.getRawClass());
        assertEquals(Object.class, type.getKeyType().getRawClass());
        assertEquals(Object.class, type.getContentType().getRawClass());
    }

    @Test
    public void testConstructMapLikeType() throws Exception {
        MapLikeType type = TypeFactory.defaultInstance()
                .constructMapLikeType(Map.Entry.class, String.class, Integer.class);
        assertEquals(Map.Entry.class, type.getRawClass());
        assertEquals(String.class, type.getKeyType().getRawClass());
        assertEquals(Integer.class, type.getContentType().getRawClass());
    }

    @Test
    public void testConstructRawMapLikeType() throws Exception {
        MapLikeType type = TypeFactory.defaultInstance().constructRawMapLikeType(Map.Entry.class);
        assertEquals(Map.Entry.class, type.getRawClass());
        assertEquals(Object.class, type.getKeyType().getRawClass());
        assertEquals(Object.class, type.getContentType().getRawClass());
    }

    @Test
    public void testConstructReferenceType() throws Exception {
        TypeFactory factory = TypeFactory.defaultInstance();
        JavaType type = factory.constructReferenceType(AtomicReference.class, factory.constructType(String.class));
        assertEquals(AtomicReference.class, type.getRawClass());
        assertEquals(String.class, type.getContentType().getRawClass());
    }

    @Test
    public void testConstructSpecializedTypePreservesCollectionElement() throws Exception {
        TypeFactory factory = TypeFactory.defaultInstance();
        JavaType base = factory.constructCollectionType(Collection.class, String.class);
        JavaType result = factory.constructSpecializedType(base, ArrayList.class);
        assertEquals(ArrayList.class, result.getRawClass());
        assertEquals(String.class, result.getContentType().getRawClass());
    }

    @Test
    public void testConstructSpecializedTypeRejectsUnrelatedClass() throws Exception {
        TypeFactory factory = TypeFactory.defaultInstance();
        JavaType base = factory.constructType(String.class);
        try {
            factory.constructSpecializedType(base, Integer.class);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) { }
    }

    @Test
    public void testConstructGeneralizedTypeFindsParameterizedSupertype() throws Exception {
        TypeFactory factory = TypeFactory.defaultInstance();
        JavaType base = factory.constructCollectionType(ArrayList.class, String.class);
        JavaType result = factory.constructGeneralizedType(base, Collection.class);
        assertEquals(Collection.class, result.getRawClass());
        assertEquals(String.class, result.getContentType().getRawClass());
    }

    @Test
    public void testConstructGeneralizedTypeRejectsUnrelatedClass() throws Exception {
        TypeFactory factory = TypeFactory.defaultInstance();
        try {
            factory.constructGeneralizedType(factory.constructType(String.class), Integer.class);
            fail("expected IllegalArgumentException");
        } catch (IllegalArgumentException expected) { }
    }

    @Test
    public void testFindTypeParametersOnParameterizedList() throws Exception {
        TypeFactory factory = TypeFactory.defaultInstance();
        JavaType list = factory.constructCollectionType(ArrayList.class, String.class);
        JavaType[] parameters = factory.findTypeParameters(list, Collection.class);
        assertEquals(1, parameters.length);
        assertEquals(String.class, parameters[0].getRawClass());
    }

    @Test
    public void testFindTypeParametersForUnrelatedTypeIsEmpty() throws Exception {
        TypeFactory factory = TypeFactory.defaultInstance();
        JavaType[] parameters = factory.findTypeParameters(factory.constructType(String.class), Map.class);
        assertEquals(0, parameters.length);
    }

    @Test
    public void testMoreSpecificTypeSelectsSubtype() throws Exception {
        TypeFactory factory = TypeFactory.defaultInstance();
        JavaType parent = factory.constructType(Number.class);
        JavaType child = factory.constructType(Integer.class);
        assertSame(child, factory.moreSpecificType(parent, child));
        assertSame(child, factory.moreSpecificType(child, parent));
    }

    @Test
    public void testMoreSpecificTypeHandlesNull() throws Exception {
        TypeFactory factory = TypeFactory.defaultInstance();
        JavaType value = factory.constructType(String.class);
        assertSame(value, factory.moreSpecificType(null, value));
        assertSame(value, factory.moreSpecificType(value, null));
    }

    @Test
    public void testCanonicalRoundTrip() throws Exception {
        TypeFactory factory = TypeFactory.defaultInstance();
        JavaType original = factory.constructCollectionType(ArrayList.class, String.class);
        JavaType parsed = factory.constructFromCanonical(original.toCanonical());
        assertEquals(original.getRawClass(), parsed.getRawClass());
        assertEquals(String.class, parsed.getContentType().getRawClass());
    }

    @Test
    public void testClearCacheDoesNotChangeResolvedType() throws Exception {
        TypeFactory factory = TypeFactory.defaultInstance().withClassLoader(null);
        assertEquals(Integer.class, factory.constructType(Integer.class).getRawClass());
        factory.clearCache();
        assertEquals(Integer.class, factory.constructType(Integer.class).getRawClass());
    }

    @Test
    public void testUncheckedSimpleTypeUsesRequestedClass() throws Exception {
        JavaType type = TypeFactory.defaultInstance().uncheckedSimpleType(Integer.class);
        assertEquals(Integer.class, type.getRawClass());
    }
}
