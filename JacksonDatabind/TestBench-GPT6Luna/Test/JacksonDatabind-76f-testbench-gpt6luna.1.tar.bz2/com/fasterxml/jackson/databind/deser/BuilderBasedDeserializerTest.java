package com.fasterxml.jackson.databind.deser;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.util.*;
import com.fasterxml.jackson.core.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.deser.impl.*;
import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
import com.fasterxml.jackson.databind.util.NameTransformer;
import com.fasterxml.jackson.databind.util.TokenBuffer;

public class BuilderBasedDeserializerTest {
    @Test
    public void testUnwrappingDeserializerWithoutTransformer() {}
// Defects4J: flaky method
//     @Test
//     public void testUnwrappingDeserializerWithoutTransformer() throws Exception {
//         fail("Cannot construct a configured BuilderBasedDeserializer using the visible API");
//     }

    @Test
    public void testUnwrappingDeserializerWithTransformer() {}
// Defects4J: flaky method
//     @Test
//     public void testUnwrappingDeserializerWithTransformer() throws Exception {
//         fail("Cannot construct a configured BuilderBasedDeserializer using the visible API");
//     }

    @Test
    public void testWithObjectIdReader() {}
// Defects4J: flaky method
//     @Test
//     public void testWithObjectIdReader() throws Exception {
//         fail("Cannot construct a configured BuilderBasedDeserializer using the visible API");
//     }

    @Test
    public void testWithIgnorablePropertiesEmpty() {}
// Defects4J: flaky method
//     @Test
//     public void testWithIgnorablePropertiesEmpty() throws Exception {
//         fail("Cannot construct a configured BuilderBasedDeserializer using the visible API");
//     }

    @Test
    public void testWithIgnorablePropertiesNonempty() {}
// Defects4J: flaky method
//     @Test
//     public void testWithIgnorablePropertiesNonempty() throws Exception {
//         fail("Cannot construct a configured BuilderBasedDeserializer using the visible API");
//     }

    @Test
    public void testWithBeanProperties() {}
// Defects4J: flaky method
//     @Test
//     public void testWithBeanProperties() throws Exception {
//         fail("Cannot construct a configured BuilderBasedDeserializer using the visible API");
//     }

    @Test
    public void testDeserializeStartObject() {}
// Defects4J: flaky method
//     @Test
//     public void testDeserializeStartObject() throws Exception {
//         fail("Cannot construct a configured BuilderBasedDeserializer using the visible API");
//     }

    @Test
    public void testDeserializeStringToken() {}
// Defects4J: flaky method
//     @Test
//     public void testDeserializeStringToken() throws Exception {
//         fail("Cannot construct a configured BuilderBasedDeserializer using the visible API");
//     }

    @Test
    public void testDeserializeIntegerToken() {}
// Defects4J: flaky method
//     @Test
//     public void testDeserializeIntegerToken() throws Exception {
//         fail("Cannot construct a configured BuilderBasedDeserializer using the visible API");
//     }

    @Test
    public void testDeserializeFloatingPointToken() {}
// Defects4J: flaky method
//     @Test
//     public void testDeserializeFloatingPointToken() throws Exception {
//         fail("Cannot construct a configured BuilderBasedDeserializer using the visible API");
//     }

    @Test
    public void testDeserializeEmbeddedObjectToken() {}
// Defects4J: flaky method
//     @Test
//     public void testDeserializeEmbeddedObjectToken() throws Exception {
//         fail("Cannot construct a configured BuilderBasedDeserializer using the visible API");
//     }

    @Test
    public void testDeserializeTrueToken() {}
// Defects4J: flaky method
//     @Test
//     public void testDeserializeTrueToken() throws Exception {
//         fail("Cannot construct a configured BuilderBasedDeserializer using the visible API");
//     }

    @Test
    public void testDeserializeFalseToken() {}
// Defects4J: flaky method
//     @Test
//     public void testDeserializeFalseToken() throws Exception {
//         fail("Cannot construct a configured BuilderBasedDeserializer using the visible API");
//     }

    @Test
    public void testDeserializeArrayToken() {}
// Defects4J: flaky method
//     @Test
//     public void testDeserializeArrayToken() throws Exception {
//         fail("Cannot construct a configured BuilderBasedDeserializer using the visible API");
//     }

    @Test
    public void testDeserializeFieldNameToken() {}
// Defects4J: flaky method
//     @Test
//     public void testDeserializeFieldNameToken() throws Exception {
//         fail("Cannot construct a configured BuilderBasedDeserializer using the visible API");
//     }

    @Test
    public void testDeserializeEndObjectToken() {}
// Defects4J: flaky method
//     @Test
//     public void testDeserializeEndObjectToken() throws Exception {
//         fail("Cannot construct a configured BuilderBasedDeserializer using the visible API");
//     }

    @Test
    public void testDeserializeNullToken() {}
// Defects4J: flaky method
//     @Test
//     public void testDeserializeNullToken() throws Exception {
//         fail("Cannot construct a configured BuilderBasedDeserializer using the visible API");
//     }

    @Test
    public void testDeserializeFromObject() {}
// Defects4J: flaky method
//     @Test
//     public void testDeserializeFromObject() throws Exception {
//         fail("Cannot construct a configured BuilderBasedDeserializer using the visible API");
//     }

    @Test
    public void testUnwrappingDeserializerWithSimpleTransformer() {}
// Defects4J: flaky method
//     @Test
//     public void testUnwrappingDeserializerWithSimpleTransformer() throws Exception {
//         fail("Cannot construct a configured BuilderBasedDeserializer using the visible API");
//     }

    @Test
    public void testUnwrappingDeserializerWithNullTransformer() {}
// Defects4J: flaky method
//     @Test
//     public void testUnwrappingDeserializerWithNullTransformer() throws Exception {
//         fail("Cannot construct a configured BuilderBasedDeserializer using the visible API");
//     }

    @Test
    public void testWithObjectIdReaderNull() {}
// Defects4J: flaky method
//     @Test
//     public void testWithObjectIdReaderNull() throws Exception {
//         fail("Cannot construct a configured BuilderBasedDeserializer using the visible API");
//     }

    @Test
    public void testWithObjectIdReaderNonNull() {}
// Defects4J: flaky method
//     @Test
//     public void testWithObjectIdReaderNonNull() throws Exception {
//         fail("Cannot construct a configured BuilderBasedDeserializer using the visible API");
//     }

    @Test
    public void testWithIgnorablePropertiesNull() {}
// Defects4J: flaky method
//     @Test
//     public void testWithIgnorablePropertiesNull() throws Exception {
//         fail("Cannot construct a configured BuilderBasedDeserializer using the visible API");
//     }

    @Test
    public void testWithIgnorablePropertiesOneName() {}
// Defects4J: flaky method
//     @Test
//     public void testWithIgnorablePropertiesOneName() throws Exception {
//         fail("Cannot construct a configured BuilderBasedDeserializer using the visible API");
//     }

    @Test
    public void testWithBeanPropertiesNull() {}
// Defects4J: flaky method
//     @Test
//     public void testWithBeanPropertiesNull() throws Exception {
//         fail("Cannot construct a configured BuilderBasedDeserializer using the visible API");
//     }

    @Test
    public void testWithBeanPropertiesEmptyMap() {}
// Defects4J: flaky method
//     @Test
//     public void testWithBeanPropertiesEmptyMap() throws Exception {
//         fail("Cannot construct a configured BuilderBasedDeserializer using the visible API");
//     }

    @Test
    public void testDeserializeFromObjectAtEndObject() {}
// Defects4J: flaky method
//     @Test
//     public void testDeserializeFromObjectAtEndObject() throws Exception {
//         fail("Cannot construct a configured BuilderBasedDeserializer using the visible API");
//     }

    @Test
    public void testDeserializeFromObjectAtFieldName() {}
// Defects4J: flaky method
//     @Test
//     public void testDeserializeFromObjectAtFieldName() throws Exception {
//         fail("Cannot construct a configured BuilderBasedDeserializer using the visible API");
//     }
}
