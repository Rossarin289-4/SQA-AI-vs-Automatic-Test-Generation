package org.jfree.chart.plot;

import org.junit.Test;
import static org.junit.Assert.*;
import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.TreeMap;
import org.jfree.chart.LegendItem;
import org.jfree.chart.LegendItemCollection;
import org.jfree.chart.PaintMap;
import org.jfree.chart.StrokeMap;
import org.jfree.chart.entity.EntityCollection;
import org.jfree.chart.entity.PieSectionEntity;
import org.jfree.chart.event.PlotChangeEvent;
import org.jfree.chart.labels.PieSectionLabelGenerator;
import org.jfree.chart.labels.PieToolTipGenerator;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.text.G2TextMeasurer;
import org.jfree.chart.text.TextAnchor;
import org.jfree.chart.text.TextBlock;
import org.jfree.chart.text.TextBox;
import org.jfree.chart.text.TextUtilities;
import org.jfree.chart.urls.PieURLGenerator;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.chart.util.PaintUtilities;
import org.jfree.chart.util.PublicCloneable;
import org.jfree.chart.util.RectangleAnchor;
import org.jfree.chart.util.RectangleInsets;
import org.jfree.chart.util.Rotation;
import org.jfree.chart.util.SerialUtilities;
import org.jfree.chart.util.ShapeUtilities;
import org.jfree.chart.util.UnitType;
import org.jfree.data.DefaultKeyedValues;
import org.jfree.data.KeyedValues;
import org.jfree.data.general.DatasetChangeEvent;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.data.general.PieDataset;

public class PiePlotTest {

    @Test
    public void testDefaultDatasetAndAngle() throws Exception {
        PiePlot plot = new PiePlot();
        assertNull(plot.getDataset());
        assertEquals(90.0, plot.getStartAngle(), 0.0);
    }

    @Test
    public void testSetPieIndexAndStartAngle() throws Exception {
        PiePlot plot = new PiePlot();
        plot.setPieIndex(-1);
        plot.setStartAngle(0.0);
        assertEquals(-1, plot.getPieIndex());
        assertEquals(0.0, plot.getStartAngle(), 0.0);
    }

    @Test
    public void testSetDirection() throws Exception {
        PiePlot plot = new PiePlot();
        plot.setDirection(Rotation.ANTICLOCKWISE);
        assertEquals(Rotation.ANTICLOCKWISE, plot.getDirection());
    }

    @Test
    public void testNullDirectionRejected() throws Exception {
        PiePlot plot = new PiePlot();
        try {
            plot.setDirection(null);
            fail("expected IllegalArgumentException");
        }
        catch (IllegalArgumentException expected) {
            assertEquals(Rotation.CLOCKWISE, plot.getDirection());
        }
    }

    @Test
    public void testInteriorGapBoundaryValues() throws Exception {
        PiePlot plot = new PiePlot();
        plot.setInteriorGap(0.0);
        assertEquals(0.0, plot.getInteriorGap(), 0.0);
        plot.setInteriorGap(PiePlot.MAX_INTERIOR_GAP);
        assertEquals(0.40, plot.getInteriorGap(), 0.0);
    }

    @Test
    public void testInteriorGapRejectsAboveMaximum() throws Exception {
        PiePlot plot = new PiePlot();
        try {
            plot.setInteriorGap(0.41);
            fail("expected IllegalArgumentException");
        }
        catch (IllegalArgumentException expected) {
            assertEquals(PiePlot.DEFAULT_INTERIOR_GAP, plot.getInteriorGap(),
                    0.0);
        }
    }

    @Test
    public void testSetCircular() throws Exception {
        PiePlot plot = new PiePlot();
        plot.setCircular(false);
        assertFalse(plot.isCircular());
        plot.setCircular(true);
        assertTrue(plot.isCircular());
    }

    @Test
    public void testIgnoreValueFlags() throws Exception {
        PiePlot plot = new PiePlot();
        plot.setIgnoreNullValues(true);
        plot.setIgnoreZeroValues(true);
        assertTrue(plot.getIgnoreNullValues());
        assertTrue(plot.getIgnoreZeroValues());
    }

    @Test
    public void testSectionPaintMappingAndBasePaint() throws Exception {
        PiePlot plot = new PiePlot();
        Color section = Color.red;
        Color base = Color.blue;
        plot.setSectionPaint("a", section);
        plot.setBaseSectionPaint(base);
        assertSame(section, plot.getSectionPaint("a"));
        assertSame(base, plot.getBaseSectionPaint());
        assertNull(plot.getSectionPaint("missing"));
    }

    @Test
    public void testNullBaseSectionPaintRejected() throws Exception {
        PiePlot plot = new PiePlot();
        try {
            plot.setBaseSectionPaint(null);
            fail("expected IllegalArgumentException");
        }
        catch (IllegalArgumentException expected) {
            assertSame(Color.gray, plot.getBaseSectionPaint());
        }
    }

    @Test
    public void testSectionOutlineProperties() throws Exception {
        PiePlot plot = new PiePlot();
        Color paint = Color.green;
        Stroke stroke = new BasicStroke(2.0f);
        plot.setSectionOutlinesVisible(false);
        plot.setSectionOutlinePaint("a", paint);
        plot.setSectionOutlineStroke("a", stroke);
        assertFalse(plot.getSectionOutlinesVisible());
        assertSame(paint, plot.getSectionOutlinePaint("a"));
        assertSame(stroke, plot.getSectionOutlineStroke("a"));
    }

    @Test
    public void testBaseOutlineProperties() throws Exception {
        PiePlot plot = new PiePlot();
        Color paint = Color.orange;
        Stroke stroke = new BasicStroke(3.0f);
        plot.setBaseSectionOutlinePaint(paint);
        plot.setBaseSectionOutlineStroke(stroke);
        assertSame(paint, plot.getBaseSectionOutlinePaint());
        assertSame(stroke, plot.getBaseSectionOutlineStroke());
    }

    @Test
    public void testShadowProperties() throws Exception {
        PiePlot plot = new PiePlot();
        plot.setShadowPaint(null);
        plot.setShadowXOffset(-2.0);
        plot.setShadowYOffset(0.0);
        assertNull(plot.getShadowPaint());
        assertEquals(-2.0, plot.getShadowXOffset(), 0.0);
        assertEquals(0.0, plot.getShadowYOffset(), 0.0);
    }

    @Test
    public void testExplodePercentAndMaximumWithoutDataset() throws Exception {
        PiePlot plot = new PiePlot();
        plot.setExplodePercent("a", 0.25);
        assertEquals(0.25, plot.getExplodePercent("a"), 0.0);
        assertEquals(0.0, plot.getExplodePercent("missing"), 0.0);
        assertEquals(0.0, plot.getMaximumExplodePercent(), 0.0);
    }

    @Test
    public void testLabelSpacingAndVisibilityProperties() throws Exception {
        PiePlot plot = new PiePlot();
        plot.setLabelGap(0.0);
        plot.setMaximumLabelWidth(0.25);
        plot.setLabelLinksVisible(false);
        plot.setLabelLinkMargin(0.0);
        assertEquals(0.0, plot.getLabelGap(), 0.0);
        assertEquals(0.25, plot.getMaximumLabelWidth(), 0.0);
        assertFalse(plot.getLabelLinksVisible());
        assertEquals(0.0, plot.getLabelLinkMargin(), 0.0);
    }

    @Test
    public void testLabelLinkPaintAndStroke() throws Exception {
        PiePlot plot = new PiePlot();
        Color paint = Color.magenta;
        Stroke stroke = new BasicStroke(1.5f);
        plot.setLabelLinkPaint(paint);
        plot.setLabelLinkStroke(stroke);
        assertSame(paint, plot.getLabelLinkPaint());
        assertSame(stroke, plot.getLabelLinkStroke());
    }

    @Test
    public void testLabelFontAndPaint() throws Exception {
        PiePlot plot = new PiePlot();
        Font font = new Font("Serif", Font.BOLD, 12);
        Color paint = Color.cyan;
        plot.setLabelFont(font);
        plot.setLabelPaint(paint);
        assertSame(font, plot.getLabelFont());
        assertSame(paint, plot.getLabelPaint());
    }

    @Test
    public void testOptionalLabelPaintsCanBeCleared() throws Exception {
        PiePlot plot = new PiePlot();
        plot.setLabelBackgroundPaint(null);
        plot.setLabelOutlinePaint(null);
        assertNull(plot.getLabelBackgroundPaint());
        assertNull(plot.getLabelOutlinePaint());
    }

    @Test
    public void testInvalidLabelLinkPaintRejected() throws Exception {
        PiePlot plot = new PiePlot();
        try {
            plot.setLabelLinkPaint(null);
            fail("expected IllegalArgumentException");
        }
        catch (IllegalArgumentException expected) {
            assertSame(Color.black, plot.getLabelLinkPaint());
        }
    }
}
