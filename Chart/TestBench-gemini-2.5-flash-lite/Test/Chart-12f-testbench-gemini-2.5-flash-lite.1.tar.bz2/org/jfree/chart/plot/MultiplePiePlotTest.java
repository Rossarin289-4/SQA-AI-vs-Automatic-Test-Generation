package org.jfree.chart.plot;

import org.junit.Test;
import static org.junit.Assert.*;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Rectangle;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.jfree.chart.ChartRenderingInfo;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.LegendItem;
import org.jfree.chart.LegendItemCollection;
import org.jfree.chart.event.PlotChangeEvent;
import org.jfree.chart.title.TextTitle;
import org.jfree.chart.util.ObjectUtilities;
import org.jfree.chart.util.PaintUtilities;
import org.jfree.chart.util.RectangleEdge;
import org.jfree.chart.util.RectangleInsets;
import org.jfree.chart.util.SerialUtilities;
import org.jfree.chart.util.TableOrder;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.CategoryToPieDataset;
import org.jfree.data.general.DatasetChangeEvent;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.data.general.PieDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.PlotRenderingInfo;
import org.jfree.chart.plot.PlotState;
import org.jfree.chart.util.RectangleAnchor;


public class MultiplePiePlotTest {

    @Test
    public void testConstructorDefault() throws Exception {
        MultiplePiePlot plot = new MultiplePiePlot();
        assertNotNull(plot);
        assertNull(plot.getDataset());
        assertEquals(TableOrder.BY_COLUMN, plot.getDataExtractOrder());
        assertEquals(0.0, plot.getLimit(), 0.0);
        assertEquals("Other", plot.getAggregatedItemsKey());
        assertEquals(Color.lightGray, plot.getAggregatedItemsPaint());
        assertEquals("Multiple Pie Plot", plot.getPlotType());
        assertNotNull(plot.getPieChart());
        assertTrue(plot.getPieChart().getPlot() instanceof PiePlot);
    }

    @Test
    public void testConstructorWithDataset() throws Exception {
        CategoryDataset dataset = new DefaultCategoryDataset();
        MultiplePiePlot plot = new MultiplePiePlot(dataset);
        assertNotNull(plot);
        assertEquals(dataset, plot.getDataset());
    }

    @Test
    public void testSetDatasetNull() throws Exception {
        MultiplePiePlot plot = new MultiplePiePlot();
        plot.setDataset(null);
        assertNull(plot.getDataset());
    }

    @Test
    public void testSetPieChart() throws Exception {
        MultiplePiePlot plot = new MultiplePiePlot();
        JFreeChart newPieChart = new JFreeChart(new PiePlot());
        plot.setPieChart(newPieChart);
        assertEquals(newPieChart, plot.getPieChart());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSetPieChartNull() throws Exception {
        MultiplePiePlot plot = new MultiplePiePlot();
        plot.setPieChart(null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSetPieChartInvalidPlotType() throws Exception {
        MultiplePiePlot plot = new MultiplePiePlot();
        JFreeChart invalidChart = new JFreeChart(new org.jfree.chart.plot.CategoryPlot());
        plot.setPieChart(invalidChart);
    }

    @Test
    public void testSetDataExtractOrder() throws Exception {
        MultiplePiePlot plot = new MultiplePiePlot();
        plot.setDataExtractOrder(TableOrder.BY_ROW);
        assertEquals(TableOrder.BY_ROW, plot.getDataExtractOrder());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSetDataExtractOrderNull() throws Exception {
        MultiplePiePlot plot = new MultiplePiePlot();
        plot.setDataExtractOrder(null);
    }

    @Test
    public void testSetLimit() throws Exception {
        MultiplePiePlot plot = new MultiplePiePlot();
        plot.setLimit(0.1);
        assertEquals(0.1, plot.getLimit(), 0.0);
    }

    @Test
    public void testSetLimitZero() throws Exception {
        MultiplePiePlot plot = new MultiplePiePlot();
        plot.setLimit(0.0);
        assertEquals(0.0, plot.getLimit(), 0.0);
    }

    @Test
    public void testSetAggregatedItemsKey() throws Exception {
        MultiplePiePlot plot = new MultiplePiePlot();
        plot.setAggregatedItemsKey("Custom Key");
        assertEquals("Custom Key", plot.getAggregatedItemsKey());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSetAggregatedItemsKeyNull() throws Exception {
        MultiplePiePlot plot = new MultiplePiePlot();
        plot.setAggregatedItemsKey(null);
    }

    @Test
    public void testSetAggregatedItemsPaint() throws Exception {
        MultiplePiePlot plot = new MultiplePiePlot();
        Paint customPaint = Color.BLUE;
        plot.setAggregatedItemsPaint(customPaint);
        assertEquals(customPaint, plot.getAggregatedItemsPaint());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSetAggregatedItemsPaintNull() throws Exception {
        MultiplePiePlot plot = new MultiplePiePlot();
        plot.setAggregatedItemsPaint(null);
    }

    @Test
    public void testGetPlotType() throws Exception {
        MultiplePiePlot plot = new MultiplePiePlot();
        assertEquals("Multiple Pie Plot", plot.getPlotType());
    }

    // Test setup for draw and getLegendItems
    private DefaultCategoryDataset createSampleDataset() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(10, "Row1", "Col1");
        dataset.addValue(20, "Row1", "Col2");
        dataset.addValue(30, "Row2", "Col1");
        dataset.addValue(40, "Row2", "Col2");
        return dataset;
    }

    @Test
    public void testGetLegendItemsEmptyDataset() throws Exception {
        MultiplePiePlot plot = new MultiplePiePlot();
        LegendItemCollection collection = plot.getLegendItems();
        assertNotNull(collection);
        assertEquals(0, collection.getItemCount());
    }

    @Test
    public void testGetLegendItemsWithData() throws Exception {
        MultiplePiePlot plot = new MultiplePiePlot(createSampleDataset());
        plot.setDataExtractOrder(TableOrder.BY_COLUMN);
        plot.setAggregatedItemsPaint(Color.GRAY);
        plot.setLimit(0.1); // To potentially trigger aggregated item
        LegendItemCollection collection = plot.getLegendItems();
        assertNotNull(collection);
        // Expecting legend items for Col1, Col2 and potentially "Other" if limit is hit
        assertTrue(collection.getItemCount() >= 2);
    }

    @Test
    public void testEquals() throws Exception {
        MultiplePiePlot plot1 = new MultiplePiePlot();
        MultiplePiePlot plot2 = new MultiplePiePlot();
        assertTrue(plot1.equals(plot2));

        plot1.setDataExtractOrder(TableOrder.BY_ROW);
        assertFalse(plot1.equals(plot2));
        plot2.setDataExtractOrder(TableOrder.BY_ROW);
        assertTrue(plot1.equals(plot2));

        plot1.setLimit(0.1);
        assertFalse(plot1.equals(plot2));
        plot2.setLimit(0.1);
        assertTrue(plot1.equals(plot2));

        plot1.setAggregatedItemsKey("Key1");
        assertFalse(plot1.equals(plot2));
        plot2.setAggregatedItemsKey("Key1");
        assertTrue(plot1.equals(plot2));

        plot1.setAggregatedItemsPaint(Color.RED);
        assertFalse(plot1.equals(plot2));
        plot2.setAggregatedItemsPaint(Color.RED);
        assertTrue(plot1.equals(plot2));

        JFreeChart pieChart1 = new JFreeChart(new PiePlot());
        JFreeChart pieChart2 = new JFreeChart(new PiePlot());
        plot1.setPieChart(pieChart1);
        assertFalse(plot1.equals(plot2));
        // Fix: Ensure plot2 uses the same pieChart instance for the equals check to pass
        plot2.setPieChart(pieChart1);
        assertTrue(plot1.equals(plot2));
    }

    @Test
    public void testNotEqualsDifferentDataExtractOrder() throws Exception {
        MultiplePiePlot plot1 = new MultiplePiePlot();
        MultiplePiePlot plot2 = new MultiplePiePlot();
        plot1.setDataExtractOrder(TableOrder.BY_ROW);
        assertFalse(plot1.equals(plot2));
    }

    @Test
    public void testNotEqualsDifferentLimit() throws Exception {
        MultiplePiePlot plot1 = new MultiplePiePlot();
        MultiplePiePlot plot2 = new MultiplePiePlot();
        plot1.setLimit(0.1);
        assertFalse(plot1.equals(plot2));
    }

    @Test
    public void testNotEqualsDifferentAggregatedItemsKey() throws Exception {
        MultiplePiePlot plot1 = new MultiplePiePlot();
        MultiplePiePlot plot2 = new MultiplePiePlot();
        plot1.setAggregatedItemsKey("Custom");
        assertFalse(plot1.equals(plot2));
    }

    @Test
    public void testNotEqualsDifferentAggregatedItemsPaint() throws Exception {
        MultiplePiePlot plot1 = new MultiplePiePlot();
        MultiplePiePlot plot2 = new MultiplePiePlot();
        plot1.setAggregatedItemsPaint(Color.BLUE);
        assertFalse(plot1.equals(plot2));
    }

    @Test
    public void testNotEqualsDifferentPieChart() {}
// Defects4J: flaky method
//     @Test
//     public void testNotEqualsDifferentPieChart() throws Exception {
//         MultiplePiePlot plot1 = new MultiplePiePlot();
//         MultiplePiePlot plot2 = new MultiplePiePlot();
//         JFreeChart pieChart1 = new JFreeChart(new PiePlot());
//         JFreeChart pieChart2 = new JFreeChart(new PiePlot());
//         plot1.setPieChart(pieChart1);
//         plot2.setPieChart(pieChart2);
//         assertFalse(plot1.equals(plot2));
//     }

    // Serialization tests (basic checks)
    @Test
    public void testSerialization() throws Exception {
        MultiplePiePlot plot = new MultiplePiePlot(createSampleDataset());
        plot.setLimit(0.1);
        plot.setAggregatedItemsPaint(Color.CYAN);

        MultiplePiePlot deserializedPlot = (MultiplePiePlot) ObjectUtilities.clone(plot);

        assertEquals(plot.getDataset(), deserializedPlot.getDataset());
        assertEquals(plot.getDataExtractOrder(), deserializedPlot.getDataExtractOrder());
        assertEquals(plot.getLimit(), deserializedPlot.getLimit(), 0.0);
        assertEquals(plot.getAggregatedItemsKey(), deserializedPlot.getAggregatedItemsKey());
        assertTrue(PaintUtilities.equal(plot.getAggregatedItemsPaint(), deserializedPlot.getAggregatedItemsPaint()));
        // PieChart is a deep clone in ObjectUtilities.clone, so not a direct reference check needed
        assertTrue(ObjectUtilities.equal(plot.getPieChart(), deserializedPlot.getPieChart()));
    }

    @Test
    public void testSerializationWithNullDataset() throws Exception {
        MultiplePiePlot plot = new MultiplePiePlot(null);
        MultiplePiePlot deserializedPlot = (MultiplePiePlot) ObjectUtilities.clone(plot);
        assertNull(deserializedPlot.getDataset());
    }
}
