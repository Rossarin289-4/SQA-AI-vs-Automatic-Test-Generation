package org.apache.commons.math.ode;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;
import org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver;
import org.apache.commons.math.analysis.solvers.UnivariateRealSolver;
import org.apache.commons.math.exception.DimensionMismatchException;
import org.apache.commons.math.exception.MathIllegalArgumentException;
import org.apache.commons.math.exception.MathIllegalStateException;
import org.apache.commons.math.exception.MaxCountExceededException;
import org.apache.commons.math.exception.NumberIsTooSmallException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.ode.events.EventHandler;
import org.apache.commons.math.ode.events.EventState;
import org.apache.commons.math.ode.sampling.AbstractStepInterpolator;
import org.apache.commons.math.ode.sampling.StepHandler;
import org.apache.commons.math.util.FastMath;
import org.apache.commons.math.util.Incrementor;
import org.apache.commons.math.util.Precision;
import org.apache.commons.math.ode.nonstiff.ThreeEighthesIntegrator;
import org.apache.commons.math.ode.nonstiff.EulerIntegrator;
import org.apache.commons.math.ode.nonstiff.MidpointIntegrator;
import org.apache.commons.math.ode.nonstiff.GraggBulirschStoerIntegrator;
import org.apache.commons.math.ode.nonstiff.ClassicalRungeKuttaIntegrator;
import org.apache.commons.math.ode.nonstiff.GillIntegrator;

public class AbstractIntegratorTest {
    @Test
    public void testNameAndInitialSteps() throws Exception {
        EulerIntegrator integrator = new EulerIntegrator(0.1);
        assertEquals("Euler", integrator.getName());
        assertTrue(Double.isNaN(integrator.getCurrentStepStart()));
        assertTrue(Double.isNaN(integrator.getCurrentSignedStepsize()));
    }

    @Test
    public void testStepHandlersAddGetAndClear() throws Exception {
        EulerIntegrator integrator = new EulerIntegrator(0.1);
        StepHandler handler = new StepHandler() {
            public void reset() { }
            public void handleStep(org.apache.commons.math.ode.sampling.StepInterpolator i, boolean last) { }
        };
        integrator.addStepHandler(handler);
        assertEquals(1, integrator.getStepHandlers().size());
        assertSame(handler, integrator.getStepHandlers().iterator().next());
        integrator.clearStepHandlers();
        assertEquals(0, integrator.getStepHandlers().size());
    }

    @Test
    public void testStepHandlerCollectionIsUnmodifiable() throws Exception {
        EulerIntegrator integrator = new EulerIntegrator(0.1);
        try {
            integrator.getStepHandlers().clear();
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) { }
        assertEquals(0, integrator.getStepHandlers().size());
    }

    @Test
    public void testEventHandlersAddGetAndClear() throws Exception {
        EulerIntegrator integrator = new EulerIntegrator(0.1);
        EventHandler handler = new EventHandler() {
            public double g(double t, double[] y) { return 1.0; }
            public Action eventOccurred(double t, double[] y, boolean increasing) { return Action.CONTINUE; }
            public void resetState(double t, double[] y) { }
        };
        integrator.addEventHandler(handler, 1.0, 1.0e-6, 10);
        assertEquals(1, integrator.getEventHandlers().size());
        assertSame(handler, integrator.getEventHandlers().iterator().next());
        integrator.clearEventHandlers();
        assertEquals(0, integrator.getEventHandlers().size());
    }

    @Test
    public void testEventHandlerCollectionIsUnmodifiable() throws Exception {
        EulerIntegrator integrator = new EulerIntegrator(0.1);
        try {
            integrator.getEventHandlers().clear();
            fail("expected UnsupportedOperationException");
        } catch (UnsupportedOperationException expected) { }
        assertEquals(0, integrator.getEventHandlers().size());
    }

    @Test
    public void testMaxEvaluationsNegativeMeansUnlimited() throws Exception {
        EulerIntegrator integrator = new EulerIntegrator(0.1);
        integrator.setMaxEvaluations(-1);
        assertEquals(Integer.MAX_VALUE, integrator.getMaxEvaluations());
        assertEquals(0, integrator.getEvaluations());
    }

    @Test
    public void testMaxEvaluationsZero() throws Exception {
        EulerIntegrator integrator = new EulerIntegrator(0.1);
        integrator.setMaxEvaluations(0);
        assertEquals(0, integrator.getMaxEvaluations());
    }

    @Test
    public void testMaxEvaluationsPositiveValue() throws Exception {
        EulerIntegrator integrator = new EulerIntegrator(0.1);
        integrator.setMaxEvaluations(7);
        assertEquals(7, integrator.getMaxEvaluations());
    }

    @Test
    public void testMaxEvaluationsLargeValue() throws Exception {
        EulerIntegrator integrator = new EulerIntegrator(0.1);
        integrator.setMaxEvaluations(Integer.MAX_VALUE);
        assertEquals(Integer.MAX_VALUE, integrator.getMaxEvaluations());
    }

    @Test
    public void testZeroSpanIntegration() throws Exception {
        EulerIntegrator integrator = new EulerIntegrator(0.1);
        FirstOrderDifferentialEquations equations = new FirstOrderDifferentialEquations() {
            public int getDimension() { return 1; }
            public void computeDerivatives(double t, double[] y, double[] yDot) { yDot[0] = 1.0; }
        };
        double[] y = { 3.0 };
        try {
            integrator.integrate(equations, 2.0, new double[] { 3.0 }, 2.0, y);
            fail("expected NumberIsTooSmallException");
        } catch (NumberIsTooSmallException expected) { }
    }

    @Test
    public void testInitialStateDimensionMismatch() throws Exception {
        EulerIntegrator integrator = new EulerIntegrator(0.1);
        FirstOrderDifferentialEquations equations = new FirstOrderDifferentialEquations() {
            public int getDimension() { return 1; }
            public void computeDerivatives(double t, double[] y, double[] yDot) { yDot[0] = 0.0; }
        };
        try {
            integrator.integrate(equations, 0.0, new double[0], 1.0, new double[1]);
            fail("expected DimensionMismatchException");
        } catch (DimensionMismatchException expected) { }
    }

    @Test
    public void testOutputStateDimensionMismatch() throws Exception {
        EulerIntegrator integrator = new EulerIntegrator(0.1);
        FirstOrderDifferentialEquations equations = new FirstOrderDifferentialEquations() {
            public int getDimension() { return 1; }
            public void computeDerivatives(double t, double[] y, double[] yDot) { yDot[0] = 0.0; }
        };
        try {
            integrator.integrate(equations, 0.0, new double[1], 1.0, new double[0]);
            fail("expected DimensionMismatchException");
        } catch (DimensionMismatchException expected) { }
    }

    @Test
    public void testComputeDerivativesAndEvaluationCount() throws Exception {
        EulerIntegrator integrator = new EulerIntegrator(0.1);
        FirstOrderDifferentialEquations equations = new FirstOrderDifferentialEquations() {
            public int getDimension() { return 1; }
            public void computeDerivatives(double t, double[] y, double[] yDot) { yDot[0] = 2.0 * y[0]; }
        };
        integrator.setEquations(new ExpandableStatefulODE(equations));
        double[] derivative = { 0.0 };
        integrator.computeDerivatives(1.0, new double[] { 3.0 }, derivative);
        assertEquals(6.0, derivative[0], 0.0);
        assertEquals(1, integrator.getEvaluations());
    }

    @Test
    public void testDerivativeEvaluationLimit() throws Exception {
        EulerIntegrator integrator = new EulerIntegrator(0.1);
        FirstOrderDifferentialEquations equations = new FirstOrderDifferentialEquations() {
            public int getDimension() { return 1; }
            public void computeDerivatives(double t, double[] y, double[] yDot) { yDot[0] = 4.0; }
        };
        integrator.setEquations(new ExpandableStatefulODE(equations));
        integrator.setMaxEvaluations(1);
        double[] derivative = { 0.0 };
        integrator.computeDerivatives(0.0, new double[] { 0.0 }, derivative);
        assertEquals(4.0, derivative[0], 0.0);
        assertEquals(1, integrator.getEvaluations());
    }

    @Test
    public void testDerivativeEvaluationExceedsLimit() throws Exception {
        EulerIntegrator integrator = new EulerIntegrator(0.1);
        FirstOrderDifferentialEquations equations = new FirstOrderDifferentialEquations() {
            public int getDimension() { return 1; }
            public void computeDerivatives(double t, double[] y, double[] yDot) { yDot[0] = 4.0; }
        };
        integrator.setEquations(new ExpandableStatefulODE(equations));
        integrator.setMaxEvaluations(1);
        integrator.computeDerivatives(0.0, new double[] { 0.0 }, new double[1]);
        try {
            integrator.computeDerivatives(1.0, new double[] { 0.0 }, new double[1]);
            fail("expected MaxCountExceededException");
        } catch (MaxCountExceededException expected) { }
        assertEquals(2, integrator.getEvaluations());
    }
}
