package org.apache.commons.math.stat.descriptive;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.Serializable;
import org.apache.commons.math.exception.MathIllegalStateException;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.stat.descriptive.moment.GeometricMean;
import org.apache.commons.math.stat.descriptive.moment.Mean;
import org.apache.commons.math.stat.descriptive.moment.SecondMoment;
import org.apache.commons.math.stat.descriptive.moment.Variance;
import org.apache.commons.math.stat.descriptive.rank.Max;
import org.apache.commons.math.stat.descriptive.rank.Min;
import org.apache.commons.math.stat.descriptive.summary.Sum;
import org.apache.commons.math.stat.descriptive.summary.SumOfLogs;
import org.apache.commons.math.stat.descriptive.summary.SumOfSquares;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.Precision;
import org.apache.commons.math.util.FastMath;

public class SummaryStatisticsTest {
    @Test
    public void testAddAndSummaryStatistics() throws Exception {
        SummaryStatistics s = new SummaryStatistics();
        s.addValue(2.0);
        s.addValue(4.0);
        s.addValue(6.0);
        assertEquals(3, s.getN());
        assertEquals(12.0, s.getSum(), 1e-12);
        assertEquals(56.0, s.getSumsq(), 1e-12);
        assertEquals(4.0, s.getMean(), 1e-12);
        assertEquals(8.0, s.getVariance(), 1e-12);
        assertEquals(8.0 / 3.0, s.getPopulationVariance(), 1e-12);
        assertEquals(6.0, s.getMax(), 1e-12);
        assertEquals(2.0, s.getMin(), 1e-12);
        assertEquals(8.0, s.getSecondMoment(), 1e-12);
        StatisticalSummary summary = s.getSummary();
        assertEquals(3, summary.getN());
        assertEquals(4.0, summary.getMean(), 1e-12);
        assertEquals(8.0, summary.getVariance(), 1e-12);
    }

    @Test
    public void testStandardDeviationForEmptySingletonAndMultipleValues() throws Exception {
        SummaryStatistics s = new SummaryStatistics();
        assertTrue(Double.isNaN(s.getStandardDeviation()));
        s.addValue(7.0);
        assertEquals(0.0, s.getStandardDeviation(), 0.0);
        s.addValue(9.0);
        assertEquals(Math.sqrt(8.0), s.getStandardDeviation(), 1e-12);
    }

    @Test
    public void testGeometricMeanAndSumOfLogs() throws Exception {
        SummaryStatistics s = new SummaryStatistics();
        s.addValue(4.0);
        s.addValue(9.0);
        assertEquals(6.0, s.getGeometricMean(), 1e-12);
        assertEquals(Math.log(36.0), s.getSumOfLogs(), 1e-12);
    }

    @Test
    public void testClearResetsStatisticsAndAllowsReuse() throws Exception {
        SummaryStatistics s = new SummaryStatistics();
        s.addValue(3.0);
        s.addValue(5.0);
        s.clear();
        assertEquals(0, s.getN());
        assertTrue(Double.isNaN(s.getSum()));
        assertTrue(Double.isNaN(s.getMean()));
        assertTrue(Double.isNaN(s.getVariance()));
        s.addValue(8.0);
        assertEquals(1, s.getN());
        assertEquals(8.0, s.getSum(), 0.0);
        assertEquals(0.0, s.getSecondMoment(), 0.0);
    }

    @Test
    public void testConfiguredStatisticImplementationsAndIncrement() throws Exception {
        SummaryStatistics s = new SummaryStatistics();
        Sum sum = new Sum();
        SumOfSquares squares = new SumOfSquares();
        Min min = new Min();
        Max max = new Max();
        SumOfLogs logs = new SumOfLogs();
        GeometricMean geometric = new GeometricMean();
        Mean mean = new Mean();
        Variance variance = new Variance();

        s.setSumImpl(sum);
        s.setSumsqImpl(squares);
        s.setMinImpl(min);
        s.setMaxImpl(max);
        s.setSumLogImpl(logs);
        s.setGeoMeanImpl(geometric);
        s.setMeanImpl(mean);
        s.setVarianceImpl(variance);

        assertSame(sum, s.getSumImpl());
        assertSame(squares, s.getSumsqImpl());
        assertSame(min, s.getMinImpl());
        assertSame(max, s.getMaxImpl());
        assertSame(logs, s.getSumLogImpl());
        assertSame(geometric, s.getGeoMeanImpl());
        assertSame(mean, s.getMeanImpl());
        assertSame(variance, s.getVarianceImpl());

        s.addValue(2.0);
        s.addValue(8.0);
        assertEquals(10.0, s.getSum(), 1e-12);
        assertEquals(68.0, s.getSumsq(), 1e-12);
        assertEquals(2.0, s.getMin(), 1e-12);
        assertEquals(8.0, s.getMax(), 1e-12);
        assertEquals(5.0, s.getMean(), 1e-12);
        assertEquals(18.0, s.getVariance(), 1e-12);
        assertEquals(4.0, s.getGeometricMean(), 1e-12);
    }

    @Test
    public void testSettingStatisticAfterAddingValueIsRejected() throws Exception {
        SummaryStatistics s = new SummaryStatistics();
        s.addValue(1.0);
        try {
            s.setSumImpl(new Sum());
            fail("expected MathIllegalStateException");
        } catch (MathIllegalStateException expected) {
            assertEquals(1, s.getN());
        }
    }

    @Test
    public void testClearAfterConfiguredImplementations() throws Exception {
        SummaryStatistics s = new SummaryStatistics();
        Sum sum = new Sum();
        s.setSumImpl(sum);
        s.addValue(3.0);
        s.clear();
        assertEquals(0, s.getN());
        assertTrue(Double.isNaN(s.getSum()));
        s.addValue(5.0);
        assertEquals(5.0, s.getSum(), 0.0);
    }

    @Test
    public void testCopyPreservesDataAndIsIndependent() throws Exception {
        SummaryStatistics s = new SummaryStatistics();
        s.addValue(2.0);
        s.addValue(6.0);
        SummaryStatistics copy = s.copy();
        assertEquals(s, copy);
        assertEquals(s.hashCode(), copy.hashCode());
        copy.addValue(10.0);
        assertEquals(2, s.getN());
        assertEquals(3, copy.getN());
        assertEquals(4.0, s.getMean(), 1e-12);
        assertEquals(6.0, copy.getMean(), 1e-12);
    }

    @Test
    public void testStaticCopyRejectsNullSourceAndDestination() throws Exception {
        SummaryStatistics source = new SummaryStatistics();
        SummaryStatistics destination = new SummaryStatistics();
        try {
            SummaryStatistics.copy(null, destination);
            fail("expected NullArgumentException");
        } catch (NullArgumentException expected) {
            assertEquals(0, destination.getN());
        }
        try {
            SummaryStatistics.copy(source, null);
            fail("expected NullArgumentException");
        } catch (NullArgumentException expected) {
            assertEquals(0, source.getN());
        }
    }

    @Test
    public void testEqualsHandlesSelfOtherTypesAndMatchingValues() throws Exception {
        SummaryStatistics s = new SummaryStatistics();
        s.addValue(2.0);
        assertTrue(s.equals(s));
        assertFalse(s.equals(null));
        assertFalse(s.equals("not statistics"));
        SummaryStatistics same = new SummaryStatistics();
        same.addValue(2.0);
        assertTrue(s.equals(same));
        same.addValue(3.0);
        assertFalse(s.equals(same));
    }

    @Test
    public void testEmptyStatisticsCompareEqualIncludingNaNResults() throws Exception {
        SummaryStatistics first = new SummaryStatistics();
        SummaryStatistics second = new SummaryStatistics();
        assertTrue(first.equals(second));
        assertEquals(first.hashCode(), second.hashCode());
    }

    @Test
    public void testTextReportContainsComputedValues() throws Exception {
        SummaryStatistics s = new SummaryStatistics();
        s.addValue(2.0);
        s.addValue(4.0);
        String report = s.toString();
        assertTrue(report.contains("n: 2\n"));
        assertTrue(report.contains("min: 2.0\n"));
        assertTrue(report.contains("max: 4.0\n"));
        assertTrue(report.contains("mean: 3.0\n"));
        assertTrue(report.contains("variance: 2.0\n"));
        assertTrue(report.contains("sum of squares: 20.0\n"));
    }

    @Test
    public void testCopyOfEmptyStatistics() throws Exception {
        SummaryStatistics s = new SummaryStatistics();
        SummaryStatistics copy = new SummaryStatistics(s);
        assertEquals(0, copy.getN());
        assertTrue(Double.isNaN(copy.getMean()));
        assertTrue(s.equals(copy));
    }
}
