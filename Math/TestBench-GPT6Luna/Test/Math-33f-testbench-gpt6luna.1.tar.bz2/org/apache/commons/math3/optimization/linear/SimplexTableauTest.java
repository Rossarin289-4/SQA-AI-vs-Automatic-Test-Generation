package org.apache.commons.math3.optimization.linear;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.MatrixUtils;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.RealVector;
import org.apache.commons.math3.optimization.GoalType;
import org.apache.commons.math3.optimization.PointValuePair;
import org.apache.commons.math3.util.Precision;

public class SimplexTableauTest {
    @Test
    public void testNormalizePositiveConstraint() throws Exception {
        LinearConstraint input = new LinearConstraint(new double[] {2.0}, Relationship.LEQ, 3.0);
        List<LinearConstraint> result = new SimplexTableau(
            new LinearObjectiveFunction(new double[] {1.0}, 0.0),
            java.util.Arrays.asList(input), GoalType.MAXIMIZE, true, 1e-6)
            .normalizeConstraints(java.util.Arrays.asList(input));
        assertEquals(1, result.size());
        assertEquals(input, result.get(0));
    }

    @Test
    public void testNormalizeNegativeLeqReversesRelation() throws Exception {
        LinearConstraint input = new LinearConstraint(new double[] {2.0}, Relationship.LEQ, -3.0);
        LinearConstraint result = new SimplexTableau(
            new LinearObjectiveFunction(new double[] {1.0}, 0.0),
            java.util.Arrays.asList(input), GoalType.MAXIMIZE, true, 1e-6)
            .normalizeConstraints(java.util.Arrays.asList(input)).get(0);
        assertEquals(new LinearConstraint(new double[] {-2.0}, Relationship.GEQ, 3.0), result);
    }

    @Test
    public void testNormalizeNegativeGeqReversesRelation() throws Exception {
        LinearConstraint input = new LinearConstraint(new double[] {-4.0}, Relationship.GEQ, -8.0);
        LinearConstraint result = new SimplexTableau(
            new LinearObjectiveFunction(new double[] {1.0}, 0.0),
            java.util.Arrays.asList(input), GoalType.MAXIMIZE, true, 1e-6)
            .normalizeConstraints(java.util.Arrays.asList(input)).get(0);
        assertEquals(new LinearConstraint(new double[] {4.0}, Relationship.LEQ, 8.0), result);
    }

    @Test
    public void testNormalizeNegativeEquality() throws Exception {
        LinearConstraint input = new LinearConstraint(new double[] {3.0}, Relationship.EQ, -6.0);
        LinearConstraint result = new SimplexTableau(
            new LinearObjectiveFunction(new double[] {1.0}, 0.0),
            java.util.Arrays.asList(input), GoalType.MAXIMIZE, true, 1e-6)
            .normalizeConstraints(java.util.Arrays.asList(input)).get(0);
        assertEquals(new LinearConstraint(new double[] {-3.0}, Relationship.EQ, 6.0), result);
    }

    @Test
    public void testNormalizeZeroRightHandSideDoesNotReverse() throws Exception {
        LinearConstraint input = new LinearConstraint(new double[] {2.0}, Relationship.LEQ, 0.0);
        LinearConstraint result = new SimplexTableau(
            new LinearObjectiveFunction(new double[] {1.0}, 0.0),
            java.util.Arrays.asList(input), GoalType.MAXIMIZE, true, 1e-6)
            .normalizeConstraints(java.util.Arrays.asList(input)).get(0);
        assertEquals(input, result);
    }

    @Test
    public void testNormalizeSeveralConstraintsPreservesOrder() throws Exception {
        LinearConstraint first = new LinearConstraint(new double[] {1.0}, Relationship.LEQ, -2.0);
        LinearConstraint second = new LinearConstraint(new double[] {5.0}, Relationship.EQ, 7.0);
        List<LinearConstraint> result = new SimplexTableau(
            new LinearObjectiveFunction(new double[] {1.0}, 0.0),
            java.util.Arrays.asList(first, second), GoalType.MAXIMIZE, true, 1e-6)
            .normalizeConstraints(java.util.Arrays.asList(first, second));
        assertEquals(2, result.size());
        assertEquals(new LinearConstraint(new double[] {-1.0}, Relationship.GEQ, 2.0), result.get(0));
        assertEquals(second, result.get(1));
    }

    @Test
    public void testNormalizeEmptyCollection() throws Exception {
        SimplexTableau tableau = new SimplexTableau(
            new LinearObjectiveFunction(new double[] {1.0}, 0.0),
            new ArrayList<LinearConstraint>(), GoalType.MAXIMIZE, true, 1e-6);
        assertEquals(0, tableau.normalizeConstraints(new ArrayList<LinearConstraint>()).size());
    }

    @Test
    public void testEqualToItself() throws Exception {
        SimplexTableau tableau = new SimplexTableau(
            new LinearObjectiveFunction(new double[] {1.0}, 0.0),
            new ArrayList<LinearConstraint>(), GoalType.MAXIMIZE, true, 1e-6);
        assertTrue(tableau.equals(tableau));
    }

    @Test
    public void testNotEqualToNull() throws Exception {
        SimplexTableau tableau = new SimplexTableau(
            new LinearObjectiveFunction(new double[] {1.0}, 0.0),
            new ArrayList<LinearConstraint>(), GoalType.MAXIMIZE, true, 1e-6);
        assertFalse(tableau.equals(null));
    }

    @Test
    public void testNotEqualToDifferentType() throws Exception {
        SimplexTableau tableau = new SimplexTableau(
            new LinearObjectiveFunction(new double[] {1.0}, 0.0),
            new ArrayList<LinearConstraint>(), GoalType.MAXIMIZE, true, 1e-6);
        assertFalse(tableau.equals("tableau"));
    }

    @Test
    public void testEqualTableauxHaveEqualHashCodes() throws Exception {
        SimplexTableau first = new SimplexTableau(
            new LinearObjectiveFunction(new double[] {1.0}, 0.0),
            new ArrayList<LinearConstraint>(), GoalType.MAXIMIZE, true, 1e-6);
        SimplexTableau second = new SimplexTableau(
            new LinearObjectiveFunction(new double[] {1.0}, 0.0),
            new ArrayList<LinearConstraint>(), GoalType.MAXIMIZE, true, 1e-6);
        assertTrue(first.equals(second));
        assertEquals(first.hashCode(), second.hashCode());
    }

    @Test
    public void testDifferentGoalProducesDifferentTableau() throws Exception {
        SimplexTableau maximize = new SimplexTableau(
            new LinearObjectiveFunction(new double[] {1.0}, 0.0),
            new ArrayList<LinearConstraint>(), GoalType.MAXIMIZE, true, 1e-6);
        SimplexTableau minimize = new SimplexTableau(
            new LinearObjectiveFunction(new double[] {1.0}, 0.0),
            new ArrayList<LinearConstraint>(), GoalType.MINIMIZE, true, 1e-6);
        assertFalse(maximize.equals(minimize));
    }

    @Test
    public void testDifferentRestrictionSettingProducesDifferentTableau() throws Exception {
        SimplexTableau restricted = new SimplexTableau(
            new LinearObjectiveFunction(new double[] {1.0}, 0.0),
            new ArrayList<LinearConstraint>(), GoalType.MAXIMIZE, true, 1e-6);
        SimplexTableau unrestricted = new SimplexTableau(
            new LinearObjectiveFunction(new double[] {1.0}, 0.0),
            new ArrayList<LinearConstraint>(), GoalType.MAXIMIZE, false, 1e-6);
        assertFalse(restricted.equals(unrestricted));
    }

    @Test
    public void testDifferentEpsilonProducesDifferentTableau() throws Exception {
        SimplexTableau first = new SimplexTableau(
            new LinearObjectiveFunction(new double[] {1.0}, 0.0),
            new ArrayList<LinearConstraint>(), GoalType.MAXIMIZE, true, 1e-6);
        SimplexTableau second = new SimplexTableau(
            new LinearObjectiveFunction(new double[] {1.0}, 0.0),
            new ArrayList<LinearConstraint>(), GoalType.MAXIMIZE, true, 1e-5);
        assertFalse(first.equals(second));
    }

    @Test
    public void testDifferentMaximumUlpsProducesDifferentTableau() throws Exception {
        SimplexTableau first = new SimplexTableau(
            new LinearObjectiveFunction(new double[] {1.0}, 0.0),
            new ArrayList<LinearConstraint>(), GoalType.MAXIMIZE, true, 1e-6, 2);
        SimplexTableau second = new SimplexTableau(
            new LinearObjectiveFunction(new double[] {1.0}, 0.0),
            new ArrayList<LinearConstraint>(), GoalType.MAXIMIZE, true, 1e-6, 3);
        assertFalse(first.equals(second));
    }

    @Test
    public void testDifferentConstraintMakesTableauxUnequal() throws Exception {
        LinearConstraint constraint = new LinearConstraint(new double[] {1.0}, Relationship.LEQ, 2.0);
        SimplexTableau empty = new SimplexTableau(
            new LinearObjectiveFunction(new double[] {1.0}, 0.0),
            new ArrayList<LinearConstraint>(), GoalType.MAXIMIZE, true, 1e-6);
        SimplexTableau populated = new SimplexTableau(
            new LinearObjectiveFunction(new double[] {1.0}, 0.0),
            java.util.Arrays.asList(constraint), GoalType.MAXIMIZE, true, 1e-6);
        assertFalse(empty.equals(populated));
    }

    @Test
    public void testHashCodeStableAcrossCalls() throws Exception {
        SimplexTableau tableau = new SimplexTableau(
            new LinearObjectiveFunction(new double[] {1.0}, 0.0),
            new ArrayList<LinearConstraint>(), GoalType.MAXIMIZE, true, 1e-6);
        assertEquals(tableau.hashCode(), tableau.hashCode());
    }
}
