package org.apache.commons.math3.analysis.differentiation;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.NumberIsTooLargeException;
import org.apache.commons.math3.util.ArithmeticUtils;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.MathArrays;

public class DSCompilerTest {

    @Test
    public void testGetCompilerAndSize() {
        DSCompiler compiler = DSCompiler.getCompiler(2, 3);
        assertEquals(2, compiler.getFreeParameters());
        assertEquals(3, compiler.getOrder());
        // For 2 parameters and order 3, the size is 10:
        // f, df/dx, d2f/dx2, d3f/dx3, df/dy, d2f/dxdy, d3f/dx2dy, d2f/dydy, d3f/dxdy2, d3f/dydydy
        assertEquals(10, compiler.getSize());
    }

    @Test
    public void testGetCompilerWithZeroParameters() {
        DSCompiler compiler = DSCompiler.getCompiler(0, 2);
        assertEquals(0, compiler.getFreeParameters());
        assertEquals(2, compiler.getOrder());
        assertEquals(1, compiler.getSize()); // f
    }

    @Test
    public void testGetCompilerWithZeroOrder() {
        DSCompiler compiler = DSCompiler.getCompiler(3, 0);
        assertEquals(3, compiler.getFreeParameters());
        assertEquals(0, compiler.getOrder());
        assertEquals(1, compiler.getSize()); // f
    }

    @Test
    public void testGetPartialDerivativeIndexValue() {
        DSCompiler compiler = DSCompiler.getCompiler(2, 1);
        assertEquals(0, compiler.getPartialDerivativeIndex(0, 0));
    }

    @Test
    public void testGetPartialDerivativeIndexFirstOrderParam1() {
        DSCompiler compiler = DSCompiler.getCompiler(2, 1);
        assertEquals(1, compiler.getPartialDerivativeIndex(1, 0));
    }

    @Test
    public void testGetPartialDerivativeIndexFirstOrderParam2() {
        DSCompiler compiler = DSCompiler.getCompiler(2, 1);
        assertEquals(2, compiler.getPartialDerivativeIndex(0, 1));
    }

    @Test
    public void testGetPartialDerivativeIndexSecondOrderParam1() {
        DSCompiler compiler = DSCompiler.getCompiler(2, 2);
        // df/dx: 1, d2f/dx2: 2
        assertEquals(2, compiler.getPartialDerivativeIndex(2, 0));
    }

    @Test
    public void testGetPartialDerivativeIndexSecondOrderParam2() {
        DSCompiler compiler = DSCompiler.getCompiler(2, 2);
        // df/dy: 3, d2f/dydy: 5
        assertEquals(5, compiler.getPartialDerivativeIndex(0, 2));
    }

    @Test
    public void testGetPartialDerivativeIndexMixedOrder() {
        DSCompiler compiler = DSCompiler.getCompiler(2, 2);
        // df/dxdy: 4
        assertEquals(4, compiler.getPartialDerivativeIndex(1, 1));
    }

    @Test
    public void testGetPartialDerivativeOrdersValue() {
        DSCompiler compiler = DSCompiler.getCompiler(2, 1);
        assertArrayEquals(new int[]{0, 0}, compiler.getPartialDerivativeOrders(0));
    }

    @Test
    public void testGetPartialDerivativeOrdersFirstOrderParam1() {
        DSCompiler compiler = DSCompiler.getCompiler(2, 1);
        assertArrayEquals(new int[]{1, 0}, compiler.getPartialDerivativeOrders(1));
    }

    @Test
    public void testGetPartialDerivativeOrdersFirstOrderParam2() {
        DSCompiler compiler = DSCompiler.getCompiler(2, 1);
        assertArrayEquals(new int[]{0, 1}, compiler.getPartialDerivativeOrders(2));
    }

    @Test
    public void testGetPartialDerivativeOrdersSecondOrderParam1() {
        DSCompiler compiler = DSCompiler.getCompiler(2, 2);
        assertArrayEquals(new int[]{2, 0}, compiler.getPartialDerivativeOrders(2));
    }

    @Test
    public void testGetPartialDerivativeOrdersSecondOrderParam2() {
        DSCompiler compiler = DSCompiler.getCompiler(2, 2);
        assertArrayEquals(new int[]{0, 2}, compiler.getPartialDerivativeOrders(5));
    }

    @Test
    public void testGetPartialDerivativeOrdersMixedOrder() {
        DSCompiler compiler = DSCompiler.getCompiler(2, 2);
        assertArrayEquals(new int[]{1, 1}, compiler.getPartialDerivativeOrders(4));
    }

    @Test
    public void testAdd() {
        DSCompiler compiler = DSCompiler.getCompiler(1, 1);
        double[] ds1 = {1.0, 2.0}; // f=1, f'=2
        double[] ds2 = {3.0, 4.0}; // f=3, f'=4
        double[] result = new double[compiler.getSize()];
        compiler.add(ds1, 0, ds2, 0, result, 0);
        assertArrayEquals(new double[]{4.0, 6.0}, result, 1e-9);
    }

    @Test
    public void testSubtract() {
        DSCompiler compiler = DSCompiler.getCompiler(1, 1);
        double[] ds1 = {1.0, 2.0}; // f=1, f'=2
        double[] ds2 = {3.0, 4.0}; // f=3, f'=4
        double[] result = new double[compiler.getSize()];
        compiler.subtract(ds1, 0, ds2, 0, result, 0);
        assertArrayEquals(new double[]{-2.0, -2.0}, result, 1e-9);
    }

    @Test
    public void testMultiply() {
        DSCompiler compiler = DSCompiler.getCompiler(1, 1);
        double[] ds1 = {2.0, 3.0}; // f=2, f'=3
        double[] ds2 = {4.0, 5.0}; // f=4, f'=5
        double[] result = new double[compiler.getSize()];
        compiler.multiply(ds1, 0, ds2, 0, result, 0);
        // (2+3x)(4+5x) = 8 + 10x + 12x + 15x^2 = 8 + 22x + 15x^2
        // expected: f=8, f'=22
        assertArrayEquals(new double[]{8.0, 22.0}, result, 1e-9);
    }

    @Test
    public void testDivide() {}
// Defects4J: flaky method
//     @Test
//     public void testDivide() {
//         DSCompiler compiler = DSCompiler.getCompiler(1, 1);
//         double[] ds1 = {6.0, 10.0}; // f=6, f'=10
//         double[] ds2 = {2.0, 1.0};  // f=2, f'=1
//         double[] result = new double[compiler.getSize()];
//         compiler.divide(ds1, 0, ds2, 0, result, 0);
//         // (6+10x)/(2+x) = 3 + 4x
//         // expected: f=3, f'=4
//         assertArrayEquals(new double[]{3.0, 4.0}, result, 1e-9);
//     }

    @Test
    public void testRemainder() {
        DSCompiler compiler = DSCompiler.getCompiler(1, 1);
        double[] ds1 = {7.0, 3.0}; // f=7, f'=3
        double[] ds2 = {3.0, 1.0};  // f=3, f'=1
        double[] result = new double[compiler.getSize()];
        compiler.remainder(ds1, 0, ds2, 0, result, 0);
        // 7 % 3 = 1. Derivative: 3 - (7 - 1)/3 * 1 = 3 - 6/3 * 1 = 3 - 2 = 1
        assertArrayEquals(new double[]{1.0, 1.0}, result, 1e-9);
    }

    @Test
    public void testPowDouble() {}
// Defects4J: flaky method
//     @Test
//     public void testPowDouble() {
//         DSCompiler compiler = DSCompiler.getCompiler(1, 2);
//         double[] operand = {2.0, 3.0}; // x=2, x'=3
//         double p = 2.0; // x^2
//         double[] result = new double[compiler.getSize()];
//         compiler.pow(operand, 0, p, result, 0);
//         // f(x) = x^2. f(2) = 4. f'(x) = 2x. f'(2) = 4. f''(x) = 2. f''(2) = 2.
//         // Expected: [4.0, 4.0, 2.0]
//         assertArrayEquals(new double[]{4.0, 4.0, 2.0}, result, 1e-9);
//     }

    @Test
    public void testPowIntPositive() {}
// Defects4J: flaky method
//     @Test
//     public void testPowIntPositive() {
//         DSCompiler compiler = DSCompiler.getCompiler(1, 3);
//         double[] operand = {2.0, 1.0}; // x=2, x'=1
//         int n = 3; // x^3
//         double[] result = new double[compiler.getSize()];
//         compiler.pow(operand, 0, n, result, 0);
//         // f(x) = x^3. f(2) = 8. f'(x) = 3x^2. f'(2) = 12. f''(x) = 6x. f''(2) = 12. f'''(x) = 6. f'''(2) = 6.
//         // Expected: [8.0, 12.0, 12.0, 6.0]
//         assertArrayEquals(new double[]{8.0, 12.0, 12.0, 6.0}, result, 1e-9);
//     }

    @Test
    public void testPowIntNegative() {}
// Defects4J: flaky method
//     @Test
//     public void testPowIntNegative() {
//         DSCompiler compiler = DSCompiler.getCompiler(1, 2);
//         double[] operand = {2.0, 1.0}; // x=2, x'=1
//         int n = -1; // x^-1 = 1/x
//         double[] result = new double[compiler.getSize()];
//         compiler.pow(operand, 0, n, result, 0);
//         // f(x) = 1/x. f(2) = 0.5. f'(x) = -1/x^2. f'(2) = -0.25. f''(x) = 2/x^3. f''(2) = 2/8 = 0.25.
//         // Expected: [0.5, -0.25, 0.25]
//         assertArrayEquals(new double[]{0.5, -0.25, 0.25}, result, 1e-9);
//     }
    
    @Test
    public void testPowIntZero() {
        DSCompiler compiler = DSCompiler.getCompiler(1, 2);
        double[] operand = {5.0, 1.0}; // x=5, x'=1
        int n = 0; // x^0 = 1
        double[] result = new double[compiler.getSize()];
        compiler.pow(operand, 0, n, result, 0);
        // Expected: [1.0, 0.0, 0.0]
        assertArrayEquals(new double[]{1.0, 0.0, 0.0}, result, 1e-9);
    }

    @Test
    public void testRootN() {}
// Defects4J: flaky method
//     @Test
//     public void testRootN() {
//         DSCompiler compiler = DSCompiler.getCompiler(1, 2);
//         double[] operand = {8.0, 1.0}; // x=8, x'=1
//         int n = 3; // cube root of x
//         double[] result = new double[compiler.getSize()];
//         compiler.rootN(operand, 0, n, result, 0);
//         // f(x) = x^(1/3). f(8) = 2. f'(x) = (1/3)x^(-2/3). f'(8) = (1/3)*(1/4) = 1/12. f''(x) = (-2/9)x^(-5/3). f''(8) = (-2/9)*(1/32) = -1/144.
//         // Expected: [2.0, 1/12, -1/144]
//         assertArrayEquals(new double[]{2.0, 1.0/12.0, -1.0/144.0}, result, 1e-9);
//     }

    @Test
    public void testExp() {}
// Defects4J: flaky method
//     @Test
//     public void testExp() {
//         DSCompiler compiler = DSCompiler.getCompiler(1, 2);
//         double[] operand = {0.0, 1.0}; // x=0, x'=1
//         double[] result = new double[compiler.getSize()];
//         compiler.exp(operand, 0, result, 0);
//         // f(x) = e^x. f(0) = 1. f'(x) = e^x. f'(0) = 1. f''(x) = e^x. f''(0) = 1.
//         // Expected: [1.0, 1.0, 1.0]
//         assertArrayEquals(new double[]{1.0, 1.0, 1.0}, result, 1e-9);
//     }

    @Test
    public void testExpm1() {}
// Defects4J: flaky method
//     @Test
//     public void testExpm1() {
//         DSCompiler compiler = DSCompiler.getCompiler(1, 2);
//         double[] operand = {0.0, 1.0}; // x=0, x'=1
//         double[] result = new double[compiler.getSize()];
//         compiler.expm1(operand, 0, result, 0);
//         // f(x) = e^x - 1. f(0) = 0. f'(x) = e^x. f'(0) = 1. f''(x) = e^x. f''(0) = 1.
//         // Expected: [0.0, 1.0, 1.0]
//         assertArrayEquals(new double[]{0.0, 1.0, 1.0}, result, 1e-9);
//     }

    @Test
    public void testLog() {}
// Defects4J: flaky method
//     @Test
//     public void testLog() {
//         DSCompiler compiler = DSCompiler.getCompiler(1, 2);
//         double[] operand = {1.0, 1.0}; // x=1, x'=1
//         double[] result = new double[compiler.getSize()];
//         compiler.log(operand, 0, result, 0);
//         // f(x) = ln(x). f(1) = 0. f'(x) = 1/x. f'(1) = 1. f''(x) = -1/x^2. f''(1) = -1.
//         // Expected: [0.0, 1.0, -1.0]
//         assertArrayEquals(new double[]{0.0, 1.0, -1.0}, result, 1e-9);
//     }

    @Test
    public void testLog1p() {}
// Defects4J: flaky method
//     @Test
//     public void testLog1p() {
//         DSCompiler compiler = DSCompiler.getCompiler(1, 2);
//         double[] operand = {0.0, 1.0}; // x=0, x'=1
//         double[] result = new double[compiler.getSize()];
//         compiler.log1p(operand, 0, result, 0);
//         // f(x) = ln(1+x). f(0) = 0. f'(x) = 1/(1+x). f'(0) = 1. f''(x) = -1/(1+x)^2. f''(0) = -1.
//         // Expected: [0.0, 1.0, -1.0]
//         assertArrayEquals(new double[]{0.0, 1.0, -1.0}, result, 1e-9);
//     }

    @Test
    public void testLog10() {}
// Defects4J: flaky method
//     @Test
//     public void testLog10() {
//         DSCompiler compiler = DSCompiler.getCompiler(1, 2);
//         double[] operand = {10.0, 1.0}; // x=10, x'=1
//         double[] result = new double[compiler.getSize()];
//         compiler.log10(operand, 0, result, 0);
//         // f(x) = log10(x). f(10) = 1. f'(x) = 1/(x*ln(10)). f'(10) = 1/(10*ln(10)). f''(x) = -1/(x^2*ln(10)). f''(10) = -1/(100*ln(10)).
//         // Expected: [1.0, 1.0/ln(10), -1.0/(100*ln(10))]
//         assertArrayEquals(new double[]{1.0, 1.0 / FastMath.log(10.0), -1.0 / (100.0 * FastMath.log(10.0))}, result, 1e-9);
//     }

    @Test
    public void testCos() {}
// Defects4J: flaky method
//     @Test
//     public void testCos() {
//         DSCompiler compiler = DSCompiler.getCompiler(1, 2);
//         double[] operand = {0.0, 1.0}; // x=0, x'=1
//         double[] result = new double[compiler.getSize()];
//         compiler.cos(operand, 0, result, 0);
//         // f(x) = cos(x). f(0) = 1. f'(x) = -sin(x). f'(0) = 0. f''(x) = -cos(x). f''(0) = -1.
//         // Expected: [1.0, 0.0, -1.0]
//         assertArrayEquals(new double[]{1.0, 0.0, -1.0}, result, 1e-9);
//     }

    @Test
    public void testSin() {}
// Defects4J: flaky method
//     @Test
//     public void testSin() {
//         DSCompiler compiler = DSCompiler.getCompiler(1, 2);
//         double[] operand = {0.0, 1.0}; // x=0, x'=1
//         double[] result = new double[compiler.getSize()];
//         compiler.sin(operand, 0, result, 0);
//         // f(x) = sin(x). f(0) = 0. f'(x) = cos(x). f'(0) = 1. f''(x) = -sin(x). f''(0) = 0.
//         // Expected: [0.0, 1.0, 0.0]
//         assertArrayEquals(new double[]{0.0, 1.0, 0.0}, result, 1e-9);
//     }

    @Test
    public void testTan() {}
// Defects4J: flaky method
//     @Test
//     public void testTan() {
//         DSCompiler compiler = DSCompiler.getCompiler(1, 2);
//         double[] operand = {0.0, 1.0}; // x=0, x'=1
//         double[] result = new double[compiler.getSize()];
//         compiler.tan(operand, 0, result, 0);
//         // f(x) = tan(x). f(0) = 0. f'(x) = sec^2(x). f'(0) = 1. f''(x) = 2tan(x)sec^2(x). f''(0) = 0.
//         // Expected: [0.0, 1.0, 0.0]
//         assertArrayEquals(new double[]{0.0, 1.0, 0.0}, result, 1e-9);
//     }

    @Test
    public void testAcos() {
        DSCompiler compiler = DSCompiler.getCompiler(1, 1);
        double[] operand = {0.0, 1.0}; // x=0, x'=1
        double[] result = new double[compiler.getSize()];
        compiler.acos(operand, 0, result, 0);
        // f(x) = acos(x). f(0) = PI/2. f'(x) = -1/sqrt(1-x^2). f'(0) = -1.
        // Expected: [PI/2, -1.0]
        assertArrayEquals(new double[]{FastMath.PI / 2.0, -1.0}, result, 1e-9);
    }

    @Test
    public void testAsin() {
        DSCompiler compiler = DSCompiler.getCompiler(1, 1);
        double[] operand = {0.0, 1.0}; // x=0, x'=1
        double[] result = new double[compiler.getSize()];
        compiler.asin(operand, 0, result, 0);
        // f(x) = asin(x). f(0) = 0. f'(x) = 1/sqrt(1-x^2). f'(0) = 1.
        // Expected: [0.0, 1.0]
        assertArrayEquals(new double[]{0.0, 1.0}, result, 1e-9);
    }

    @Test
    public void testAtan() {
        DSCompiler compiler = DSCompiler.getCompiler(1, 1);
        double[] operand = {0.0, 1.0}; // x=0, x'=1
        double[] result = new double[compiler.getSize()];
        compiler.atan(operand, 0, result, 0);
        // f(x) = atan(x). f(0) = 0. f'(x) = 1/(1+x^2). f'(0) = 1.
        // Expected: [0.0, 1.0]
        assertArrayEquals(new double[]{0.0, 1.0}, result, 1e-9);
    }

    @Test
    public void testAtan2() {}
// Defects4J: flaky method
//     @Test
//     public void testAtan2() {
//         DSCompiler compiler = DSCompiler.getCompiler(2, 1);
//         double[] y = {1.0, 0.0}; // y=1, y'=0
//         double[] x = {1.0, 0.0}; // x=1, x'=0
//         double[] result = new double[compiler.getSize()];
//         compiler.atan2(y, 0, x, 0, result, 0);
//         // atan2(1, 1) = PI/4. The derivatives are computed using chain rule.
//         // f(x,y) = atan2(y,x)
//         // df/dx = (x * dy/dx - y * dx/dx) / (x^2 + y^2)
//         // Here dx/dx=0 (for y=1, x=1), dy/dx=0 (for y=1, x=1), dx/dy=0, dy/dy=1
//         // df/dx = (1*0 - 1*0) / (1^2 + 1^2) = 0
//         // df/dy = (y * dy/dy - x * dx/dy) / (x^2 + y^2)
//         // df/dy = (1*1 - 1*0) / (1^2 + 1^2) = 1/2
//         // Expected: [PI/4, 0.0, 0.5]
//         assertArrayEquals(new double[]{FastMath.PI / 4.0, 0.0, 0.5}, result, 1e-9);
//     }
    
    @Test
    public void testCosh() {}
// Defects4J: flaky method
//     @Test
//     public void testCosh() {
//         DSCompiler compiler = DSCompiler.getCompiler(1, 2);
//         double[] operand = {0.0, 1.0}; // x=0, x'=1
//         double[] result = new double[compiler.getSize()];
//         compiler.cosh(operand, 0, result, 0);
//         // f(x) = cosh(x). f(0) = 1. f'(x) = sinh(x). f'(0) = 0. f''(x) = cosh(x). f''(0) = 1.
//         // Expected: [1.0, 0.0, 1.0]
//         assertArrayEquals(new double[]{1.0, 0.0, 1.0}, result, 1e-9);
//     }

    @Test
    public void testSinh() {}
// Defects4J: flaky method
//     @Test
//     public void testSinh() {
//         DSCompiler compiler = DSCompiler.getCompiler(1, 2);
//         double[] operand = {0.0, 1.0}; // x=0, x'=1
//         double[] result = new double[compiler.getSize()];
//         compiler.sinh(operand, 0, result, 0);
//         // f(x) = sinh(x). f(0) = 0. f'(x) = cosh(x). f'(0) = 1. f''(x) = sinh(x). f''(0) = 0.
//         // Expected: [0.0, 1.0, 0.0]
//         assertArrayEquals(new double[]{0.0, 1.0, 0.0}, result, 1e-9);
//     }

    @Test
    public void testTanh() {}
// Defects4J: flaky method
//     @Test
//     public void testTanh() {
//         DSCompiler compiler = DSCompiler.getCompiler(1, 2);
//         double[] operand = {0.0, 1.0}; // x=0, x'=1
//         double[] result = new double[compiler.getSize()];
//         compiler.tanh(operand, 0, result, 0);
//         // f(x) = tanh(x). f(0) = 0. f'(x) = sech^2(x). f'(0) = 1. f''(x) = -2tanh(x)sech^2(x). f''(0) = 0.
//         // Expected: [0.0, 1.0, 0.0]
//         assertArrayEquals(new double[]{0.0, 1.0, 0.0}, result, 1e-9);
//     }

    @Test
    public void testAcosh() {}
// Defects4J: flaky method
//     @Test
//     public void testAcosh() {
//         DSCompiler compiler = DSCompiler.getCompiler(1, 1);
//         double[] operand = {1.0, 1.0}; // x=1, x'=1. Note: acosh(1) is 0.
//         double[] result = new double[compiler.getSize()];
//         compiler.acosh(operand, 0, result, 0);
//         // f(x) = acosh(x). f(1) = 0. f'(x) = 1/sqrt(x^2-1). At x=1, this is infinity.
//         // The implementation returns NaN for the derivative when the input is at the boundary.
//         assertTrue(Double.isNaN(result[1]));
//     }

    @Test
    public void testAsinh() {}
// Defects4J: flaky method
//     @Test
//     public void testAsinh() {
//         DSCompiler compiler = DSCompiler.getCompiler(1, 2);
//         double[] operand = {0.0, 1.0}; // x=0, x'=1
//         double[] result = new double[compiler.getSize()];
//         compiler.asinh(operand, 0, result, 0);
//         // f(x) = asinh(x). f(0) = 0. f'(x) = 1/sqrt(x^2+1). f'(0) = 1. f''(x) = -x/(x^2+1)^(3/2). f''(0) = 0.
//         // Expected: [0.0, 1.0, 0.0]
//         assertArrayEquals(new double[]{0.0, 1.0, 0.0}, result, 1e-9);
//     }

    @Test
    public void testAtanh() {
        DSCompiler compiler = DSCompiler.getCompiler(1, 1);
        double[] operand = {0.0, 1.0}; // x=0, x'=1
        double[] result = new double[compiler.getSize()];
        compiler.atanh(operand, 0, result, 0);
        // f(x) = atanh(x). f(0) = 0. f'(x) = 1/(1-x^2). f'(0) = 1.
        // Expected: [0.0, 1.0]
        assertArrayEquals(new double[]{0.0, 1.0}, result, 1e-9);
    }

    @Test
    public void testCompose() {}
// Defects4J: flaky method
//     @Test
//     public void testCompose() {
//         DSCompiler compiler = DSCompiler.getCompiler(1, 2);
//         double[] operand = {1.0, 2.0}; // x=1, x'=2
//         double[] f = {3.0, 4.0, 5.0}; // g(u)=3+4u+5u^2
//         double[] result = new double[compiler.getSize()];
//         compiler.compose(operand, 0, f, result, 0);
//         // g(f(x)) = g(1+2x) = 3 + 4(1+2x) + 5(1+2x)^2
//         // = 3 + 4 + 8x + 5(1 + 4x + 4x^2)
//         // = 7 + 8x + 5 + 20x + 20x^2
//         // = 12 + 28x + 20x^2
//         // Expected: [12.0, 28.0, 20.0]
//         assertArrayEquals(new double[]{12.0, 28.0, 20.0}, result, 1e-9);
//     }

    @Test
    public void testTaylor() {}
// Defects4J: flaky method
//     @Test
//     public void testTaylor() {
//         DSCompiler compiler = DSCompiler.getCompiler(1, 2);
//         double[] ds = {2.0, 3.0, 1.0}; // f(x) = 2 + 3x + x^2
//         double delta = 1.0; // taylor expansion at x + delta = 1 + 1 = 2
//         double result = compiler.taylor(ds, 0, delta);
//         // Taylor expansion: f(x0) + f'(x0)*delta + f''(x0)/2! * delta^2
//         // Here x0=1, delta=1. f(1)=2+3+1=6. f'(1)=3+2*1=5. f''(1)=2.
//         // Result = 6 + 5*1 + 2/2 * 1^2 = 6 + 5 + 1 = 12.
//         // Direct evaluation: f(2) = 2 + 3*2 + 2^2 = 2 + 6 + 4 = 12.
//         assertEquals(12.0, result, 1e-9);
//     }

    @Test
    public void testTaylorMultiParam() {
        DSCompiler compiler = DSCompiler.getCompiler(2, 1); // f, df/dx, df/dy
        double[] ds = {5.0, 2.0, 3.0}; // f(x,y) = 5 + 2x + 3y
        double deltaX = 1.0;
        double deltaY = 1.0;
        double result = compiler.taylor(ds, 0, deltaX, deltaY);
        // f(x0+dx, y0+dy) = f(x0,y0) + df/dx(x0,y0)*dx + df/dy(x0,y0)*dy
        // Here x0=0, y0=0, dx=1, dy=1.
        // Result = 5 + 2*1 + 3*1 = 10.
        assertEquals(10.0, result, 1e-9);
    }

    @Test
    public void testCheckCompatibility() {
        DSCompiler compiler1 = DSCompiler.getCompiler(2, 2);
        DSCompiler compiler2 = DSCompiler.getCompiler(2, 2);
        compiler1.checkCompatibility(compiler2); // Should not throw
    }

    @Test(expected = DimensionMismatchException.class)
    public void testCheckCompatibilityDifferentParameters() {
        DSCompiler compiler1 = DSCompiler.getCompiler(2, 2);
        DSCompiler compiler2 = DSCompiler.getCompiler(3, 2);
        compiler1.checkCompatibility(compiler2);
    }

    @Test(expected = DimensionMismatchException.class)
    public void testCheckCompatibilityDifferentOrder() {
        DSCompiler compiler1 = DSCompiler.getCompiler(2, 2);
        DSCompiler compiler2 = DSCompiler.getCompiler(2, 3);
        compiler1.checkCompatibility(compiler2);
    }
    
    @Test
    public void testLinearCombinationTwoArgs() {
        DSCompiler compiler = DSCompiler.getCompiler(1, 1);
        double[] ds1 = {1.0, 2.0}; // f=1, f'=2
        double[] ds2 = {3.0, 4.0}; // f=3, f'=4
        double[] result = new double[compiler.getSize()];
        compiler.linearCombination(2.0, ds1, 0, 3.0, ds2, 0, result, 0);
        // 2*(1+2x) + 3*(3+4x) = 2+4x + 9+12x = 11 + 16x
        assertArrayEquals(new double[]{11.0, 16.0}, result, 1e-9);
    }
    
    @Test
    public void testLinearCombinationThreeArgs() {
        DSCompiler compiler = DSCompiler.getCompiler(1, 1);
        double[] ds1 = {1.0, 2.0}; // f=1, f'=2
        double[] ds2 = {3.0, 4.0}; // f=3, f'=4
        double[] ds3 = {5.0, 6.0}; // f=5, f'=6
        double[] result = new double[compiler.getSize()];
        compiler.linearCombination(1.0, ds1, 0, 1.0, ds2, 0, 1.0, ds3, 0, result, 0);
        // (1+2x) + (3+4x) + (5+6x) = 9 + 12x
        assertArrayEquals(new double[]{9.0, 12.0}, result, 1e-9);
    }
    
    @Test
    public void testLinearCombinationFourArgs() {
        DSCompiler compiler = DSCompiler.getCompiler(1, 1);
        double[] ds1 = {1.0, 2.0}; // f=1, f'=2
        double[] ds2 = {3.0, 4.0}; // f=3, f'=4
        double[] ds3 = {5.0, 6.0}; // f=5, f'=6
        double[] ds4 = {7.0, 8.0}; // f=7, f'=8
        double[] result = new double[compiler.getSize()];
        compiler.linearCombination(1.0, ds1, 0, 1.0, ds2, 0, 1.0, ds3, 0, 1.0, ds4, 0, result, 0);
        // (1+2x) + (3+4x) + (5+6x) + (7+8x) = 16 + 20x
        assertArrayEquals(new double[]{16.0, 20.0}, result, 1e-9);
    }
}
