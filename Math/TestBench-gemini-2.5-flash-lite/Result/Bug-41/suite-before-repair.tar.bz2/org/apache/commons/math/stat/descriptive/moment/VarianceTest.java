package org.apache.commons.math.stat.descriptive.moment;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.Serializable;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.stat.descriptive.WeightedEvaluation;
import org.apache.commons.math.stat.descriptive.AbstractStorelessUnivariateStatistic;
import org.apache.commons.math.util.MathUtils;

public class VarianceTest {

    @Test
    public void testConstructor() throws Exception {
        Variance variance = new Variance();
        assertNotNull(variance);
        assertTrue(variance.isBiasCorrected());
        assertEquals(0, variance.getN());
    }

    @Test
    public void testConstructorWithBiasCorrection() throws Exception {
        Variance varianceTrue = new Variance(true);
        assertTrue(varianceTrue.isBiasCorrected());
        assertEquals(0, varianceTrue.getN());

        Variance varianceFalse = new Variance(false);
        assertFalse(varianceFalse.isBiasCorrected());
        assertEquals(0, varianceFalse.getN());
    }

    @Test
    public void testConstructorWithExternalMoment() throws Exception {
        SecondMoment m2 = new SecondMoment();
        Variance variance = new Variance(m2);
        assertNotNull(variance);
        assertTrue(variance.isBiasCorrected());
        // Should not increment internal moment if external is provided
        variance.increment(1.0);
        assertEquals(0, variance.getN());
        assertEquals(0, m2.getN());
    }

    @Test
    public void testConstructorWithBiasAndExternalMoment() throws Exception {
        SecondMoment m2 = new SecondMoment();
        Variance varianceTrue = new Variance(true, m2);
        assertTrue(varianceTrue.isBiasCorrected());
        assertEquals(0, varianceTrue.getN());

        Variance varianceFalse = new Variance(false, m2);
        assertFalse(varianceFalse.isBiasCorrected());
        assertEquals(0, varianceFalse.getN());
    }

    @Test
    public void testCopyConstructor() throws Exception {
        Variance original = new Variance();
        original.increment(1.0);
        original.increment(2.0);
        original.increment(3.0);
        original.setBiasCorrected(false);

        Variance copy = new Variance(original);
        assertNotNull(copy);
        assertEquals(original.getN(), copy.getN());
        assertEquals(original.isBiasCorrected(), copy.isBiasCorrected());
        assertEquals(original.getResult(), copy.getResult(), 1e-9);

        // Ensure it's a deep copy
        copy.increment(4.0);
        assertNotEquals(original.getN(), copy.getN());
        assertNotEquals(original.getResult(), copy.getResult(), 1e-9);
    }

    @Test
    public void testIncrementAndGetResultSingleValue() throws Exception {
        Variance variance = new Variance();
        variance.increment(5.0);
        assertEquals(1, variance.getN());
        assertEquals(0.0, variance.getResult(), 1e-9); // Variance of a single value is 0
    }

    @Test
    public void testIncrementAndGetResultMultipleValuesUnbiased() throws Exception {
        Variance variance = new Variance();
        variance.increment(1.0);
        variance.increment(2.0);
        variance.increment(3.0);
        variance.increment(4.0);
        variance.increment(5.0);
        assertEquals(5, variance.getN());
        // Expected unbiased variance: sum((x_i - mean)^2) / (n - 1)
        // Mean = 3
        // Deviations: -2, -1, 0, 1, 2
        // Squared deviations: 4, 1, 0, 1, 4. Sum = 10
        // Variance = 10 / (5 - 1) = 10 / 4 = 2.5
        assertEquals(2.5, variance.getResult(), 1e-9);
    }

    @Test
    public void testIncrementAndGetResultMultipleValuesBiased() throws Exception {
        Variance variance = new Variance(false); // biased
        variance.increment(1.0);
        variance.increment(2.0);
        variance.increment(3.0);
        variance.increment(4.0);
        variance.increment(5.0);
        assertEquals(5, variance.getN());
        // Expected biased variance: sum((x_i - mean)^2) / n
        // Mean = 3
        // Sum of squared deviations = 10
        // Variance = 10 / 5 = 2.0
        assertEquals(2.0, variance.getResult(), 1e-9);
    }

    @Test
    public void testClear() throws Exception {
        Variance variance = new Variance();
        variance.increment(1.0);
        variance.increment(2.0);
        variance.increment(3.0);
        assertEquals(3, variance.getN());
        variance.clear();
        assertEquals(0, variance.getN());
        // When n=0, getResult() returns Double.NaN
        assertEquals(Double.NaN, variance.getResult(), 1e-9);
    }

    @Test
    public void testEvaluateWithArraySingleValue() throws Exception {
        Variance variance = new Variance();
        double[] values = {5.0};
        assertEquals(0.0, variance.evaluate(values), 1e-9);
        assertEquals(0, variance.getN()); // Should not change internal state
    }

    @Test
    public void testEvaluateWithArrayEmpty() throws Exception {
        Variance variance = new Variance();
        double[] values = {};
        assertEquals(Double.NaN, variance.evaluate(values), 1e-9);
        assertEquals(0, variance.getN()); // Should not change internal state
    }

    @Test
    public void testEvaluateWithArrayNull() throws Exception {
        Variance variance = new Variance();
        try {
            variance.evaluate((double[]) null);
            fail("Expected NullArgumentException");
        } catch (NullArgumentException e) {
            // Expected
        }
    }

    @Test
    public void testEvaluateWithArrayMultipleValuesUnbiased() throws Exception {
        Variance variance = new Variance();
        variance.setBiasCorrected(true);
        double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
        // Mean = 3, Sum of squared deviations = 10, n = 5
        // Variance = 10 / (5 - 1) = 2.5
        assertEquals(2.5, variance.evaluate(values), 1e-9);
        assertEquals(0, variance.getN()); // Should not change internal state
    }

    @Test
    public void testEvaluateWithArrayMultipleValuesBiased() throws Exception {
        Variance variance = new Variance(false); // biased
        double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
        // Mean = 3, Sum of squared deviations = 10, n = 5
        // Variance = 10 / 5 = 2.0
        assertEquals(2.0, variance.evaluate(values), 1e-9);
        assertEquals(0, variance.getN()); // Should not change internal state
    }

    @Test
    public void testEvaluateWithArrayAndOffsetLength() throws Exception {
        Variance variance = new Variance();
        variance.setBiasCorrected(true);
        double[] values = {0.0, 1.0, 2.0, 3.0, 4.0, 5.0};
        // Evaluating {1.0, 2.0, 3.0, 4.0}
        // Mean = 2.5
        // Deviations: -1.5, -0.5, 0.5, 1.5
        // Squared deviations: 2.25, 0.25, 0.25, 2.25. Sum = 5.0
        // Variance = 5.0 / (4 - 1) = 5.0 / 3.0
        assertEquals(5.0 / 3.0, variance.evaluate(values, 1, 4), 1e-9);
        assertEquals(0, variance.getN()); // Should not change internal state
    }

    @Test
    public void testEvaluateWithArrayAndOffsetLengthSingleValue() throws Exception {
        Variance variance = new Variance();
        double[] values = {10.0};
        assertEquals(0.0, variance.evaluate(values, 0, 1), 1e-9);
    }

    @Test
    public void testEvaluateWithArrayAndOffsetLengthEmpty() throws Exception {
        Variance variance = new Variance();
        double[] values = {1.0, 2.0};
        assertEquals(Double.NaN, variance.evaluate(values, 1, 0), 1e-9);
    }

    @Test
    public void testEvaluateWithWeightsSingleValue() throws Exception {
        Variance variance = new Variance();
        double[] values = {5.0};
        double[] weights = {1.0};
        assertEquals(0.0, variance.evaluate(values, weights), 1e-9);
        assertEquals(0, variance.getN());
    }

    @Test
    public void testEvaluateWithWeightsEmpty() throws Exception {
        Variance variance = new Variance();
        double[] values = {};
        double[] weights = {};
        assertEquals(Double.NaN, variance.evaluate(values, weights), 1e-9);
        assertEquals(0, variance.getN());
    }

    @Test
    public void testEvaluateWithWeightsNullValues() throws Exception {
        Variance variance = new Variance();
        double[] weights = {1.0, 1.0};
        try {
            variance.evaluate((double[]) null, weights);
            fail("Expected NullArgumentException");
        } catch (NullArgumentException e) {
            // Expected
        }
    }

    @Test
    public void testEvaluateWithWeightsNullWeights() throws Exception {
        Variance variance = new Variance();
        double[] values = {1.0, 2.0};
        try {
            variance.evaluate(values, (double[]) null);
            fail("Expected NullArgumentException");
        } catch (NullArgumentException e) {
            // Expected
        }
    }

    @Test
    public void testEvaluateWithWeightsLengthMismatch() throws Exception {
        Variance variance = new Variance();
        double[] values = {1.0, 2.0, 3.0};
        double[] weights = {1.0, 1.0};
        try {
            variance.evaluate(values, weights);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            // Expected
        }
    }

    @Test
    public void testEvaluateWithWeightsMultipleValuesUnbiased() throws Exception {
        Variance variance = new Variance();
        variance.setBiasCorrected(true);
        double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
        double[] weights = {1.0, 1.0, 1.0, 1.0, 1.0}; // Equal weights, same as unweighted
        // Mean = 3, Sum of squared deviations = 10, n = 5
        // Variance = 10 / (5 - 1) = 2.5
        assertEquals(2.5, variance.evaluate(values, weights), 1e-9);
        assertEquals(0, variance.getN());
    }

    @Test
    public void testEvaluateWithWeightsMultipleValuesWeighted() throws Exception {
        Variance variance = new Variance();
        variance.setBiasCorrected(true);
        double[] values = {1.0, 2.0, 3.0};
        double[] weights = {1.0, 2.0, 3.0}; // Weights are 1, 2, 3
        // Weighted Mean = (1*1 + 2*2 + 3*3) / (1+2+3) = (1 + 4 + 9) / 6 = 14 / 6 = 7/3
        // Deviations from mean (7/3):
        // 1 - 7/3 = -4/3
        // 2 - 7/3 = -1/3
        // 3 - 7/3 = 2/3
        // Squared deviations: 16/9, 1/9, 4/9
        // Weighted sum of squared deviations = 1*(16/9) + 2*(1/9) + 3*(4/9) = (16 + 2 + 12) / 9 = 30/9 = 10/3
        // Sum of weights = 1 + 2 + 3 = 6
        // Variance (unbiased) = (10/3) / (6 - 1) = (10/3) / 5 = 10/15 = 2/3
        assertEquals(2.0 / 3.0, variance.evaluate(values, weights), 1e-9);
        assertEquals(0, variance.getN());
    }

    @Test
    public void testEvaluateWithWeightsAndOffsetLength() throws Exception {
        Variance variance = new Variance();
        variance.setBiasCorrected(true);
        double[] values = {0.0, 1.0, 2.0, 3.0, 4.0, 5.0};
        double[] weights = {1.0, 1.0, 1.0, 1.0, 1.0, 1.0};
        // Evaluating values[1..4] with weights[1..4] which are {1.0, 2.0, 3.0, 4.0} with weights {1.0, 1.0, 1.0, 1.0}
        // This is the same as testEvaluateWithArrayAndOffsetLength
        assertEquals(5.0 / 3.0, variance.evaluate(values, weights, 1, 4), 1e-9);
        assertEquals(0, variance.getN());
    }

    @Test
    public void testEvaluateWithWeightsAndOffsetLengthWeighted() throws Exception {
        Variance variance = new Variance();
        variance.setBiasCorrected(true);
        double[] values = {0.0, 1.0, 2.0, 3.0, 4.0, 5.0};
        double[] weights = {1.0, 2.0, 1.0, 2.0, 1.0, 2.0};
        // Evaluating values[1..4] with weights[1..4] which are {1.0, 2.0, 3.0, 4.0} with weights {2.0, 1.0, 2.0, 1.0}
        // Weighted Mean = (1*2 + 2*1 + 3*2 + 4*1) / (2+1+2+1) = (2 + 2 + 6 + 4) / 6 = 14 / 6 = 7/3
        // Deviations from mean (7/3):
        // 1 - 7/3 = -4/3
        // 2 - 7/3 = -1/3
        // 3 - 7/3 = 2/3
        // 4 - 7/3 = 5/3
        // Squared deviations: 16/9, 1/9, 4/9, 25/9
        // Weighted sum of squared deviations = 2*(16/9) + 1*(1/9) + 2*(4/9) + 1*(25/9) = (32 + 1 + 8 + 25) / 9 = 66/9 = 22/3
        // Sum of weights = 2+1+2+1 = 6
        // Variance (unbiased) = (22/3) / (6 - 1) = (22/3) / 5 = 22/15
        assertEquals(22.0 / 15.0, variance.evaluate(values, weights, 1, 4), 1e-9);
        assertEquals(0, variance.getN());
    }

    @Test
    public void testEvaluateWithMeanSingleValue() throws Exception {
        Variance variance = new Variance();
        double[] values = {5.0};
        double mean = 5.0;
        assertEquals(0.0, variance.evaluate(values, mean), 1e-9);
        assertEquals(0, variance.getN());
    }

    @Test
    public void testEvaluateWithMeanMultipleValuesUnbiased() throws Exception {
        Variance variance = new Variance();
        variance.setBiasCorrected(true);
        double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
        double mean = 3.0;
        // Sum of squared deviations = 10, n = 5
        // Variance = 10 / (5 - 1) = 2.5
        assertEquals(2.5, variance.evaluate(values, mean), 1e-9);
        assertEquals(0, variance.getN());
    }

    @Test
    public void testEvaluateWithMeanMultipleValuesBiased() throws Exception {
        Variance variance = new Variance(false); // biased
        double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
        double mean = 3.0;
        // Sum of squared deviations = 10, n = 5
        // Variance = 10 / 5 = 2.0
        assertEquals(2.0, variance.evaluate(values, mean), 1e-9);
        assertEquals(0, variance.getN());
    }

    @Test
    public void testEvaluateWithMeanAndOffsetLength() throws Exception {
        Variance variance = new Variance();
        variance.setBiasCorrected(true);
        double[] values = {0.0, 1.0, 2.0, 3.0, 4.0, 5.0};
        // Evaluating values[1..4] which are {1.0, 2.0, 3.0, 4.0}
        double mean = 2.5;
        // Sum of squared deviations = 5.0, n = 4
        // Variance = 5.0 / (4 - 1) = 5.0 / 3.0
        assertEquals(5.0 / 3.0, variance.evaluate(values, mean, 1, 4), 1e-9);
        assertEquals(0, variance.getN());
    }

    @Test
    public void testEvaluateWithWeightedMeanAndOffsetLength() throws Exception {
        Variance variance = new Variance();
        variance.setBiasCorrected(true);
        double[] values = {0.0, 1.0, 2.0, 3.0, 4.0, 5.0};
        double[] weights = {1.0, 2.0, 1.0, 2.0, 1.0, 2.0};
        // Evaluating values[1..4] with weights[1..4] which are {1.0, 2.0, 3.0, 4.0} with weights {2.0, 1.0, 2.0, 1.0}
        double mean = 7.0 / 3.0;
        // Weighted sum of squared deviations = 22/3, Sum of weights = 6
        // Variance = (22/3) / (6 - 1) = 22/15
        assertEquals(22.0 / 15.0, variance.evaluate(values, weights, mean, 1, 4), 1e-9);
        assertEquals(0, variance.getN());
    }

    @Test
    public void testSetBiasCorrected() throws Exception {
        Variance variance = new Variance();
        assertTrue(variance.isBiasCorrected());
        variance.setBiasCorrected(false);
        assertFalse(variance.isBiasCorrected());
        variance.setBiasCorrected(true);
        assertTrue(variance.isBiasCorrected());
    }

    @Test
    public void testIsBiasCorrected() throws Exception {
        Variance varianceTrue = new Variance(true);
        assertTrue(varianceTrue.isBiasCorrected());

        Variance varianceFalse = new Variance(false);
        assertFalse(varianceFalse.isBiasCorrected());
    }

    @Test
    public void testEdgeCaseDoubleMaxValues() throws Exception {
        Variance variance = new Variance();
        variance.increment(Double.MAX_VALUE);
        variance.increment(Double.MAX_VALUE);
        assertEquals(2, variance.getN());
        assertEquals(0.0, variance.getResult(), 1e-9); // Variance of two identical numbers is 0
    }

    @Test
    public void testEdgeCaseDoubleMinValue() throws Exception {
        Variance variance = new Variance();
        variance.increment(Double.MIN_VALUE);
        variance.increment(Double.MIN_VALUE);
        assertEquals(2, variance.getN());
        assertEquals(0.0, variance.getResult(), 1e-9); // Variance of two identical numbers is 0
    }

    @Test
    public void testEdgeCaseVerySmallDifference() throws Exception {
        Variance variance = new Variance();
        double val1 = 1.0;
        double val2 = 1.0 + 1e-15;
        variance.increment(val1);
        variance.increment(val2);
        assertEquals(2, variance.getN());
        // Mean = 1.0 + 0.5e-15
        // Deviations: -0.5e-15, +0.5e-15
        // Squared deviations: 0.25e-30, 0.25e-30. Sum = 0.5e-30
        // Variance (unbiased) = 0.5e-30 / (2 - 1) = 0.5e-30
        assertEquals(0.5e-30, variance.getResult(), 1e-30);
    }

    @Test
    public void testEvaluateWithWeightsNullWeightsForZeroLength() throws Exception {
        Variance variance = new Variance();
        double[] values = {};
        double[] weights = {}; // Null weights for empty array is valid per evaluate(values, weights, begin, length)
        assertEquals(Double.NaN, variance.evaluate(values, weights), 1e-9);
    }

    @Test
    public void testEvaluateWithWeightsNonZeroSumForBiased() throws Exception {
        Variance variance = new Variance(false); // biased
        double[] values = {1.0, 2.0, 3.0};
        double[] weights = {1.0, 2.0, 3.0};
        // Weighted Mean = 7/3
        // Sum of squared deviations = 10/3
        // Sum of weights = 6
        // Variance (biased) = (10/3) / 6 = 10/18 = 5/9
        assertEquals(5.0 / 9.0, variance.evaluate(values, weights), 1e-9);
    }
}
